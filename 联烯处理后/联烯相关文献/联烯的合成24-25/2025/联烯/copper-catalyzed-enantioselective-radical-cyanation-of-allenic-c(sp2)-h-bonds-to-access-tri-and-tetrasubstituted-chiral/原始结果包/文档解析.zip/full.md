pubs.acs.org/acscatalysis

Research Article

# Copper-Catalyzed Enantioselective Radical Cyanation of Allenic C(sp<sup>2</sup>)−H Bonds to Access Tri- and Tetrasubstituted Chiral Allenes

Daqi Lv, Xiaotao Zhu,\* and Hongli Bao\*

![](images/875bd624e36b4b36e395da820445cacc272fcc99294e582146fe223e06282378.jpg)

ABSTRACT: The asymmetric radical functionalization of allenic C(sp<sup>2</sup>)−H bonds represents an appealing strategy for synthesizing axially chiral allenes. This method enables us to generate the more structurally complex and highly functionalized axially chiral allenes directly by using the readily accessible and less substituted racemic allenes while concurrently achieving apparent dynamic kinetic resolution. However, compared to alkyne derivative-based approaches, the asymmetric functionalization of allenic C(sp<sup>2</sup>)−H bonds remains a challenge primarily due to the intertwined demands of chemo-, regio-, and enantioselectivity. Here, we report a copper-catalyzed asymmetric cyanation of allenic $\mathrm { C } ( \mathsf { s p } ^ { 2 } ) \mathrm { - H }$ bonds by using a substituted oxazoline chiral ligand. This strategy eficiently transforms low-substituted racemic allenes into highly functionalized, axially chiral allenyl nitriles in a highly chemo-, regio-, and enantioselective manner.

KEYWORDS: enantioselective cyanation, C−H functionalization, radical, chiral allene, copper catalysis

## ■ INTRODUCTION

Axially chiral allenes are a class of significant organic molecules, characterized by their distinctive orthogonal twisted π- systems.<sup>1</sup> Functionalized allenes often exhibit notable physiological activities, such as enzyme inhibition, cytotoxicity, and antibacterial properties (Scheme 1a).<sup>2</sup> As a result, structural modifications of allene compounds or their incorporation into pharmaceutical molecules to enhance biological activity represent a key direction for future development in this field.<sup>3</sup>

Over the past decade, significant progress has been made in 4 the development of radical synthesis methods for allenes. Among these advancements, the asymmetric transformation of allenyl radicals has emerged as a powerful strategy for constructing axially chiral allenes (Scheme 1b, left). Our group previously reported the first copper-catalyzed radical 1,4- bifunctionalization of 1,3-enynes, achieving asymmetric 1,4- oxycyanation and ofering a novel method for synthesizing elusive axially chiral allenes.<sup>5</sup> Subsequently, Deng et al. demonstrated a stereoselective decarboxylation strategy for 1,3-enynes using a photoinduced dual catalytic system.<sup>6</sup> Meanwhile, Liu<sup>7</sup> and Guo<sup>8</sup> independently achieved coppercatalyzed asymmetric 1,4-alkylalkynylation and arylalkynylation via allenyl radical-terminal alkyne coupling. Notably, He et al. introduced a nickel-catalyzed radical cascade reaction for enantio- and regioselective 1,4-arylalkylation of 1,3-enynes.<sup>9</sup> These enantioselective radical 1,4-difunctionalization protocols collectively provide eficient access to structurally diverse, enantioenriched tetrasubstituted allenes. Expanding the scope further, Liu et al. reported copper-catalyzed enantioselective radical cyanation of propargylic $\mathrm { C } ( \mathsf { s p } ^ { 3 } ) \mathrm { - H }$ bonds, delivering chiral trisubstituted allenyl nitriles.<sup>10</sup> These outstanding works demonstrate that constructing axially chiral allenes from alkyne derivatives, such as 1,3-enynes or alkynes, has become a reliable and promising strategy.

From another perspective, the asymmetric radical functionalization of allenic C(sp<sup>2</sup>)−H bonds also represents an attractive strategy for synthesizing axially chiral allenes (Scheme 1b, right). This approach enables the functionalization of readily available low-substituted racemic allenes while simultaneously achieving apparent dynamic kinetic resolution. As a result, this provides access to structurally complex and

![](images/9fdc92b15d8c079b2310fe6e8902e42c83e6082eea7a79b5c9d40eb50574c6ff.jpg)

## Scheme 1. Enantiocontrol of Allenyl Radicals to Access Chiral Allenes

(a) Allenic Natural Products and Pharmaceuticals  
![](images/e256fe1ca0f8258260f8fc245c9ba4f5c50b9879017d88a1c0874ecd2629fe43.jpg)  
tivity but also highlights the potential of C−H functionalization strategies for the synthesis of complex organic molecules.

highly functionalized axially chiral allenes. However, this strategy faces significant challenges, particularly in achieving satisfactory stereoselective control and the addressing issues of chemical and regioselectivity during the activation of allenic $\mathrm { C } \left( \mathrm { s p } ^ { 2 } \right)$ −H bonds and the transformation of allenyl radicals. In 2016, Lee and colleagues demonstrated the use of peroxyl radicals to abstract hydrogen atoms from allenic C−H bonds, thereby generating allenyl radical intermediates.<sup>11</sup> More recently, $\overline { { \mathrm { L i u } } } ^ { 1 2 }$ and $\mathrm { \Delta W u } ^ { 1 3 }$ almost simultaneously introduced a groundbreaking strategy for the functionalization of allenes via radical activation of allylic $\mathrm { C } ( \mathsf { s p } ^ { 2 } ) \mathrm { - H }$ bonds. These elegant studies achieved high chemoselectivity and regioselectivity, paving the way for the synthesis of complex and functionalized allenyl derivatives from simple precursors. Despite these advances, the asymmetric radical functionalization of allenic $\mathrm { C } \left( \mathrm { s p } ^ { 2 } \right)$ −H bonds remains a significant challenge due to the intertwined demands of chemo- $[ \mathrm { C } ( \mathrm { s p } ^ { 2 } ) \mathrm { - H }$ vs $\mathrm { C } ( \mathsf { s p } ^ { 3 } ) \mathrm { - H }$ activation vs radical addition], regio- (allenyl vs propargyl radical pathways), and enantioselectivity (the linear geometry of allenyl radicals).<sup>12a,13a</sup>

In this context, we have conducted extensive studies to address these challenges, and herein, we report an asymmetric cyanation reaction of $\mathrm { C } \bigl ( \mathsf { s p } ^ { 2 } \bigr )$ −H bonds catalyzed by a copper complex with a substituted oxazoline (Scheme 1c). This approach enables the eficient transformation of lowsubstituted racemic allenes into highly functionalized, axially chiral allenyl nitriles under mild conditions. This work not only addresses the challenges of chemo-, regio-, and enantioselec-

## ■ METHODS

Reaction Optimization. To initiate these studies, (1- methyl-1,2-butadienyl)benzene (1a) was reacted as the model substrate, with N-fluorobenzenesulfonimide (NFSI) as the HAT reagent and trimethylsilyl cyanide (2) as the coupling partner in the presence of a catalytic amount of Cu-$\mathrm { \bar { ( C H _ { 3 } C N ) _ { 4 } P F _ { 6 } } }$ (5 mol %) in acetone at room temperature for 24 h. To our delight, the desired product 3a was obtained in 25% yield and 64:36 er when bis(oxazoline) L1 (7.5 mol %) was used as the ligand (Table 1, entry 1). We then screened a series of bis(oxazoline) ligands (L2−L7) with diferent substituents on R, finding that L7 gave the best result (25% yield, 91:9 er) (entry 7). A $\mathrm {  ~ \Omega ~ } _ { \mathrm { i t } } \mathrm {  ~ 0 ~ } ^ { \circ } { \bf C } ,$ both the yield and er were improved compared to room temperature (entry 8). Given the propensity of the reaction substrates to polymerize, a number of inhibitors were tested as additives.<sup>14</sup> It was found that the addition of 1 mol % of 4-(trans-4-butylcyclohexyl)phenol (A4) significantly increased the reaction yield without compromising the high enantioselectivity. Finally, examination of diferent copper salts showed that CuBr was the best choice, yielding 58% yield, 93:7 er (for details of optimization of the conditions, see Supporting Information). Therefore, the optimal conditions were established as $\mathrm { C u B r } _ { 2 } / \mathbf { L } 7$ (1:1.5), NFSI (1.5 equiv), TMSCN (3 equiv), A4 (1 mol %), $0 \ ^ { \circ } \mathrm { C } ,$ 48 h.

Table 1. Optimization of the Reaction Conditions<sup>a,b,c</sup>  
![](images/3268db7ba36b4f33da2d16969ac8dc4de3c597ef3fcda51b4fe7caed0c4ebe6e.jpg)

<table><tr><td>entry</td><td>ligand</td><td>additive</td><td>yield (%)</td><td>Er</td></tr><tr><td>1</td><td>L1</td><td></td><td>25</td><td>64:36</td></tr><tr><td>2</td><td>L2</td><td></td><td>22</td><td>80:20</td></tr><tr><td>3</td><td>L3</td><td></td><td>21</td><td>81:19</td></tr><tr><td>4</td><td>L4</td><td></td><td>26</td><td>80:20</td></tr><tr><td>5</td><td>L5</td><td></td><td>24</td><td>75:25</td></tr><tr><td>6</td><td>L6</td><td></td><td>21</td><td>80:20</td></tr><tr><td>7</td><td>L7</td><td></td><td>25</td><td>91:9</td></tr><tr><td> $8 ^ { d }$ </td><td>L7</td><td></td><td>35</td><td>93:7</td></tr><tr><td> $9 ^ { d }$ </td><td>L7</td><td>A1</td><td>21</td><td>90:10</td></tr><tr><td> $1 0 ^ { d }$ </td><td>L7</td><td>A2</td><td>26</td><td>87:13</td></tr><tr><td> $1 1 ^ { d }$ </td><td>L7</td><td>A3</td><td>50</td><td>92:8</td></tr><tr><td> $1 2 ^ { d }$ </td><td>L7</td><td>A4</td><td>50</td><td>93:7</td></tr><tr><td> $1 3 ^ { d , e }$ </td><td>L7</td><td>A4</td><td>58</td><td>93:7</td></tr></table>

<sup>a</sup>Reaction conditions: Cu catalyst (5 mol %), ligand (7.5 mol %), 1a (0.1 mmol), NFSI (0.15 mmol), TMSCN (0.3 mmol), in acetone under $\Nu _ { 2 }$ at rt for 24 h. <sup>b</sup>Isolated yield. <sup>c</sup>Er values determined by HPLC on a chiral stationary phase. ${ } ^ { d } 0 ~ ^ { \circ } \mathrm { C }$ for 48 h. ${ } ^ { e } \mathrm { C u B r } _ { 2 }$ as the catalyst.

Substrate Scope. Having established the optimized reaction conditions, we tested a variety of substituted allenes to probe the versatility of our catalytic system (Scheme 2). A variety of enantioenriched tetrasubstituted allenyl nitriles $\left( 3 \mathbf { a } - \mathbf { \right. }$ 3y) were obtained in moderate to good yields $( 4 3 - 6 2 \% )$ and with high enantiomeric ratios $\left( 8 2 { : } 1 8 { - } 9 7 { : } 3 \mathrm { e r } \right)$ Allene substrates with electron-donating or electron-withdrawing groups introduced at various positions on the aromatic ring can provide the corresponding products $\left( 3 \mathbf { a } - 3 \mathbf { h } \right)$ with an er value as high as 97:3. Moreover, other aromatic rings such as the naphthyl group (3i and 3j) and thienyl group (3k) are tolerated. A screening of the $\mathrm { \ddot { R } ^ { 1 } }$ and $\mathrm { R } ^ { 2 }$ revealed that alkyl chains (3l−3q), phosphonate group (3r), silyl ether group (3s), chloroalkyl group (3t), benzyl group (3u), and vinyl groups (3v and 3w) are tolerated. Notably, a diverse array of substrates, encompassing those with benzyl C−H bonds (3u) as well as allyl C−H bonds (3v and 3w), have been selectively transformed through the cyanation of the allenic $ \mathrm { C } ( \mathsf { s p } ^ { 2 } ) \mathrm { - } \dot { \mathrm { H } }$ bond, afording the target products without the observation of $\mathrm { C } ( \mathsf { s p } ^ { 3 } ) \mathrm { - H }$ bond cyanation. The absolute configuration of axially chiral allenyl nitriles 3c was unambiguously confirmed by X-ray analysis. Both $3 { \bf x } ^ { 1 2 \mathrm { a } }$ and $3 \mathbf { y } ^ { \mathrm { { 1 3 a } } }$ can also be obtained in good yields as well as with higher enantioselectivities by our method. To showcase the practical application of our method, the allenic $\mathbf { C } ( \mathbf { s p } ^ { 2 } ) \mathbf { - H }$ cyanation reaction was scaled up to a 10 mmol batch. This amplification synthesis exhibits even higher enantioselectivity compared to standard conditions (3a, 96:4 er and 3y, 93:7 er), highlighting the enormous synthetic potential of our method.

The versatility of this strategy extends to the synthesis of trisubstituted allenyl nitriles. Under the standard reaction conditions, a spectrum of enantioenriched trisubstituted allenyl nitriles (5a−5j) was successfully synthesized. The process demonstrates the well tolerance for diverse functional groups, including phenyl (5a−5c), naphthyl (5d), benzothiophene (5e), and secondary and tertiary alkyl groups (5f and 5g). Products 5h−5j can also be obtained in good yields as well as with higher enantioselectivities by our method.<sup>12a,13a</sup> Moreover, scaling up the reaction has led to a further enhancement in enantioselectivity, as evidenced by product 5c, which achieved an enantiomeric ratio of 96:4.

Further Transformations. Such obtained enantioenriched allenyl nitriles potentially have wide applications in organic synthesis (Scheme 3). For example, the reduction of allenyl nitrile 3a with 1.1 equiv of DIBAL-H eficiently yields allenyl aldehyde ${ \mathbf 6 , } ^ { 1 5 }$ which can be further reduced to produce allenyl propanol 7. Additionally, chiral allenyl nitrile 3a can be readily transformed into allenyl amide 8 in a high yield through hydrolysis. In the presence of potassium hydroxide, compound 3a can be fully hydrolyzed to generate the corresponding acid ${ \mathbf { 9 . } } ^ { 1 ; }$ 5

The construction of chiral quaternary carbon centers remains a major challenge in synthetic chemistry, and the development of methods to form such chiral centers is an important goal. In this context, the transfer of axial chirality to

Scheme 2. Scope of Chiral Allenyl Nitriles<sup>a</sup>

![](images/5881cc671716680ae7fead7174525c43ecabef8434d9f3b6a987b806b877a6ca.jpg)  
<sup>a</sup>Reactions were conducted on a 0.2 mmol scale with the reaction condition of entry 13 in Table 1. <sup>b</sup>10 mmol scale.

central chirality was explored. For instance, treatment of 7 with NBS leads to the formation of enantioenriched cyclic ether 10 with a chiral quaternary carbon center.<sup>8</sup> Furthermore, chiral allenyl amide 8 reacts smoothly with $\mathrm { C u B r } _ { 2 }$ to produce the highly functionalized lactam $1 1 . ^ { \dot { 1 } 6 }$ Cyclization of allenyl acid 9 efectively generates chiral butenolides 12 and 13, which are crucial structural motifs for numerous biologically active compounds.<sup>17</sup> Notably, the enantioselectivity was retained in all of these reactions.

Mechanistic Investigations. To elucidate the reaction mechanism, we conducted a series of experiments (Scheme $_ { 4 \mathsf { a } - \mathsf { f } ) }$ . Initial radical scavenger studies using 2,2,6,6-tetramethylpiperidine-1-oxyl or butylated hydroxytoluene under standard conditions completely suppressed product formation, confirming a radical-mediated pathway (Scheme 4a). A radicalclock experiment with an alkenyl cyclopropane substrate generated the ring-opening product (15), directly evidencing the allenyl radical intermediate (Scheme 4b). Kinetic isotope efect studies $\left( k _ { \mathrm { H } } / k _ { \mathrm { D } } \ = \ 2 . 3 \right)$ suggest that intermolecular hydrogen atom abstraction might be the rate-limiting step (Scheme 4c).

Scheme 3. Further Transformations of Products  
![](images/16a35ee93d974646f1dc2ed3c16793967dc7c0e296c5196cb22bbc36cb9b1171.jpg)

We then proceeded to investigate the nonlinear efects in this method and found that allenyl nitrile 3a indeed exhibited linear efects (Scheme 4d).<sup>18</sup> This led us to consider that a monoligand copper complex acts as the active catalytic species in the reaction.<sup>19</sup> To delve deeper into the structure of the metal complex, we conducted control experiments under standard conditions using ligand L8, with its hydroxyl group protected by trimethylsilyl; these results closely mirrored those obtained under standard conditions (Scheme 4e, 58% yield, 93:7 er vs 50% yield, 93:7 er). This finding implies that the hydroxyl group as an electron-donating group may be a spectator and the hydrogen bonding may not play a role in the metal complex. Furthermore, the structure of L7CuBr (16) was elucidated through X-ray crystallography, revealing the complex composed of a single copper atom and a single ligand (Scheme 4f). Upon subjecting this crystal to a cyanation reaction as the catalyst, we observed that the reaction eficiencies and enantioselectivities were nearly identical to those under standard conditions (47% yield, 92:8 er), thereby validating the existence of a monoligand copper active species. This is also consistent with the conclusions drawn from the linear efect observed earlier.

Drawing from these experimental outcomes, we propose a potential catalytic cycle mechanism (Scheme 5). Initially, a monovalent monoligand copper species A undergoes singleelectron transfer with NFSI, leading to the formation of a divalent fluorinated copper species B and a nitrogen radical. This nitrogen radical can abstract the $\mathbf { C } ( \mathbf { s p } ^ { 2 } ) \mathrm { - H }$ bond from the allene, forming an allenyl radical.<sup>12a,13a</sup> The divalent fluorinated copper species B then undergoes transmetalation with TMSCN, yielding cyanated copper intermediate C. Ultimately, intermediate C engages in an asymmetric functional group transfer with the allenyl radical, yielding the target product and regenerating the catalyst.

## ■ CONCLUSIONS

In conclusion, we have developed a copper-catalyzed enantioselective radical cyanation of allenic $\mathrm { C } ( \mathsf { s p } ^ { 2 } ) \mathrm { - H }$ bonds under mild reaction conditions, enabling eficient access to trisubstituted and tetrasubstituted axially chiral allenyl nitriles. This strategy achieves high chemoselectivity, regioselectivity, and enantioselectivity, with broad functional group tolerance. Mechanistic studies corroborate a radical pathway involving a monoligand copper species. The synthetic utility of this method is further highlighted by its scalability (10 mmol scale) and the versatile downstream derivatization with a chiral quaternary carbon center of chiral allenyl nitriles into cyclic ether, lactam, and butenolides. We believe that this work may open up new possibilities of allenic C(sp<sup>2</sup>)−H asymmetric functionalization, ofering a promising entry to highly functionalized axially chiral allene derivatives.

## ■ MATERIALS AND METHODS

All information pertaining to the materials and methods used in this study is provided in the Supporting Information.

## Scheme 4. Mechanistic Investigations

(a) Radical trapping experiments

![](images/d0fad9d7dce354793dfad7a100cfdf271ddfee16a28527db858af6708febfb58.jpg)

![](images/d0625f9c4ec1d60123c9eee8624d5ff5f61c29c449e6e69b34f2fc0790ae224d.jpg)

![](images/aa9d1753f2f927d6ec46fd172fe8fb12cb89ecfe3588c3bf6b94f49f27ce502b.jpg)

![](images/99309237f6d7e75d78992f638986fbbf1c8970878fae96ab91e9c4485196e779.jpg)

(e) Control experiments

![](images/515afdb9f0ff79a9ca875b8d48efdf16e078aab598d585ea13305c813544a69c.jpg)  
Standard conditions with L7: 58% yield, 93:7 er

![](images/f88a3e594a650a8a733736a56af4f8978bb83aa4bef3c55d19e791898498301a.jpg)

(f) Single crystal of L7CuBr2

![](images/db4daf0bf60af0b648984a8dd4f2109aa1f91f4506fa80cb3df5143fd7652353.jpg)

![](images/bd8320c5b067883351da1a5198a1c23b6192d435fec93cf2b69563f324f3d61b.jpg)

## Scheme 5. Proposed Reaction Mechanism

![](images/334c23e4e85d8fde4ce1965de5df53f5013dc63b3052f54b2d983dd23ce79f2e.jpg)

## ■ ASSOCIATED CONTENT

## \*sı Supporting Information

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acscatal.5c01796.

Experimental procedures; properties of some compounds; copies of <sup>1</sup>H and $^ { 1 3 } \mathrm { C }$ spectra of the products; and cif files for solid-state structures (PDF)

## ■ AUTHOR INFORMATION

## Corresponding Authors

Xiaotao Zhu − State Key Laboratory of Structural Chemistry, Fujian Institute of Research on the Structure of Matter, Chinese Academy of Sciences, Fuzhou, Fujian 350002, P. R. China; Email: zhuxt@fjirsm.ac.cn

Hongli Bao − State Key Laboratory of Structural Chemistry, Fujian Institute of Research on the Structure of Matter,

Chinese Academy of Sciences, Fuzhou, Fujian 350002, P. R. China; University of Chinese Academy of Sciences, Beijing 100049, P. R. China; Fujian College, University of Chinese Academy of Sciences, Fuzhou, Fujian 350002, P. R. China; orcid.org/0000-0003-1030-5089; Email: hlbao@ fjirsm.ac.cn

## Author

Daqi Lv − State Key Laboratory of Structural Chemistry, Fujian Institute of Research on the Structure of Matter, Chinese Academy of Sciences, Fuzhou, Fujian 350002, P. R. China; University of Chinese Academy of Sciences, Beijing 100049, P. R. China; Fujian College, University of Chinese Academy of Sciences, Fuzhou, Fujian 350002, P. R. China

Complete contact information is available at: https://pubs.acs.org/10.1021/acscatal.5c01796

## Notes

The authors declare no competing financial interest.

## ■ ACKNOWLEDGMENTS

This work was supported by the National Natural Science Foundation of China (22225107) and the Self-deployment Project Research Program of Haixi Institutes, Chinese Academy of Sciences (CXZX-2022-GH03). Thanks to Professor Yuan Daqiang in the single crystal data analysis.

## ■ REFERENCES

(1) Krause, N. H. A. S. K. Modern Allene Chemistry; Wiley-VCH: Weinheim, Germany, 2004.

(2) (a) Ma, S. Some Typical Advances in the Synthetic Applications of Allenes. Chem. Rev. 2005, 105, 2829−2872. (b) Phadtare, S.; Zemlicka, J. Nucleic Acid Derived Allenols. Unusual Analogs of Nucleosides with Antiretroviral Activity. J. Am. Chem. Soc. 1989, 111, 5925−5931. (c) Jones, B. C.; Silverton, J. V.; Simons, C.; Megati, S.; Nishimura, H.; Maeda, Y.; Mitsuya, H.; Zemlicka, J. Synthesis Absolute Configuration, and Enantioselectivity of Antiretroviral Effect of (R)-(−)- and (S)-(+)-Cytallene. Lipase-Catalyzed Enantioselective Acylations of (±)-N4-Acylcytallenes. J. Med. Chem. 1995, 38, 1397− 1405. (d) Qiu, Y. L.; Ksebati, M. B.; Ptak, R. G.; Fan, B. Y.; Breitenbach, J. M.; Lin, J. S.; Cheng, Y. C.; Kern, E. R.; Drach, J. C.; Zemlicka, J. (Z)- and (E)-2-((hydroxymethyl)cyclopropylidene)- methyladenine and -Guanine. New Nucleoside Analogues with a Broad-Spectrum Antiviral Activity. J. Med. Chem. 1998, 41, 10−23. (e) Hayashi, S.; Phadtare, S.; Zemlicka, J.; Matsukura, M.; Mitsuya, H.; Broder, S. Adenallene and Cytallene: Acyclic-Nucleoside Analogues that Inhibit Replication and Cytopathic Effect of Human Immunodeficiency Virus in vitro. Proc. Natl. Acad. Sci. U.S.A. 1988, 85, 6127−6131.

(3) (a) Hoffmann-Roder, A.; Krause, N. Synthesis and Properties of Allenic Natural Products and Pharmaceuticals. Angew. Chem., Int. Ed. 2004, 43, 1196−1216. (b) Yu, S.; Ma, S. Allenes in Catalytic Asymmetric Synthesis and Natural Product Syntheses. Angew. Chem., Int. Ed. 2012, 51, 3074−3112. (c) Collins, P. W.; Djuric, S. W. Synthesis of Therapeutically Useful Prostaglandin and Prostacyclin Analogs. Chem. Rev. 1993, 93, 1533−1564. (d) Margolin, A. L. Synthesis of Optically Pure Mechanism-Based Inhibitors of γ- Aminobutyric Acid Aminotransferase (GABA-T) via Enzyme-Catalyzed Resolution. Tetrahedron Lett. 1993, 34, 1239−1242.

(4) (a) Chen, L.; Lin, C.; Zhang, S.; Zhang, X.; Zhang, J.; Xing, L.; Guo, Y.; Feng, J.; Gao, J.; Du, D. 1,4-Alkylcarbonylation of 1,3-Enynes to Access Tetra-Substituted Allenyl Ketones via an NHC-Catalyzed Radical Relay. ACS Catal. 2021, 11, 13363−13373. (b) Song, Y.; Fu, C.; Ma, S. Copper-Catalyzed Syntheses of Multiple Functionalizatized Allenes via Three-Component Reaction of Enynes. ACS Catal. 2021, 11, 10007−10013. (c) Lv, Y.; Xie, J.; Pu, W.; Wang, X.; Zhang, H.; Li,

M.; Mao, X.; Zhou, Q. Q.; Ding, W. Visible-Light-Induced Regioselective Radical-Polar Crossover 1,4-Hydrophosphinylation of 1,3-Enynes: Access to Trisubstituted Allenes Bearing a Phosphine Oxide Group. Org. Lett. 2024, 26, 4678−4683.

(5) Zeng, Y.; Chiou, M. F.; Zhu, X.; Cao, J.; Lv, D.; Jian, W.; Li, Y.; Zhang, X.; Bao, H. Copper-Catalyzed Enantioselective Radical 1,4- Difunctionalization of 1,3-Enynes. J. Am. Chem. Soc. 2020, 142, 18014−18021.

(6) Peng, K.; Cao, Y.-S.; Wang, Q.; Xia, Z.; Chen, Y.; Lu, Y.; Deng, G.-J. Metallaphotoredox Synthesis of Axially Chiral Tetrasubstituted Allenes through Regio- and Enantioselective 1,4-Carbocyanation of 1,3-Enynes. ACS Catal. 2024, 14, 14048−14057.

(7) Dong, X. Y.; Zhan, T. Y.; Jiang, S. P.; Liu, X. D.; Ye, L.; Li, Z. L.; Gu, Q. S.; Liu, X. Y. Copper-Catalyzed Asymmetric Coupling of Allenyl Radicals with Terminal Alkynes to Access Tetrasubstituted Allenes. Angew. Chem., Int. Ed. 2021, 60, 2160−2164.

(8) Huang, H.; Zhang, H.; Wang, Q.; Sun, Y.; Su, L.; Xu, W.; Ma, Y.; Kong, S.; Zhang, G.; Guo, R. Copper-Catalyzed Asymmetric 1,4-Aryl/ Alkynylation of 1,3-Enynes to Access Axially Chiral Tetrasubstituted Allenes. ChemCatChem 2023, 15, No. e202300697.

(9) Du, J.; Liu, A.; Zhang, W.; Luo, S.; Yao, H.; He, Y. Enantio- and Regioselective Ni-Catalyzed Radical Relay 1,4-Arylalkylation of 1,3- Enynes to Access Chiral Tetrasubstituted Allenes. ACS Catal. 2024, 14, 13940−13946.

(10) Lu, R.; Yang, T.; Chen, X.; Fan, W.; Chen, P.; Lin, Z.; Liu, G. Enantioselective Copper-Catalyzed Radical Cyanation of Propargylic C-H Bonds: Easy Access to Chiral Allenyl Nitriles. J. Am. Chem. Soc. 2021, 143, 14451−14457.

(11) Sabbasani, V. R.; Lee, H.; Xia, Y.; Lee, D. Complementary Iron(II)-Catalyzed Oxidative Transformations of Allenes with Differ ent Oxidants. Angew. Chem., Int. Ed. 2016, 55, 1151−1155.

(12) (a) Cheng, Z.; Yang, T.; Li, C.; Deng, Y.; Zhang, F.; Chen, P.; Lin, Z.; Ma, S.; Liu, G. Site-Selective sp(2) C-H Cyanation of Allenes via Copper-Catalyzed Radical Relay. J. Am. Chem. Soc. 2023, 145, 25995−26002. (b) Cheng, Z.; Zhang, J.; Li, C.; Li, X.; Chen, P.; Liu, G. Copper-Catalyzed sp(2) C-H Arylation and Alkynylation of Allenes via Hydrogen Atom Abstraction. J. Am. Chem. Soc. 2024, 146, 24689−24698.

(13) (a) Wei, Y.; Wang, Z.; Wang, K.; Qiu, J. K.; Wang, Z.; Li, H.; Duan, X.; Guo, K.; Bao, X.; Wu, X. Copper-Catalyzed Radical Allene C(sp(2))-H Cyanation. Angew. Chem., Int. Ed. 2024, 63, No. e202317132. (b) Duan, X.; Jin, Q.; Wang, K.; Sun, Y.; Wei, Y.; Wang, Z.; Qiu, J.-K.; Guo, K.; Bao, X.; Wu, X. Copper-Catalyzed Site-Selective C(sp<sup>2</sup>)−H Alkynylation of Allenes. ACS Catal. 2024, 14, 13219−13226.

(14) (a) Endo, T. Novel Polymerization Methods for Allene Derivatives. Prog. Polym. Sci. 1997, 22, 565−600. (b) Osakada, K.; Takeuchi, D. Coordination Polymerization of Dienes, Allenes, and Methylenecycloalkanes. Adv. Polym. Sci. 2004, 171, 137−194.

(c) Wang, C.; Zou, H.; Liu, N.; Wu, Z. Q. Recent Advances in Polyallenes: Preparation, Self-Assembly, and Stimuli-Responsiveness. Chem. Asian. J. 2021, 16, 3864−3872.

(15) Xia, Y.; Verduzco, R.; Grubbs, R. H.; Kornfield, J. A. Welldefined liquid crystal gels from telechelic polymers. J. Am. Chem. Soc. 2008, 130, 1735−1740.

(16) Ma, S.; Yu, Z.; Wu, S. CuCl-Catalyzed Cycloisomerization Reaction of 1,2-Allenyl Carboxylic Acids. A Cost-Effective Synthesis of β-Unsubstituted Butenolides. Tetrahedron 2001, 57, 1585−1588.

(17) (a) Xu, J.; Tang, K.; Ju, Z. Synthesis and anti-Inflammatory Activity of Novel Firocoxib Analogues with Balanced COX Inhibition. Chem. Biol. Drug Des. 2024, 103, No. e14437. (b) Xie, C. L.; Xiao, H. X.; Song, P. F.; Liu, Q. M.; Wei, H.; Wu, L.; Zhu, G. H.; Liu, G. M.; Zhang, Y.; Wang, P.; Yang, X. W. Lead Optimization of Butyrolactone I as an Orally Bioavailable Antiallergic Agent Targeting FcgammaR-IIB. J. Med. Chem. 2024, 67, 7504−7515. (c) Saemian, N.; Shirvani, G.; Matloubi, H. Synthesis of Carbon-14 Analogue of N-(1-Methyl-2- Oxo-5-Phenyl-2,3-Dihydro-1H-benzo[e][1,4]diazepin-3-yl)-Benzamide-[Carboxyl-14C] as CCK-A Antagonist. J. Label. Compd. Radiopharm. 2006, 49, 71−76.

(18) To a flame-dried, argon-purged 10 mL scintillation vial equipped with a stir bar was added (R)-L7 stock solution and (S)-L7 stock solution in the desired ratio to total 2 mL. CuBr (0.01 mmol, 5 mol %) were allowed to stir 10 min before being added to the 10 mL scintillation vials. The mixture was stirred at room temperature for 30 min at which 1a (0.2 mmol, 1.0 equiv), NFSI (0.3 mmol, 1.5 equiv), A4 (0.001 mmol, 1 mol %) and TMSCN (0.6 mmol, 3.0 equiv) were sequentially added at 0 °C under a nitrogen atmosphere. The reaction mixture was stirred at same temperature for 48 h.

(19) (a) Satyanarayana, T.; Abraham, S.; Kagan, H. B. Nonlinear Effects in Asymmetric Catalysis. Angew. Chem., Int. Ed. 2009, 48, 456−494. (b) Kagan, H. B. Practical Consequences of Non-Linear Effects in Asymmetric Synthesis. Adv. Synth. Catal. 2001, 343, 227− 233. (c) Zhu, X.; Li, Y.; Bao, H. Mechanistic Applications of Nonlinear Effects in First-Row Transition-Metal Catalytic Systems. Chin. J. Chem. 2023, 41, 3097−3114. (d) Zhu, X.; Huang, M.; Bao, H.; Zhang, X. Mechanistic Insights into Nonlinear Effects in Copper-Catalyzed Asymmetric Esterification. Nat. Commun. 2025, 16, 2183.

(20) (a) Sibi, M. P.; Patil, K. Enantioselective H-atom Transfer Reactions: a New Methodology for the Synthesis of beta<sup>2</sup>-Amino Acids. Angew. Chem., Int. Ed. 2004, 43, 1235−1238. (b) Chen, B.; Fang, C.; Liu, P.; Ready, J. M. Rhodium-Catalyzed Enantioselective Radical Addition of CX Reagents to Olefins. Angew. Chem., Int. Ed. 2017, 56, 8780−8784. (c) Zhu, X.; Jian, W.; Huang, M.; Li, D.; Li, Y.; Zhang, X.; Bao, H. Asymmetric Radical Carboesterification of Dienes. Nat. Commun. 2021, 12, 6670. (d) Ge, L.; Zhou, H.; Chiou, M.-F.; Jiang, H.; Jian, W.; Ye, C.; Li, X.; Zhu, X.; Xiong, H.; Li, Y.; Song, L.;

Zhang, X.; Bao, H. Iron-catalysed asymmetric carboazidation of styrenes. Nat. Catal. 2021, 4, 28−35.

![](images/f17625ad525babb67973b811a41adbc9abcbb44ff0b133925e28e9a964fd17db.jpg)

CAS INSIGHTS™

## EXPLORE THE INNOVATIONS SHAPING TOMORROW

Discover the latest scientific research and trends with CAS Insights. Subscribe for email updates on new articles, reports, and webinars at the intersection of science and innovation.

Subscribe today