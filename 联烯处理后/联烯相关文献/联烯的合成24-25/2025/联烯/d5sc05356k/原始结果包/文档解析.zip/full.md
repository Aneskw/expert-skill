EDGE ARTICLE

View Article Online View Journal | View Issue

![](images/9f842ea0b5bfd4449229f1461be1d9a9dfb7eb958b39b7155e2d607db282df67.jpg)

Check for updates

Cite this: Chem. Sci., 2025, 16, 19711

All publication charges for this article have been paid for by the Royal Society of Chemistry

Received 18th July 2025   
Accepted 22nd September 2025

DOI: 10.1039/d5sc05356k

rsc.li/chemical-science

# Photochemical deracemization of 2,3-allenoic acids mediated by a sensitizing chiral phosphoric acid catalyst

Max Stierle,<sup>a</sup> Daniel Bitterlich, <sup>b</sup> Julia Westermayr <sup>bc</sup> and Thorsten Bach \*<sup>a</sup>

Photochemistry opens the possibility to convert a racemic mixture of a chiral compound into a distinct enantiomer in a single operation. Seven chiral phosphoric acids with a pendant thioxanthone chromophore were synthesized and evaluated as catalysts for the visible light-driven deracemization of 2,4-disubstituted 2,3-allenoic acids. A catalyst derived from 1,10-spirobiindane-7,70-diol (spinol) performed best and delivered 2-benzyl-4-tert-butyl-2,3-allenoic acids in 58–97% yield and with enantiomeric ratios (e.r.) varying between 71/29 and 85/15 depending on the benzyl substitution pattern. The major enantiomer was shown to be (R)-configured, and other 2,3-allenoic acids were also probed in the reaction. A mechanistic scenario for the observed enantioselectivity is provided that rests on experimental and quantum-chemical studies.

## Introduction

Since racemates of chiral compounds are typically available at a lower cost than enantiomerically pure compounds, extensive eforts have been undertaken to resolve racemic mixtures. A wide arsenal of separation techniques has become available to obtain the two enantiomers of a given chiral compound with high purity.<sup>1</sup> Alternatively, it is possible to diferentiate two enantiomers in a racemic mixture by kinetic resolution. Typically, chiral catalysts, oen enzymes,<sup>2</sup> are employed to involve one enantiomer in a chemical transformation while the other enantiomer remains unchanged. For the preparation of enantiopure carboxylic acid derivatives, a kinetic resolution reaction frequently involves either an esteri<sup></sup>cation or an ester hydrolysis.<sup>3</sup> Since ester and carboxylic acid are easily interconvertible, the process can be iterated, eventually leading to a single enantiomer. Alternatively, kinetic resolution reactions can be performed under conditions which allow for an equilibration of the two enantiomers (dynamic kinetic resolution),<sup>4</sup> thus facilitating complete conversion of a racemic mixture into an enantioenriched or enantiopure product.

Allenes (1,2-propadienes) display an axis of chirality if they carry two sets of diferent substituents at their terminal carbon atoms. The compound class has received great interest due to its high synthetic utility and its potential for creating chiral structures with a de<sup></sup>ned absolute con<sup></sup>guration.<sup>5</sup> In the latter context, 2,4-disubstituted 2,3-allenoic acids invite kinetic resolutions by enzyme catalysis starting from an ester precursor. Pioneering work by Jones and co-workers<sup>6</sup> revealed that enantioenriched 2,3-allenoic acids 1 can be obtained by hydrolysis of the respective allenoate (Scheme 1). Ethyl ester rac-2a was reported to deliver the (S)-con<sup></sup>gured allenoic acid in a low, yet detectable enantiomeric ratio (e.r.) of 53.5/46.5.

While subsequent work with wild-type enzymes delivered improved results,<sup>7</sup> major breakthroughs were not achieved before directed evolution was applied to allenoate hydrolysis. The Reetz and the B¨ackvall laboratories engineered a lipase by site-speci<sup></sup>c mutagenesis which processes almost exclusively one enantiomer of ester rac-2b to provide product (+)-1b with an excellent e.r.<sup>8</sup> Although a method for the racemization of allenoates had been previously reported,<sup>9</sup> a dynamic kinetic resolution was to the best of our knowledge never applied to the preparation of enantioenriched 2,4-disubstituted 2,3-allenoic acids. Despite the development of highly powerful alternative kinetic resolution methods,<sup>10,11</sup> there is no direct access to this compound class that allows for a complete conversion of the respective racemate to a single enantiomer.

![](images/098a119eca969a3366f0e3ad22430515ec3336be45db9b85328cb863f0853da6.jpg)  
Scheme 1 Enantioenriched 2,4-disubstituted 2,3-allenoic acids (1) obtained by enzymatic kinetic resolution of racemic esters 2. PLE = pig liver esterase. PAL = Pseudomonas aeruginosa lipase.

Given our interest in photochemical deracemization reactions of allenes and related axially chiral compounds,<sup>12,13</sup> we considered possible catalyst designs to be applicable to chiral 2,3-allenoic acids. Deracemization promises the complete conversion of a racemic mixture to a given enantiomer under photochemical conditions.<sup>14</sup> A suitable photocatalyst requires a binding motif for the carboxylic acid group and needs to display chromophores that induce the desired deracemization event. From previous work, it was known that thioxanthones are competent to facilitate promotion of allenes into their triplet state,<sup>12a,c</sup> which in turn suggested that a catalyst with suitably placed thioxanthones<sup>15</sup> might enable the required diferentiation of enantiomeric starting materials (vide infra). We now report on the synthesis of new chiral phosphoric acid-based<sup>16</sup> thioxanthone catalysts<sup>17,18</sup> and their application to the photochemical deracemization of 2,4-disubstituted 2,3-allenoic acids (1). A catalyst derived from 1,10-spirobiindane-7,70-diol (spinol) evolved as best suited for this purpose, and its mode of action was studied in more detail by mechanistic and quantumchemical investigations.

## Results and discussion

Preliminary experiments were performed with chiral allenoic acid rac-1c, which was irradiated with light of <sup></sup>uorescent lamps at an emission maximum of l = 420 nm (for details see the SI). At this wavelength, the allenoic acid is transparent, while thioxanthones typically absorb visible light in the blue region of the electromagnetic spectrum (l # 450 nm). Since separation of the two enantiomers of rac-1c by chiral HPLC was not feasible, the acid was converted into its methyl ester by treatment with trimethylsilyldiazomethane (TMS = trimethylsilyl). The methyl ester enantiomers 2c and ent-2c were separable and allowed for an assessment of their relative ratio by chiral HPLC (Scheme 2). Initial experiments were performed with previously reported chiral phosphoric acids, which were derived from 1,10-bi-2- naphthol (binol, 3a),<sup>18</sup> $5 , 5 ^ { \prime } , 6 , 6 ^ { \prime } , 7 , 7 ^ { \prime } , 8 , 8 ^ { \prime }$ -octahydro-1,10-bi-2- naphthol (octahydrobinol, 3b and $3 \mathbf { d } ) ^ { 1 9 }$ or 1,10-spirobiindane-7,70-diol (spinol, 3c).<sup>19</sup> At rst sight, the outcome of the reactions was disappointing because there was no signi<sup></sup>cant preference for one of the two enantiomers. Even prolonged irradiation did not lead to an improvement. On the positive side, we noted that the spinol-based catalyst 3c outperformed the related catalysts 3a and 3b, and that it seemed bene<sup></sup>cial to move the thioxanthone chromophore closer to the chiral backbone. In catalysts 3a–3c, a meta-substituted phenyl group acts as a hinge connecting the chromophore with the phosphoric acid, while the chromophore is directly attached to the chiral backbone in catalyst 3d. The results indicated that it might be bene<sup></sup>cial to prepare new spinol-based catalysts to which thioxanthone was directly attached at the 6- and 60-positon of the biindane skeleton.

![](images/c82dee0f9678fbb86eda05ab9a1d94ffc27b3a835b170ae00c2980821ecb0334.jpg)  
Scheme 2 Photochemical deracemization attempts performed with 2,3-allenoic acid rac-1c and known catalysts 3a–3d. The acid was methylated to determine the enantiomeric ratio (e.r.) by chiral HPLC analysis.

The synthesis of the spinol derivatives commenced with the respective mono- or diiodinated precursors 4a <sup>20</sup> and $\mathbf { 4 b , ^ { 2 1 } }$ the hydroxy groups of which were protected by methoxymethyl (MOM) substituents (Fig. 1). Subsequent Pd-catalysed crosscoupling with known boronates $\mathbf { 5 4 } ^ { \mathbf { 1 7 } \mathbf { c } }$ and $5 { \bf b } ^ { 2 2 }$ was immediately followed by removal of the MOM protecting groups and formation of the respective phosphates 3e–3g.

Catalyst 3e was obtained in an overall yield of 52%. The reaction to the 6,60-disubstituted catalysts 3f (48% overall) and 3g (72% overall) turned out to be equally eficient, but the separation from impurities proved tedious in all cases. The performance of the catalysts notably improved when compared to the previous results obtained with catalysts 3a–3d in the photochemical deracemization. Particularly, the two-fold thioxanthone-substituted catalyst 3f combined a good enantiodiscrimination in the reaction of chiral acid rac-1c (e.r. = 76/24) with good availability on larger scale. Further optimisation experiments were consequently performed with the latter catalyst (Table 1). By choosing diferent reaction times (entries 1–4), it was con<sup></sup>rmed that the photostationary state was reached aer an irradiation time of four hours. There was no improvement of the e.r. at longer reaction times.

![](images/bd0649a60330094ed7c79a2dfa9bc333c4ef9de680f1637560772f6183ce24c1.jpg)  
Fig. 1 Starting materials 4–5 (top) required for the synthesis of spinolbased chiral phosphoric acids $3 \mathsf { e } \mathrm { - } 3 \mathsf { g } .$ . The e.r. refers to the enantiomeric ratio obtained with the respective catalyst in the photochemical deracemization of 2,3-allenoic acid rac-1c (cf. Scheme 2).

Table 1 Reaction optimisation for the photochemical deracemization of 2,3-allenoic acid rac-1c catalyzed by chiral Brønsted acid 3f (cf. Scheme 2 and Fig. 1)
<table><tr><td>entryª</td><td>3f [mol%]</td><td>Solvent</td><td> $T \left[ { } ^ { \circ } \mathbf { C } \right]$ </td><td>t [h]</td><td>Yield</td><td> $\mathrm { e . r } ^ { b }$ </td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>1</td><td>10</td><td> $\mathrm { C H } _ { 2 } \mathrm { C l } _ { 2 }$ </td><td>30</td><td>4</td><td>Quant</td><td>76/24</td></tr><tr><td>2</td><td>10</td><td> $\mathrm { C H } _ { 2 } \mathrm { C l } _ { 2 }$ </td><td>30</td><td>2</td><td>Quant</td><td>74/26</td></tr><tr><td>3</td><td>10</td><td> $\mathrm { C H } _ { 2 } \mathrm { C l } _ { 2 }$ </td><td>30</td><td>6e</td><td>Quant</td><td>75/25</td></tr><tr><td>4</td><td>10</td><td> $\mathrm { C H } _ { 2 } \mathrm { C l } _ { 2 }$ </td><td>30</td><td>22</td><td>78%</td><td>70/30</td></tr><tr><td> $5 ^ { c }$ </td><td>10</td><td> $\mathrm { C H } _ { 2 } \mathrm { C l } _ { 2 }$ </td><td>30</td><td>4</td><td>88%</td><td>74/26</td></tr><tr><td> $6 ^ { d }$ </td><td>10</td><td> $\mathrm { C H } _ { 2 } \mathrm { C l } _ { 2 }$ </td><td>30</td><td>4</td><td>93%</td><td>76/24</td></tr><tr><td>7</td><td>5</td><td> $\mathrm { C H } _ { 2 } \mathrm { C l } _ { 2 }$ </td><td>30</td><td>4</td><td>Quant</td><td>73/27</td></tr><tr><td>8</td><td>20</td><td> $\mathrm { C H } _ { 2 } \mathrm { C l } _ { 2 }$ </td><td>30</td><td>4</td><td>96%</td><td>74/26</td></tr><tr><td>9</td><td>10</td><td> $\mathrm { C H } _ { 2 } \mathrm { C l } _ { 2 }$ </td><td>-10</td><td>4</td><td>97%</td><td>82/18</td></tr><tr><td>10</td><td>10</td><td> $\mathrm { C H } _ { 2 } \mathrm { C l } _ { 2 }$ </td><td>-40</td><td>4</td><td>Quant</td><td>80/20</td></tr><tr><td> $1 1 ^ { e }$ </td><td>10</td><td> $\mathrm { C H } _ { 2 } \mathrm { C l } _ { 2 }$ </td><td>-10</td><td>4</td><td>97</td><td>79/21</td></tr><tr><td>12</td><td>10</td><td> $\scriptstyle \mathrm { D C E } ^ { f }$ </td><td>30</td><td>4</td><td>96%</td><td>58/42</td></tr><tr><td>13</td><td>10</td><td>Toluene</td><td>30</td><td>4</td><td>Quant</td><td>65/35</td></tr><tr><td>14</td><td>10</td><td> $_ \mathrm { A c e t o n e }$ </td><td>30</td><td>4</td><td>97%</td><td>51/49</td></tr><tr><td>15</td><td>10</td><td> $\mathrm { T F T } ^ { g }$ </td><td>30</td><td>4</td><td>89%</td><td>72/28</td></tr><tr><td>16</td><td>10</td><td> $\mathrm { H F X } ^ { h }$ </td><td>30</td><td>4</td><td>87%</td><td>75/25</td></tr></table>

<sup>a</sup> Unless otherwise noted, the reactions were performed at a substrate concentration of $c = 1 0$ mM. The product was isolated as its methyl ester 2c/ent-2c. <sup>b</sup> The enantiomeric ratio (e.r.) was determined aer methylation by chiral-phase HPLC analysis. $c _ { \textup { c } = 5 }$ mM. <sup>d</sup> c = 20 mM. <sup>e</sup> The irradiation was performed at $\lambda = 4 4 0$ nm. <sup>f</sup> 1,2-Dichloroethane. <sup>g</sup> Tri<sup></sup>uorotoluene. <sup>h</sup> 1,3-Bis(tri<sup></sup>uoromethyl)benzene.

The in<sup></sup>uence of the substrate concentration (c) was probed by changing the concentration to c = 5 mM (entry 5) and $c =$ 20 mM (entry 6), respectively. There was no notable change which is why a concentration of c = 10 mM was routinely chosen. Likewise the catalyst loading (entries 7, 8) had little in<sup></sup>uence on the reaction outcome and the loading was kept at 10 mol%. The most signi<sup></sup>cant parameter leading to an improvement of the enantioselectivity was the reaction temperature. $\mathbf { A } \mathbf { t } - 1 0 \ ^ { \circ } \mathbf { C } ,$ the e.r. increased to 82/18 (entry 9) but there was no further increase upon lowering the temperature to 40 °C (entry 10). Since the <sup></sup>uorescent light bulbs display a relative broad emission spectrum, other light sources with a narrower emission band were tested. One example is included in Table 1 (entry 11). Here, a light emitting diode (LED) with an emission maximum at l = 440 nm was used. The outcome was somewhat inconsistent, possible due to the little overlap between emission and absorption by the catalyst (vide infra). On average, neither yield nor e.r. improved notably when choosing other light sources (see the SI for details). The choice of solvent was limited by the solubility of the chiral Brønsted acid. All tested solvents (entries 12–16) turned out to be inferior to dichloromethane, and we selected the conditions of entry 9 to study diferent substrates in photochemical deracemization reactions mediated by catalyst 3f.

Initial substrate modi<sup></sup>cations concerned primarily the substituent in 2-position. Diversely substituted phenyl groups were probed at the benzylic position and it was shown that the protocol was compatible with alkyl (1g, 1i, 1j), <sup></sup>uoro (1d), chloro (1o), bromo (1e), iodo (1f), alkylsulfanyl (1h), phenyl (1k), cyano (1l) and alkoxy (1m) substituents (Scheme 3). In some cases, the ratio of the acid enantiomers could not be directly assessed, and the acid was converted into the respective methyl ester. Yields were consistently high but decreased for strongly electron de<sup></sup>cient (1p) and electron rich (1n) substituents.

Although steric bulk at the 2-benzyl substituent did not change the enantioselectivity of the deracemization, as seen for example in the reaction of rac-1j, the 1-naphthyl group led to a notable decrease in e.r. (product 1q). It was possible to scaleup the reaction, and an improved yield was recorded when running the reactions on larger scale. For instance, acid 1f was obtained in 94% yield when the reaction was run on 0.5 mmol scale while the small-scale reaction (50 mmol) gave only a yield of 76%. Catalyst recovery was feasible, and 70% of the catalyst was re-isolated in the mentioned 0.5 mmol scale reaction.

In general, the free acids elute relatively slowly from column, and some product was likely lost because it was too diluted for detection in late fractions or it remained on column. The issue was particularly relevant on small scale, and the lower yields for cases in which the acids were isolated are partially due to their high polarity. For example, product 1l was obtained in only 64% as the acid, but the yield was 95% for the methyl ester 2l under otherwise identical reaction conditions.

Expectedly, the size of the substituents in 2- and 4-position plays a signi<sup></sup>cant role in the enantiomer discrimination by the catalyst. If the size of the substituent $\mathbf { R } ^ { 1 }$ at C4 was decreased, the e.r. of the product acid was lower than for standard substrate 1c $( \mathbf { R } ^ { 1 } = t e r t \ – \mathbf { b u t y l } )$ . The methyl-substituted acid 1r $\left( \mathbf { R } ^ { 1 } = \mathrm { m e t h y l } \right)$ was obtained in a comparably low e.r. of 65/35. When increasing the steric bulk of ${ \mathbf { R } } ^ { 1 } { \mathrm { : } }$ , the e.r. improved as seen for 1s, 1t, and 1u. Likewise, small groups R at position C2 led to relatively low enantioselectivity (Scheme 4).

For R = H (1v) and R = methyl (1w), the e.r. was lower than for the standard substrate 1c with R = benzyl. A dimethylallyl group at C2, however, seems to mimic the benzyl group well, and acid 1x was successfully deracemized in good yield (85%,

Chemical Science

![](images/2af98c5427500b50170da2271b633449cdf650ee2ba66ea7e582ee39ed8be670.jpg)  
Scheme 3 Photochemical deracemization of 2,3-allenoic acids rac-1c to rac-1q as catalysed by chiral Brønsted acid 3f (50 mmol scale). <sup>a</sup> Yield and e.r. of the product were obtained after methyl ester formation as described in Scheme 2. <sup>b</sup> When performed on 0.5 mmol scale the yield was $9 4 \% ( \mathrm { e . r . } = 8 0 / 2 0 )$

$\mathbf { e . r . } = 8 4 / 1 6 )$ . Phenyl groups in position C2 or C4 of the allene lead to a bathochromic shi of the UV/Vis absorption which likely invites a direct excitation and hampers the enantioselectivity in an attempted deracemization reaction (see the SI for details). Although an association of the carboxylic acid to the catalyst by hydrogen bonding was assumed to be an integral part of the mode of action, we con<sup></sup>rmed the critical in<sup></sup>uence of the binding site by subjecting other allenoic acid derivatives to the deracemization conditions. Both amide rac-6c and ester rac-2c resulted in low or no enantioselectivity.

The absolute con<sup></sup>guration of the products was established by comparison with authentic material of known con<sup></sup>guration. Enantioenriched acid 1f was converted to amide 6f which was shown by chiral HPLC analysis to exist as an 80/20 mixture of enantiomers 6f/ent-6f. The absolute con<sup></sup>guration of minor enantiomer ent-6f was known from previous work.<sup>12c</sup> On chiral HPLC, the enantiomers are baseline separated which allowed to assign the absolute con<sup></sup>guration of the stereogenic axis as (R). The same exercise was performed for acid 1h con<sup></sup>rming the assignment. All other con<sup></sup>guration assignments were based on analogy with the major enantiomer being (R)-con<sup></sup>gured (Scheme 5).

Mechanistically, the con<sup></sup>gurational instability of allenes 1 seems to be the result of a sensitized excitation leading to an achiral triplet intermediate.<sup>23</sup> Experiments with enantioenriched (scalemic) substrate 1f $( \mathrm { e . r . } = 8 0 / 2 0 )$ performed at $\lambda =$

View Article Online

Edge Article

![](images/b215e184b283583a62746459131958a8f852c010ed1b3802da94de158eed2afb.jpg)  
Scheme 4 Influence of substitution and binding motif on the outcome of the photochemical deracemization of 2,3-allenoic acids rac-1r to rac-1x and of allenoic acid derivatives rac-6c and rac-2c. <sup>a</sup> Yield and e.r. of the product were obtained after methyl ester formation as described in Scheme 2. <sup>b</sup> Yield of the isolated carboxylic acid, the e.r. was determined after primary amide formation.

440 nm and at $T = - 1 0 \mathrm { ~ } ^ { \circ } \mathrm { C }$ showed the compound to be con<sup></sup>gurationally stable. If achiral thioxanthen-9-one was added and the reaction was performed under otherwise unchanged conditions (Scheme 6) a slight but clearly detectable racemization was observed. The most likely scenario to account for the racemization is a sensitization by thioxanthen-9-one, the triplet energy $\left[ \mathrm { E } ( \mathrm { T } _ { 1 } ) \right]$ of which has been determined as $\begin{array} { r l } { \mathbf { E } ( \mathbf { T _ { 1 } } ) } & { { } = } \end{array}$ 274 kJ mol−<sup>1</sup> (77 $\mathbf { K } ,$ methylcyclohexane-isopentane).<sup>24</sup> The intermediate allene-derived diradical $\mathbf { 7 6 ^ { 2 5 } }$ is achiral and reforms statistically either one of the two product enantiomers 1f and ent-1f. The only small e.r. change is attributed to the low absorption coeficient 3 of thioxanthen-9-one at l = 440 nm (3 # 1 L mol−<sup>1</sup> cm−<sup>1</sup> in $\mathrm { C H } _ { 2 } \mathrm { C l } _ { 2 } )$

At shorter wavelength, employing <sup></sup>uorescent lamps emitting at l = 420 nm, the racemization was more extensive (e.r. = 66/34) under otherwise identical conditions. However, it was surprisingly found, that substrate 1f undergoes a detectable racemization $\left( \mathrm { e . r . } = 7 6 / 2 4 \right)$ even in the absence of the catalyst. We ascribe this observation to a minor emission band of the <sup></sup>uorescent lamps occurring at l = 365 nm (for the spectral data see the SI). In the deracemization experiments, this emission should be inconsequential, since catalyst 3f has a far more extensive absorption at this wavelength than substrate rac-1f and it should be almost exclusively excited. The allenoic acid absorbs minimally at $\lambda = 3 6 5$ nm with $\varepsilon \leq 1 \mathrm { ~ L ~ m o l } ^ { - 1 } \mathrm { ~ c m } ^ { - 1 }$ (CH Cl ) while the absorption coeficient for 3f is $\varepsilon = 5 6 3 0$ L mol $^ { - 1 } \mathrm { { c m } ^ { - 1 } \left( C H _ { 2 } C l _ { 2 } \right) }$ . In fact, the photophysical properties of catalyst 3f (Fig. 2) are similar to parent thioxanthen-9-one.<sup>26</sup>

![](images/0c759325deaef4c723182f8f6b0000e3181885a97b3af5010eba6933cc04b3c8.jpg)  
Scheme 5 Proof of absolute configuration: Enantioenriched carboxylic acid was converted into amide 6f (EDCI = 1-ethyl-3-(3-dimethylaminopropyl)carbodiimide, HOBt = 1-hydroxybenzotriazole) which was compared on chiral HPLC with a sample of amide ent- $. 6 \mathsf { f } , ^ { 1 2 c }$ the absolute configuration of which was known.

![](images/a7317f0351a6e82f3e63e74903b32bb3330d5eaa91992efabb99e1c70e4a8392.jpg)  
Scheme 6 2,3-Allenoic acid 1f is not configurationally stable upon excitation. In the presence of thioxanthen-9-one, irradiation at $\lambda =$ 440 nm leads to a decrease in the enantiomeric ratio, presumably via achiral triplet intermediate 5.

The energy of the lowest lying singlet state was determined from the crossing point of the absorption and <sup></sup>uorescence emission as $\mathrm { E } \big ( \mathrm { S } _ { 1 } \big ) = 2 9 5 \ \mathrm { k J \ m o l } ^ { - 1 }$ . The compound shows an intense luminescence at $7 7 \ \mathrm { ~ K ~ }$ which is mostly due to phosphorescence. The triplet energy was calculated from the point of in<sup></sup>ection in the phosphorescence spectrum as $\mathrm { E ( T _ { 1 } ) } = 2 6 0 \pm$ 2 kJ $\mathrm { m o l ^ { - 1 } \left( 7 7 ~ K , C H _ { 2 } C l _ { 2 } \right) }$

The most coherent explanation for the observed enantiomer diferentiation is based on a preferred energy transfer to one substrate enantiomer of allenoic acid. The situation is depicted for the parent compound rac-1c in Scheme 7 and was further corroborated by quantum-chemical calculations. Dexter energy transfer<sup>27</sup> is strongly distance dependent, and proximity of the triplet energy donor and the respective acceptor facilitate energy transfer.<sup>28</sup> We propose that enantiomer ent-1c is more readily processed by photoexcited catalyst $3 \mathbf { f } ^ { * }$ because the thioxanthone and the allene chromophore are spatially closer in complex 3f\$ent-1c than in the diastereomeric complex 3f\$1c. If this is correct the catalytic cycle involving the former complex is preferred and the rate of racemization via achiral intermediate 7c is higher for allenoic acid enantiomer ent-1c. In the photostationary state, the enantiomer 1c, which is more slowly processed, prevails and is isolated in excess.

![](images/62b21c378be4ba7ae16ec34aa8e89c3a3159e0d7178b718fa9c43b588a51f148.jpg)

![](images/43c184419a684428a836b6fe31ba667f58f88d17e39e4035bfea67ed8abb9bb5.jpg)  
Fig. 2 Photophysical properties of catalyst 3f: Normalized absorption and emission spectra at ambient temperature in CH Cl solution (left). Emission spectra recorded at r.t. (red solid line) and 77 K (blue solid line) in $\mathsf { C H } _ { 2 } \mathsf { C l } _ { 2 } \left( \lambda _ { \mathrm { e x c } } = 3 8 5 \right.$ nm). The blue dotted line shows the phosphorescence spectrum at 77 K $( \lambda _ { \mathrm { e x c } } = 3 8 5 \ : \mathrm { n m }$ $t _ { \mathrm { d e l a y } } = 1 0 0$ ms) in $C H _ { 2 } C l _ { 2 }$

For theoretical investigations, minimum energy conformers were computed using conformational sampling<sup>29–31</sup> of complexes 3f\$ent-1c and 3f\$1c with the GFN2-xTB<sup>32,33</sup> method, followed by subsequent geometry optimization and frequency calculation to con<sup></sup>rm the correct minimum energy structures. Therefore, the PBEh-3c<sup>34–37</sup> composite method including implicit solvation<sup>38,39</sup> was used. In addition, thermodynamic corrections<sup>33,40,41</sup> were included to the electronic energies that were computed using the PW6B95-D3(BJ)/def2-QZVP<sup>35,36,42,43</sup> level of theory. The most stable minimum energy conformers of both complexes are visualized in Scheme 7. The Gibbs free enthalpy of both diastereomeric complexes is almost identical with a calculated DG of only 0.473 kJ mol−<sup>1</sup>. Subsequent analyses were based on all sampled ground-state minimum energy conformers (40 for 3f\$ent-1c and 24 for 3f\$1c) that were weighted by a Boltzmann distribution. Computational details on the sampling procedure, energy calculations, and analyses can be found in the SI.

As Dexter-type triplet energy transfers are strongly distance dependent, we analysed the interatomic distances of the two distinct diastereomeric complexes as previous investigations of similar allene deracemizations have shown that distances observed in the ground-state equilibrium geometries are similar to those in the triplet manifold.<sup>12c</sup> Analysis revealed that the distance between the thioxanthone moiety and the conjugated atoms in the allene is smaller in case of complex 3f\$ent-1c compared to complex 3f\$1c, both for the lowest minimum energy conformer as well as in the Boltzmann-weighted average. To avoid dependencies on arbitrary reference points and the resulting introduction of a bias, we used the overlap of scaled van der Waals radii<sup>44</sup> as a measure for the proximity of the relevant groups. A larger volume indicates a better overlap of the radii and a greater proximity of the two components within the assembly. The resulting volumes obtained for the minimum structures, 2.98 $\mathring { \mathbf { A } } ^ { 3 }$ for 3f\$1c and 3.81 $\mathring { \mathbf { A } } ^ { 3 }$ for 3f\$ent-1c, are plotted in addition to the structures in Scheme 7 (green areas). The Boltzmann-weighted averages, 2.97 $\mathring { \mathbf { A } } ^ { 3 }$ for 3f\$1c and 3.72 $\mathring { \mathbf { A } } ^ { 3 }$ for 3f\$ent-1c, con<sup></sup>rm the observation obtained from the lowest minimum energy conformers. The diferences in the volumina are clearly visible and are additionally supported by the distances of each atom in the allene moiety to the thioxanthone plane that are plotted in the SI. These results con<sup></sup>rm previously observed trends that shorter distances are in correlation with lower barriers in Dexter-type triplet-energy transfers.<sup>28</sup>

Since the distance diference for the diastereomeric complexes 3f\$1 vs. 3f\$ent-1 is relatively low, the achieved enantioselectivity is not as high as in previous cases.<sup>12</sup> While the enantioselectivities obtained with spinol-derived catalyst 3f are moderate, our computational analysis shows that the selectivity correlates with diferences in Dexter energy transfer eficiency between diastereomeric complexes, quanti<sup></sup>ed by Boltzmann-

Chemical Science

View Article Online

Edge Article

![](images/4493b510e2a80ba32f2e4e059ff7b10a8d873d933e14599964941f7945d9976f.jpg)  
Scheme 7 Mechanistic scenario for the deracemization of racemic allenoic acid rac-1c upon irradiation in the presence of catalyst 3f. Triplet energy transfer is faster in complex 3f\$ent-1c than in complex 3f\$1c because the average distance of the thioxanthone chromophore to the allene is smaller. Triplet energy transfer from excited 3f\* to the allene leads to formation of achiral triplet intermediate 5c (cf. Scheme 6) which dissociates from the phosphoric acid and forms either one of the two enantiomers 1c or ent-1c of the allenoic acid. The lowest minimum energy conformations of each enantiomer with catalyst 3f are shown below, in addition to the overlap of scaled van der Waals radii (green areas) to visualize the proximity of the allenoic acids to the catalyst.

weighted proximity/overlap descriptors. This mechanistic handle suggests avenues for optimization, such as closer or asymmetric placement of the thioxanthone unit, tuning of the chromophore's triplet energy, or reinforcement of the hydrogen-bonding network. These strategies, together with data-driven screening based on the computed descriptors<sup>45</sup> or machine learning optimization techniques,<sup>46</sup> provide a roadmap for future improvements in enantioselectivity.

An interesting twist of the Dexter energy transfer mechanism relates to the fact that a dual catalytic system is conceivable, in which achiral thioxanthen-9-one and a chiral phosphoric acid with a suitable chromophore act synergistically. Preliminary results showed the approach to be viable but the enantioselectivities remained lower than with the sensitizing phosphoric acid 3f (see the SI for details).

![](images/06fd0f94dbd1fe7984c09c7aa5cc20b0ce71a3c2888b7d005b7686b20368d528.jpg)  
Scheme 8 Consecutive reactions of scalemic allenoic acid 1f. Abbreviations: Dibal-H = diisobutylaluminium hydride; im = imidazole; NBS = N-bromosuccinimide; TBS = tert-butyldimethylsilyl.

The transformation of axially chiral allenes to products with a stereogenic center has been studied extensively in prior work. In particular, the Diels–Alder reaction has been broadly utilized and was shown to occur with high chirality transfer.<sup>47</sup> In the present study, we have mainly investigated a consecutive halolactonization<sup>48</sup> or haloesteri<sup></sup>cation (Scheme 8).<sup>49</sup> We found the bromolactonization of scalemic allenoic acid 1f to occur with perfect chirality transfer generating lactone 8 in high yield. The absolute con<sup></sup>guration of the major enantiomer was assigned based on the assumption that the temporarily formed bromonium ion is substituted intramolecularly by the carboxylic acid.<sup>48,50</sup> The iodolactonization to product 9 proceeded smoothly but the enantiomeric purity was not fully retained. Upon reduction of the acid to alcohol 10, the iodoetheri<sup></sup>cation delivered the desired ether 11 in an e.r. of 75/25. Since the e.r. of alcohol 10 could not be determined by chiral HPLC, it was transformed into silyl ether 12. Based on the fact that its e.r. was identical to the e.r. of the iodoetheri<sup></sup>cation product, it seems most likely that the observed loss of enantiomeric purity is due to the reduction step while the absolute con<sup></sup>guration is retained in the two consecutive reactions.

## Conclusions

In summary, we have successfully shown that a chiral phosphoric acid can be employed as a single photocatalyst for a photochemical deracemization reaction. The catalyst operates

likely by triplet energy transfer to the allenoic acid, inducing a racemization via the triplet state of the substrate. Proper positioning of the thioxanthone chromophore in the catalyst is crucial for the diferentiation of the two substrate enantiomers. The relatively high <sup></sup>exibility of catalyst and allenoic acid precludes the catalyst from recruiting a single allene enantiomer in the energy transfer step. Although there is a preference for processing one enantiomer over the other, the degree of diferentiation and consequently the enantioselectivity are yet not as optimal as previously seen for azabicyclo[3.1.1]nonan-2-one-based energy transfer catalysts. Still, the results provide an excellent starting point for further catalyst optimization and design.

## Author contributions

M. S. and T. B. developed the project. Funding was acquired by T. B. and J. W.; M. S. designed and performed the synthetic experiments. M. S. generated and validated the experimental data, D. B. the computational data. T. B. and J. W. administered the project and supervised the research. All authors wrote, reviewed, and edited the manuscript.

## Conflicts of interest

There are no con<sup></sup>icts to declare.

## Data availability

The data that supports the <sup></sup>ndings of this study are available in the supplementary material (SI) of this article. Primary research data are openly available in the repository RADAR4Chem at https://doi.org/10.22000/14d69n7httd5f1yw.<sup>51</sup> Supplementary information: synthetic procedures and full characterization for all starting materials and products (1c–1x, 2c, 2e, 2g, 2i, 2j, 2k, 2r, 2u, 3e–3g, 6c, 6f, 6x, 8–12), spectroscopic and computational data. See DOI: https://doi.org/10.1039/ d5sc05356k.

## Acknowledgements

Financial support by the Deutsche Forschungsgemeinscha (DFG, German Research Foundation) – TRR 325 (project B2 and seed funding for JW) – 444632635 is gratefully acknowledged. Computations for this work were done using resources of the Leipzig University Computing Center, the NHR Center at TU Dresden, and Paderborn Center for Parallel Computing (PC2). We thank O. Ackermann, J. Kudermann, P. Freund, and N. P<sup></sup>aum (all TU Munich) for their help with the GLC and HPLC analyses. We are grateful to Dr S. Breitenlechner (TU Munich) for his help with the preparation of the repository. M. Reichel and J.-J. Schneider are acknowledged for synthetic assistance. Toni Oestereich is acknowledged for initial quantum chemical calculations.

## Notes and references

1 (a) H. Lorenz and A. Seidel-Morgenstern, Angew. Chem., Int. Ed., 2014, 53, 1218–1250; (b) J. Sui, N. Wang, J. Wang, X. Huang, T. Wang, L. Zhou and H. Hao, Chem. Sci., 2023, 14, 11955–12003.

2 For recent reviews on enzyme catalysis, see:(a) M. T. Reetz, G. Qu and Z. Sun, Nat. Synth., 2024, 3, 19–32; (b) A. O'Connell, A. Barry, A. J. Burke, A. E. Hutton, E. L. Bell, A. P. Green and E. O'Reilly, Chem. Soc. Rev., 2024, 53, 2828–2850; (c) E. J. Hossack, F. J. Hardy and A. P. Green, ACS Catal., 2023, 13, 12436–12444; (d) M. T. Reetz, Adv. Synth. Catal., 2022, 364, 3326–3335; (e) R. A. Sheldon, D. Brady and M. L. Bode, Chem. Sci., 2020, 11, 2587–2605.

3 (a) A. Ghanem and H.-Y. Aboul-Enein, Chirality, 2005, 17, 1– 15; (b) P. D. de Mar´ıa, C. A. Garc´ıa-Burgos, G. Bargeman and R. W. van Gemert, Synthesis, 2007, 1439–1452; (c) E. Fern´andez-Alvaro, R. Kourist, J. Winter, D. Böttcher,<sup>´</sup> K. Liebeton, C. Naumer, J. Eck, C. Leggewie, K. E. Jaeger, W. Streit and U. T. Bornscheuer, Microb. Biotechnol., 2010, 3, 59–64; (d) A. Brodzka, D. Koszelewski, M. Zysk and R. Ostaszewski, Catal. Commun., 2018, 106, 82–86; (e) K. Okuno, Y. Furuya and S. Shirakawa, Eur. J. Org Chem., 2024, 27, e202300985; (f) Z. Dou, X. Chen, L. Zhu, X. Zheng, X. Chen, J. Xue, S. Niwayama, Y. Ni and G. Xu, Nat. Commun., 2024, 15, 9057.

4 Selected reviews:(a) H. Pellissier, Eur. J. Org Chem., 2022, e202101561; (b) L.-C. Yang, H. Deng and H. Renata, Org. Process Res. Dev., 2022, 26, 1925–1943; (c) O. Verho and J.-E. B¨ackvall, J. Am. Chem. Soc., 2015, 137, 3996–4009; (d) H. Pellissier, Tetrahedron, 2003, 59, 8291–8327.

5 (a) N. Krause and S. Hashmi, Modern Allene Chemistry, Wiley-VCH, Weinheim, 2004; (b) S. Yu and S. Ma, Angew. Chem., Int. Ed., 2012, 51, 3074–3112.

6 S. Ramaswamy, R. A. H. F. Hui and J. B. Jones,J. Chem. Soc., Chem. Commun., 1986, 1545–1546.

7 (a) M. Pietzsch, O. Vielhauer, D. Pamperin, B. Ohse and H. Hopf, J. Mol. Catal. B: Enzym., 1999, 6, 51–57; (b) B. Skrobo, J. D. Rolfes and J. Deska, Tetrahedron, 2016, 72, 1257–1275.

8 J. D. Carballeira, P. Krumlinde, M. Bocola, A. Vogel, M. T. Reetz and J.-E. B¨ackvall, The absolute con<sup></sup>guration of the major enantiomer is not provided in the paper, but it is said to be the (+)-allenoic acid, Chem. Commun., 2007, 1913–1915.

9 A. Horv´ath and J. E. B¨ackvall, Chem. Commun., 2004, 964– 965.

10 (a) J. Nyhl´en, L. Eriksson and J.-E. B¨ackvall, Chirality, 2008, 20, 47–50; (b) J. Yu, W.-J. Chen and L.-Z. Gong, Org. Lett., 2010, 12, 4050–4053; (c) Y.-F. Ao, D.-X. Wang, L. Zhao and M.-X. Wang, J. Org. Chem., 2014, 79, 3103–3110.

11 For the preparation of enantiopure 2,3-allenoic acids, see: (a) W. Runge, G. Kresze and E. Ruch, Liebigs Ann. Chem., 1975, 1361–1378; (b) S. Ma and S. Wu, Chem. Commun., 2001, 5, 441–442; (c) J. Nyhl´en, L. Eriksson and J.-E. B¨ackvall, Chirality, 2008, 1, 47–50; (d) W.-F. Zheng, W. Zhang,

C. Huang, P. Wu, H. Qian, L. Wang, Y.-L. Guo and S. Ma, Nat. Catal., 2019, 2, 997–1005; (e) J. Wang, W.-F. Zheng, Y. Li, Y.-L. Guo, H. Qian and S. Ma, Org. Chem. Front., 2024, 11, 2477–2484.

12 (a) A. Hölzl-Hobmeier, A. Bauer, A. V. Silva, S. M. Huber, C. Bannwarth and T. Bach, Nature, 2018, 564, 240–243; (b) M. Plaza, C. Jandl and T. Bach, Angew. Chem., Int. Ed., 2020, 59, 12785–12788; (c) M. Plaza, J. Großkopf, S. Breitenlechner, C. Bannwarth and T. Bach, J. Am. Chem. Soc., 2021, 143, 11209–11217; (d) T. Kratz, P. Steinbach, S. Breitenlechner, G. Storch, C. Bannwarth and T. Bach, J. Am. Chem. Soc., 2022, 144, 10133–10138.

13 For a diferent approach towards the photochemical deracemization of allenes, see:(a) C. Song, X. Bai, B. Li, Y. Dang and S. Yu, J. Am. Chem. Soc., 2024, 146, 21137– 21146; (b) C. Song and S. Yu, ACS Catal., 2024, 14, 15997– 16002.

14 Selected reviews:(a) M. Huang, T. Pan, X. Jiang and S. Luo, J. Am. Chem. Soc., 2023, 145, 10917–10929; (b) J. Großkopf and T. Bach, Angew. Chem., Int. Ed., 2023, 62, e202308241; (c) J. Wang, X. Lv and Z. Jiang, Chem.–Eur. J., 2023, 6, e202204029; (d) Q. Shi and J. Ye, Angew. Chem., Int. Ed., 2020, 59, 4998–5001.

15 For the use of thioxanthone in photocatalysis, see: N. F. Nikitas, P. L. Gkizis and C. G. Kokotos, Org. Biomol. Chem., 2021, 19, 5237–5253.

16 For key references on the use of phosphoric acids in enantioselective photocatalysis, see:(a) L. J. Rono, H. G. Yayla, D. Y. Wang, M. F. Armstrong and R. R. Knowles, J. Am. Chem. Soc., 2013, 135, 17735–17738; (b) R. S. J. Proctor, H. J. Davis and R. J. Phipps, Science, 2018, 360, 419–422; (c) K. Cao, S. M. Tan, R. Lee, S. Yang, H. Jia, X. Zhao, B. Qiao and Z. Jiang, J. Am. Chem. Soc., 2019, 141, 5437–5443; (d) Y.-Z. Cheng, Q.-R. Zhao, X. Zhang and S.-L. You, Angew. Chem., Int. Ed., 2019, 58,

(f) E. M. Sherbrook, M. J. Genzink, B. Park, I. A. Guzei, M.-H. Baik and T. P. Yoon, Nat. Commun., 2021, 12, 5735;

(g) Z. C. Girvin, L. F. Cotter, H. Yoon, S. J. Chapman, J. M. Mayer, T. P. Yoon and S. J. Miller, J. Am. Chem. Soc., 2022, 144, 20109–20117; (h) T. Uchikura, N. Kamiyama, T. Mouri and T. Akiyama, ACS Catal., 2022, 12, 5209–5216;

17 For work on chiral phosphoric acid-based thioxanthone catalysts by other groups, see: (a) J. Lyu, A. Claraz, M. R. Vitale, C. Allain and G. Masson, J. Org. Chem., 2020, 85, 12843–12855; (b) R. Takagi and C. Tabuchi, Org. Biomol. Chem., 2020, 18, 9261–9267; (c) R. Takagi and T. Tanimoto, Org. Biomol. Chem., 2022, 20, 3940–3947.

18 (a) F. Pecho, Y.-Q. Zou, J. Gramüller, T. Mori, S. M. Huber, A. Bauer, R. M. Gschwind and T. Bach, Chem.–Eur. J., 2020, 26, 5190–5194; (b) F. Pecho, Y. Sempere, J. Gramüller, F. M. Hörmann, R. M. Gschwind and T. Bach, J. Am. Chem. Soc., 2021, 143, 9350–9354.

19 M. Stierle, C. Jaschke, D. J. Grenda, M. T. Peschel, T. Pickl, N. Gessner, P. Nuernberger, B. P. Fingerhut, C. Ochsenfeld, R. de Vivie-Riedle and T. Bach, Angew. Chem., Int. Ed., 2025, 64, e202501433.

20 X. Xiong, T. Zheng, X. Wang, Y.-L. S. Tse and Y.-Y. Yeung, Chem, 2020, 6, 919–932.

21 Y. Yang, S.-F. Zhu, H.-F. Duan, C.-Y. Zhou, L.-X. Wang and Q.-L. Zhou, J. Am. Chem. Soc., 2006, 129, 2248–2249.

22 X. Dong, S. Shen, Y. Qin, X. Hu, H. Gao, G. Liu, T. Gao, Z. Pang, P. Wang and Y. Wang, Chin. Chem. Lett., 2023, 34, 108331.

23 For early precedence, see:(a) O. Rodriguez and H. Morrison, J. Chem. Soc., Chem. Commun., 1971, 679; (b) C. S. Drucker, V. G. Toscano and R. G. Weiss, J. Am. Chem. Soc., 1973, 95, 6482–6484.

24 W. G. Herkstroeter, A. A. Lamola and G. S. Hammond,J. Am. Chem. Soc., 1964, 86, 4537–4540.

25 For the structure of a related diradical, see: G. Bucher, A. A. Mahajan and M. Schmittel, J. Org. Chem., 2009, 74, 5850–5860.

26 A. Iyer, A. Clay, S. Jockusch and J. Sivaguru, J. Phys. Org. Chem., 2017, 30, e3738.

27 (a) D. L. Dexter, J. Chem. Phys., 1953, 21, 836–850; (b) N. J. Turro, V. Ramamurthy and J. C. Scaiano, Modern Molecular Photochemistry of Organic Molecules; University Science, Sausalito, 2010, pp. 383–413.

28 J. Großkopf, T. Kratz, T. Rigotti and T. Bach, Chem. Rev., 2022, 122, 1626–1653.

29 P. Pracht, F. Bohle and S. Grimme, Phys. Chem. Chem. Phys., 2020, 22, 7169–7192.

30 S. Grimme, J. Chem. Theory Comput., 2019, 15, 2847–2862.

31 P. Pracht, S. Grimme, C. Bannwarth, F. Bohle, S. Ehlert, G. Feldmann, J. Gorges, M. Müller, T. Neudecker, C. Plett, S. Spicher, P. Steinbach, P. A. Wesołowski and F. Zeller, J. Chem. Phys., 2024, 160, 114110.

32 C. Bannwarth, S. Ehlert and S. Grimme, J. Chem. Theory Comput., 2019, 15, 1652–1671.

33 S. Ehlert, M. Stahn, S. Spicher and S. Grimme, J. Chem. Theory Comput., 2021, 17, 4250–4261.

34 S. Grimme, J. G. Brandenburg, C. Bannwarth and A. Hansen, J. Chem. Phys., 2015, 143, 054107.

35 S. Grimme, J. Antony, S. Ehrlich and H. Krieg,J. Chem. Phys., 2010, 132, 154104.

36 S. Grimme, S. Ehrlich and L. Goerigk, J. Comput. Chem., 2011, 32, 1456–1465.

37 H. Kruse and S. Grimme, J. Chem. Phys., 2012, 136, 154101.

38 M. Garcia-Rat´es and F. Neese, J. Comput. Chem., 2020, 41, 922–939.

39 V. Barone and M. Cossi, J. Phys. Chem. A, 1998, 102, 1995– 2001.

40 S. Grimme, Chem.–Eur. J., 2012, 18, 9955–9964.

41 C. Bannwarth, E. Caldeweyher, S. Ehlert, A. Hansen, P. Pracht, J. Seibert, S. Spicher and S. Grimme, Wiley Interdiscip. Rev.: Comput. Mol. Sci., 2021, 11, e1493.

42 F. Weigend and R. Ahlrichs, Phys. Chem. Chem. Phys., 2005, 7, 3297–3305.

43 Y. Zhao and D. G. Truhlar,J. Phys. Chem. A, 2005, 109, 5656– 5667.

44 S. Alvarez, Dalton Trans., 2013, 42, 8617–8636.

45 J. P. Reid and M. S. Sigman, Nature, 2019, 571, 343–348.

46 F. H¨ase, L. M. Roch, C. Kreisbeck and A. Aspuru-Guzik, ACS Cent. Sci., 2018, 4, 1134–1145.

47 F. M. Harvey, A. H. Heidecker, C. Merten and T. Bach, Org. Biomol. Chem., 2023, 21, 4422–4428.

48 (a) G. B. Gill and M. S. H. Idris, Tetrahedron Lett., 1985, 26, 4811–4814; (b) S. Ma, Z. Shi and Z. Yu, Tetrahedron, 1999, 55, 12137–12148; (c) S. Ma, B. Wu and Z. Shi, J. Org. Chem., 2004, 69, 1429–1431; (d) G. Nemecek, R. Thomas,

H. Goesmann, C. Feldmann and J. Podlech, Eur. J. Org Chem., 2013, 6420–6432.

49 (a) J. Li, C. Fu, G. Chen, G. Chai and S. Ma, Adv. Synth. Catal., 2008, 350, 1376–1382; (b) J. Deska and J.-E. B¨ackvall, Org. Biomol. Chem., 2009, 7, 3379–3381.

50 K. Shingu, S. Hagishita and M. Nakagawa, Tetrahedron Lett., 1967, 8, 4371–4374.

51 M. Stierle, D. Bitterlich, J. Westermayr and T. Bach; 2025, Dataset for Publication “Photochemical deracemization of2,3- allenoic acids mediated by a sensitizing chiral phosphoric acid catalyst” RADAR4Chem, DOI: 10.22000/14d69n7httd5f1yw.