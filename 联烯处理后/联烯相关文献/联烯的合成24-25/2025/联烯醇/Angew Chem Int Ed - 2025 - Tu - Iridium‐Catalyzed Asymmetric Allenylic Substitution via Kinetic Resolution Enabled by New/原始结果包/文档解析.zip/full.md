![](images/4a8e6bc1d287bc5e22517aaac4c01ad110e1569c8e52ffed5ccc59bde61670b1.jpg)

Asymmetric Catalysis Hot Paper

How to cite: Angew. Chem. Int. Ed. 2025, 64, e202506350   
doi.org/10.1002/anie.202506350

# Iridium-Catalyzed Asymmetric Allenylic Substitution via Kinetic Resolution Enabled by New Monodentate Ligands

Youshao Tu, Xiangfeng Lin, Jie Lin, Chaoshen Zhang,\* and Jianwei Sun\*

Abstract: Iridium-catalyzed asymmetric allenylic substitution represents a useful method for the construction of allenes bearing an allenylic central chirality, but current success has uniformly relied on only one specific chiral bidentate ligand. Herein, we address the limitation by the design of a new type of monodentate ligands leading to not only excellent enantiocontrol in allenylic substitution but also efficient kinetic resolution of α-allenylic alcohols, a new phenomenon never observed before in iridium-catalyzed allenylic substitution. This is also a rare demonstration of the non-enzymatic kinetic resolution of α-allenylic alcohols. A range of highly enantioenriched allenylic diarylmethanes and α-allenylic alcohols could be accessed under mild conditions. Control experiments and DFT studies indicated that this process proceeds by an S 1 pathway featuring a rate-determining ionization step followed by ligand-controlled enantiodetermining nucleophilic addition. The newly designed rigid and bulky ligands modified from SPHENOL were believed to assemble the key iridium-bound allenylic carbocation intermediate in a different complexation mode, thus serving as the origin of enantiocontrol and the unprecedented kinetic resolution.

## Introduction

Allenes represent a useful molecular platform for new reactivity discovery and synthetic applications.<sup>[1–11]</sup> Specifically, chiral allenes bearing a stereogenic center in the allenylic position are particularly versatile, owing to their viability to diverse valuable chiral building blocks that may not be straightforward to construct by other methods.<sup>[9]</sup> Catalytic asymmetric allenylic substitution of racemic electrophiles (e.g., allenylic alcohols) represents arguably one of the most direct approaches to establishing such allenylic chirality.<sup>[12–32]</sup> However, when compared with the well-established asymmetric allylic substitution processes,<sup>[33–40]</sup> the corresponding allenylic counterparts remained underdeveloped. In 2012, Ma and coworkers pioneered the first example enabled by palladium catalysis.<sup>[12]</sup> Since then, this catalytic system has been demonstrated as a useful means for the generation of allenylic stereogenic centers with high enantioselectivity and efficiency, particularly effective for the reactions between α-alkyl allenylic alcohols and soft nucleophiles.<sup>[12–18]</sup>

Recently, Carreira and coworkers pioneered the first example by iridium catalysis, featuring an outer-sphere mechanism without involving an Ir(I) Ir(III) Ir(I) cycle (Scheme 1a).<sup>[25]</sup> The iridium catalyst serves to activate the allene by η<sup>2</sup>-coordination to the terminal π-bond to facilitate the generation of a planar α-allenylic carbocation. Notably, this system is effective for both soft and hard nucleophiles (e.g., silyl enol ethers, alkyl zinc reagents, amides) as well as α-aryl allenylic alcohols.<sup>[25–32]</sup> However, despite the versatility of this system, all the current examples so far uniformly relied on one specific bidentate phosphoramidite-olefin ligand L1.<sup>[25–32,41]</sup> Notably, in the key intermediate (Scheme 1a), the two phosphoramidite moieties are located cis to each other, and the olefin motif is essential for the assembly of this well-defined chiral structure. It has also been documented that saturation or removal of this olefin unit led to dramatic change/loss of reactivity and/or stereocontrol.<sup>[25–28]</sup> Moreover, this ligand system has been completely ineffective for chiral recognition (kinetic resolution) of the racemic allene substrates, i.e., both enantiomers react at equal rates, probably due to the long distance between the iridium coordination site and the allenylic position.<sup>[25–32]</sup> Nevertheless, the kinetic resolution represents a highly attractive approach to access enantioenriched α-allenylic alcohols,<sup>[42–49]</sup> an important family of chiral building blocks in organic synthesis.<sup>[1–11]</sup> However, existing protocols for the kinetic resolution of these compounds have mainly relied on enzymatic catalysis,<sup>[42–49]</sup> with the exception of an elegant silver-catalyzed example developed by Hong and coworkers.<sup>[50]</sup> Notably, access to enantioenriched α-allenylic alcohols by asymmetric allenylic substitution remains unknown.<sup>[8,51–61]</sup>

The restriction of this useful catalytic system to a single bidentate phosphoramidite-olefin ligand, combined with its inability for effective kinetic resolution of α-allenylic alcohols, prompted us to address these limitations and further expand its synthetic utility. Herein we report our progress by designing a type of new monodentate ligands lacking the previously essential olefin motif, which enabled not only efficient asymmetric allenylic substitution but also efficient kinetic resolution of α-allenylic alcohols for the first time (Scheme 1b).

![](images/aa6c8b1430da9a030badca4be4dedb896c872e46d5917ae374e4effe6f8e65a0.jpg)  
Scheme 1. a) Introduction to iridium-catalyzed asymmetric allenylic substitution. b) Our development of an iridium-catalyzed kinetic resolution approach.

## Results and Discussion

In 2021, our laboratory reported a highly rigid spirocyclic framework, SPHENOL,<sup>[62]</sup> which combines some advantages of the established chiral catalyst backbones BINOL and SPINOL to some extent. We envisioned the possibility of using such a highly bulky and rigid structure to alter the outcomes of those reactions restricted to certain ligands or coordination modes, such as the iridium-catalyzed allenylic substitution. Initially, we tested the SPHENOL-derived monodentate phosphoramidite L2, which lacks an olefin motif, for the iridium-catalyzed allenylic substitution reaction between racemic α-allenylic alcohol 1a and 2-methylpyrrole 2a (Scheme 2). With difluoroacetic acid and 4 Å molecular sieves as additives and meta-xylene as the solvent, the reaction proceeded smoothly at 0 °C within 8 h to form the desired product 3a in 39% yield and 87% ee. Interestingly, the remaining 1a was found to be enantioenriched (84% ee). We further monitored the reaction progress and confirmed that the product ee value was almost constant, but the substrate

Scheme 2. Preliminary results.

ee value increased over time, consistent with substrate kinetic resolution and an S 1 pathway. Although the enantioselectivity was not excellent, this observation stands in sharp contrast to all the previous Ir-catalyzed allenylic substitutions where no substrate kinetic resolution was involved,<sup>[25–32]</sup> indicative of a distinct mechanistic feature and the unusual performance of our new ligands.

The encouraging preliminary results prompted us to further improve the enantioselectivity and understand the mechanism. Initially, considerable efforts were devoted to modifying the amine substituents in the phosphoramidite, but unfortunately with no improvement. We then further envisioned the possibility of tuning the dihedral angle by introducing two additional substituents at the back side of the chiral backbone (Scheme 3).<sup>[63–66]</sup> Thus, a three-step sequence was employed for the synthesis. The dienone S1, a known precursor to SPHENOL,<sup>[62]</sup> was subjected to asymmetric conjugate arylation with an aryl boronic acid in the presence of a known chiral rhodium/diene complex.<sup>[64]</sup> This reaction was robust enough to furnish almost enantiopure adduct S2 in essentially quantitative yield as a single diastereomer. With the chirality already established, the subsequent spirocyclization was expected to take place with diastereocontrol. Indeed, a racemic BINOL-derived phosphoric acid (RPA) efficiently catalyzed this step to form spirocycle S3 as a single diastereomer. Notably, when BF<sub>3</sub><sup>●</sup>OEt<sub>2</sub> was used as a promoter, a different spirocycle S3- was obtained, with its structure confirmed by X-ray crystallography.<sup>[67]</sup> Further installation of the phosphoramidite functionality on S3 was efficiently implemented to provide a series of ligands L3– L10 in almost enantiopure forms with high overall efficiency. The structure and absolute stereochemistry of L3 were determined by X-ray crystallography.<sup>[67]</sup>

The above new phosphoramides were examined as ligands for the allenylic substitution between 1a and 2a. To simplify the operation for kinetic resolution, the nucleophile loading was reduced by half. After considerable efforts in screening the ligands and other parameters (see Supporting Information for more details), ligand L3 was identified as the optimal ligand with a selectivity factor as high as 61. Both product 3a and the remaining substrate 1a were obtained in excellent enantiopurity (Table 1). Notably, under otherwise identical conditions, the previous ideal ligand L1 proved ineffective (entry 2).<sup>[25–32]</sup> Similarly, the less bulky monodentate ligand L1- led to almost no conversion as well (entry 3). It is worth noting that the combined use of difluoroacetic acid as an additive was crucial for this unusual kinetic resolution. The absence of this promoter or replacing it with other common Lewis acids, such as AgOTf, Bi(OTf) , Fe(OTf) , Zn(OTf) , and Yb(OTf) , all led to no or low conversion (entries 4 and 5). Moreover, the use of p-TsOH in place of CF HCO H led to significantly inferior results, affording 3a in low yield with almost no enantiocontrol, together with 1a- (entry 6). However, it is important to note that, during the preparation of this manuscript, Chakrabarty and Mukherjee reported a DyKAT process of similar substrates using Carreira’s ligand L1 and Sc(OTf) as an additive, but no kinetic resolution was involved.<sup>[32]</sup> We also examined Sc(OTf) in our reaction with L3 as a ligand, but 3a was not obtained (entry 7). Instead, a messy mixture was observed. This result further highlighted the unusual performance of the new ligand that likely changed the energy profiles of the key intermediates and transition states involved. Furthermore, without molecular sieves, the reaction afforded the enone product 1a- as the major product,[68] presumably resulting from initial ionization (dehydroxylation) followed by water addition to the sp-hybridized carbon (entry 8). Using other water scavengers, such as $\mathrm { N a } _ { 2 } \mathrm { S O } _ { 4 }$ and $\mathrm { { \bf M g } S O _ { 4 } } ,$ , also resulted in a decrease in selectivity. Unfortunately, the kinetic resolution efficiency could not be further improved by lowering the temperature (s 45, entry 9). Other metal complexes, such as $\mathrm { C u } ( \mathrm { a c a c } ) _ { 2 } , \mathrm { N i } ( \mathrm { O A c } ) _ { 2 } , \mathrm { C o } ( \mathrm { O A c } ) _ { 2 } , \mathrm { F e } ( \mathrm { O A c } ) _ { 2 } .$ , and $\mathrm { P d } ( \mathrm { O A c } ) _ { 2 }$ did not promote this reaction (entry 10). Finally, decreasing the catalyst loading to 1 mol% resulted in a slightly lower s factor (entry 11).

![](images/e08e645c385d7dcc05b42d9db410524f967c9b398587168ba3e833c51164b761.jpg)  
Scheme 3. Design and synthesis of new ligands.

With the established optimized conditions, we examined the generality of this unusual kinetic resolution process (Scheme 4). A range of α-allenylic alcohols bearing different substituents participated in the highly enantioselective nucleophilic substitution process and provided not only diverse α-allenylic diarylmethanes 3 but also highly enantioenriched α-allenylic alcohols 1. Substitution at the ortho-position (3c), though adjacent to the reactive site, did not affect the excellent enantiocontrol. An electron-donating group (3e and 3 g) on the aryl ring could react smoothly, but a strong electron-withdrawing group (e.g., CN) led to no reactivity. Nevertheless, an α-heteroaryl group, such as indole, furan, and thiophene, also resulted in good to excellent selectivity factors. However, if an additional substituent is present in the allene motif, no reaction was observed, presumably due to ineffective coordination with the iridium center (see Supporting Information for unsuccessful examples). Other substituted pyrroles could also serve as suitable nucleophiles (3l–3n). Moreover, it is noteworthy that this protocol is equally effective for the tertiary alcohols (1q–1v), allowing efficient C─C bond formation to construct quaternary stereocenters with good efficiency and enantioselectivity. The remaining tertiary alcohols could also be obtained in enantioenriched forms. Of note, efficient strategies to construct quaternary stereogenic centers bearing an allene and two aryl substituents remained scarce. This is also the first demonstration using Ir-catalyzed allenylic substitution. It is also worth noting that catalytic enantioselective access to highly enantioenriched α-allenylic tertiary alcohols has been rarely demonstrated with known strategies.<sup>[42–61]</sup>

Table 1: Evaluation of ligands and conditions.<sup>a)</sup>
<table><tr><td>1a +</td><td>2a</td><td>[Ir(cod)Cl]2 (2.5 mol%) (1S,3S,3&#x27;S)-L3 (10 mol%) CF₂HCO₂H (0.75 equiv)</td><td>3a +</td><td>(S)-1a</td></tr><tr><td>racemic</td><td>(0.5 equiv)</td><td>m-xylene (0.05 M) 4 A MS, 0 °C, 24 h</td><td>45% yield 92% ee</td><td>46% yield 99% ee</td></tr><tr><td colspan="5"></td></tr><tr><td></td><td colspan="3">1a&#x27;</td></tr><tr><td>Entry</td><td colspan="2">Variation of conditions</td><td>L1&#x27; Results</td><td></td></tr><tr><td>1</td><td colspan="2"></td><td>s = 61</td><td></td></tr><tr><td>2</td><td colspan="2">L1 in place of L3</td><td>&lt;10% conv</td><td></td></tr><tr><td>3</td><td colspan="2">L1&#x27; in place of L3</td><td>&lt;10% conv</td><td></td></tr><tr><td>4</td><td colspan="2"> $n _ { 0 } ~ C \mathsf { F } _ { 2 } \mathsf { H C O } _ { 2 } \mathsf { H }$ </td><td>&lt;10% conv</td><td></td></tr><tr><td>5</td><td colspan="2">Lewis acidb) instead of</td><td>&lt;10% conv</td><td></td></tr><tr><td>6</td><td colspan="2"> ${ \mathsf { C F } } _ { 2 } { \mathsf { H C O } } _ { 2 } { \mathsf { H } }$  p-TsOH in place of  ${ \mathsf { C F } } _ { 2 } { \mathsf { H C O } } _ { 2 } { \mathsf { H } }$ </td><td>3a (32%, 7% ee) 1a′</td><td></td></tr><tr><td></td><td colspan="2"></td><td>(28%)</td><td></td></tr><tr><td>7</td><td colspan="2"> $S c ( O \mathsf { T f } ) _ { 3 }$ </td><td></td><td>3a (0%), messy mixture</td></tr><tr><td>8</td><td colspan="2"> $n o 4 \mathring { A } \bowtie S$ </td><td></td><td>1a&#x27; as major product</td></tr><tr><td>9</td><td colspan="2"> $- 7 0 { } ^ { \circ } \mathsf { C }$ </td><td>s = 45</td><td></td></tr><tr><td>10 11</td><td colspan="2">other metal  $\mathsf { c a t a l y s t s ^ { c ) } }$  [Ir(cod)Cl]2 (1 mol%)d)</td><td>&lt;10% conv</td><td></td></tr></table>

<sup>a)</sup> 1a (0.1 mmol), 2a (0.05 mmol), CF HCO H (0.75 mmol), [Ir(cod)Cl] (0.025 mmol), ligand (0.1 mmol), m-xylene (2 mL), 0 °C. Yield and conversion were determined by <sup>1</sup>H NMR analysis of the crude reaction mixture using CH<sub>2</sub>Br<sub>2</sub> as the internal standard. Ee value was determined by chiral HPLC analysis. The selectivity factor (s) was calculated by the equation s  ln[(1 – conv)(1 – ee<sub>1a</sub>)]/ln[(1 – conv)(1  ee<sub>1a</sub>)]. <sup>b)</sup> The examined Lewis acids include AgOTf, Bi(OTf)<sub>3</sub>, Fe(OTf)<sub>2</sub>, $Z _ { \mathsf { n } } ( \mathsf { O T f } ) _ { 2 } ,$ and Yb(OTf)<sub>3</sub>. <sup>c)</sup> The examined other metal catalysts include Cu(acac)<sub>2</sub>, Ni(OAc)<sub>2</sub>, Co(OAc)<sub>2</sub>, Fe(OAc)<sub>2</sub>, and ${ \mathsf { P d } } ( { \mathsf { O A c } } ) _ { 2 } .$ <sup>d)</sup> Run with 4 mol% of (1S,3S,3S)-L3.

We were also curious about the reactivity of alkylsubstituted α-allenylic alcohols (Equation 1). Unfortunately, the standard protocol could not be applied (no reaction was observed). Nevertheless, the use of Ho(OTf) as an additive in place of $\mathrm { C F } _ { 2 } \mathrm { H C O } _ { 2 } \mathrm { H }$ , the reaction of 1x and 2a at $4 0 ~ ^ { \circ } \mathrm { C }$ resulted in clean formation of the desired substitution product 3x, though in moderate enantioselectivity (80% yield and 66% ee).

Moreover, free indole and N-substituted $( N { \cdot } \mathbf { M e } , \ N { \cdot } \mathbf { T s } , $ or N-Boc) indoles showed no reaction under the standard conditions. However, briefly optimization indicated that the use of La(OTf) as a co-catalyst led to good results. For example, the reaction between 1g and Nmethylindole successfully produced the desired product 3x with respectable efficiency and enantioselectivity (Equation 2). Notably, these two examples were not kinetic resolution, since the recovered substrate remained racemic. We believe the enantioconvergence was owing to the use of suitable Lewis acids that decreased the barrier for the ionization step.

![](images/e9f836b263bafe337efc0e8f41ceda15aef3920dd979082f1b32c1c0b2d44430.jpg)

To illustrate the practical application of our protocol, a 3-mmol scale reaction of 1a was performed under the standard conditions. The reaction proceeded with high efficiency to form the desired product 3a with recovery of allene substrate, both in high enantiopurity (Scheme 5a). Moreover, the α-allenylic diarylmethane products are useful precursors to other chiral building blocks (Scheme 5b). For example, the dihydroindole unit in product 3n could be easily oxidized to an indole ring (4) by p-benzoquinone. Regioselective copper-catalyzed hydroboration followed by oxidation smoothly furnished β-diaryl ketone 5.<sup>[69]</sup> Finally, Mo-catalyzed hydrosilylation<sup>[70]</sup> and Pd-catalyzed hydrogenation of 3h afforded the corresponding allyl silane 6 and 1,1-diarylbutane 7, respectively. Notably, the enantiopurity remained essentially intact in these transformations.

A series of control experiments were designed to understand the reaction mechanism (Scheme 6). In the absence of a nucleophile, subjection of enantiopure (R)-1a to the standard conditions led to almost full recovery of the α- allenylic alcohol with little erosion in enantiopurity even for 30 h (Scheme 6a). Next, the two enantiomers of 1a were separately examined for this reaction (Scheme 6b). As the matched enantiomer, (R)-1a reacted much faster than (S)-1a, forming (S)-3a (98% ee) together with (R)-1a recovered in 88% ee. However, the mismatched enantiomer (S)-1a showed almost no reactivity and no change in enantiopurity, in good agreement with the efficient kinetic resolution with a high selectivity factor. However, the failure to obtain product 3a caused difficulty in determining its absolute configuration in the mismatched case, which prevented a conclusion on the substitution mechanism (e.g., S 1 or $\mathrm { S } _ { \mathrm { N } } 2 )$ . To address this problem, we employed racemic ligand L3 for the reaction of (R)-1a, which resulted in racemic product 3a, together with recovered (R)-1a with its enantiopurity remaining intact. These findings suggested that the product stereochemistry is dictated by the chiral ligand, but not substrate, which is consistent with an $\mathrm { S } _ { \mathrm { N } } 1$ pathway.

![](images/055a0ab4c86554e36cf96c1439e5fc81208d2787b1dfada42edef5f157716721.jpg)

Scheme 4. Reaction scope.<sup>[a]</sup> [a] Reaction scale: 1 (0.5 mmol), 2 (0.25 mmol), CF HCO H (0.375 mmol), [Ir(cod)Cl] (0.125 mmol), (1S,3S,3S)-L3 (0.05 mmol), m-xylene (10 mL). Isolated yield is provided. The ee value was determined by chiral HPLC analysis. The selectivity factor was calculated by the equation $s = \mathsf { I n } [ ( 1 - \mathsf { c } ) ( 1 - \mathsf { e e } _ { 1 } ) ] / \mathsf { I n } [ ( 1 - \mathsf { c } ) ( 1 + \mathsf { e e } _ { 1 } ) ]$ , conv was determined by <sup>1</sup>H NMR analysis of the crude reaction mixture using CH Br as the internal standard. [b] Product 3 g partially decomposed on a silica gel column. Thus, the yield based on <sup>1</sup>H NMR analysis of the crude reaction mixture is provided in parentheses.

![](images/75854e0d882626846b1348eb3d2d6f9f560c1ac4b7516d683dc91ff50dedc184.jpg)  
Scheme 5. a) Large-scale reaction. b) Product transformations.

Further kinetic studies indicated that this reaction exhibits essentially 0th order in allene 1a and pyrrole 2a, and first order in catalyst [Ir/L3] (Scheme 6c). These results are consistent with a typical $\mathrm { S } _ { \mathrm { N } } 1$ pathway that has a fast nucleophilic addition step. Moreover, the catalyst irreversibly forms an adduct with the allene substrate, a situation consistent with catalyst saturation by substrate, thus showing pseudo 0th order in allene. These are also consistent with the DFT results.

Furthermore, we also attempted to obtain a catalytic active complex between iridium and L3. With different equivalents of the ligand (1 4 equiv), a stable complex that could be isolated was found to be (L3)<sub>3</sub>IrCl, a 1:3 adduct between iridium and L3, whose structure was confirmed by Xray crystallography (Scheme 7). Unfortunately, this complex showed no catalytic activity in the allenylic substitution. This observation was consistent with the DFT studies that suggested this 1:3 complex is thermodynamically stable and the 1:2 complex [Ir(L3)<sub>2</sub>] might be the catalytically active species (vide infra).

![](images/46fe9c812dd3dc3ec2e622e8b9772fe70ad12095159306ad621596ee05ee76b9.jpg)

a) No racemization of enantiopure 1a  
![](images/c7ff6789d6b07347650e6afe976801d8ad5d60a180a44da0071dcd3991b1974f.jpg)

![](images/91c95762ef631816d057cb3694355162cdd62a82efa3841692a1911165f7c741.jpg)

![](images/2cf9090fd2c438aa9a1642eade95a934fe984bffb7b7574ccb9745501a0ed2e6.jpg)  
Scheme 6. Mechanism study. a) Stability of the substrate chirality. b) Control reactions with enantiopure 1a. c) Kinetic studies.

## DFT Studies

![](images/f20555b7ac3eb9e86ba0ff49aa3fc2428bc8eef1429c6b882ccf77d040ac0edd.jpg)

To shed more light on the mechanism of the iridium-catalyzed allenylic substitution enabled by a new monodentate ligand, density functional theory (DFT) studies were performed using α-allenylic alcohol 1b and pyrrole 2a as model substrates (see Supporting Information for computational details).

![](images/9afeaf28a31dd1f0ed8e5379b352c7762f3d4d8d075dce2eeff6c45f8cd296f0.jpg)  
Scheme 7. Study of an Ir/L3 complex and its catalytic activity.

As shown in Figure 1a, the reaction begins by dissociation of the dimeric iridium complex [Ir(cod)Cl]<sub>2</sub> followed by ligand exchange with L3 and an allene substrate (see Figure S9 for details), leading to the most exoergic $\eta ^ { 2 } .$ -complex R-

![](images/ff254cc9104ee1099fbf57fff1e19e60571c27cd66cf3131f6897556ea139ab3.jpg)

![](images/948b789dcb8a3bff8526aacb3f092dc6ae933b4cafc0c558d3c20401e830141d.jpg)

IM1-trans. The two monodentate ligands L3 prefer to adopt trans relative configurations $\left( \angle \mathrm { P - I r - P } = 1 7 7 . 9 ^ { \circ } \right)$ . Notably, the corresponding cis-isomer $R – \mathbf { I M 1 } – c i s \ ( \angle \mathbf { P - I r - P } = 1 0 1 . 1 ^ { \circ } )$ is much less stable by 14.7 kcal $\mathrm { m o l ^ { - 1 } }$ , presumably due to the severe steric clash when the two bulky ligands are cis to each other. This is in sharp contrast to those previously reported Ir-catalyzed allenylic substitutions using bidentate ligand L1 featuring cis configuration of the two phosphoramidites (Scheme 1a). This may perturb the relative energies of the transition states and intermediates, which likely cause the distinct performance of L3 and unprecedented kinetic resolution. Additional conformational search on R-IM1-trans indicated that the two amine units are oriented with a dihedral angle of -116.9° (∠N P P N) to effectively avoid steric repulsions (both ligand–ligand and ligand–substrate repulsions, see Figure S10 for more details). Further structural analysis showed that the allene unit in R-IM1-trans has considerable bending $( \angle \mathbf { C } _ { 1 } - \mathbf { C } _ { 2 } - \mathbf { C } _ { 3 } = 1 4 5 . 7 ^ { \circ } )$ , with the metal center situated closer to $\mathrm { C } _ { 2 }$ than $\mathrm { C _ { 1 } }$ in the $\eta ^ { 2 } .$ -coordination $( \mathrm { I r - C } _ { 1 } = 2 . 1 5 \mathrm { \AA }$ vs. $\mathrm { I r - C } _ { 2 } = 2 . 0 4 \mathrm { \AA }$ , Figure 1a).

A proposed pathway starting from R-IM1-trans and S-IM1-trans is depicted in Figure 1b. The key step is $\mathrm { C F } _ { 2 } \mathrm { H C O } _ { 2 } \mathrm { H }$ -promoted heterolytic cleavage of the allenylic C─O bond to form an allenylic carbocation IM2-(Z,E) (Figure 1b). Notably, the Z,E terms denote the configurations of $\mathrm { C } _ { 2 } { = } \mathrm { C } _ { 3 }$ and $\mathrm { C } _ { 3 } { = } \mathrm { C } _ { 4 }$ bonds, respectively. Although various possible transition states with different permutations on the double bond configurations were computed for this step (see

![](images/d36728a5432218123a23bd7176ce4432e6bae580c3e89ec09d0a302d4277654e.jpg)  
Figure 1. Gibbs-free-energy profile (in kcal mol−<sup>1</sup>) for the kinetic resolution of racemic α-allenylic alcohol (1b) and pyrrole (2a) at the M06/6–311 G(d, p) SDD(Ir)/SMD(m-xylene)//B3LYP-D3/6–31G(d) SDD(Ir)/SMD(m-xylene) level of theory. a) Preactivation via ligand–substrate exchange. b) Free energy profile for the substitution process.

Figures S11–S13 for more details), the ionization of (R)- 1b via R-TS1-(Z,E) is energetically most favorable, with a barrier 3.1 kcal mol−<sup>1</sup> lower than that via S-TS1-(Z,E) for the enantiomer (S)-1b. This is in good agreement with the observed substrate enantioenrichment with a high selectivity factor. The involvement of a planar carbocation is consistent with the observed dictation of product stereochemistry by catalyst instead of substrate.

The following nucleophile attack by 2a to the allenylic carbocation is the enantiodetermining step. Based on DFT results, the delivery of nucleophile from the top face via R-TS2-(Z,E) has a lower barrier than from the bottom face via the transition state S-TS2-(Z,E) (see Figure S14 for the optimization details). The two pathways lead to opposite product enantiomers with a barrier difference of 4.8 kcal mol−<sup>1</sup>, which qualitatively explains the observed high enantioselectivity. Finally, facile deprotonation of R-IM3-(Z) recovers the pyrrole ring to furnish the product. Notably, an alternative S 2 pathway was also conceived, but the corresponding transition state was not found (see Figure S15 for details).

Next, structural analysis and noncovalent interactions (NCIs) analyses were performed to gain more understanding of the origin of enantioselectivity (Figure 2).<sup>[71–73]</sup> Indeed, structural analysis of the prochiral allenylic carbocation IM2- (Z,E) indicated that its si-face is more open for nucleophilic attack, whereas the re-face is blocked by the bulky naphthalene ring and the phenyl group in the ligand backbone. Moreover, NCIs analyses further confirmed that when the nucleophile approaches from the less favored re-face via S-TS2- (Z,E), it encounters substantial steric repulsion from the two aryl rings in the substrate and ligand, thus forcing them away from each other and disrupting the favorable π–π interaction (Figure 2, bottom). On the contrary, in the well-organized R-TS2-(Z,E), two π–π interactions were observed between the three aryl rings (in the allene, nucleophile, and ligand), which provide key contributions to the favorable formation of the major product enantiomer (Figure 2, top). Notably, the phenyl group in L3 introduced during ligand modification plays an important role in the above facial discrimination, which explains its better performance relative to L2.

![](images/c36cd3eb498e6b9dbe49a9f6cfec7735c67d61a81a3521cf992efdfcd8689cae.jpg)  
Figure 2. Structural analysis and noncovalent interactions analysis for the enantioselective nucleophilic attack step.

## Conclusion

A type of chiral monodentate ligand has been developed for iridium-catalyzed asymmetric allenylic substitution reactions, breaking the previous restrictions in these reactions, including the reliance on one specific bidentate phosphoramidite-olefin ligand and the incapability of kinetic resolution. Herein, efficient kinetic resolution with a high selectivity factor was achieved for the first time in this type of reaction. It also represents a rare demonstration of the non-enzymatic kinetic resolution of α-allenylic alcohols, a family of versatile chiral building blocks lacking efficient access before, particularly for those tertiary alcohols. Thus, a range of racemic allenes reacted efficiently with pyrrole nucleophiles to generate the corresponding chiral α-allenylic diarylmethanes and highly enantioenriched α-allenylic alcohols under mild conditions. The products are also useful precursors to other valuable chiral molecules. The specially designed rigid ligands, combined with difluoroacetic acid and molecular sieves as additives, constitute the key to success. Control experiments and DFT studies indicated that this process proceeds via an S 1 pathway featuring a rate-determining ionization step followed by ligand-controlled enantiodetermining nucleophilic addition. The key iridium-bound allenylic carbocation intermediate is distinct from previous reports in that the two phosphoramidite ligands are trans to each other due to severe steric repulsion, which is likely the origin of excellent enantiocontrol as well as the unprecedented kinetic resolution.

## Acknowledgements

The authors thank the National Natural Science Foundation of China (22271242, 22471232), the Hong Kong Research Grants Council (C6012-21G, 16303420, 16309321, 16304322, 16309722), and Innovation and Technology Commission (ITC-CNERC14SC01) for financial support. The authors thank Dr. Herman H. Y. Sung for assistance in structure determination by X-ray crystallography.

## Conflict ofInterests

A provisional patent has been filed.

## Data Availability Statement

The data that support the findings of this study are available in the supplementary material of this article.

Keywords: Allenes • Allenylic substitution • Chiral ligand • Iridium • Kinetic resolution

[1] Selected reviews on allenes: D. A. Taylor, Chem. Rev., 1967, 67, 317–359.

[2] R. W. Bates, V. Satcharoen, Chem. Soc. Rev. 2002, 31, 12–21.

[3] N. Krause, A. S. K. Hashmi, Modern Allene Chemistry, Wiley-VCH: Weinheim, 2004.

[4] S. Ma, Chem. Rev. 2005, 105, 2829–2872.

[5] S. Ma, Acc. Chem. Res. 2009, 42, 1679–1688.

[6] S. Yu, S. Ma, Angew. Chem. Int. Ed. 2012, 51, 3074–3112.

[7] J. Ye, S. Ma, Acc. Chem. Res. 2014, 47, 989–1000.

[8] G. Li, X. Huo, X. Jiang, W. Zhang, Chem. Soc. Rev. 2020, 49, 2060–2118.

[9] J. M. Alonso, P. Almendros, Chem. Rev. 2021, 121, 4193–4252.

[10] S. Dong, W. Cao, M. Pu, X. Liu, X. Feng, CCS Chem. 2023, 5, 2717–2735.

[11] J. M. Alonso, P. Almendros, Adv. Synth. Catal. 2023, 365, 1332– 1384.

[12] Leading examples of Pd-catalyzed asymmetric allenylic substitution with central chirality: Q. Li, C. Fu, S. Ma, Angew. Chem. Int. Ed. 2012, 51, 11783–11786.

[13] Q. Li, C. Fu, S. Ma, Angew. Chem. Int. Ed. 2014, 53, 6511–6514.

[14] J. Dai, X. Duan, J. Zhou, C. Fu, S. Ma, Chin. J. Chem. 2018, 36, 387–391.

[15] H.-C. Liu, Y.-Z. Hu, Z.-F. Wang, H.-Y. Tao, C.-J. Wang, Chem.- Eur. J. 2019, 25, 8681–8685.

[16] J. Xiao, H. Xu, X. Huo, W. Zhang, S. Ma, Chin. J. Chem. 2021, 39, 1958–1964.

[17] J. Zhang, X. Huo, J. Xiao, L. Zhao, S. Ma, W. Zhang, J. Am. Chem. Soc. 2021, 143, 12622–12632.

[18] L. Zhao, Y. Luo, J. Xiao, X. Huo, S. Ma, W. Zhang, Angew. Chem. Int. Ed. 2023, 62, e202218146.

[19] Y. Imada, K. Ueno, K. Kutsuwa, S.-I. Murahashi, Chem. Lett. 2002, 31, 140–141.

[20] B. M. Trost, D. R. Fandrick, D. C. Dinh, J. Am. Chem. Soc. 2005, 127, 14186–14187.

[21] B. Wan, S. Ma, Angew. Chem. Int. Ed. 2013, 52, 441–445.

[22] S. Song, J. Zhou, C. Fu, S. Ma, Nat. Commun. 2019, 10, 507.

[23] T. Zha, J. Rui, Z. Zhang, D. Zhang, Z. Yang, P. Yu, Y. Wang, F. Peng, Z. Shao, Angew. Chem. Int. Ed. 2023, 62, e202300844.

[24] S. Kezuka, K. Kanemoto, R. Takeuchi, Tetrahedron Lett. 2004, 45, 6403–6406.

[25] D. A. Petrone, M. Isomura, I. Franzoni, S. L. Rössler, E. M. Carreira, J. Am. Chem. Soc. 2018, 140, 4697–4704.

[26] F. Glatz, D. A. Petrone, E. M. Carreira, Angew. Chem. Int. Ed. 2020, 59, 16404–16408.

[27] M. Isomura, D. A. Petrone, E. M. Carreira, J. Am. Chem. Soc. 2021, 143, 3323–3329.

[28] M. Isomura, D. A. Petrone, E. M. Carreira, J. Am. Chem. Soc. 2019, 141, 4738–4748.

[29] A. Chakrabarty, S. Mukherjee, Angew. Chem. Int. Ed. 2022, 61, e202115821.

[30] S. Ghosh, A. Changotra, D. A. Petrone, M. Isomura, E. M. Carreira, R. B. Sunoj, J. Am. Chem. Soc. 2023, 145, 2884–2900.

[31] P. Das, D. Ghosh, S. Mukherjee, Angew. Chem. Int. Ed. 2024, e202413609.

[32] Y. Xu, H. Wang, Y. Zhou, Y. Zhou, Y. Liu, X. Feng, Chem., 2022, 8, 2011–2022.

[34] Z. Lu, S. Ma, Angew. Chem. Int. Ed. 2008, 47, 258–297.

[33] B. M. Trost, D. L. Van Vranken, Chem. Rev. 1996, 96, 395–422.

[35] C. X. Zhuo, C. Zheng, S. L. You, Acc. Chem. Res. 2014, 47, 2558– 2573.

[36] J. Fu, X. Huo, B. Li, W. Zhang, Org. Biomol. Chem. 2017, 15, 9747–9759.

[37] Q. Cheng, H.-F. Tu, C. Zheng, J.-P. Qu, G. Helmchen, S.-L. You, Chem. Rev. 2019, 119, 1855–1969.

[38] S. L. Rössler, D. A. Petrone, E. M. Carreira, Acc. Chem. Res. 2019, 52, 2657–2672.

[39] O. Pàmies, J. Margalef, S. Cañellas, J. James, E. Judge, P. J. Guiry, C. Moberg, J.-E. Bäckvall, A. Pfaltz, M. A. Pericàs, M. Diéguez, Chem. Rev. 2021, 121, 4373–4505.

[40] T. Sawano, R. Takeuchi, Catal. Sci. Technol. 2022, 12, 4100–4112.

[41] L1 was first reported by Carreira and coworkers: C. Defieber, M. A. Ariger, P. Moriel, E. M. Carreira, Angew. Chem. Int. Ed. 2007, 46, 3139–3143.

[42] K. Burgess, L. D. Jennings, J. Am. Chem. Soc. 1991, 113, 6129– 6139.

[43] D. Xu, Z. Li, S. Ma, Chem. Eu. J. 2002, 8, 5012–5018.

[44] D. Xu, Z. Li, S. Ma, Tetrahedron: Asymmetry 2003, 14, 3657– 3666.

[45] B. Yang, C. Zhu, Y. Qiu, J.-E. Bäckvall, Angew. Chem. Int. Ed. 2016, 55, 5568–5572.

[46] W. Li, Z. Lin, L. Chen, X. Tian, Y. Wang, S.-H. Huang, R. Hong, Tetrahedron Lett. 2016, 57, 603–606.

[47] C. Zhu, T. Zhang, Synlett 2024, 35, 1170.

[48] C. Manzuna Sapu, J.-E. Bäckvall, J. Deska, Angew. Chem. Int. Ed. 2011, 50, 9731–9734.

[49] J. Deska, C. Del Pozo Ochoa, J.-E. Bäckvall, Chem.-Eur. J. 2010, 16, 4447–4451.

[50] We are aware of only one example by non-enzymatic kinetic resolution, with a single demonstration on a tertiary alcohol (moderate ee): Y. Wang, K. Zheng, R. Hong, J. Am. Chem. Soc. 2012, 134, 4096–4099.

[51] X. Huang, S. Ma, Acc. Chem. Res. 2019, 52, 1301–1312.

[52] S. Ma, H. Hou, S. Zhao, G. Wang, Synthesis 2002, 2002, 1643– 1645.

[53] G. P. Boldrini, E. Tagliavini, C. Trombini, A. Umani-Ronchi, J. Chem. Soc. Chem. Comm. 1986, 9, 685–686.

[54] G. P. Boldrini, L. Lodi, E. Tagliavini, C. Tarasco, C. Trombini, A. Umani-Ronchi, J. Org. Chem. 1987, 52, 5447–5452.

[55] K. Iseki, Y. Kuroki, Y. Kobayashi, Tetrahedron: Asymmetry. 1998, 9, 2889–2894.

[56] E. J. Corey, C. M. Yu, D. H. Lee, J. Am. Chem. Soc. 1990, 112, 878–879.

[57] M. Inoue, M. Nakada, Angew. Chem. Int. Ed. 2006, 45, 252– 255.

[58] G. Xia, H. Yamamoto, J. Am. Chem. Soc. 2007, 129, 496–497.

[59] L. R. Reddy, Chem. Commun. 2012, 48, 9189–9191.

[60] M. Wang, S. Khan, E. Miliordos, M. Chen, Adv. Synth. Catal. 2018, 360, 4634–4639.

[61] Y. Kondo, K. Nagao, H. Ohmiya, Chem. Commun. 2020, 56, 7471–7474.

[62] R. Zhang, S. Ge, J. Sun, J. Am. Chem. Soc. 2021, 143, 12445– 12449.

[63] Z. Zheng, Y. Cao, Q. Chong, Z. Han, J. Ding, C. Luo, Z. Wang, D. Zhu, Q.-L. Zhou, K. Ding, J. Am. Chem. Soc. 2018, 140, 10374–10381.

[64] L. Yin, J. Xing, Y. Wang, Y. Shen, T. Lu, T. Hayashi, X. Dou, Angew. Chem. Int. Ed. 2019, 58, 2474–2478.

[65] Q. Zhou, R. Pan, H. Shan, X. Lin, Synthesis 2019, 51, 557–563.

[66] During the revision of this paper, a similar modification of SPHENOL appeared: C. Peng, C. Wang, C. Wu, J. Xing, F. Xue, X. Dou, Org. Lett. 2025, 27, 869–873.

[67] Deposition numbers 2370692 for L2, 2389417 for S3-, 2326595 for L3, and 2428300 for (L3)<sub>3</sub>IrCl, contain the supplementary crystallographic data for this paper. The data are provided free of charge by the joint Cambridge Crystallographic Data Centre and Fachinformationszentrum Karlsruhe Access Structures service.

[68] B. Alcaide, P. Almendros, S. Cembellín, T. Martínez Del Campo, Adv. Synth. Catal. 2015, 357, 1070–1078.

[69] K. Semba, M. Shinomiya, T. Fujihara, J. Terao, Y. Tsuji, Chem.- Eur. J. 2013, 19, 7125–7132.

[70] S. Asako, S. Ishikawa, K. Takai, ACS Catal. 2016, 6, 3387–3395.

[71] S. Grimme, Angew. Chem. Int. Ed. 2008, 47, 3430–3434.

[72] E. R. Johnson, S. Keinan, P. Mori-Sánchez, J. Contreras-García, A. J. Cohen, W. Yang, J. Am. Chem. Soc. 2010, 132, 6498– 6506.

[73] J. Contreras-García, E. R. Johnson, S. Keinan, R. Chaudret, J.- P. Piquemal, D. N. Beratan, W. Yang, J. Chem. Theory Comput. 2011, 7, 625–632.