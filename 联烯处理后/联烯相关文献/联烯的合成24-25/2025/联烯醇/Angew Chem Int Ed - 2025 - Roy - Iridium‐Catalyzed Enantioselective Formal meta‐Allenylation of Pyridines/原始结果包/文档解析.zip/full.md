How to cite: Angew. Chem. Int. Ed. 2025, 64, e202511571

Asymmetric Catalysis

doi.org/10.1002/anie.202511571

# Iridium-Catalyzed Enantioselective Formal meta-Allenylation of Pyridines

Pankaj Roy+, Pratibha Mahto+, and Santanu Mukherjee\*

Abstract: Site-selective functionalization of pyridines is an important yet challenging transformation. Temporary dearomatization of pyridines through redox-neutral cycloaddition has recently emerged as a reliable and attractive strategy for meta-functionalization of pyridines. Despite the amenability of the resulting bench-stable cycloadduct, oxazinopyridine, to a variety of electrophilic and radical-based reagents, its enantioselective functionalization remains unexplored. Herein, we present the first enantioselective meta-functionalization of pyridines through the intermediacy of oxazinopyridines. This highly enantioselective formal meta-allenylation of pyridines is achieved by treating the easily accessible oxazinopyridines with racemic allenylic alcohol under the combination of a catalytic amount of an Ir(I)/(P, olefin) complex and Lewis acidic Sc(OTf) followed by acid-mediated rearomatization. With oxazinopyridines derived from unsubstituted or suitably substituted pyridines, iterative 3,5-difunctionalization is possible, which also allows for the stereodivergent synthesis of all four stereoisomers of 3,5-bis-allenylic pyridines.

## Introduction

Pyridine is among the most abundant nitrogenous heterocycles in natural products,<sup>[1]</sup> pharmaceuticals,<sup>[2–4]</sup> and agrochemicals<sup>[5]</sup> (Figure 1). Pyridine derivatives also serve as ligands<sup>[6]</sup> and catalysts<sup>[7,8]</sup> in asymmetric synthesis besides acting as precursors to targets of biological and material importance.<sup>[9]</sup> Consequently, site-selective functionalization of pyridines is a highly sought-after transformation. Direct C–H functionalization is the most straightforward avenue of decorating pyridines.<sup>[10,11]</sup> The inherent electron-deficient nature of pyridines renders their ortho- and para-positions electrophilic and amenable to nucleophilic substitution (Scheme 1a).<sup>[12,13]</sup> In contrast, meta-functionalization of pyridines is challenging.<sup>[14–16]</sup> Electrophilic aromatic substitution reactions such as nitration<sup>[17]</sup> and bromination<sup>[18]</sup> of pyridines are known but require harsh reaction conditions, which restrict their application.

The adversities associated with functionalizing the metaposition of pyridines have spurred innovative strategies in recent years.<sup>[14,15]</sup> Various approaches, including directing group-assisted C–H activation,<sup>[19,20]</sup> non-directed metalation,<sup>[21–23]</sup> and temporary dearomatization of the pyridine ring,<sup>[24,25]</sup> have been explored to enable metafunctionalization, of which the latter emerged as the most attractive one (Scheme 1b). Among different temporary dearomatization strategies adopted so far,<sup>[24,26–31]</sup> the redoxneutral dearomatization of pyridine through cycloaddition is particularly noteworthy.

In 1967, Huisgen et al. reported a three-component cycloaddition of pyridine or isoquinoline with dimethyl acetylenedicarboxylate (DMAD) and phenyl isocyanate, which could be converted back to its components upon heating.<sup>[32]</sup> The Nair group further advanced this area by substituting phenyl isocyanate with other dipolarophiles, thereby expanding the scope of this reaction.<sup>[33–36]</sup>

Notwithstanding the reversibility of this cycloaddition reaction, its potential in functionalizing pyridines was not realized until recently. In 2022, Studer et al. exploited this strategy to transform pyridines into bench-stable dearomatized oxazinopyridines C, via Huisgen 1,4- dipolar cycloaddition with DMAD and methyl pyruvate (Scheme 1b).<sup>[28]</sup> These oxazinopyridines (oxazinoazines) are nucleophilic in nature by virtue of their (di)enamine character and may be viewed as meta-nucleophilic pyridine surrogates. Consequently, they have been intercepted with a variety of electrophiles and radical-based reagents prior to rearomatization to afford meta-substituted pyridines.<sup>[28,37–41]</sup> In addition, meta-sulfonylation of pyridines has also been achieved under electrochemical<sup>[42]</sup> or photochemical conditions.<sup>[43,44]</sup>

Despite their growing popularity, the application of these meta-nucleophilic pyridine surrogates in catalytic transformations is rare.<sup>[40,43]</sup> Moreover, this redox-neutral dearomatization strategy has never been applied for enantioselective functionalization of pyridines or any other azines. In fact, the only examples of enantioselective meta-functionalization of pyridines, reported by Wang et al., involve reductive dearomatization of pyridines.<sup>[45,46]</sup> These processes comprise of borane-catalyzed dearomative hydroboration of pyridines to 1,4-dihydropyridines (A, Scheme 1b) followed by Pdor Ir-catalyzed enantioselective meta-allylation and oxidative rearomatization.

![](images/06e16d43eeccf974e7470f15604975779d802cce343c064b55b8aef288968dd1.jpg)  
Figure 1. Examples of meta-functionalized pyridines bearing an adjacent stereocenter.

In an effort to expand the synthetic toolbox for enantioselective functionalization of pyridines with precise metaregioselectivity, we herein report the first enantioselective functionalization of oxazinopyridines en route to chiral metafunctionalized pyridines.<sup>[47]</sup>

As a part of our research program on enantioselective C(sp<sup>2</sup>)–H allenylation under iridium catalysis,<sup>[48,49]</sup> we became interested in introducing an allenylic substituent at the meta-position of pyridines. Ir-catalyzed allenylic substitution reaction was first reported by Takeuchi et al. in 2004.<sup>[50]</sup> However, Ir-catalyzed enantioselective allenylic substitution was pioneered by the Carreira group and was proposed to proceed via an Ir-bound allenylic carbocation intermediate.<sup>[51–53]</sup> Recent studies by our laboratory<sup>[48]</sup> and the Takeuchi group<sup>[54]</sup> demonstrated the utility of this catalyst system for Friedel–Crafts allenylation of (hetero)arenes. However, electron-deficient nature of pyridines precludes their direct application in Friedel–Crafts allenylation.

We hypothesized that the nucleophilic (di)enamine functionality of oxazinopyridines<sup>[28]</sup> can be intercepted with an Ir-bound electrophilic allenylic fragment<sup>[53]</sup> (Scheme 1c). Subsequent acid-mediated rearomatization would furnish chiral pyridine derivatives, bearing a synthetically versatile allenylic group at the meta-position.

## Results and Discussion

We embarked upon testing our hypothesis by selecting oxazinopyridine 2a, derived through dearomatization of

![](images/08feac2609ed39e73caf50d0170454803dc1e023c08da51b003b2ed2cfb5a804.jpg)  
Scheme 1. Enantioselective meta-allenylation of pyridines: The backdrop of this study.

![](images/1fce2f82e70e1d2e118c57b995dd9796ec2c4f6a5225dc71c7d2889522a1b0dd.jpg)  
Scheme 2. a) Initial studies and b) optimized protocols for meta-allenylation of pyridines.

pyridine (1a), as the model substrate (Scheme 2a).<sup>[28]</sup> Both C3 and C5 positions of 2a are nucleophilic owing to their dienamine and enamine reactivity, respectively, which gives rise to the possibility of over-allenylation. Therefore, it was imperative to identify conditions for selective monoallenylation of 2a at the outset of our investigation. The Ir(I)- complex derived in situ from a 1:2 mixture of [Ir(COD)Cl]<sub>2</sub> and Carreira’s (P, olefin) ligand<sup>[55]</sup> (S<sub>a</sub>)-L was selected as the catalyst candidate. A reaction of 2a with an excess (1.7 equiv) of racemic allenylic alcohol 3a, in the presence of 6 mol% of the $\operatorname { I r } ( \mathrm { I } ) / ( S _ { a } ) -$ L complex and 10 mol% of Sc(OTf) at $7 0 ~ ^ { \circ } \mathrm { C } .$ indeed furnished bis-allenylic oxazinopyridine 4aapredominantly in an overall 58% yield within 21 h. The exact position of the allenylic substituent in 4aa (i.e., C3 or C5), although inconsequential for the final outcome, could not be determined. Treatment of this mixture of 4aa and 4aa- with 2 M HCl in acetonitrile at $6 0 ~ ^ { \circ } \mathrm { C }$ led to rearomatization and afforded a 1:5 mixture of 3-allenylic pyridine (5aa) and 3, 5-bis-allenylic pyridine (5aa-) in 90% yield essentially as a single enantiomer for each of them (Scheme 2a, entry 1). Lowering the temperature to $4 5 ~ ^ { \circ } \mathrm { C }$ in an attempt to prevent over-allenylation proved futile, as 5aa- still formed as the major product (Scheme 2a, entry 2). However, reversing the stoichiometry of 2a and 3a reduced the extent of bisallenylation considerably. Finally, a 3:1 ratio of 2a and 3a turned out to be the optimum and favored mono-allenylation (5aa/5aa- 15:1). Under these conditions, 5aa was isolated in an overall 36% yield with >99:1 e.r. (Scheme 2a, entry 4).

Starting with these initial conditions for selective monoallenylation of 2a en route to meta-allenylic pyridine 5aa, we undertook a detailed optimization of various reaction parameters for improving the yield of 5aa (see Supporting Information). These variables included promoter, reaction medium, temperature, and initial concentration for the allenylation step as well as the choice of acid and temperature for the rearomatization step.

These studies revealed a combination of 6 mol% of the Ir(I)/(S )-L complex and 20 mol% of Sc(OTf) to be the optimum for the allenylation reaction at 70 °C in THF (Scheme 2b). Subsequent rearomatization with 4 M HCl in acetonitrile at $6 0 ^ { \circ } \mathrm { C }$ afforded meta-allenylic pyridine 5aa with >99.5:0.5 e.r. in 65% yield over two steps. It is worth noting that oxazinopyridine 2a contains two stereocenters and forms as an inseparable mixture of diastereomers (with 4.5:1 d.r.). However, the stereochemistry of 2a did not seem to have any effect on the final stereochemical outcome, since 5aa was isolated with outstanding e.r. The enantioinduction of the allenylation reaction was completely controlled by the Ir(I)/(S )-L complex.

Similarly, 3-substituted pyridines can give rise to two regioisomeric oxazinopyridines, which are inseparable. However, each of these oxazinopyridines contains only one accessible position for allenylation and upon rearomatization should converge into the same product. As expected from the reaction with 2a, catalyst controlled-enantioinduction should override the substrate control. Indeed, when oxazinopyridine 2b, derived from 3-methyl pyridine 1b, was reacted as a mixture of diastereo- and regioisomers in a 1:1.2 ratio with rac-3a, the 3-allenylic 5-methyl pyridine 5ba was isolated in 68% yield with >99.5:0.5 e.r. (Scheme 2b). Clearly, each isomer of 2b yields the same product enantiomer upon rearomatization with equally high enantioselectivity.

Having optimized the reaction conditions, the scope and limitations of meta-allenylation of pyridines were investigated. We first sought to examine the scope of pyridines in this reaction (Scheme 3). A variety of oxazinopyridines (2b-q), derived from 3-substituted pyridines, reacted efficiently with allenylic alcohol rac-3a under our optimized reaction conditions. In all these cases, the isomeric mixtures of oxazinopyridines were employed as substrate, and the corresponding meta-allenylic pyridines 5ba-qa were obtained in moderate to good yields over two steps with uniformly outstanding e.r. Electron-rich oxazinopyridines (2b-h) turned out to be superior substrates compared to most of the electron-deficient ones (2i-q), as the products with relatively higher yields were generally observed with the former. Protected functionalities on oxazinopyridines such as NHBoc (2e), OAc (2g), acetal (2l) didn’t hamper the allenylation reaction, but the protecting groups fell off under the acidic conditions employed for the rearomatization step. However, we were pleased to note that other functional groups such as amide and ketone survived all three steps.

![](images/1b54258d1a883b060e88c0fd40cb27d117050d312fad2c43790e65685deaf1e8.jpg)  
Scheme 3. Scope of azines in enantioselective formal meta-allenylation. Unless noted otherwise, the reaction conditions indicated above were followed. Yields refer to the isolated product, over two steps starting from an isomeric mixture ofoxazinopyridines after chromatographic purification. Enantiomeric ratios (e.r.) were determined by HPLC analysis using a stationary-phase chiral column. <sup>a)</sup>Starting from the corresponding tert-butyl carbamate. <sup>b)</sup>E.r. of the corresponding tert-butyl carbamate. <sup>c)</sup>Starting from the corresponding acetate. <sup>d)</sup>Starting from the corresponding ethylene glycol acetal. Reaction with 2l (0.6 mmol) and 3a (0.2 mmol). <sup>e)</sup>E.r. of the corresponding alcohol. <sup>f)</sup>Reaction with 2m (0.6 mmol) and 3a (0.2 mmol).

In the case of 2-substituted pyridines, availability of both 3- and 5-positions gives rise to the possibility of regioisomeric allenylation apart from bis-allenylation. Interestingly, oxazinopyridine 2r, derived from 2-phenyl pyridine, did not pose any regioselectivity issue and furnished 2-phenyl 5-allenylic pyridine 5ra exclusively with excellent enantioselectivity, albeit in only 32% yield. The same trend was observed with other 2-aryl pyridine-derived oxazinopyridines (2s-u). In these instances, allenylation proceeded through the dienamine functionality of the oxazinopyridine to avoid steric repulsion with the aryl substituent. To the best of our knowledge, this is the first example of enantioselective C5- functionalization of 2-aryl pyridines. Unfortunately, 2-alkyl pyridines failed to react in the Huisgen 1,4-dipolar cycloaddition step to generate oxazinopyridines and, therefore, aren’t compatible with this dearomative meta-allenylation strategy. 2-Heteroaryl pyridines furnished the desired product but in low yield (see Supporting Information).

4-Methyl pyridine-derived oxazinopyridine 2v is also amenable to allenylation under our optimized reaction conditions and led only to mono-allenylation: The 3-allenylic 4-methyl pyridine 5va was isolated in moderate yield with high enantiopurity. 5,6,7,8-Tetrahydroisoquinoline (1w) via dearomative meta-allenylation gave access to polysubstituted pyridine 5wa in decent yield.

Subsequently, we became interested in exploring other structurally related azines, such as quinoline, isoquinoline, etc., under our protocol. While the dearomatized intermediate derived from quinoline did not participate in the allenylation reaction, isoquinoline (1x) smoothly produced 4-allenylic isoquinoline 5xa in 37% yield with 95.5:4.5 e.r.

After showcasing the scope of azines, we turned to explore the scope of allenylic alcohols (Scheme 4). For this purpose, oxazinopyridine 2b, derived from 3-methyl pyridine (1b), was selected as the nucleophile. An array of electronrich (3b-d) and electron-deficient (3e-g) para-substituted aryl allenylic alcohols underwent successful substitution reaction with 3-methyl oxazinopyridine (2b) and delivered the 3- allenylic 5-methyl pyridines (5bb-bg) in moderate to good yields with uniformly high enantioselectivity. In addition, meta- and ortho-substituted allenylic alcohols (3h-m) were found to be equally competent electrophiles for this reaction and afforded the corresponding pyridine derivatives 5bhbm in good to high yields and excellent e.r. Electronic as well as steric diversity was equally accommodated across a spectrum of disubstituted aryl rings on the allenylic alcohols (3n-q). Polyaromatics (3r-t) and heterocyclic group (3u-v) on allenylic alcohols also proved to be suitable substrates for this reaction. To our delight, cyclopropyl-substituted allenylic alcohol 3w furnished the 3-allenylic pyridine 5bw in 38% yield with 92:8 e.r.

![](images/a736ed3394e8c78504a3909eceedc036b35c44f0888e3a0f4a265461c764dfdc.jpg)  
Scheme 4. Scope of allenylic alcohols. Unless noted otherwise, the reaction conditions indicated above were followed. Yields refer to the isolated product over two steps, starting from an isomeric mixture of oxazinopyridines, after chromatographic purification. Enantiomeric ratios (e.r.) were determined by HPLC analysis using a stationary phase chiral column.

![](images/f505bd389e5f5614b9cb4b8e6f148b0dabc5f3330f9955a1a8a570b38fea1eeb.jpg)  
Scheme 5. a) Scale-up synthesis and b) synthetic modifications of 5ba.

Unfortunately, products derived from alkenyl and alkynyl substituted allenylic alcohols were isolated in poor yields under our reaction conditions (see Supporting Information), which remains a limitation of the current protocol.

As expected, other combinations of oxazinoazine derivatives with allenylic alcohols can be employed in this Ir-catalyzed reaction. This aspect was demonstrated by allenylation of isoquinoline with 3,4-dichlorophenyl-substituted allenylic alcohol 3o. The resulting 4-allenylic isoquinoline 5xo was isolated with 99:1 e.r. in 41% yield over two steps (Scheme 4b).

To showcase the practicality of this protocol, a 1.0 mmol scale reaction was carried out between branched allenylic alcohol rac-3a and 3-methyl oxazinopyridine 2b, which afforded 5ba in 74% yield with a similar level of enantioselectivity (Scheme 5a).

The utility of the allene functionality was demonstrated through a few synthetic elaborations involving 5ba (Scheme 5b). Hydrogenation of the allene functionality in 5ba under catalytic Pd/C led to the formation of 3,5-dialkylated pyridine 6 in quantitative yield. Reductive ozonolysis of 5ba produced primary alcohol 7 in 78% yield, which was converted to carbamate 8 by reacting with p-bromophenylisocyanate.

![](images/04836894707d46e39bc083c7245883bf5164340fe83ac23528206479969787f3.jpg)  
Scheme 6. Sequential difunctionalization of 2-phenyl pyridine.

Even though we failed to crystallize the allenylic pyridines shown in Schemes 3 and 4 or the derivatives (6–8) shown in Scheme 5, the hydrochloride salt of 5ba, prepared by treating it with a solution of HCl in $\mathrm { E t } _ { 2 } \mathrm { O } ,$ formed diffraction quality crystals. Single crystal X-ray diffraction analysis of the pyridinium chloride 9 revealed the absolute configuration of 5ba as (R) (CCDC 2426343, Scheme 5b).<sup>[56]</sup> The absolute configuration of other pyridine derivatives reported in this article was assigned in analogy with 5ba.

Given the prevalence of multifunctional heterocycles in bioactive molecules,<sup>[2–4]</sup> systematic installation of functionalities around the pyridine core in a site-selective manner is an alluring goal. However, such a transformation, especially involving an enantioselective step, is elusive. Exclusive C3-selective allenylation of 6-phenyl oxazinopyridine (2r) intrigued us to assess the possibility of introducing a less sterically demanding electrophile adjacent to the phenyl group following enantioselective allenylation. Accordingly, when 3-allenylic 6-phenyl oxazinopyridine 4ra was subjected to a reaction with N-chlorosuccinimide (NCS) in CH Cl at 70 °C,<sup>[28]</sup> chlorination through the enamine functionality of 4ra indeed took place to yield 5-allenylic-3-chloro-2- phenylpyridine 10 after rearomatization (Scheme 6).

During the optimization studies (Scheme 2a), bisallenylation was encountered with unsubstituted oxazinopyridine 2a. Using 2.2 equiv of rac-3a in this reaction, C - symmetric 3,5-bis-allenylic pyridine 5aa- was isolated with excellent relative (>20:1 d.r.) and absolute (>99.5:0.5 e.r.) stereocontrol (Scheme 7a). The absence of meso-product indicates complete ligand control in the second allenylation and opens avenues for stereodivergent<sup>[57]</sup> iterative bisallenylation of pyridine with two different allenylic alcohols.

To achieve this goal, controlled mono-allenylation was performed using an excess of oxazinopyridine 2a for the reaction with 4-fluorophenyl allenylic alcohol rac-3f (Scheme 7b). Under our otherwise standard reaction conditions, both stereoisomers of 4af were isolated in good yield. The second allenylation of 4af with 2-naphthyl allenylic alcohol rac-3r and subsequent rearomatization afforded all four possible stereoisomers of differently substituted 3,5-bis-allenylic pyridine 11 with superb diastereo- and enantioselectivity. Overall, starting from 2a, stereodivergent synthesis of 11 was possible simply through the choice of the ligand antipode in each step.

Based on the literature reports<sup>[52,53]</sup> and our prior experimental findings,<sup>[48]</sup> a tentative catalytic cycle is depicted in Scheme 8. Activation of allenylic alcohol (rac-3) through the η<sup>2</sup>-coordination of its terminal double bond to Ir(I)/(P, olefin) complex (3 12) followed by Lewis acid-mediated ionization of the C─O bond is believed to generate Ir(I)-bound allenylic carbocation 13.<sup>[53]</sup> Due to the steric crowding at the si-face of the η<sup>2</sup>-Ir(I)-bound planar butadienylium fragment in 13 $( \mathbf { R } = \mathrm { P h } )$ , caused by the binaphthyl moiety of the axially bound (S )-L on Ir(I), nucleophilic attack of oxazinopyridine 2a is expected to occur at its sterically more accessible reface. In this enantiodetermining nucleophilic addition, the C─C bond formation can take place either from the C3 or C5 position of 2a, which would give rise to a mixture of allenylic oxazinopyridines (only 3-allenylic oxazinopyridine 4 is shown here) after deprotonation and decomplexation. For unsubstituted oxazinopyridine 2a and oxazinopyridine derived from 4-substituted pyridines, this mixture is inconsequential since acid-mediated rearomatization would generate 3-allenylic pyridine (5) and 3-allenylic 4-substituted pyridine, respectively. In the case of 4-methyl oxazinopyridine (2v), <sup>1</sup>H NMR analysis of the unpurified intermediate revealed the incorporation of the allenylic fragment at its dienamine position (i.e., at C3) (see Supporting Information). Since the formation or the absence of the other isomer (i.e., at C5) could not be confirmed from this NMR analysis, the possibility of allenylation through the enamine position of oxazinopyridines cannot be ruled out at this stage. For 3- substituted pyridines, two regioisomeric oxazinopyridines are possible. However, each of them contains only one accessible position for allenylation and upon rearomatization converges into the same product. In contrast, non-selective nucleophilic attack of oxazinopyridine derived from 2-substituted pyridine could generate a regioisomeric mixture of allenylic pyridine derivatives. However, as shown with 6-aryl oxazinopyridines 2r-u, only 2-aryl 5-allenylic pyridines (5ra-ua) were produced exclusively, arising out of the preferential dienamine reactivity of oxazinopyridines (Scheme 3). Therefore, enantioselective synthesis of regioisomeric 2-substituted 3-allenylic pyridine remains a challenge.

It must be noted that the oxazinopyridines contain two stereocenters and are used as a mixture of diastereomers in racemic form. While an inherent substrate bias over stereoinduction in the allenylation step gives rise to the likelihood of a match/mismatch scenario, powerful catalyst control rules out such a possibility, and meta-allenylic pyridines are obtained with high e.r. in each case.

## Conclusion

In conclusion, we have accomplished enantioselective metaallenylation of pyridines via their temporary redox-neutral dearomatization to easily accessible oxazinopyridines. The nucleophilic reactivity of oxazinopyridines through their dienamine-like structural feature was leveraged to achieve exclusive site-selectivity. With allenylic alcohols as electrophile, these reactions are catalyzed by a combination of ${ \mathrm { I r } } ( \mathrm { I } ) / ( P ,$ olefin) complex and Lewis acidic ${ \mathrm { S c } } ( { \mathrm { O T f } } ) _ { 3 } .$ and furnished meta-allenylic pyridines, after rearomatization under acidic conditions, in moderate to good yields and generally with excellent enantioselectivity. With oxazinopyridines derived from unsubstituted or suitably substituted pyridines, iterative 3,5-difunctionalization is possible, which also allowed for the stereodivergent synthesis of 3,5-bisallenylic pyridines with exquisite diastereo- and enantioselectivities. This is the first example of the use of oxazinopyridines in an enantioselective transformation.

![](images/cbc88476e7c40eaab7197bca08dee44c94b6cdc954aafdb21883c3482cc6bc56.jpg)  
Scheme 8. A tentative catalytic cycle for enantioselective formal meta-allenylation of pyridine.

## Acknowledgements

The funding from the Science and Engineering Research Board (SERB), New Delhi, in the form of the Science and Technology Award for Research (SERB-STAR) [Grant No. STR/2021/000009], is gratefully acknowledged. P.R. acknowledges the Ministry of Education, Government of India, for his doctoral fellowship through the Prime Minister’s Research Fellowship (PMRF) scheme. P.M. thanks IISc Bangalore for her postdoctoral fellowship. The authors thank Mr. Kishorkumar Sindogi (Central X-Ray Facility, IISc Bangalore) for his help with the X-ray diffraction analysis. High-resolution mass spectra (HR-MS) were recorded on equipment procured under the Department of Science and Technology (DST)- FIST grant [Grant No. SR/FST/CS II-040/2015].

## Conflict of Interests

The authors declare no conflict of interest.

## Data Availability Statement

The data that support the findings of this study are available in the supplementary material of this article.

Keywords: Enantioselective allenylic substitution • Iridium catalysis • meta-Functionalization • Oxazinopyridine • Pyridine

[1] D. O’Hagan, Nat. Prod. Rep. 2000, 17, 435–446.

[2] C. M. Marshall, J. G. Federice, C. N. Bell, P. B. Cox, J. T. Njardarson, J. Med. Chem. 2024, 67, 11622–11655.

[3] P. Bhutani, G. Joshi, N. Raja, N. Bachhav, P. K. Rajanna, H. Bhutani, A. T. Paul, R. Kumar, J. Med. Chem. 2021, 64, 2339–2381.

[4] E. Vitaku, D. T. Smith, J. T. Njardarson, J. Med. Chem. 2014, 57, 10257–10274.

[5] V. V. Zakharychev, A. M. Martsynkevich, Adv. Agrochem. 2025, 4, 30–48.

[6] H.-L. Kwong, H.-L. Yeung, C.-T. Yeung, W.-S. Lee, C.-S. Lee, W.-L. Wong, Coord. Chem. Rev. 2007, 251, 2188–2222.

[7] R. Kluga, A. Kinens, E. Suna, Chem. Eur. J. 2024, 30, e202301136.

[8] R. Gujjarappa, N. Vodnala, C. C. Malakar, ChemistrySelect 2020, 5, 8745–8758.

[9] G. de Ruiter, M. Lahav, M. E. van der Boom, Acc. Chem. Res. 2014, 47, 3407–3416.

[10] S. B. Mohite, Y. K. Mirza, P. S. Bera, S. Nadigar, S. Yugendhar, R. Karpoormath, M. Bera, Chem. Eur. J. 2025, 31, e202403032.

[11] S. Maity, A. Bera, A. Bhattacharjya, P. Maity, Org. Biomol. Chem. 2023, 21, 5671–5690.

[12] F.-Y. Zhou, L. Jiao, Synlett 2020, 32, 159–178.

[13] K. Murakami, S. Yamada, T. Kaneda, K. Itami, Chem. Rev. 2017, 117, 9302–9332.

[14] H. Cao, Q. Cheng, A. Studer, Angew. Chem. Int. Ed. 2023, 62, e202302941.

[15] S. Chakraborty, A. T. Biju, Angew. Chem. Int. Ed. 2023, 62, e202300049.

[16] D. E. Stephens, O. V. Larionov, Tetrahedron 2015, 71, 8683–8716.

[17] H. Suzuki, M. Iwaya, T. Mori, Tetrahedron Lett. 1997, 38, 5647– 5650.

[18] S. M. E. Englert, S. M. McElvain, J. Am. Chem. Soc. 1929, 51, 863–866.

[19] M. Wasa, B. T. Worrell, J.-Q. Yu, Angew. Chem. Int. Ed. 2010, 49, 1275–1277.

[20] G. C. Clososki, C. J. Rohbogner, P. Knochel, Angew. Chem. Int. Ed. 2007, 46, 7681–7684.

[21] T. Zhang, Y.-X. Luan, N. Y. S. Lam, J.-F. Li, Y. Li, M. Ye, J.-Q. Yu, Nat. Chem. 2021, 13, 1207–1213.

[22] L. Yang, N. Uemura, Y. Nakao, J. Am. Chem. Soc. 2019, 141, 7972–7979.

[23] M. Ye, G.-L. Gao, J.-Q. Yu, J. Am. Chem. Soc. 2011, 133, 6964– 6967.

[24] J. Lei, Z. G. Xu, Mol. Divers. 2025, 29, 849–869.

[25] C.-S. Giam, S. D. Abbott, J. Am. Chem. Soc. 1971, 93, 1294–1296.

[26] G.-Q. Sun, P. Yu, W. Zhang, W. Zhang, Y. Wang, L.-L. Liao, Z. Zhang, L. Li, Z. Lu, D.-G. Yu, S. Lin, Nature 2023, 615, 67–72.

[28] H. Cao, Q. Cheng, A. Studer, Science 2022, 378, 779–785.

[27] Z. Liu, J.-H. He, M. Zhang, Z.-J. Shi, H. Tang, X.-Y. Zhou, J.-J. Tian, X.-C. Wang, J. Am. Chem. Soc. 2022, 144, 4810–4818.

[29] B. T. Boyle, J. N. Levy, L. de Lescure, R. S. Paton, A. McNally, Science 2022, 378, 773–779.

[30] S. Wübbolt, M. Oestreich, Angew. Chem. Int. Ed. 2015, 54, 15876–15879.

[31] O. Tsuge, S. Kanemasa, T. Naritomi, J. Tanaka, Chem. Lett. 1984, 13, 1255–1258.

[32] R. Huisgen, M. Morikawa, K. Herbig, E. Brunn, Chem. Ber. 1967, 100, 1094–1106.

[33] V. Nair, A. Deepthi, D. Ashok, A. E. Raveendran, R. R. Paul, Tetrahedron 2014, 70, 3085–3105.

[34] V. Nair, A. R. Sreekanth, N. Abhilash, A. T. Biju, B. R. Devi, R. S. Menon, N. P. Rath, R. Srinivas, Synthesis 2003, 1895–1902.

[35] V. Nair, A. R. Sreekanth, A. T. Biju, N. P. Rath, Tetrahedron Lett. 2003, 44, 729–732.

[36] V. Nair, A. R. Sreekanth, N. Abhilash, M. M. Bhadbhade, R. C. Gonnade, Org. Lett. 2002, 4, 3575–3577.

[37] K. Balanna, A. Studer, J. Am. Chem. Soc. 2025, 147, 7485–7495.

[38] D. Bhattacharya, A. Studer, Angew. Chem. Int. Ed. 2025, 64, e202423512.

[39] M. Haring, K. Balanna, Q. Cheng, J. Lammert, A. Studer, J. Am. Chem. Soc. 2024, 146, 30758–30763.

[40] S.-M. Guo, P. Xu, A. Studer, Angew. Chem. Int. Ed. 2024, 63, e202405385.

[41] P. Xu, Z. Wang, S.-M. Guo, A. Studer, Nat. Commun. 2024, 15, 4121.

[42] S. Qin, M. Yang, M. Xu, Z.-H. Peng, J. Cai, S. Wang, H. Gao, Z. Zhou, A. S. K. Hashmi, W. Yi, Z. Zeng, Nat. Commun. 2024, 15, 7428.

[43] M. Yang, M. Wang, H. Zhang, S. Qin, M. Zaman, J. Luo, S. Zhan, X. Wang, C. Zhang, S. Wang, H. Gao, Z. Zhou,

A. S. K. Hashmi, W. Yi, Z. Zeng, Chem Catal. 2025, 5, 101326.

[44] Y. Ye, Z. Ye, M. Guo, X. He, C. Huang, H. Xiang, K. Chen, H. Yang, Chem. Commun. 2025, 61, 6368–6371.

[45] Z. Liu, Z.-J. Shi, L. Liu, M. Zhang, M.-C. Zhang, H.-Y. Guo, X.-C. Wang, J. Am. Chem. Soc. 2023, 145, 11789– 11797.

[46] J.-J. Tian, R.-R. Li, G.-X. Tian, X.-C. Wang, Angew. Chem. Int. Ed. 2023, 62, e202307697.

[47] An earlier version of this manuscript was deposited to Chem-Rxiv on 09 December 2024: P. Roy, P. Mahto, S. Mukherjee, ChemRxiv 2024, https://doi.org/10.26434/chemrxiv-2024-934x8.

[48] P. Das, D. Ghosh, S. Mukherjee, Angew. Chem. Int. Ed. 2024, 63, e202413609.

[49] A. Chakrabarty, K. Jaiswal, M. De, S. Mukherjee, Org. Chem. Front. 2024, 11, 5107–5115.

[50] S. Kezuka, K. Kanemoto, R. Takeuchi, Tetrahedron Lett. 2004, 45, 6403–6406.

[51] S. Ghosh, A. Changotra, D. A. Petrone, M. Isomura, E. M. Carreira, R. B. Sunoj, J. Am. Chem. Soc. 2023, 145, 2884– 2900.

[52] M. Isomura, D. A. Petrone, E. M. Carreira, J. Am. Chem. Soc. 2019, 141, 4738–4748.

[53] D. A. Petrone, M. Isomura, I. Franzoni, S. L. Rössler, E. M. Carreira, J. Am. Chem. Soc. 2018, 140, 4697–4704.

[54] T. Sawano, M. Kobayashi, M. Ishikawa, E. Ishikawa, R. Takeuchi, Org. Chem. Front. 2025, 12, 1080–1085.

[55] S. L. Rössler, D. A. Petrone, E. M. Carreira, Acc. Chem. Res. 2019, 52, 2657–2672.

[56] Deposition Number 2426343 (for 9) contains the supplementary crystallographic data for this paper. These data are provided free of charge by the joint Cambridge Crystallographic Data Centre and Fachinformationszentrum Karlsruhe Access Structures service.

[57] S. Krautwald, E. M. Carreira, J. Am. Chem. Soc. 2017, 139, 5627– 5639.