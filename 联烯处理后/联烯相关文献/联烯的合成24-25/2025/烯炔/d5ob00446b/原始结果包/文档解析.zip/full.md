PAPER

View Article Online View Journal | View Issue

Check for updates

Cite this: Org Biomol Chem , 2025, 23, 4718

Received 12th March 2025,

Accepted 9th April 2025

DOI: 10.1039/d5ob00446b

rsc.li/obc

# Base-promoted regio- and diastereoselective synthesis of tri- and tetra-substituted homoallenyl phosphine oxides via alkynyl enones†

Shaochan Zhou,<sup>a</sup> Haotian Zou,<sup>a</sup> Xianqiang Huang, \*<sup>a</sup> Jialin Qi \*<sup>a</sup> and Zhenghu Xu <sup>b,c</sup>

## Introduction

A novel base-promoted method for hydrophosphinylation of alkynyl enones with secondary phosphine oxides has been developed. Using inexpensive and commercially available potassium carbonate, a variety of functionalized tri-substituted allene products were synthesized with exclusive regio- and diastereoselectivity under mild conditions. Furthermore, a one-pot, two-step, three-component tandem hydrophosphinylation/Heck reaction eficiently produced tetra-substituted homoallenyl phosphine oxides in excellent yields, demonstrating a relatively broad substrate scope.

Allenes and their derivatives represent a distinct class of organic compounds that have garnered significant interest in recent years.<sup>1–4</sup> In particular, tri- and tetra-substituted allene compounds containing various functionalities (Scheme 1a) are receiving increasing attention due to their presence in numerous bioactive molecules.<sup>5–8</sup> As a result, several efective synthetic methodologies for multi-substituted allenes have been developed.<sup>9–16</sup> Among these synthons, alkynyl enones are readily accessible, versatile building blocks developed by Larock,<sup>17</sup> Zhan g,<sup>18–21</sup> and others.<sup>22–26</sup> 1,4-Addition to alkynyl enones provides a novel and eficient strategy for accessing functionalized allenes.<sup>27–34</sup> Xu et $a l . ^ { 3 2 }$ established a coppercatalyzed 1,4-protosilylation of α-alkynylenones to form functionalized chiral homoallenylsilanes (Scheme 1b, left). $\mathrm { Y a n g ^ { 3 1 } }$ achieved the synthesis of tri-substituted allenes through asymmetric additions of oxazolones to enynones, facilitated by chiral phosphoric acid (CPA) catalysis (Scheme 1b, right). Despite these significant contributions, there appears to be no reported instance of a 1,4-addition reaction utilizing alkynyl enones with a phosphorus nucleophile to synthesize homoallenyl phosphines.

On the other hand, organophosphorus motifs have been extensively employed in the design of chiral ligands and catalysts, as well as in medicinal and materials chemistry.<sup>35–40</sup> Hydrophosphinylation of unsaturated carbon–carbon bonds have emerged as direct and eficient strategies for constructing structures that incorporate both allenes and organophosphorus groups.<sup>41–56</sup> Recently, $\mathrm { H e } ^ { 4 7 }$ reported the reactions of α-hydroxyalkylphosphonates, acting as masked phosphonating reagents, with 1,3-enynes producing disubstituted allenes. Additionally, Ding’s group<sup>48</sup> developed a visible-light-induced radical-polar crossover 1,4-hydrophosphinylation of 1,3- enynes, enabling the formation of trisubstituted allenes featuring a phosphine oxide group. Several previous studies have attempted to establish diastereoselective processes related to the synthesis of homoallenyl phosphines. However, they typically resulted in 1 : 1 diastereoselectivity for the transformation.

![](images/9184d4443b06368896c49f985ce96907e5afbe8ef036eb76a8da3eb66e7b8b69.jpg)  
Scheme 1 Hydrofunctionalization of alkynyl enones to produce triand tetra-substituted allenes.

Thus, we aim to accomplish regio- and diastereoselective synthesis of multi-substituted homoallenyl phosphines. Given the importance of multi-substituted allenes and organophosphorus compounds, along with our focus on the transformation of alkynyl enones,<sup>22</sup> we have designed a hydrophosphinylation reaction using alkynyl enones and secondary phosphine oxides to generate tri- and tetra-substituted homoallenyl phosphines(Scheme 1c).

## Results and discussion

Alkynyl enone 1a and diphenylphosphine oxide 2a were selected to evaluate the viability of this hypothesis without any additives. In our preliminary test, the reaction successfully occurred using DCM as the solvent at room temperature (entry 1, Table 1), and the desired tri-substituted homoallenyl phosphine oxide was isolated in 25% yield without diastereoselectivity (3a/3a′ = 50/50). Encouraged by this initial result, we proceeded with screening various bases to improve both the yield and diastereoselectivity of the reaction. Both organic and inorganic bases were efective in facilitating the reaction, providing products in good to excellent yields (entries 2–4). The type and amount of base were found to significantly influence diastereoselectivity. When 4 equivalents of $\mathbf { { K } } _ { 2 } \mathbf { { C O } } _ { 3 }$ were used, the product was isolated in 92% yield with the best diastereoselectivity (88/12 dr). Reducing the equivalents of base or 2a resulted in diminished yield and diastereoselectivity (entries 5–7). Solvent screening revealed that DCM remained the best solvent (entries 8–10). When THF was used as the solvent, another diastereomer, 3a′, emerged as the major product, but the yield dropped sharply to 34% (entry 8). At present, we have not achieved satisfactory results for the isomer 3a′ (for additional optimization results, see the ESI†).

Table 1 Optimization of hydrophosphinylation reaction conditions<sup>a</sup>
<table><tr><td colspan="5">Ph O O=P O Ph Ph、 base (x eq) Ph、 Ph + -H Ph solvent, r.t. Ph Ph Ph Ph 1a 2a 3a/3a&#x27;</td></tr><tr><td>Entry</td><td>Base (x equiv.)</td><td>Solvent</td><td>Yieldb/%</td><td>dr (3a/3a′)c</td></tr><tr><td>1 2</td><td></td><td>DCM DCM</td><td>30(25)</td><td>50:50</td></tr><tr><td>3</td><td>Et3N(4 equiv.) DIPEA(4 equiv.)</td><td>DCM</td><td>68 77</td><td>67:33 67:33</td></tr><tr><td>4</td><td> ${ \bf K } _ { 2 } { \bf C O } _ { 3 } \dot { ( 4 \mathrm { \bf ~ e q u i v . ) } }$ </td><td>DCM</td><td>96(92)</td><td>88:12</td></tr><tr><td> ${ \bar { 5 } } ^ { d }$ </td><td> ${ \bf K } _ { 2 } { \bf C O } _ { 3 } ( 4 \mathrm { \ e q u i v . } )$ </td><td>DCM</td><td>85</td><td>80:20</td></tr><tr><td> $6 ^ { e }$ </td><td> $\mathrm { K } _ { 2 } \mathrm { C O } _ { 3 } \big ( 4 \ e q u i v . \big )$ </td><td>DCM</td><td>84</td><td>80:20</td></tr><tr><td> $^ 7$ </td><td> ${ \bf K } _ { 2 } { \bf C O } _ { 3 } ( 2 \mathrm { \ e q u i v . } )$ </td><td>DCM</td><td>81</td><td>75:25</td></tr><tr><td>8</td><td> $\mathrm { K } _ { 2 } \mathrm { C O } _ { 3 } \big ( 4 \ e q u i v . \big )$ </td><td>THF</td><td>34</td><td>25:75</td></tr><tr><td>9</td><td> ${ \bf K } _ { 2 } { \bf C O } _ { 3 } ( 4 \mathrm { \ e q u i v . } )$ </td><td> $\mathrm { C H } _ { 3 } \mathrm { C N }$ </td><td>96</td><td>67:33</td></tr><tr><td>10</td><td> ${ \bf K } _ { 2 } { \bf C O } _ { 3 } ( 4 \mathrm { \ e q u i v . } )$ </td><td>Toluene</td><td>64</td><td>67:33</td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr></table>

<sup>a</sup> Reaction conditions: 1a (0.2 mmol), 2a (0.8 mmol), base (x equiv.), and solvent (2 mL), at room temperature for 26 h. <sup>b</sup> Combined yields of the two diastereomers (3a and 3a′) and determined by <sup>1</sup>H NMR analysis with 1,3,5-trimethoxybenzene as an internal standard. Combined isolation for all isomers was indicated in parentheses. <sup>c</sup> Determined by <sup>1</sup>H NMR analysis of the crude reaction mixtures. <sup>d</sup> 2a (2 equiv.) was used. <sup>e</sup> 2a (3 equiv.) was used.

Following the establishment of optimised conditions, the substrate scope of base-promoted hydrophosphinylation was next investigated. As summarized in Table 2, the scope is quite broad, with reactions requiring 26 hours and yielding the corresponding tri-substituted homoallenyl phosphine oxides in good to excellent yields with good diastereoselectivities. First, the reactivities of various alkynyl enones were examined. Diverse halogens, such as F, Cl, and Br, as well as electrondonating groups like $\mathrm { C H } _ { 3 } , \mathrm { O C H } _ { 3 }$ and OTs were well tolerated in this reaction. Substrates containing a 2-naphthyl group (3i) and heterocycles such as thienyl (3f) were also compatible with the transformation, delivering corresponding allenes in 59% and 52% yields respectively. When the substituent (R<sup>2</sup>) on the ketone moiety was replaced with a methyl-substituted ketone (2l), the corresponding product 3l was obtained in an excellent yield (94%) with 57/43 diastereoselectivity. Next, a series of substituted diaryl phosphine oxides were studied to evaluate the potential for synthetic elaboration under the optimal conditions. Electron-donating substituents on the phenyl rings were compatible, yielding products (3m–3o) with 84%–98% yields and diastereomeric ratios of 56 : 44 to 78 : 22.

Table 2 Scope of alkynyl enones and diaryl phosphine oxides<sup>a,b</sup>  
![](images/703a71a10bc1e2500e9e5859f89099032fe79f888098fe84cf8b4524671be50d.jpg)  
<sup>a</sup> Standard condition: 1 (0.2 mmol), 2 (0.8 mmol), K CO (4 equiv.), and DCM (2 mL), at room temperature for 26 h. <sup>b</sup> Isolated yields were reported, and dr were determined by <sup>1</sup>H NMR analysis of the crude reaction mixtures.

Subsequently, a novel one-pot, two-step, three-component tandem hydrophosphinylation/Heck reaction was developed.<sup>57–59</sup> This reaction involves electron-deficient enynes, secondary phosphine oxides, and aryl halides to provide highly functionalized tetrasubstituted allenes (Table 3). However, the complex reaction system, characterized by numerous byproducts, an elusive reaction mechanism, and poor reaction eficiency, makes this process quite challenging. The intermolecular nucleophile, diaryl phosphine oxides, initially attacks to form an allenyl intermediate. Subsequently, the potential reaction pathway depends on the Lewis acidity of the ArPdX species generated by the oxidative addition of aryl halides with a $\operatorname { P d } ( 0 )$ catalyst. By utilising Lewis acid catalysis, several tetra-substituted homoallenyl phosphine oxides were successfully synthesised.

Herein, we report the Heck reaction of allenes, produced by hydrophosphinylation of alkynyl enones, carried out at 80 °C catalysed by 5 mol% $\mathrm { P d } ( \mathrm { P P h } _ { 3 } ) _ { 4 }$ in the presence of $\mathbf { { K } } _ { 2 } \mathbf { { C O } } _ { 3 }$ (4.0 equiv.) as a base (Table 3). The coupling reaction between 2a and 4a is performed,<sup>60–62</sup> therefore a one-pot approach is employed to progressively add reaction reagents, ensuring that the cascade reaction proceeds in a controlled manner. After careful optimization, reducing the loading of diphenylphosphine oxide to 1.5 equiv. and raising the reaction temperature to ${ 9 0 } \ { ^ { \circ } \mathrm { C } } ,$ the desired tetrasubstituted allene 5a was isolated in 80% yield. As illustrated in Table 4, a variety of structurally interesting tetra-substituted homoallenyl phosphine oxides were obtained in good yields, and the structure of 5c was unambiguously confirmed by X-ray difraction analysis.

Tri-substituted homoallenyl phosphine oxides could readily undergo various classical transformations to aford synthetically useful chiral building blocks and bioactive molecules (Scheme 2a). The gold(I)-catalyzed rearrangement of 3a pro-

Table 3 Optimization of tandem hydrophosphinylation/Heck reaction<sup>a</sup>
<table><tr><td colspan="3">Base (y eq.)</td></tr><tr><td>Entry</td><td> $2 \mathbf { a } \left( x \mathrm { e q . } \right)$ </td></tr><tr><td>1c 4 eq. 4 eq.</td><td> ${ \bf K } _ { 2 } { \bf C O } _ { 3 } \left( 4 \mathrm { ~ e q . } \right)$   ${ \bf K } _ { 2 } { \bf C O } _ { 3 } \left( 4 \mathrm { ~ e q . } \right)$ </td></tr><tr><td>2 3 4 eq.</td><td>5 eq. 40(33) 5 eq. 68  $1 0 \ { \mathrm { e q . } }$  45</td></tr><tr><td> ${ \bf K } _ { 2 } { \bf C O } _ { 3 } \left( 4 \mathrm { ~ e q . } \right)$ </td><td> $3 \ \mathrm { e q . }$  40</td></tr><tr><td>4 4 eq.  ${ \bf K } _ { 2 } { \bf C O } _ { 3 } \left( 4 \mathrm { ~ e q . } \right)$ </td><td></td></tr><tr><td>5  $1 . 5 \ { \mathrm { e q . } }$   $\mathrm { K } _ { 2 } \mathrm { C O } _ { 3 } \left( 1 . 5 \mathrm { e q . } \right)$ </td><td>5 eq. 52</td></tr><tr><td>6 1.5 eq.  $\mathbf { K _ { 2 } C O _ { 3 } } \left( 4 ~ \mathbf { e q . } \right)$ </td><td>5 eq. 82(80)</td></tr><tr><td> $1 . 5 \ { \mathrm { e q . } }$   $\mathbf { A g } _ { 2 } \mathbf { O } \left( 0 . 6 \mathrm { e q . } \right)$ </td><td>5 eq. n.d.</td></tr><tr><td>7</td><td></td></tr></table>

<sup>a</sup> Reaction conditions: 1b (0.2 mmol), 2a (x equiv.), base (y equiv.) and DCM (2 mL) were employed at room temperature for 24 h. Subsequently, iodobenzene 4a $( z \ \mathrm { e q . } ) ,$ $\mathrm { P d } ( \mathrm { P P h } _ { 3 } ) _ { 4 }$ (0.01 mmol) and $^ { 1 , 4 - }$ dioxane (2 mL) were added to the reaction solution and allowed to react at ${ \dot { 9 } } 0 \ { } ^ { \circ } { \bf C }$ for 24 hours. <sup>b</sup> Determined by <sup>1</sup>H NMR analysis with $^ { 1 , 3 , 5 }$ -trimethoxybenzene as an internal standard. Isolation was indicated in parentheses. ${ } ^ { c } 8 0 \ { } ^ { \circ } { \bf C }$ was used for the second step.

Table 4 Scope of alkynyl enones, diarylphosphineoxides and aryl a,b

![](images/8f931fb46a8c8a99ed83b62593e69916c7bf62c6ad1fd1b19fcb89c991b9ae9c.jpg)  
<sup>a</sup> Standard condition: 1 (0.2 mmol), 2 (0.3 mmol), K CO (4 equiv.) and DCM (2 mL) were employed at room temperature for 24 h. Subsequently, iodobenzene 4 (1.0 mmol), $\mathrm { P d } ( \mathrm { P P h } _ { 3 } ) _ { 4 }$ (0.01 mmol) and 1,4-dioxane (2 mL) were added to the reaction solution and allowed to react at $9 0 ~ ^ { \circ } \dot { \mathbf { C } }$ for 24 hours. <sup>b</sup> Isolated yields were reported.

![](images/be0fd61f443120a49cfd2be03f04bd1413a24a0fbb902b9c27959e81a3bf4822.jpg)

![](images/27cf49e995ce32fac83214ed83a14a01aaef2317a1bddf226214a07f9ab56459.jpg)

c) Diastereoselective transformations of tri-substituted homoallenyl phosphine oxides 3a in base  
![](images/122615820ec1f810fca800916435cddc5d0733961f946bc1a8181631e24d1820.jpg)  
Scheme 2 Synthetic application and reaction investigation.

duced the tri-substituted furan derivative 6 in 84% yield and its structure was unambiguously confirmed by X-ray difraction analysis ([eqn (1)], Scheme $2 \mathrm { a } ) . ^ { 6 3 }$ Furthermore, when treated with 1.2 equiv. of benzoyl hydrazine 7 at $6 0 \ { } ^ { \circ } \mathrm { C } ,$ 3b was transformed into the tetra-substituted 5-hydroxypyrazoline 8 in 78% yield with >20 : 1 dr ([eqn (2)], Scheme 2a). Notably, the family of 8 has been reported to possess antimicrobial,<sup>64</sup> antiinflammatory,<sup>65</sup> antimalarial,<sup>66</sup> hypolipidemic,<sup>67</sup> and analgesic activities.<sup>68</sup> To elucidate the mechanism and operative pathway of the diastereoselective 1,4-hydrophosphinylation reaction, we conducted mechanistic experiments. Monitoring the reaction progress revealed that alkynyl enones 1a essentially completed the hydrophosphinylation reaction in about 6 hours, giving only 50 : 50 diastereoselectivity. Subsequently, with the aid of the base $\mathbf { K } _ { 2 } \mathbf { C O } _ { 3 } ,$ the dr value gradually increased, with the optimum result achieved at 26 hours (Scheme 2b). After this point, the diastereoselectivity decreased precipitously, so we controlled the reaction time of alkynyl enones and diarylphosphineoxides to 26 h and tested diastereoselective transformations of tri-substituted homoallenyl phosphine oxide 3a in the presence of a base using a single isomer (Scheme 2c). The decline in dr value of tri-substituted allenes over time serves as a significant indication of the pivotal role that the base plays in the hydrophosphinylation.

![](images/0afe3318e0db380a523ec866787e54f12191746322609652142bb8d5cecc9da7.jpg)  
Scheme 3 Proposed reaction mechanism.

Based on the experimental results outlined above, the proposed mechanism is depicted in Scheme 3. Initially, R<sub>2</sub>P(O)H is deprotonated to form the phosphoryl anion A in the presence of a base. This anion then undergoes the 1,4-addition reaction with the alkynyl enone, generating the allenyl carbanion intermediate B. Intermediate B can extract a proton (H<sup>+</sup>) from SPOs, leading to the formation of the tri-substituted homoallenyl phosphine oxide 3 and the regeneration of the phosphoryl anion A. The two-component product 3 can then undergo the Heck reaction with an aryl iodide in the presence of Pd(0). The resulting aryl palladium(II) intermediate C, formed via the oxidative addition of iodobenzene, undergoes the migratory insertion with compound 3, forming the allyl– Pd complex D. Finally, the β-H elimination reaction occurs, yielding the tetra-substituted homologous phosphine oxide 5 and product E.

## Conclusions

In summary, we have successfully developed an eficient 1,4- addition of alkynyl enones under mild conditions, providing tri- and tetra-substituted homoallenyl phosphine oxides. Using only the inexpensive potassium carbonate, various functionalized tri-substituted allenes were generated in moderate to excellent yields with complete regio- and diastereoselectivity. A base-promoted and Pd(0)-catalyzed one-pot, two-step, threecomponent tandem hydrophosphinylation/Heck reaction of alkynyl enones, diarylphosphineoxides and aryl iodides resulted in tetra-substituted allenes. These simple and eficient methods further expand the synthetic potential of these scafolds in organic synthesis.

## Data availability

The authors confirm that the data supporting the findings of this study are available within the article and its ESI.†

## Conflicts of interest

There are no conflicts to declare.

## Acknowledgements

We are grateful for the financial support from the Natural Science Foundation of China and Shandong Province (no. 22402073, ZR2023QB102) as well as Special Construction Project Fund for Shandong Province Taishan Scholars. We thank Liaocheng University Structural Constituent and Physical Property Research Facilities for carrying out the NMR, mass spectra, and X-ray crystallographic analysis.

## References

1 S. Ma, Electrophilic Addition and Cyclization Reactions of Allenes, Acc. Chem. Res., 2009, 42, 1679.

2 P. Rivera-Fuentes and F. Diederich, Allene in Molekularen Materialien, Angew. Chem., Int. Ed., 2012, 51, 2818.

3 B. Alcaide, P. Almendros and C. Aragoncillo, Cyclization reactions of bis(allenes) for the synthesis of polycarbo (hetero)cycles, Chem. Soc. Rev., 2014, 43, 3106.

4 J. Singh, A. Sharma and A. Sharma, Visible light mediated functionalization of allenes, Org. Chem. Front., 2021, 8, 5651.

5 A. Hofmann–Röder and N. Krause, Synthesis and Properties of Allenic Natural Products and Pharmaceuticals, Angew. Chem., Int. Ed., 2004, 43, 1196.

6 M. DellaGreca, C. Di Marino, A. Zarrelli and B. D’Abrosca, Isolation and Phytotoxicity of Apocarotenoids from Chenopodium album, J. Nat. Prod., 2004, 67, 1492.

7 Z. Gao, Y. Li, J. P. Cooksey, T. N. Snaddon, S. Schunk, E. M. E. Viseux, S. M. McAteer and P. J. Kocienski, A Synthesis of an Ionomycin Calcium Complex, Angew. Chem., Int. Ed., 2009, 48, 5022.

8 S. Yu and S. Ma, Allenes in Catalytic Asymmetric Synthesis and Natural Product Syntheses, Angew. Chem., Int. Ed., 2012, 51, 3074.

9 S. Yu and S. Ma, How easy are the syntheses of allenes?, Chem. Commun., 2011, 47, 5384.

10 R. K. Nef and D. E. Frantz, Recent Advances in the Catalytic Syntheses of Allenes: A Critical Assessment, ACS Catal., 2014, 4, 519.

11 X. Huang and S. Ma, Allenation of Terminal Alkynes with Aldehydes and Ketones, Acc. Chem. Res., 2019, 52, 1301.

12 S. Du, A.-X. Zhou, R. Yang, X.-R. Song and Q. Xiao, Recent advances in the direct transformation of propargylic alcohols to allenes, Org. Chem. Front., 2021, 8, 6760.

13 I. T. Crouch, R. K. Nef and D. E. Frantz, Pd-Catalyzed Asymmetric β–Hydride Elimination en Route to Chiral Allenes,J. Am. Chem. Soc., 2013, 135, 4970.

14 R. K. Nef and D. E. Frantz, Cationic Alkynyl Heck Reaction toward Substituted Allenes Using BobCat: A New Hybrid Pd (0)-Catalyst Incorporating a Water-Soluble dba Ligand, J. Am. Chem. Soc., 2018, 140, 17428.

15 Y. Tang, J. Xu, J. Yang, L. Lin, X. Feng and X. Liu, Asymmetric Three-Component Reaction for the Synthesis of Tetrasubstituted Allenoates via Allenoate-Copper Intermediates, Chem, 2018, 4, 1658.

16 X. Li and J. Sun, Organocatalytic Enantioselective Synthesis of Chiral Allenes: Remote Asymmetric 1,8-Addition of Indole Imine Methides, Angew. Chem., Int. Ed., 2020, 59, 17049.

17 T. Yao, X. Zhang and R. C. Larock, AuCl -Catalyzed Synthesis of Highly Substituted Furans from 2-(1-Alkynyl)- 2-alken-1-ones,J. Am. Chem. Soc., 2004, 126, 11164.

18 D. Qian and J. Zhang, Yne-Enones Enable Diversity-Oriented Catalytic Cascade Reactions: A Rapid Assembly of Complexity, Acc. Chem. Res., 2020, 53, 2358.

19 Y. Xiao and J. Zhang, Tetrasubstituted Furans by a PdII-Catalyzed Three-Component Michael Addition/ Cyclization/Cross-Coupling Reaction, Angew. Chem., Int. Ed., 2008, 47, 1903.

20 F. Liu, Y. Yu and J. Zhang, Highly Substituted Furo[3,4- d][1,2]oxazines: Gold-Catalyzed Regiospecific and Diastereoselective 1,3-Dipolar Cycloaddition of 2-(1- Alkynyl)-2-alken-1-ones with Nitrones, Angew. Chem., Int. Ed., 2009, 48, 5505.

21 F. Liu, D. Qian, L. Li, X. Zhao and J. Zhang, Diastereo- and Enantioselective Gold(I)-Catalyzed Intermolecular Tandem Cyclization/[3 + 3]Cycloadditions of 2-(1-Alkynyl)-2-alken-1- ones with Nitrones, Angew. Chem., Int. Ed., 2010, 49, 6669.

22 J. Qi, Q. Teng, N. Thirupathi, C.-H. Tung and Z. Xu, Diastereoselective Synthesis of Polysubstituted Spirocyclopenta[c]furans by Gold-Catalyzed Cascade Reaction, Org. Lett., 2019, 21, 692.

23 V. Rauniyar, Z. J. Wang, H. E. Burks and F. D. Toste, Enantioselective Synthesis of Highly Substituted Furans by a Copper(II)-Catalyzed Cycloisomerization Indole Addition Reaction,J. Am. Chem. Soc., 2011, 133, 8486.

24 S. R. Pathipati, A. van der Werf, L. Eriksson and N. Selander, Diastereoselective Synthesis of Cyclopenta[c] furans by a Catalytic Multicomponent Reaction, Angew. Chem., Int. Ed., 2016, 55, 11863.

25 S. Liu, P. Yang, S. Peng, C. Zhu, S. Cao, J. Li and J. Sun, Gold-catalyzed sequential annulations towards 3,4-fused bi/tri-cyclic furans involving a [3 + 2 + 2]-cycloaddition, Chem. Commun., 2017, 53, 1152.

26 G. Yang, Y. Ke and Y. Zhao, Stereoselective Access to Polyfunctionalized Nine-Membered Heterocycles by Sequential Gold and Palladium Catalysis, Angew. Chem., Int. Ed., 2021, 60, 12775.

27 Y. Xiao and J. Zhang, Tetrasubstituted allenes by Pd<sup>0</sup>-catalyzed three-component tandem Michael addition/crosscoupling reaction, Chem. Commun., 2010, 46, 752.

28 H. Qian, X. Yu, J. Zhang and J. Sun, Organocatalytic Enantioselective Synthesis of 2,3-Allenoates by Intermolecular Addition of Nitroalkanes to Activated Enynes,J. Am. Chem. Soc., 2013, 135, 18020.

29 Q. Yao, Y. Liao, L. Lin, X. Lin, J. Ji, X. Liu and X. Feng, Eficient Synthesis of Chiral Trisubstituted 1,2-Allenyl Ketones by Catalytic Asymmetric Conjugate Addition of Malonic Esters to Enynes, Angew. Chem., Int. Ed., 2016, 55, 1859.

30 P. H. Poulsen, Y. Li, V. H. Lauridsen, D. K. B. Jorgensen, T. A. Palazzo, M. Meazza and K. A. Jorgensen, Organocatalytic Formation of Chiral Trisubstituted Allenes and Chiral Furan Derivatives, Angew. Chem., Int. Ed., 2018, 57, 10661.

31 J. Wang, S. Zheng, S. Rajkumar, J. Xie, N. Yu, Q. Peng and X. Yang, Chiral phosphoric acid-catalyzed stereodivergent synthesis of trisubstituted allenes and computational mechanistic studies, Nat. Commun., 2020, 11, 5527.

32 Q. Li, Z.-L. Wang, H.-X. Lu and Y.-H. Xu, Copper-Catalyzed Enantioselective 1,4-Protosilylation of Alkynylsubstituted Enones to Synthesize the Highly Diastereomeric Chiral Homoallenylsilanes, Org. Lett., 2022, 24, 2832.

33 Y. Tang, M. Huang, J. Jin, S. Sun, L. Wang, Y. Tan, X. Sun and H. Guo, Asymmetric Construction of Chiral 2-Azetines and Axially Chiral Tetrasubstituted Allenes Via Phosphine Catalysis, Angew. Chem., Int. Ed., 2024, 64, e202415787.

34 D. Bhatt, K. Miyake, S. Nakamura, H. Y. Kim and K. Oh, Photoredox-Catalyzed 1,4-Peroxidation-Sulfonylation of Enynones: A Three-Component Radical Coupling Approach for the Synthesis of Highly Functionalized Allenes, Org. Lett., 2024, 26, 2955.

35 F. Mathey, Phospha-Organic Chemistry: Panorama and Perspectives, Angew. Chem., Int. Ed., 2003, 42, 1578.

36 K. Neog and P. Gogoi, Recent advances in the synthesis of organophosphorus compounds via Kobayashi’s aryne precursor: a review, Org. Biomol. Chem., 2020, 18, 9549.

37 H. Ni, W.-L. Chan and Y. Lu, Phosphine-Catalyzed Asymmetric Organic Reactions, Chem. Rev., 2018, 118, 9344.

38 H. Guo, Y. Fan, Z. Sun, Y. Wu and O. Kwon, Phosphine Organocatalysis, Chem. Rev., 2018, 118, 10049.

39 S. J. Hecker and M. D. Erion, Prodrugs of Phosphates and Phosphonates,J. Med. Chem., 2008, 51, 2328.

40 G. P. Horsman and D. L. Zechel, Phosphonate Biochemistry, Chem. Rev., 2017, 117, 5704.

41 Y.-R. Chen and W.-L. Duan, Silver-Mediated Oxidative C-H/P-H Functionalization: An Eficient Route for the Synthesis of Benzo[b]phosphole Oxides, J. Am. Chem. Soc., 2013, 135, 16754.

42 T. Chen, C.-Q. Zhao and L.-B. Han, Hydrophosphorylation of Alkynes Catalyzed by Palladium: Generality and Mechanism,J. Am. Chem. Soc., 2018, 140, 3139.

43 S.-Z. Nie, R. T. Davison and V. M. Dong, Enantioselective Coupling of Dienes and Phosphine Oxides, J. Am. Chem. Soc., 2018, 140, 16450.

44 J. Long, Y. Li, W. Zhao and G. Yin, Nickel/Bronsted acid dual-catalyzed regio- and enantioselective hydrophosphinylation of 1,3-dienes: access to chiral allylic phosphine oxides, Chem. Sci., 2022, 13, 1390.

45 Y.-F. Qiu, S.-P. Chen, J.-H. Cao, S. Wang, J.-H. Li, M. Li, Z.-J. Quan, X.-C. Wang and Y.-M. Liang, Access to Polysubstituted Halophosphorylated Dihydrofurans via Halotrimethylsilane-Promoted Cascade Cyclization of γ– Hydroxyl Ynones with Diphenylphosphine Oxides, Org. Lett., 2022, 24, 8609.

46 Y.-Q. Zhang, X.-Y. Han, Y. Wu, P.-J. Qi, Q. Zhang and Q.-W. Zhang, Ni-catalyzed asymmetric hydrophosphinylation of conjugated enynes and mechanistic studies, Chem. Sci., 2022, 13, 4095.

47 M.-Q. Tang, Z.-J. Yang, A.-J. Han and Z.-T. He, Diastereoselective and Enantioselective Hydrophosphinylations of Conjugated Enynes, Allenes and Dienes via Synergistic Pd/Co Catalysis, Angew. Chem., Int. Ed., 2024, 64, e202413428.

48 Q. Cao, M.-M. Li, X. Mao, Q.-Q. Zhou and W. Ding, Visible-Light-Induced Regioselective Radical-Polar Crossover 1,4- Hydrophosphinylation of 1,3-Enynes: Access to Trisubstituted Allenes Bearing a Phosphine Oxide Group, Org. Lett., 2024, 26, 4678.

49 G. Hu, C. Shan, W. Chen, P. Xu, Y. Gao and Y. Zhao, Copper-Catalyzed Direct Coupling of Unprotected Propargylic Alcohols with P(O)H Compounds: Access to Allenylphosphoryl Compounds under Ligand- and Base-Free Conditions, Org. Lett., 2016, 18, 6066.

50 R. Shen, B. Luo, J. Yang, L. Zhang and L.-B. Han, Convenient synthesis of allenylphosphoryl compounds via Cu-catalysed couplings of P(O)H compounds with propargyl acetates, Chem. Commun., 2016, 52, 6451.

51 C.-H. Yang, H. Fan, H. Li, S. Hou, X. Sun, D. Luo, Y. Zhang, Z. Yang and J. Chang, Direct Access to Allenylphosphine Oxides via a Metal Free Coupling of Propargylic Substrates with P(O)H Compounds, Org. Lett., 2019, 21, 9438.

52 Q. Lin, S. Zheng, L. Chen, J. Wu, J. Li, P. Liu, S. Dong, X. Liu, Q. Peng and X. Feng, Catalytic Regio- and Enantioselective Protonation for the Synthesis of Chiral Allenes: Synergistic Efect of the Counterion and Water, Angew. Chem., Int. Ed., 2022, 61, e202203650.

53 H. Wang, H. Qian, J. Zhang and S. Ma, Catalytic Asymmetric Axially Chiral Allenyl C-P Bond Formation, J. Am. Chem. Soc., 2022, 144, 12619.

54 W.-H. Wang, Y. Wu, H.-T. Wang, P.-J. Qi, W.-N. Lan and Q.-W. Zhang, Enantioselective synthesis of P-stereogenic allenylphosphines through Ni-catalysed propargylic substitution, Nat. Synth., 2022, 1, 738.

55 X. Gu, K. Y. Ngai, W. Wang, B. Li and J. Wang, Ni-catalyzed propargylic substitution reaction: A general and versatile tool to assemble axially Article chiral phosphorus-containing allenes, Chem. Catal., 2024, 4, 100903.

56 J.-Y. Zheng, F. Wang, Y. Zhang, Z. Zheng, J. Wu, X. Ren, Z. Su, W. Chen and T. Wang, Novel Stereo-Induction Pattern in Pudovik Addition/PhosphaBrook Rearrangement towards Chiral Trisubstituted Allenes, Angew. Chem., Int. Ed., 2024, 63, e202403707.

57 I. P. Beletskaya and A. V. Cheprakov, The Heck Reaction as a Sharpening Stone of Palladium Catalysis, Chem. Rev., 2000, 100, 3009.

58 D. Mc Cartney and P. J. Guiry, The asymmetric Heck and related reactionsw, Chem. Soc. Rev., 2011, 40, 5122.

59 X.-S. Zhang, Y.-P. Han, Y. Zhang and Y. Liang, Transition-Metal-Catalyzed Transformations Involving the Heck Reaction, Adv. Synth. Catal., 2023, 365, 2436.

60 K. Xu, F. Yang, G. Zhang and Y. Wu, Palladacycle-catalyzed phosphonation of aryl halides in neat water, Green Chem., 2013, 15, 1055.

61 Y. Zhang, H. He, Q. Wang and Q. Cai, Asymmetric synthesis of chiral P-stereogenic triaryl phosphine oxides via Pd-catalyzed kinetic arylation of diaryl phosphine oxides, Tetrahedron Lett., 2016, 57, 5308.

62 J. Kang, K. Ding, S. Ren and B. Su, Copper-Catalyzed Dynamic Kinetic Asymmetric P-C Coupling of Secondary Phosphine Oxides and Aryl Iodides, Angew. Chem., Int. Ed., 2023, 62, e202301628.

63 S. Guo, J. Wang, D. Guo, X. Zhang and X. Fan, Highly regioselective and practical synthesis of 1-acyl-5-hydroxypyrazolines and 1-acyl pyrazoles from 1,2-allenic ketones and hydrazides, Tetrahedron, 2012, 68, 7768.

64 Y. Zhao, A. Bacher, B. Illarionov, M. Fischer, G. Georg, Q.-Z. Ye, P. E. Fanwick, S. G. Franzblau, B. Wan and M. Cushman, Discovery and Development of the Covalent Hydrates of Trifluoromethylated Pyrazoles as Riboflavin Synthase Inhibitors with Antibiotic Activity Against Mycobacterium tuberculosis, J. Org. Chem., 2009, 74, 5297.

65 P. D. Sauzem, P. Machado, M. A. Rubin, G. Da, S. Sant’Anna, H. B. Faber, A. H. De Souza, C. F. Mello, P. Beck, R. A. Burrow, H. G. Bonacorso, N. Zanatta and M. A. P. Martins, Design and microwave-assisted synthesis of 5-trifluoromethyl-4,5-dihydro-1H-pyrazoles: Novel agents with analgesic and anti-inflammatory properties, Eur.J. Med. Chem., 2008, 43, 1237.

66 W. Cunico, C. A. Cechinel, H. G. Bonacorso, M. A. P. Martins, N. Zanatta, M. V. N. De Souza, I. O. Freitas, R. P. P. Soares and A. U. Krettli, Antimalarial

activity of 4-(5-trifluoromethyl-1H-pyrazol-1-yl)chloroquine analogues, Bioorg. Med. Chem. Lett., 2006, 16, 649.

67 G. A. Idrees, O. M. Aly, G. E.-D. A. A. Abuo-Rahma and M. F. Radwan, Design, synthesis and hypolipidemic activity of novel 2-(naphthalen-2-yloxy)propionic acid derivatives as desmethyl fibrate analogs, Eur.J. Med. Chem., 2009, 44, 3973.

68 P. Machado, P. T. Campos, G. R. Lima, F. A. Rosa, A. F. C. Flores, H. G. Bonacorso, N. Zanatta and M. A. P. Martins, Experimental and calculated structural parameters of 5-trihalomethyl-4,5-dihydro-1H-pyrazole derivatives, novel analgesic agents, J. Mol. Struct., 2009, 917, 176.