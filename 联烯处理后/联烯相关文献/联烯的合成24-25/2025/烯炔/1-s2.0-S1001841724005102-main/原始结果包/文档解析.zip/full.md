# Copper-catalyzed 1,4-silylcyanation of 1,3-enynes: A silyl radical-initiated approach for synthesis of difunctionalized allenes

![](images/41faea9ac5d2c5866789bd665ae875701b69732f29eb93c8633933daaa4bcfbe.jpg)

Qi Li<sup>1</sup>, Zi-Lu Wang<sup>1</sup>, Yun-He Xu∗

Department of Chemistry, University of Science and Technology of China, Hefei 230026, China

## a r t i c l e i n f o

Article history:   
Received 12 January 2024   
Revised 24 April 2024   
Accepted 10 May 2024   
Available online 11 May 2024

Keywords:   
Copper-catalyst   
Unactivated enynes   
1,4-Difunctionalization   
Radical silylation   
Cyanation

## a b s t r a c t

Herein, we developed the first example of copper-catalyzed silicon radical-initiated 1,4-silylcyanation of unactivated 1,3-enynes, which provided an eficient method to access CN-bearing tri- and tetrasubstituted homoallenylsilane derivatives in high yields with excellent regioselectivities. This protocol featured good functional group compatibility and broad substrate scopes, enabling the formation of C-Si bond under cheap copper catalyst with a low loading. Furthermore, this means showed potential application value in the late-stage functionalization of natural products.

© 2025 Published by Elsevier B.V. on behalf of Chinese Chemical Society and Institute of Materia Medica, Chinese Academy of Medical Sciences.

Allenes are important synthetic blocks in organic synthesis due to their unique chemical structure, which are widely found in natural products, pharmaceutical molecules and functional organic materials [1–7]. In the past few decades, continuous efforts have been devoted to their diversified synthesis. Traditional methods for the synthesis of allenes including the isomerization of alkynes [8,9], elimination [10,11], substitution [12,13], rearrangement [14,15], and 1,4-addition to enynes, etc. [16–18], usually introduce only one functional group into allene products. Recently, the catalytic 1,4-difunctionalization of 1,3-enynes has attracted widespread attention as a powerful tool for the one-step preparation of multi-functionalized allenes. Notably, 1,3-enynes can be broadly categorized into two types based on their reactivity: unactivated enynes (enynes with aryl, alkyl, or hydrogen substitutions) and activated enynes (1,3-enynes with a C–C double bond or triple bond attached to an electron-withdrawing group). Among these two types, unactivated enynes are relatively easy to synthesize. However, they often encounter various challenges, including lower reactivity, inferior regioselectivity, and an increased likelihood of side reactions. Therefore, the 1,4-difunctionalization of unactivated 1,3-enynes has always been one of the research hot topics. During the past period, many effective methodologies have been successfully developed, enabling facile 1,4-difunctionalization of unactivated 1,3-enynes via different allenyl intermediates pathway. Compared with the allenyl ions [19–23], allenyl radical mode represents one of the most eficient novel strategies [24–27]. On the other hand, the introduction of the cyano group into organic molecules is significant in organic synthesis [28,29], and reports from Liu [30], Bao [31,32], Ma [33], and others groups [34–36], demonstrated the practicality of 1,4-difunctionalization of unactivated 1,3-enynes via a radical cyanation. However, most of these studies are focused on alkyl or fluoroalkyl radical, and silyl radical remains elusive (Scheme 1a).

Silyl radicals are common intermediates in the formation of organosilicon compounds [37–39]. Homoallenylsilane compounds possess highly potential worth as important organosilicon synthons in organic synthesis [40,41]. In this research field, we have developed some convenient methods to synthesize various homoallenylsilane derivatives applying 1,4-protosilylation of enynes [42,43]. Unfortunately, the necessity of using activated 1,3-enynes, the dificulty to obtain tetrasubstituted allenes, and the requirement of expensive PhMe Si-Bpin still motivated us to tackle these challenges. In 2017, we also reported a copper-catalyzed 1,2- silylperoxidation of 1,3-enynes via a silyl radical pathway [44]. The silyl radical 1,4-addition of 1,3-enynes has not been explored (Scheme 1b). Thus, this study focused to demonstrate whether the 1,4-silylcyanation via silyl radicals would become a complementary approach to overcome aforementioned limitations of previous works. Based on this idea, herein we would like to report the results of copper-catalyzed silyl radical-initiated 1,4-silylcyanation of unactivated 1,3-enynes to synthesize CN-bearing tri- or tetrasubstituted homoallenylsilane products (Scheme 1c).

Generally, the generation of silicon radicals plays an important role on radical silylation reaction, thus different free-radical initia) Transition metal-catalyzed 1,4-difunctionalization of 1,3-enynes via radical pathway

![](images/97f031511454c3129d87d2f7e56c814aee00dc7159353fcc156ebc6a5c56e438.jpg)  
b) Previous work (difficult to achieve 1,4-silylation of unactivated 1,3-enynes)

![](images/dbb41d1eeffde92c7917ec746f55a8f3bdbd18b725e721b19ef15e6b9f5801db.jpg)  
c) This work: copper-catalyzed silyl radical-initiated 1,4-silylcyanation of unactivated 1,3-enynes

![](images/607fc260901f2b3da7afbd0628564d5a5e658605eaf49fdda0fd2da92c87aa49.jpg)  
Scheme 1. 1,4-Difunctionalization of unactivated 1,3-enynes.

ation pathways were firstly investigated. The use of peroxide as the radical initiator in metal-free conditions was unsuccessful for this 1,4-silylcyanation reaction (Table 1, entry 1). Transition-metalinduced peroxide decomposition initiated radical silylation representing an appealing way to access free silicon radical, hence different catalysts were evaluated. The desired product 3 was obtained in an encouraging yield (33%) when CuO was selected as the catalyst in the presence of 1,10-phenanthroline as ligand (entry 3). Delightly, when Ph SiH with lower Si-H bond dissociation energy was used as silicon radical precursor, the yield of target product 3 was improved to 53% even at lower reaction temperature (entry 4). This result illustrated the important influence of the generation of silicon radicals on this reaction. Basis on this outcome, other copper salts were also screened (entries 4–8), and CuCN was found to be the best choice (entry 7). Then, other peroxides including DTBP, TBPB, BPO were examined, but no better results were obtained (entries 9–11). To adjust the electron-donor capacity of copper catalyst, different diazo ligands were tested, but the results were not satisfactory. To enhance the formation eficiency of silicon radicals, (TMS) SiH with lower Si-H bond dissociation energy than Ph SiH was applied as silicon radical precursor. As expected, the yield of product 3 was improved to 86% (entry 15). Moreover, reducing the amount of (TMS) SiH to 2.0 equiv. gave similar result even at lower catalyst loading (1 mol%) (entry 16). Slightly higher yield was delivered when the reaction was performed on 50 °C (entry 17). In the absence of ligand, no desired product was obtained, and 1,2- silylperoxidation product was formed in 25% yield (entry 19).

With the optimal reaction conditions in hand, we next turned our attention to investigating the substrate scope of 1,3-enynes (Scheme 2). In general, a library of mono- or disubstituted 1,3- enynes bearing different substituents were competent in this transformation, affording the corresponding tri- or tetrasubstituted allene derivatives in good to excellent yields (3a-3ac). The variation of $\mathsf { R } ^ { 1 }$ was investigated and whether $\mathsf { R } ^ { \bar { 1 } }$ was an aryl or alkyl substitute groups, the target products were obtained in high yields. A series of electron-withdrawing (Cl, CF<sub>3</sub>) or electron-donating (Me, OMe) groups on the phenyl ring were well tolerated, and provided the target products in excellent yields (3b-3f). Besides, free hydroxyl group, amides or ester group were also tolerated (3j, 3k, 3m, 3n). Similarly, when $\mathsf { R } ^ { 2 }$ was replaced with other aryl- or alkyl groups, the corresponding allene derivatives were afforded in good yields (3o-3t). In addition, activated 1,3-enynes were also compatible in this reaction, and the desired products were furnished in satisfactory yields (3u-3z). Furthermore, the synthesis of trisubstituted homoallenylsilanes was also explored, and the products 3aa, 3ab, and 3ac were formed from the corresponding monosubstituted 1,3-enynes in moderate yields under the standard conditions.

Subsequently, the silanes substrate compatibility was also examined. The results indicated that different tertiary silanes were well tolerated under the optimal conditions, delivering the corresponding allene derivatives in moderate yields (3ba-3ga). However, primary and secondary silanes were not competent silylation reagents under this condition. This phenomenon was probably caused by the higher bond dissociation energy (BDE) of Si-H bond of primary and secondary silanes. In addition, the pres-

![](images/9a04f391c050b75efcdf0f1d292ac5539613aae55115b92abd71b55dffee7b55.jpg)  
Scheme 2. Substrate scope of copper-catalyzed 1,4-silylcyanation of 1,3-enynes. Unless otherwise noted, reaction was run under the following reaction conditions: 1 (0.4 mmol), HSi(TMS)<sub>3</sub> (0.8 mmol), CuCN (1 mol%), phen (1.1 mol%), TBHP (0.8 mmol, 70% in H<sub>2</sub>O), TMSCN (0.8 mmol) in 2.0 mL of acetone at 50 °C for 12 h under argon atmosphere. Isolated yield. <sup>a</sup> 1a (0.2 mmol), silane (1.0 mmol), CuCN (5 mol%), L (5.5 mol%), TBHP (0.6 mmol, 70% in H O), TMSCN (0.6 mmol) in 1.0 mL of acetone at 60 °C for 12 h under argon atmosphere.

Optimization of reaction conditions.<sup>a</sup>

![](images/d4c4a5cb5b4ec492291bed5fff990bd7fb772677dbdec1cdd893fd44dd3b5897.jpg)

<table><tr><td>Entry</td><td>[Cu]</td><td>Silane (2)</td><td>L</td><td>Peroxide</td><td>T (C)</td><td>Yield b (%)</td></tr><tr><td>1</td><td>1</td><td>HSiEt{3</td><td> $\mathbf { L } _ { 1 }$ </td><td>TBHP</td><td>85</td><td>0</td></tr><tr><td>2</td><td> $\mathrm { F e } ( \mathrm { O T f } ) _ { 2 }$ </td><td> $\mathrm { H S i E t } _ { 3 }$ </td><td> $\mathbf { L } _ { 1 }$ </td><td>TBHP</td><td>85</td><td>0</td></tr><tr><td>3</td><td>CuO</td><td> $\mathrm { H S i E t } _ { 3 }$ </td><td> $\mathbf { L } _ { 1 }$ </td><td>TBHP</td><td>85</td><td>33</td></tr><tr><td>4</td><td>CuO</td><td> $\mathrm { H S i P h } _ { 3 }$ </td><td> $\mathbf { L } _ { 1 }$ </td><td>TBHP</td><td>60</td><td>53</td></tr><tr><td>5</td><td>CuOAc</td><td> $\mathrm { H S i P h } _ { 3 }$ </td><td> $\mathbf { L } _ { 1 }$ </td><td>TBHP</td><td>60</td><td>45</td></tr><tr><td>6</td><td> $\mathrm { C u ( C H _ { 3 } C N ) _ { 4 } P F _ { 6 } }$ </td><td> $\mathrm { H S i P h } _ { 3 }$ </td><td> $\mathbf { L } _ { 1 }$ </td><td>TBHP</td><td>60</td><td>53</td></tr><tr><td>7</td><td>CuCN</td><td> $\mathrm { H S i P h } _ { 3 }$ </td><td> $\mathbf { L } _ { 1 }$ </td><td>TBHP</td><td>60</td><td>63</td></tr><tr><td>8</td><td>Cu(OAc)₂</td><td> $\mathrm { H S i P h } _ { 3 }$ </td><td> $\mathbf { L } _ { 1 }$ </td><td>TBHP</td><td>60</td><td>43</td></tr><tr><td>9</td><td>CuCN</td><td> $\mathrm { H S i P h } _ { 3 }$ </td><td> $\mathbf { L } _ { 1 }$ </td><td>DTBP</td><td>60</td><td>0</td></tr><tr><td>10</td><td>CuCN</td><td> $\mathrm { H S i P h } _ { 3 }$ </td><td> $\mathbf { L } _ { 1 }$ </td><td>TBPB</td><td>60</td><td>21</td></tr><tr><td>11</td><td>CuCN</td><td> $\mathrm { H S i P h } _ { 3 }$ </td><td> $\mathbf { L } _ { 1 }$ </td><td>BPO</td><td>60</td><td>15</td></tr><tr><td>12</td><td>CuCN</td><td> $\mathrm { H S i P h } _ { 3 }$ </td><td> $\mathbf { L } _ { 2 }$ </td><td>TBHP</td><td>60</td><td>58</td></tr><tr><td>13</td><td>CuCN</td><td> $\mathrm { H S i P h } _ { 3 }$ </td><td> $\mathbf { L } _ { 3 }$ </td><td>TBHP</td><td>60</td><td>15</td></tr><tr><td>14</td><td>CuCN</td><td>HSiPh3</td><td> $\mathbf { L } _ { 4 }$ </td><td>TBHP</td><td>60</td><td>33</td></tr><tr><td>15</td><td>CuCN</td><td> ${ \mathrm { H S i } } ( { \mathrm { T M S } } ) _ { 3 }$ </td><td> $\mathbf { L } _ { 1 }$ </td><td>TBHP</td><td>60</td><td>86</td></tr><tr><td>16</td><td>CuCN</td><td> ${ \mathrm { H S i } } ( { \mathrm { T M S } } ) _ { 3 }$ </td><td> $\mathbf { L } _ { 1 }$ </td><td>TBHP</td><td>60</td><td>88c</td></tr><tr><td>17</td><td>CuCN</td><td> ${ \mathrm { H S i } } ( { \mathrm { T M S } } ) _ { 3 }$ </td><td> $\mathbf { L } _ { 1 }$ </td><td>TBHP</td><td>50</td><td>92/88c,d</td></tr><tr><td>18</td><td>CuCN</td><td>HSi(TMS)3</td><td> $\mathbf { L } _ { 1 }$ </td><td>TBHP</td><td>40</td><td>78c</td></tr><tr><td>19</td><td>CuCN</td><td>HSi(TMS)3</td><td>1</td><td>TBHP</td><td>80</td><td>0e</td></tr></table>

<sup>a</sup> Unless otherwise noted, reaction was run under the following reaction conditions: 1a (0.2 mmol), silane (1.0 mmol), [Cu] (5 mol%), L (7 mol%), TBHP (0.6 mmol, 70% in H O), TMSCN (0.6 mmol) in 1.0 mL of acetone at different temperatures for 12 h under argon atmosphere.  
<sup>b</sup> Yield was determined by <sup>1</sup>H NMR.  
<sup>c</sup> 1a (0.4 mmol), HSi(TMS)<sub>3</sub> (0.8 mmol), CuCN (1 mol%), L<sub>1</sub> (1.1 mol%), TBHP (0.8 mmol, 70% in H<sub>2</sub>O), TMSCN (0.8 mmol) in 2.0 mL of acetone at different temperatures for 12 h under argon atmosphere.  
<sup>d</sup> Isolated yield.  
<sup>e</sup> 1,2-Silylperoxidation product was observe in 25% yield.

ence of multiple Si-H bonds may have caused additional undesired side-reaction. To further demonstrate the practicability of the current method, we studied the 1,4-silylcyanation of 1,3-enynes for the late-stage functionalization of biologically active molecules and natural products. A number of 1,3-enynes derived from menthol, dihydrocholesterol, and estrone reacted smoothly, producing the corresponding allene derivatives in high eficiency (3ae-3ag).

![](images/8364efa85dc9f7dec81e83770bc477daa8d9889ba3b0ea313ddb4e7d9080db26.jpg)  
Scheme 3. Scale up and derivatization experiments.

Next, the copper-catalyzed 1,4-silylcyanation of 1a was carried out smoothly in a gram scale without obvious diminishment in yield (Scheme 3A). To showcase the synthetic utility of this method, further derivatizations of the silylcyanation products were conducted based on the transformations of allene fragment (Scheme 3B). For example, the product 3a reacted smoothly with bis(pinacolato)diboron under the copper-catalyzed protoborylation conditions, and provided protoborylation product 4a in 94% yield. In addition, homoallenylsilanes could also be used as a powerful precursor to construct butadienyl fragments. For example, treatment of 3a with NIS led to the formation of butadienyl derivative 5a in high yield and 3da could also be readily converted into butadienyl derivative 6a in moderate yield in the presence of ${ \mathrm { C O } } _ { 2 }$ as an electrophile.

![](images/eb3ae236387bb17bb0ae8609884a9bbd0a742cfcf2e02306be6a23f0c1f9cfc2.jpg)

![](images/3c6d4977eda6c4f6c027cef591c4d8c7c11bff811c2ff853bdf3522bd17ce6d9.jpg)  
Scheme 4. Mechanistic experiments.

![](images/bd099c5d3c4f95dafc852ba6d0d23228015a99f74740f5917c489a0e85ce7ca3.jpg)  
Scheme 5. Plausible mechanism.

Several control experiments were performed to gain further insight into the reaction mechanism. When the reaction was run in the presence of the radical trapper TEMPO, the 1,4-silylcyanation was completely inhibited. Meanwhile, in this reaction system, the TEMPO-trapped products 7 and 8 could be detected by HRMS (high resolution mass spectrometry), which comfirmed the formation of silicon radical and allene radical species during the reaction (Scheme 4a). Moreover, compound 9 was used to perform the radical clock experiment under the standard reaction conditions. This reaction proceeded smoothly and generated the ring-opened product 10 in 78% yield (Scheme 4b). This result further demonstrated that the reaction indeed prodeed through a silyl radical pathway.

On the basis of abovementioned experimental results and previous literature studies, a plausible mechanism was proposed (Scheme 5). Initially, tert–butoxyl radical species was generated from the single-electron-transfer (SET) process between TBHP and Cu(I) catalyst. Then, the tert–butoxyl radical would abstract the H atom from the ${ \mathrm { H S i } } ( { \mathrm { T M S } } ) _ { 3 }$ to form the silicon radical. Silicon radical intermediate then reacted with 1,3-enyne 1 to give a propargyl radical intermediate III. Owing to the significant steric hindrance of the tertiary propargyl radical, propargyl radical III rapidly resonated with allenyl radical IV [33,45,46]. This process led to the coupling of intermediate II, formed by ligand exchange of intermediate I with TMSCN, with allenyl radical IV, resulting in the formation of allenyl copper(III) intermediate V. The subsequent reductive elimination of V produced the desired product 3, along with the regeneration of the catalytically active Cu(I) species.

In summary, we developed an eficient copper-catalyzed 1,4- silylcyanation of conjugated enynes via a silyl radical pathway. Under the mild reaction conditions, various tri- and tetra-substituted homoallenylsilane products could be obtained in good yields with high regioselectivity by using trace amount of cheap copper as catalyst. In addition, a wide range of functional groups were well tolerated in this conversion. This work provided a complementary method for the synthesis of homoallenylsilanes.

## Declaration of competing interest

The authors declare that they have no known competing interests or personal relationships that could have appeared to influence the work reported in this paper.

## CRediT authorship contribution statement

Qi Li: Investigation. Zi-Lu Wang: Writing – review & editing, Writing – original draft, Visualization, Investigation. Yun-He Xu: Supervision, Conceptualization.

## Acknowledgments

We gratefully acknowledge research support of this work by the funding of the National Natural Science Foundation of China (No. 22371269), the State Key Laboratory of Elementoorganic Chemistry Nankai University (No. 202001), the Strategic Priority Research Program of the Chinese Academy of Sciences (No. XDB0450301), and the Open Project of Key Laboratory of Organosilicon Chemistry, and Material Technology of Ministry of Education, Hangzhou Normal University (No. KFJJ2022013).

## Supplementary materials

Supplementary material associated with this article can be found, in the online version, at doi:10.1016/j.cclet.2024.109991.

## References

[1] A. Hoffmann-Röder, N. Krause, Angew. Chem. Int. Ed. 43 (2004) 1196–1216.

[2] S. Ma, Acc. Chem. Res. 42 (2009) 1679–1688.

[3] S. Ma, Chem. Rev. 105 (2005) 2829–2872.

[4] R. Zimmer, H.U. Reissig, Chem. Soc. Rev. 43 (2014) 2888–2903.

[5] S. Yu, S. Ma, Angew. Chem. Int. Ed. 51 (2012) 3074–3112.

[6] J.M. Alonso, P. Almendros, Chem. Rev. 121 (2021) 4193–4252.

[7] Z. Zhou, K. Chen, Y. Wang, et al., Chin. Chem. Lett. 34 (2023) 107849–107854.

[8] S.D. Lepore, A. Khoram, D.C. Bromfield, et al., J. Org. Chem. 70 (2005) 7443–7446.

[9] M. Brossat, M.P. Heck, C. Mioskowski, J. Org. Chem. 72 (2007) 5938–5941.

[10] V. Lavallo, C.A. Dyker, B. Donnadieu, G. Bertrand, Angew. Chem. Int. Ed. 47 (2008) 5411–5414.

[11] M. Melaimi, P. Parameswaran, B. Donnadieu, G. Frenking, G. Bertrand, Angew. Chem. Int. Ed. 48 (2009) 4792–4795.

[12] P. Rona, P. Crabbe, J. Am. Chem. Soc. 91 (1969) 3289–3292.

[13] N. Krause, A. Hoffmann-Röder, Tetrahedron 60 (2004) 11671–11694.

[14] K. Tanaka, E. Okazaki, Y. Shibata, J. Am. Chem. Soc. 131 (2009) 10822–10823.

[15] C. Madelaine, V. Valerio, N. Maulide, Angew. Chem. Int. Ed. 49 (2010) 1583–1586.

[16] Q. Dherbassy, S. Manna, F.J.T. Talbot, et al., Chem. Sci. 11 (2020) 11380–11393.

[17] L. Fu, S. Greßies, P. Chen, G. Liu, Chin. J. Chem. 38 (2020) 91–100.

[18] W. Xiao, J. Wu, Org. Chem. Front. 9 (2022) 5053–5073.

[19] J.W. Han, N. Tokunaga, T. Hayashi, J. Am. Chem. Soc. 123 (2001) 12915–12916.

[20] Y. Huang, J. del Pozo, S. Torker, A.H. Hoveyda, J. Am. Chem. Soc. 140 (2018) 2643–2655.

[21] L. Bayeh-Romero, S.L. Buchwald, J. Am. Chem. Soc. 141 (2019) 13788–13794.

[22] Y. Liao, X. Yin, X. Wang, et al., Angew. Chem. Int. Ed. 59 (2020) 1176–1180.

[23] W. Jian, M.F. Chiou, Y. Li, H. Bao, S. Yang, Chin. Chem. Lett. 35 (2024) 108980–108983.

[24] K.F. Zhang, K.J. Bian, C. Li, et al., Angew. Chem. Int. Ed. 58 (2019) 5069–5074.

[25] X.Y. Dong, T.Y. Zhan, S.P. Jiang, et al., Angew. Chem. Int. Ed. 60 (2021) 2160–2164.

[26] Y. Li, H. Bao, Chem. Sci. 13 (2022) 8491–8506.

[27] Y. Yu, J. Zhang, Eur. J. Org. Chem. 2022 (2022) e202201017.

[28] W.B. Wu, J.S. Yu, J. Zhou, ACS Catal. 10 (2020) 7668–7690.

[29] B. Zhang, T.T. Li, Z.C. Mao, et al., J. Am. Chem. Soc. 146 (2024) 1410–1422.

[30] F. Wang, D. Wang, Y. Zhou, et al., Angew. Chem. Int. Ed. 57 (2018) 7140–7145.

[31] X. Zhu, W. Deng, M.F. Chiou, et al., J. Am. Chem. Soc. 141 (2019) 548–559.

[32] Y. Zeng, M.F. Chiou, X. Zhu, et al., J. Am. Chem. Soc. 142 (2020) 18014–18021.

[33] Y. Song, C. Fu, S. Ma, ACS Catal. 11 (2021) 10007–10013.

[34] Y. Chen, J. Wang, Y. Lu, Chem. Sci. 12 (2021) 11316–11321.

[35] Y. Zhao, J.L. Wang, Z. Zhang, et al., J. Org. Chem. 86 (2021) 18056–18066.

[36] Y. Lv, W. Han, W. Pu, et al., Org. Chem. Front. 9 (2022) 3775–3780.

[37] X. Zhang, J. Fang, C. Cai, G. Lu, Chin. Chem. Lett. 32 (2021) 1280–1292.

[38] M. Khatravath, K.R. Maurya, A. Dey, et al., Curr. Org. Chem. 26 (2022) 920–960.

[39] H.G. Xihui Yang, Jiale Yan, Lei Shi, Chin. J. Org. Chem. 42 (2022) 4122–4151.

[40] G. Mentink, J.H. van Maarseveen, H. Hiemstra, Org. Lett. 4 (2002) 3497–3500.

[41] M.C. Pacheco, V. Gouverneur, Org. Lett. 7 (2005) 1267–1270.

[42] C. Yang, Z.L. Liu, D.T. Dai, et al., Org. Lett. 22 (2020) 1360–1367.

[43] Q. Li, Z.L. Wang, H.X. Lu, Y.H. Xu, Org. Lett. 24 (2022) 2832–2836.

[44] Y. Lan, X.H. Chang, P. Fan, et al., ACS Catal. 7 (2017) 7120–7125.

[45] R. Lu, T. Yang, X. Chen, et al., J. Am. Chem. Soc. 143 (2021) 14451–14457.

[46] Q. Liu, J. Zheng, X. Zhang, S. Ma, Nat. Commun. 13 (2022) 3302.