# Nickel-catalyzed electrochemical carboxylation of propargylic esters with ${ \mathrm { C O } } _ { 2 }$ to 2,3-allenoic acids

![](images/835f2ff0b035c33e515615b1d893142da3fa28df358550ec981457d5e80a4266.jpg)

Yuqing Zhong, Mengmeng Jiang, Deyong Yang, Nan Feng, Ying Sun, Huimin Wang, Feng Zhou∗

State Key Laboratory of Petroleum Molecular & Process Engineering, Shanghai Key Laboratory of Green Chemistry and Chemical Processes, Shanghai Engineering Research Center of Molecular Therapeutics and New Drug Development, School of Chemistry and Molecular Engineering, East China Normal University, Shanghai 200062, China

## a r t i c l e i n f o

Article history:   
Received 22 January 2025   
Revised 18 March 2025   
Accepted 1 April 2025   
Available online 2 April 2025

Keywords:   
CO<sub>2</sub>   
Nickel-catalysis   
Electro-carboxylation   
Propargylic esters   
2,3-Allenoic acids

## a b s t r a c t

Here, we report a novel nickel-catalyzed electrochemical carboxylation of propargylic esters with ${ \mathrm { C O } } _ { 2 } ,$ characterized by the regioselective synthesis of 2,3-allenoic acids rather than propargylic carboxylic acids. Both acyclic propargylic esters and cyclic propargylic carbonates serve as effective substrates, facilitating the synthesis of mono-, di-, tri-, and tetra-substituted 2,3-allenoic acids with broad substrate scope under mild conditions. Mechanistic investigations indicate that the in situ generated Ni(I) complex might serve as the active species to react with propargylic esters, forming the allenyl-Ni(I) complex under electroreductive conditions. A possible γ-selective nucleophilic attack of allenyl-Ni(I) complex on ${ \mathrm { C O } } _ { 2 }$ is likely involved in the formation of the desired 2,3-allenoic acids.

© 2025 Published by Elsevier B.V. on behalf of Chinese Chemical Society and Institute of Materia Medica, Chinese Academy of Medical Sciences.

Allenes are common structural motifs in a diverse range of natural products, pharmaceuticals, agrochemicals, and biologically active molecules (Scheme 1a) [1,2]. Their distinctive feature of bearing two cumulated carbon–carbon double bonds make them attractive precursors in various organic transformations [3–8]. The 2,3-allenoic acid, a specific type of functionalized allene that combines the distinctive allenic structure with carboxylic acid functionality, exhibits unique reactivity and biological activities. It can be readily transformed into other allene derivatives, such as allenols, allenals, allenoates, allenamides, and butenolides [9–12]. The effective construction of 2,3-allenoic acids is of great interest, and the conversion of propargylic alcohol derivatives has emerged as a promising synthetic strategy due to the accessibility of these substrates [13–17]. Notable progress has been made in the carboxylation of propargylic alcohols with CO for the construction of 2,3- allenoic acid derivatives [18–28].

Notably, the carboxylation of propargylic alcohol derivatives with ${ \mathsf { C O } } _ { 2 }$ represents a direct and effective way to construct valuable 2,3-allenoic acids, due to the abundant, nontoxic, and recyclable properties of $\mathsf C 0 _ { 2 } \left[ 2 9 - 3 9 \right]$ . However, the thermodynamic stability and kinetic inertness of ${ \mathsf { C O } } _ { 2 }$ make it dificult to achieve high eficiency under mild reaction conditions [40–42]. Despite this, seminal research from the Ma [43] and Li & Cheng groups [44] has demonstrated the feasibility of this strategy (Scheme 1b). As early as 2015, Ma developed an elegant Zn-mediated carboxylation of 2-alkynyl bromides with ${ \mathrm { C O } } _ { 2 } ,$ enabling the synthesis of 2- substituted 2,3-allenoic acids with high eficiency from primary 2- alkynyl bromides [43]. Notably, the carboxylation of secondary 2- alkynyl bromides yielded 3-alkynoic acids rather than 2,3-allenoic acids, likely due to steric effects. In 2023, Li & Cheng reported the carboxylation of propargylic acetates with ${ \mathsf { C O } } _ { 2 }$ under an electrochemical reductive system, enabling the construction of tetrasubstituted 2,3-allenoic acids under mild conditions [44]. However, likely due to the instability of the radical intermediate, the range of substrates was limited to 3-aryl propargylic acetates, yielding no more than 2-aryl-4,4-dialkyl substituted 2,3-allenoic acids. Despite these advances, both types of reactions are limited to highly reactive substrates and can only yield di- or tetra-substituted $^ { 2 , 3 - }$ allenoic acids, respectively. The carboxylation of more challenging materials with ${ \mathrm { C O } } _ { 2 }$ to construct differently (mono-, di-, tri-, and tetra-) substituted 2,3-allenoic acids with good functional group tolerance remains a highly desirable goal.

With our continuous interest in ${ \mathsf { C O } } _ { 2 }$ chemical fixation [45– 54] and propargylic substitution [55,56], and also encouraged by the advances in electro-reductive [57–71] and metal-catalyzed carboxylation of $\mathrm { C O } _ { 2 } \ \mathrm { [ 7 2 - 7 7 ] }$ , we endeavor to develop an electrocatalytic carboxylation of propargylic esters with $\mathrm { C O } _ { 2 } ,$ for the diverse construction of differently substituted 2,3-allenoic acids. The combination of electrocatalysis and transition metal catalysis unites (a) Representative examples of allene derivatives

![](images/41bec96b3d6d23090dd0cbdc8a6e167b46107b74b71f2ab464e9a13f0de6cc64.jpg)

![](images/bd798863e0ab3e247ef577eb2bf105a5896db6a03659cf0725b0c067ea9935bc.jpg)  
(b) Synthesis of 2,3-allenoic acids from ${ \mathsf { C O } } _ { 2 }$

(c) Nickel-catalyzed electro-carboxylation of propargylic esters  
![](images/ce88ac75bc2340d83c00440cec5e9671c9ceb8e3cc2c1e02b0937dff26e57098.jpg)  
Scheme 1. Carboxylation with CO to 2,3-allenoic acids.

the sustainable nature of electrochemistry with the chemo-, regio-, and stereoselective hallmarks of transition metal-catalyzed synthetic methods, thus providing opportunities for the realization of challenging transformations [78–88]. Recently, Guo & Yu reported an elegant enantioselective Ni-electrocatalyzed reductive propargylic carboxylation of propargylic carbonates with ${ \mathrm { C O } } _ { 2 }$ (Scheme 1c) [89]. The combination of electro-reduction and Ni-catalysis facilitated the transformation of electrophilic allenyl-Ni(II) into nucleophilic allenyl-Ni(I) species, and the subsequent nucleophilic addition to ${ \mathrm { C O } } _ { 2 }$ yielded the desired propargylic carboxylic acid with high regio- and enantio-selectivity. On the other hand, for Nicatalyzed carboxylation with $\mathrm { C O } _ { 2 } ,$ the activity and selectivity of the Ni-complex catalyst can be tuned by modifying the electronic and steric properties of the ligands, thus enabling regiodivergent carboxylation [90,91]. In particular, the ligand-controlled regiodivergent Ni-catalyzed carboxylation of alkenes, allyl esters, allylic alcohols and alkyl halide has been realized [92–96]. Accordingly, Nicatalyzed carboxylation of propargylic esters with ${ \mathrm { C O } } _ { 2 }$ could not only yield propargylic carboxylic acids but also afford 2,3-allenoic acids via regiodivergent manner (Scheme 1c). However, such transformations have never been studied before.

In this context, we envisaged nickel-catalyzed electroreductive carboxylation of propargylic esters with ${ \mathrm { C O } } _ { 2 }$ would offer a versatile approach to achieve a general and modular catalytic assembly of 2,3-allenoic acids in a regiodivergent manner. Apart from controlling the regioselectivity, avoiding competitive further reductive carboxylation of the allene moiety [97], as well as the application to the synthesis of differently substituted 2,3-allenoic acids, also represent challenges to be overcome to validate this hypothesis. Herein, we present a feasible nickel-catalyzed electrocatalytic carboxylation of propargylic esters with ${ \mathrm { C O } } _ { 2 }$ to produce 2,3-allenoic acids with a broad substrate scope. Not only acyclic propargylic esters but also cyclic propargylic carbonates serve as effective substrates, facilitating the synthesis of mono-, di-, tri-, and tetra-substituted 2,3-allenoic acids effectively under mild conditions (Scheme 1c).

Table 1  
Condition optimization.
<table><tr><td rowspan="2"></td><td><img src="images/f3c96e12eeff136b18f19d484ece5ab19242064a0afd179c5803bc58a0673948.jpg"/></td><td></td><td></td></tr><tr><td></td><td>Yield (%)a</td><td></td></tr><tr><td>Entry</td><td>Variations</td><td> $\mathbf { 2 a }$ </td><td>3</td></tr><tr><td>1</td><td>None</td><td>66</td><td>Trace</td></tr><tr><td>2</td><td> $\mathrm { E t } _ { 4 } \mathrm { N C l O } _ { 4 }$  instead of  $\mathrm { E t _ { 4 } N B F _ { 4 } }$ </td><td>58</td><td>Trace</td></tr><tr><td>3</td><td> ${ } ^ { n } \mathbf { B u } _ { 4 } \mathbf { N B F } _ { 4 }$  instead of  $\mathrm { E t } _ { 4 } \mathrm { N B F } _ { 4 }$ </td><td>34</td><td>Trace</td></tr><tr><td> $4 ^ { b }$ </td><td>Foam Ni instead of C paper</td><td>25</td><td>8</td></tr><tr><td>5b</td><td>Al instead of Mg</td><td>41</td><td>Trace</td></tr><tr><td> $6 ^ { c }$ </td><td> $\mathrm { C H } _ { 3 } \mathrm { C N }$  as solvent</td><td>93d</td><td>Trace</td></tr><tr><td> $7 ^ { e }$ </td><td> $\mathsf { N i } ( \mathsf { O T f } ) _ { 2 }$  instead of NiBr2</td><td>86</td><td>Trace</td></tr><tr><td>8e</td><td>NiCl2 instead of NiBr2</td><td>55</td><td>Trace</td></tr><tr><td>ge</td><td>phen instead of bpy</td><td>69</td><td>Trace</td></tr><tr><td>10e</td><td>tpy instead of bpy</td><td>84</td><td>Trace</td></tr><tr><td>11e</td><td>10 mol% of bpy</td><td>74</td><td>Trace</td></tr></table>

<sup>a</sup> Determined by <sup>1</sup>H NMR with 1,3,5-trimethylbenzene as standard.  
<sup>b</sup> Variation of entry 2.  
<sup>c</sup> 4 A<sup>˚</sup> MS as additive.  
<sup>d</sup> Isolated yield.  
<sup>e</sup> Variation of entry 6.

Our study began with the nickel-catalyzed electrochemical carboxylation of propargylic ester 1a with ${ \mathsf { C O } } _ { 2 }$ as a model reaction. Following a series of conditional optimizations (for details, see Section 2 in Supporting information), the target tri-substituted 2,3- allenoic acid 2a was isolated in a 66% yield. The reaction was catalyzed by a $\mathrm { N i B r } _ { 2 } { \mathrm { - b i p y r i d i n e } }$ (bpy) complex under a constant current of 20 mA at room temperature in DMF containing $\mathrm { E t _ { 4 } N B F _ { 4 } }$ as the electrolyte, with a C paper as the cathode and a Mg plate as the anode (Table 1, entry 1). The screening of electrolytes by varying the cation or counter anion did not yield improved results (entries 2 and 3). Subsequent studies indicated that the choice of electrode materials significantly influenced the reaction. Using a foam Ni as the cathode or an Al plate as the anode resulted in decreased yields of 25% and 41%, respectively (entries 4 and 5). Fortunately, using $\mathrm { C H } _ { 3 } \mathrm { C N }$ as the solvent resulted in a marked increase to 93% yield (entry 6). Under these conditions, further screening of Ni salts with Ni(OTf) or $\mathrm { N i C l } _ { 2 }$ as catalysts resulted in decreased yields of 86% and 55%, respectively (entries 7 and 8). The influence of ligands was also studied; changing bpy to 1,10-phenanthroline (phen) or $2 , 2 ^ { \prime } { : } 6 ^ { \prime } , 2 ^ { \prime \prime } ,$ -terpyridine (tpy) as ligand resulted in inferior 69% and 84% yields, respectively (entries 9 and 10). The reduction in ligand loading likely impaired the dissolution of Ni salt, thus leading to a decreased 74% yield (entry 11). Ultimately, the conditions shown in entry 6 were selected as the optimized reaction conditions for the nickel-catalyzed electro-carboxylation. Notably, under these conditions, the formation of propargylic carboxylic acid was not detected, as only the 2,3-allenoic acid 2a was formed, underscoring the exceptional regioselectivity of this Ni-catalyzed electrochemical carboxylation process.

Having established the optimal reaction conditions, we next evaluated the scope of the reaction with respect to propargylic esters (Scheme 2). First, we attempted the synthesis of trisubstituted allenoic acids from propargyl esters. For acetophenonederived propargyl esters, we found that both electron-withdrawing and electron-donating substituents at the para-position on the benzene ring, such as methyl, cyano, phenyl, and fluorine atoms, were suitable for this system, yielding the corresponding 2,4,4- trisubstituted allenoic acids 2a-2e with 46% 93% yield. Similarly, ortho- and meta-fluoro substituted propargylic esters also worked well, delivering 2f and 2g in 98% and 92% yield, respectively. Additionally, various heterocycles, such as naphthyl and piperonyl, were well-tolerated, yielding the corresponding 2,3-allenoic acids 2h and 2i in 54% and 65% yield, respectively. Replacing the methyl group with other substituents, such as trifluoromethyl, n–butyl, and phenyl, resulted in 2,3-allenoic acids 2j-2l with 51% 91% yield. Later, we tried propargylic esters derived from di-alkyl ketones, which also reacted smoothly, yielding 4,4-dialkyl-substituted 2,3- allenoic acids 2m-2p with 42% 63% yield. The construction of 2,2,4-trisubstituted allenoic acids was also attempted, and starting from n-amyl substituted internal propargylic ester 1q, the desired 2,2,4-trisubstituted allenoic acid 2q was obtained smoothly, albeit with a promising 22% yield.

![](images/334e45460060badaecd8aaca94409e584cceefa4dce69645bb3c8e32b6597bca.jpg)  
Scheme 2. Substrate scope. Reaction conditions: 1 or 4 (0.2 mmol), Et NBF (0.5 mmol), NiBr (0.02 mmol), bpy (0.04 mmol), 4 A<sup>˚</sup> MS (200 mg) in 5 mL CH CN with CO balloon in undivided cell with Mg anode and C paper cathode, under constant current of 20 mA at room temperature for 4 h. Isolated yields. <sup>a</sup> Yield of the corresponding propargylic carboxylic acids, determined by <sup>1</sup>H NMR analysis of the crude reaction mixture, using 1,3,5-trimethylbenzene as an internal standard.

After successfully synthesizing trisubstituted 2,3-allenoic acids, we further examined the applicability of this system for the construction of tetrasubstituted 2,3-allenoic acids. Satisfactorily, the reaction of propargylic esters derived from di-alkyl, arylalkyl, and di-aryl ketones afforded the corresponding tetrasubstituted 2,3-allenoic acids 2r-2w bearing 2-TMS, 2-methyl, and 2-phenyl substituents with up to 86% yield. This result further demonstrates the broad substrate scope and versatility of this system.

Next, we explored the synthesis of di-substituted 2,3-allenoic acids. The carboxylation of terminal propargylic esters derived from aldehydes with ${ \mathsf { C O } } _ { 2 }$ proceeded smoothly, yielding the desired 2,4-disubstituted 2,3-allenoic acids 2x-2z bearing 4-phenyl, 4-methyl, and 4-n-amyl substituents with 70% 82% yield. Meanwhile, the reaction of internal propargylic esters derived from formaldehyde delivered the 2,2-disubstituted 2,3-allenoic acids 2aa and 2ab with 2-phenyl and 2-n-amyl substituents in 38% and 45% yield, respectively. Gratifyingly, structurally complex propargylic esters derived from drugs such as ibuprofen, gemfibrozil (Lopid), and adapalene also afforded the corresponding 2,4-disubstituted 2,3-allenoic acids 2ad-2af with good yields. Lastly, the construction of the simplest monosubstituted 2,3-allenoic acid was attempted, and the reaction of 2-propynyl benzoate successfully afforded 2,3- butadienoic acid 2ac in 84% yield.

(A) Cyclic voltammetry studies  
(C) Reaction with chiral propargylic ester  
![](images/2c7b49f8ee4a5a5c2bc5cb0b95dc3f20a85fa7eea793c4c2bd71604035ce315d.jpg)

![](images/2ad9a09af44210befdda02d15fa6271af985db162f7ebc04019d91873e7e85a4.jpg)

![](images/481c7678de83128ec4c5a522e76f01f1deaf5566078c52a7c886d5da64372e9f.jpg)

![](images/f732df412253b6a9abeec2a6ea3f03d76a2a2af67ca17fada9971a7474dd3a21.jpg)

![](images/b2ef1b0055ab28028097e304a077c7c9009e16142491f45987b8695c3a09ab8b.jpg)  
Scheme 3. Mechanistic study. <sup>a</sup> The CV was performed in DMF with 0.1 mol/L $\mathrm { E t _ { 4 } N B F _ { 4 } } ,$ 100 mV/s using glassy carbon as working electrode.

Motivated by the successful electrochemical carboxylation of propargylic esters, we extended our investigation to cyclic propargylic carbonates, aiming to synthesize methylol-substituted 2,3- allenic acids. To our delight, the reaction with α-ethynyl cyclic carbonate was successful, affording a series of trisubstituted 2,3- allenic acids 5a-5e featuring a 4-methylol moiety with 47%–77% yield. Through the evaluation of various propargyl alcohol derivatives, we believe that the reaction under electrochemical conditions exhibits broad substrate versatility and application prospects, adding a new method for synthesizing a series of structurally diverse 2,3-allenoic acids.

It should be pointed out that during the synthesis of typical 2- trisubstituted 2,3-allenoic acids, such as 2q-2u and 2aa-2ab, the generation of corresponding propargylic acids could be detected. This is likely due to the steric hindrance effect of the γ -selective carboxylation of allenyl-Ni species, which presents a limitation of this method (For detail, please see Section 5 in Supporting information).

To elucidate the reaction mechanism, cyclic voltammetry (CV) analyses were initially conducted to study the electrochemical process at the cathode. The results revealed that the nickel complex exhibits two reduction potential peaks: The first at 1.3 V and the second at 2.0 V, corresponding to the Ni(II)/Ni(I) and Ni(I)/Ni(0) processes, respectively. The first reduction potential peak is more positive than that of ${ \mathsf { C O } } _ { 2 }$ and propargylic ester 1a, indicating that during the reaction process, the Ni(II) complex is initially reduced to Ni(I) (Scheme 3A-a). Upon the addition of 1a to the nickel complex, the current at 1.3 V increases significantly, indicating that the Ni(I) complex generated after the first (single-electron transfer) SET reduction should interact with 1a immediately, leading to an increase in the current. During this process, new complexes might be formed and subsequently further electrolyzed, giving rise to new reduction peaks. Further introduction of ${ \mathsf { C O } } _ { 2 }$ shows no obvious changes in the reduction peak at 1.3 V, while the current at the secondary reduction peak increases significantly, indicating that the new species generated after the secondary reduction should react with ${ \mathrm { C O } } _ { 2 }$ immediately (Scheme 3A-b). Furthermore, the influence of the concentration of 1a on the reduction of the Ni complex was studied. As the concentration of 1a increases, the current at 1.3 V increases, whereas there is no substantial increase in current at 2.0 V (Scheme 3A-c). This further substantiates that it shoulbe the Ni(I) species, rather than the Ni(0) species, that reacts with propargylic ester 1a during the reaction course.

To gain more insights into the reaction process, the following control experiments were conducted. First, a deuteration experiment with compound 1v was performed under optimal conditions using 5.0 equiv. of $\mathsf { D } _ { 2 } \mathsf { O }$ (Scheme 3B). The experiment resulted in the detection of allene 2v’ in 48% yield with a 92% deuteration ratio, implying the possible involvement of allenyl-Ni(I) intermediates during the transformation. Furthermore, the carboxylation of chiral propargylic ester 1a under standard conditions yielded the racemic product 2a in 87% yield (Scheme 3C). This outcome suggests that the C–O bond cleavage is chirality-unretained, and a radical process might be involved.

Based on experimental outcomes and literature reports on the Ni-catalyzed coupling reaction of $\mathsf { s p } ^ { 3 }$ electrophiles [98–102], particularly those involving ${ \mathsf { C } } ( { \mathsf { s p } } ^ { 3 } ) – 0$ bond transformations [103–105], a plausible mechanism for the Ni-catalyzed electrochemical carboxylation of propargylic esters with ${ \mathrm { C O } } _ { 2 }$ to form 2,3-allenoic acids is proposed (Scheme 3D). Initially, the catalyst precursor, a Ni(II) complex, is reduced at the cathode to afford a Ni(I) species. This Ni(I) species reacts with propargylic esters 1 to generate a radical intermediate I and regenerate the Ni(II) species, which could be further reduced to Ni(I) species at the cathode. The interaction of Ni(I) species with radical intermediate I resulting the generation of allenyl-Ni(II) species II, which undergoes a further SET reduction to form the nucleophilic allenyl-Ni(I) complex III. Finally, nucleophilic attack at the γ -position of III with ${ \mathrm { C O } } _ { 2 }$ produces an intermediate IV, which upon acidification yields the 2,3-allenoic acid product 2. At the anode, magnesium oxidizes to $\mathsf { M g } ^ { 2 + }$ , which could stabilize carboxylate intermediates through electrostatic interactions and may also enhance reaction eficiency by increasing electrolyte conductivity. Additionally, the magnesium electrode offers a high reducing potential, making it superior to other metal anodes.

In conclusion, we have successfully developed an electrochemical approach for the Ni-catalyzed carboxylation of propargylic esters with ${ \mathrm { C O } } _ { 2 }$ , achieving the selective construction of 2,3-allenoic acids. This process offers high regioselectivity and broad substrate tolerance, with both propargylic esters and cyclic carbonates serving as viable substrates. It enables the synthesis of mono-, di-, tri-, and tetra-substituted 2,3-allenoic acids with diverse structures. Mechanistic investigations support a pathway involving the generation of a Ni(I) complex as the active species for the reaction with propargylic esters and a possible γ-selective nucleophilic attack on ${ \mathsf { C O } } _ { 2 }$ of the allenyl-Ni(I) complex. The extension of this electrocatalytic carboxylation strategy for the synthesis of various carboxylic acids through reductive C–O bond cleavage is currently underway.

## Declaration of competing interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

## CRediT authorship contribution statement

Yuqing Zhong: Writing – original draft, Methodology, Investigation, Data curation. Mengmeng Jiang: Investigation, Data curation. Deyong Yang: Investigation, Data curation. Nan Feng: Investigation, Data curation. Ying Sun: Investigation, Data curation. Huimin Wang: Investigation, Data curation. Feng Zhou: Writing – review & editing, Project administration, Methodology.

## Acknowledgments

The financial support from the National Natural Science Foundation of China (Nos. 22171090, 21871090), National Key Research and Development Program of China (No. 2020YFA0710200), the Innovation Program of Shanghai Municipal Education Commission (No. 2023ZKZD37) and the Fundamental Research Funds for the Central Universities are highly appreciated.

## Supplementary materials

Supplementary material associated with this article can be found, in the online version, at doi:10.1016/j.cclet.2025.111169.

## References

[1] N.Krause Hoffmann-Röder, Angew. Chem. Int. Ed. 43 (2004) 1196–1216.

[2] P. Rivera-Fuentes, F. Diederich, Angew. Chem. Int. Ed. 51 (2012) 2818–2828.

[3] S.M. Ma, Chem. Rev. 105 (2005) 2829–2872.

[4] S.C. Yu, S.M. Ma, Angew. Chem. Int. Ed. 51 (2012) 3074–3112.

[5] F. López, J.F. Mascareñas, Chem. Soc. Rev. 43 (2014) 2904–2915.

[6] L. Liu, R.M. Ward, J.M. Schomaker, Chem. Rev. 119 (2019) 12422–12490.

[7] R. Zimmer, C.U. Dinesh, E. Nandanan, F.A. Khan, Chem. Rev. 100 (2000) 3067–3126.

[8] A.S.K. Hashmi, Angew. Chem. Int. Ed. 39 (2000) 3590–3593.

[9] B.J. Cowen, S.J. Miller, Chem. Soc. Rev. 38 (2009) 3102–3116.

[10] S.M. Ma, Acc. Chem. Res. 42 (2009) 1679–1688.

[11] J.T. Ye, S.M. Ma, Acc. Chem. Res. 47 (2014) 989–1000.

[12] R. Hajinasiri, Tetrahedron 126 (2022) 133053.

[13] S.C. Yu, S.M. Ma, Chem. Commun. 47 (2011) 5384–5418.

[15] J.T. Ye, S.M. Ma, Org. Chem. Front. 1 (2014) 1210–1224.

[17] X. Huang, S.M. Ma, Acc. Chem. Res. 52 (2019) 1301–1312.

[18] J. Tsuji, T. Sugiura, I. Minami, Tetrahedron Lett. 27 (1986) 731–734.

[19] J.A. Marshall, M.A. Wolf, E.M. Wallace, J. Org. Chem. 62 (1997) 367–371.

[20] Y.L. Wang, S.M. Ma, Adv. Synth. Catal. 355 (2013) 741–750.

[21] Y.L. Wang, W.L. Zhang, S.M. Ma, J. Am. Chem. Soc. 135 (2013) 11517–11520.

[22] Y.L. Wang, W.L. Zhang, S.M. Ma, Org. Chem. Front. 1 (2014) 807–811.

[23] W.L. Zhang, S.M. Ma, Chem. Eur. J. 23 (2017) 8590–8595.

[24] W.L. Zhang, C.F. Huang, Y. Yuan, M.S. Ma, Chem. Commun. 53 (2017) 12430–12433.

[25] W.F. Zheng, W.L. Zhang, J.H. Huang, et al., Org. Chem. Front. 5 (2018) 1900–1904.

[26] W.F. Zheng, W.L. Zhang, C.F. Huang, et al., Nat. Catal. 2 (2019) 997–1005.

[27] J. Wang, W. Zhang, P. Wu, et al., Org. Chem. Front. 7 (2020) 3907–3911.

[28] J. Wang, W.F. Zheng, Y. Li, et al., Org. Chem. Front. 11 (2024) 2477–2484.

[29] M. Aresta, Carbon Dioxide as Chemical Feedstock, Wiley VCH, Weinheim, 2010.

[30] L.N. He, Carbon Dioxide Chemistry, Science Press, Beijing, 2013.

[31] M.Y. He, Y. Sun, B.X. Han, Angew. Chem. Int. Ed. 52 (2013) 9620–9633.

[32] Q. Liu, L.P. Wu, R. Jackstell, M. Beller, Nat. Commun. 6 (2015) 5933–5947.

[33] G.Q. Yuan, C.R. Qi, W.Q. Wu, H.F. Jiang, Curr. Opin. Green Sustain. Chem. 3 (2017) 22–27.

[34] J.H. Ye, T. Ju, H. Huang, L.L. Liao, D.G. Yu, Acc. Chem. Res. 54 (2021) 2518–2531.

[35] L.Q. Qiu, H.R. Li, L.N. He, Acc. Chem. Res. 56 (2023) 2225–2240.

[36] S. Dabral, T. Schaub, Adv. Synth. Catal. 361 (2019) 223–246.

[37] M.D. Burkart, N. Hazar, C.L. Tway, E.L. Zeitler, ACS Catal. 9 (2019) 7937–7956.

[38] S.Gennen Grignard, C. Jérôme, A.W. Kleij, C. Detrembleur, Chem. Soc. Rev. 48 (2019) 4466–4514.

[39] H.W.Cheo Cai, T. Liu, J. Wu, Angew. Chem. Int. Ed. 60 (2021) 18950–18980.

[40] R. Cauwenbergh, V. Goyal, R. Maiti, K. Natte, S. Das, Chem. Soc. Rev. 51 (2022) 9371–9423.

[41] C.K. Ran, H.Z. Xiao, L.L. Liao, et al., Natl. Sci. Open. 2 (2023) 20220024.

[42] N.R. Pearson, G. Hahn, G. Zweifel, J. Org. Chem. 47 (1982) 3364–3366.

[43] B.K.Y. Miao, G. Li, S.M. Ma, Chem. Eur. J. 21 (2015) 17224–17228.

[44] J.H. Qin, Z.Q. Xiong, C.Z.H. Cheng, M. Hu, J.H. Li, Org. Lett. 25 (2023) 9176–9180.

[45] D.Y. Yang, Y. Sun, N. Feng, et al., Angew. Chem. Int. Ed. (2025) e202419702.

[46] X.T. Gao, Z. Zhang, X. Wang, et al., Chem. Sci. 11 (2020) 10414–10420.

[47] Z. Zhang, Z.H. Zhang, F. Zhou, J. Zhou, Org. Lett. 23 (2021) 2726–2730.

[48] X.T. Gao, C.C. Gan, S.Y. Liu, et al., ACS Catal. 7 (2017) 8588–8593.

[49] F. Zhou, S.L. Xie, X.T. Gao, et al., Green Chem. 19 (2017) 3908–3915.

[50] X.T. Gao, S.L. Xie, F. Zhou, H.H. Wu, J. Zhou, Chem. Commun. 55 (2019) 14303–14306.

[51] S.L. Xie, X.Y. Cui, X.T. Gao, et al., Org. Chem. Front. 6 (2019) 3678–3682.

[52] S.L. Xie, X.T. Gao, F. Zhou, H.H. Wu, J. Zhou, Chin. Chem. Lett. 31 (2020) 324–332.

[53] S.L. Xie, X.T. Gao, H.H. Wu, F. Zhou, J. Zhou, Org. Lett. 22 (2020) 8424–8429.

[54] Z.P. Zhao, H.R. Lin, Z. Zhang, et al., Org. Lett. 25 (2023) 7895–7899.

[55] Z. Zhang, Y. Sun, Y. Gong, et al., Nat. Chem. 16 (2024) 521–532.

[56] Z. Zhang, Z.H. Zhang, Y. Sun, et al., Sci. China Chem. 68 (2025) 1402–1411.

[57] Y. Cao, X. He, N. Wang, H.R. Li, L.N. He, Chin. J. Chem. 36 (2018) 644–659.

[58] Z. Yu, M. Shi, Chem. Commun. 58 (2022) 13539–13555.

[59] Z.X. Yang, Y. Yu, L.C. Lai, et al., Green Synth. Catal. 2 (2021) 19–26.

[60] G.Q. Sun, W. Zhang, L.L. Liao, et al., Nat. Commun. 12 (2021) 7086–7095.

[61] S.Y. Wang, T. Feng, Y.W. Wang, Y.A. Qiu, Chem. Asian J. 17 (2022) e202200543.

[62] X.F. Liu, K. Zhang, L. Tao, X.B. Lu, W.Z. Zhang, Green Chem. Eng. 3 (2022) 125–137.

[63] L.L. Liao, Z.H. Wang, K.G. Cao, et al., J. Am. Chem. Soc. 144 (2022) 2062–2068.

[64] W. Zhang, L.L. Liao, L. Li, et al., Angew. Chem. Int. Ed. 62 (2023) e202301892.

[65] G.Q. Sun, P. Yu, W. Zhang, et al., Nature 615 (2023) 67–72.

[66] H. Senboku, Curr. Org. Chem. 28 (2024) 76–88.

[67] X.T. Gao, Y.Q. Zhong, N. Feng, et al., Chin. J. Org. Chem. 44 (2024) 3043–3062.

[68] G.Q. Sun, L. Liao, C.K. Ran, J.H. Ye, D.G. Yu, Acc. Chem. Res. 57 (2024) 2728–2745.

[69] C.K. Ran, Q. Qu, Y.Y. Tao, et al., Sci. China Chem. 67 (2024) 3366–3372.

[70] L. Li, Z.X. Yan, C.K. Ran, et al., Chin. Chem. Lett. 35 (2024) 110104–110108

[71] P.F. Li, Y.W. Wang, H.Y. Zhang, Y.A. Qiu, Acc. Chem. Res. 58 (2025) 113–129.

[72] K. Huang, C.L. Sun, Z.J. Shi, Chem. Soc. Rev. 40 (2011) 2435–2452.

[73] S.S. Yan, Q. Fu, L.L. Liao, et al., Coord. Chem. Rev. 374 (2018) 439–463.

[74] A. Tortajada, F. Juliá-Hernández, M. Börjesson, T. Moragas, R. Martin, Angew. Chem. Int. Ed. 57 (2018) 15948–15982.

[75] Y.G. Chen, X.T. Xu, K. Zhang, et al., Synthesis 50 (2018) 35–48.

[76] Y. Yi, W. Hang, C. Xi, Chin. J. Org. Chem. 41 (2021) 80–93.

[77] A. Tortajada, M. Börjesson, R. Martin, Acc. Chem. Res. 54 (2021) 3941–3952.

[78] B.L. Chen, H.W. Zhu, Y. Xiao, et al., Electrochem. Commun. 42 (2014) 55–59.

[79] M. Yan, Y. Kawamata, P.S. Baran, Chem. Rev. 117 (2017) 13230–13319.

[80] P. Xiong, H.C. Xu, Acc. Chem. Res. 52 (2019) 3339–3350.

[81] J.C. Siu, N. Fu, S. Lin, Acc. Chem. Res. 53 (2020) 547–560.

[82] T.H. Meyer, I. Choi, C. Tian, L. Ackermann, Chem 6 (2020) 2484–2496.

[83] K.J. Jiao, Y.K. Xing, Q.L. Yang, H. Qiu, T.S. Mei, Acc. Chem. Res. 53 (2020) 300–310.

[84] Y. Yuan, J. Yang, A. Lei, Chem. Soc. Rev. 50 (2021) 10058–10086.

[85] X. Cheng, A.W. Lei, T.S. Mei, et al., CCS Chem. 4 (2022) 1120–1152.

[86] C. Ma, P. Fang, D. Liu, et al., Chem. Sci. 12 (2021) 12866–12873

[87] Y.Y. Gui, S.S. Yan, W. Wang, et al., Sci. Bull. 68 (2023) 3124–3128.

[88] J. Rein, S.B. Zacate, K.N. Mao, S. Lin, Chem. Soc. Rev. 52 (2023) 8106–8125.

[89] Q.D. Hu, B.Y. Wei, M.X. Wang, et al., J. Am. Chem. Soc. 146 (2024) 14864–14874.

[90] C. Nájera, I.P. Beletskaya, M. Yus, Chem. Soc. Rev. 48 (2019) 4515–4618.

[91] Y. Ke, W. Li, W.F. Liu, W.Q. Kong, Sci. China Chem. 66 (2023) 2951–2976.

[92] T. Moragas, J. Cornella, R. Martin, J. Am. Chem. Soc. 136 (2014) 17702–17705.

[93] M.V. Gemmeren, M. Bçrjesson, A. Tortajada, et al., Angew. Chem. Int. Ed. 56 (2017) 6558–6562.

[94] F.J. Hernández1, T. Moragas, J. Cornella, R. Martin, Nature 545 (2017) 84–88.

[95] M. Gaydou, T. Moragas, F.J. Hernández, R. Martin, J. Am. Chem. Soc. 139 (2017) 12161–12164.

[96] Q.Y. Meng, S. Wang, G.S. Huff, B. König, J. Am. Chem. Soc. 140 (2018) 3198–3201.

[97] C.L. Ding, J.S. Zhong, H. Yan, K.Y. Ye, Synthesis 56 (2024) 1687–1694.

[98] S.Z. Tasker, E.A. Standley, T.F. Jamison, Nature 509 (2014) 299–309.

[99] J. Choi, G.C. Fu, Science 356 (2017) eaaf7230.

[100] E.L. Lucas, E.R. Jarvo, Nat. Rev. Chem. 1 (2017) 0065–0071.

[101] T.B. Hamby, M.J. LaLama, C.S. Sevov, Science 376 (2022) 410–416.

[102] H. Huo, B.J. Gorsline, G.C. Fu, Science 367 (2020) 559–564.

[103] S.Q. Zhang, X. Hong, Acc. Chem. Res. 54 (2021) 2158–2171.

[104] C.S. Day, R.G. Ángel, J.T. Stephanie, et al., Nat. Catal. 6 (2023) 244–253.

[105] L. Talavera, C. Odena, R. Martin, Adv. Catal. 74 (2024) 133–179.