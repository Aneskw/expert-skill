pubs.acs.org/OrgLett

Letter

# De Novo Synthesis of Oligofurans via Copper-Catalyzed Dimerization of Ethynylethylene Carbonates

Zhengyu Han, Biao Zhu, Yuxuan Liu, Luyao Wei, Lixia Xu, Xiaolin Zhu, Jingrui Ye,\* Jianwei Sun, and Hai Huang\*

![](images/743f219dff590b2b861d5c5a75923894911500f27572cb3bf50b29ccdf8f8d77.jpg)

Cite This: Org. Lett. 2025, 27, 9483−9488

![](images/73fb7d0a165a6f8b55cb36de457de82d27d151cddbb64fa030fea4699968894b.jpg)

Read Online

ACCESS

Metrics & More

Article Recommendations

\*sı Supporting Information

![](images/1decfdd37a359a926501d8c9d5723fbddbcd6fda922fc308c59d47f51846fa91.jpg)

Propargyl alcohols act as both an electrophile and a nucleophile (1st time)

Controlled synthesis of dihydro-bifurans, oligofurans and allenols

The rapid approach to β',β'-diaryl-α,α-oligofuran monomer (1st time)

ABSTRACT: Disclosed here is an eficient Cu-catalyzed de novo synthesis of oligofurans, a type of valuable core unit in organic materials. From the readily available ethynylethylene carbonates, the dimerization process allowed convenient access to diferently substituted oligofurans that could not have been easily synthesized before. In contrast to the conventional strategies, this protocol does not rely on preinstallation of cross-coupling functionalities or presynthesis of advanced enyne precursors. Brief studies of their photophysical properties also indicated the great potential of our protocol in tuning these properties for applications. Mechanistic studies not only provided important insights into the reaction pathway but also allowed the identification of another protocol for the synthesis of furan-substituted allenylic alcohols.

O <sup>ligofurans</sup> <sup>and</sup> <sup>oligothiophenes</sup> <sup>are</sup> <sup>important</sup> <sup>core</sup> <sup>units</sup> in organic dyes and related semiconductor molecules (Figure 1a).<sup>1−10</sup> The structurally rigid electron-rich π- conjugation system has a critical influence on the photophysical and electrochemical properties of the resulting materials. Specifically, oligofuran-based organic materials not only have superior electron transport performance but also possess good biodegradability, making them highly attractive in the development of environmentally friendly electronic devices for large-scale applications.<sup>11−13</sup>

Over the past few decades, the synthesis of oligofurans and related structures has primarily relied on tedious procedures involving repetitive cross-coupling from the corresponding furyl electrophiles and nucleophiles. The less friendly stannyl furan species were often used as nucleophilic partners, which also posed significant concerns to the environment and human health (Figure 1b).<sup>1−7,14,15</sup> The cross-coupling products were sometimes contaminated by homocoupling products with similar polarity, thus leading to challenges in purification. Moreover, due to the strong nucleophilicity of the α-positions in furan rings, the conventional synthesis of oligofurans has been limited to α′,α′-diaryl-α,α-oligofurans II. To overcome the above drawbacks, tremendous progress has been achieved in developing more sustainable and eficient strategies.<sup>16−22</sup> Among them, Zhu and co-workers have recently reported an elegant de novo strategy featuring the cyclization of a linear enyne-conjugated aldehyde precursor in the presence of a Brønsted acid or π-Lewis acid catalyst.<sup>21,22</sup> While such protocols are highly atom-economic and environmentally benign, the synthesis of those advanced linear precursors may take a few steps (Figure 1c).

Dimerizations of terminal alkynes are important tools in organic synthetic, particularly the “head-to-head” or “head-totail” dimerizations, which serve as key strategies for synthesizing 1,3-enynes.<sup>23−26</sup> However, due to the propargylic leaving group, the metal-catalyzed cleavage of the propargylic leaving group often precedes the deprotonation at the terminal position, thereby forcing the propargyl substitution to be the major pathway for terminal propargylic electrophiles (Figure 1d).<sup>27−32</sup> As a result, the development of dimerization of propargyl electrophiles involving cleavage of the leaving group has remained highly challenging, thus impeding advances in this realm.

Aiming to further simplify the assembly line, we envisioned the possibility of intermolecular dimerization of readily available simple alkyne substrates, like ethynylethylene carbonates (EECs),<sup>33−37</sup> which features the formation of both furan rings and the C−C bond between them in the same process (Figure 1e). To the best of our knowledge, this represents the first example of EECs simultaneously acting as both nucleophiles and electrophiles at the same reaction site, afording furyl dihydrofurans V via head-to-head deoxygenative dimerization of EECs. These products can be transformed into oligofurans VI in one pot, which holds immense promise in the development of functional materials. Additionally, we demonstrated a solvent-controlled dimerization approach to construct diverse furyl allenols VII via an interrupted pathway.

![](images/a53cb756dbcd20b86485098e60754acf298b1699ae7dbcb59b9078a115372bba.jpg)

![](images/a9de51cff3b093cdb68a0455dc76c6101a246b0aac5b5b17a479c0609bd41e0d.jpg)  
Figure 1. Introduction to the synthesis of oligofurans and reaction design.

With 1a as the model substrate and a Cu(I) salt as the catalyst, we were delighted to determine that dimerization product 2a could be directly generated (Table 1). Systematic evaluation of diferent parameters indicated that, with $\mathrm { C u ( M e C N ) _ { 4 } B F _ { 4 } }$ as the catalyst, diamine L3 as the ligand, diisopropyletheylamine (DIPEA) as the base, and trifluoroethanol (TFE) as the solvent, the desired product could be generated in 82% yield at room temperature (entry 1 and more details in the Supporting Information). Other ligands, such as bipyridine L1, phenanthroline L2, cyclohexanediamine L4, and PyBox L5, provided decreased yields (entries 2−5, respectively). Other copper salts, including Cu(OTf) and Cu(OTf) , proved to be much less efective (entries 6 and 7, respectively). Interestingly, less polar solvents (THF, DCM, and toluene) were completely unsuitable for this reaction, resulting in no reaction (entry 8). KOH and DBU were less efective bases, but $\mathrm { E t } _ { 3 } \mathrm { N }$ led to a slightly higher yield (entries 9 and 10). Increasing the temperature to 60 $^ \circ \mathrm { C }$ could further improve the eficiency (91% yield, entry 11).

We were also curious about the possibility of the direct formation of bis(furan) from the same pot in the presence of an oxidant. Thus, various oxidation conditions were examined on the crude product (see the Supporting Information for more details). To our delight, a one-pot reaction employing elemental sulfur in DMF eficiently furnished oligofuran 2a-F in 57% isolated yield, thus representing a convenient de novo strategy for the synthesis of oligofurans (entry 12).

Table 1. Evaluation of the Reaction Conditions for Alkyne Dimerization a  
![](images/e0e2b79267b747817fd2216a383803be261e748f45a97b904ca7a2dee18d2566.jpg)

<table><tr><td>entry</td><td>variation of conditions</td><td>yield (%)</td><td>product</td></tr><tr><td>1</td><td>none</td><td>82</td><td>2a</td></tr><tr><td>2</td><td>L1 as the ligand</td><td>30</td><td>2a</td></tr><tr><td>3</td><td>L2 as the ligand</td><td>39</td><td>2a</td></tr><tr><td>4</td><td>L4 as the ligand</td><td>66</td><td>2a</td></tr><tr><td>5</td><td>L5 as the ligand</td><td>31</td><td>2a</td></tr><tr><td>6</td><td> $\operatorname { C u } ( \operatorname { O T f } ) _ { 2 }$  as the copper salt</td><td>15</td><td>2a</td></tr><tr><td>7</td><td>Cu(OTf) as the copper salt</td><td>20</td><td>2a</td></tr><tr><td>8</td><td>DCM, toluene, or THF as the solvent</td><td>NR</td><td>2a</td></tr><tr><td>9</td><td>KOH or DBU as the base</td><td>45-47</td><td>2a</td></tr><tr><td>10</td><td>Et3N as the base</td><td>84</td><td>2a</td></tr><tr><td> $1 1 ^ { b }$ </td><td> $\mathrm { E t } _ { 3 } \mathrm { N }$  as the base,  $6 0 ~ ^ { \circ } \mathrm { C }$ </td><td>91</td><td>2a</td></tr><tr><td> $1 2 ^ { c }$ </td><td>with an oxidant</td><td>57</td><td>2a-F</td></tr></table>

<sup>a</sup>Reaction conditions: 1a (0.1 mmol), Cu(MeCN) BF (10.0 mol %), a ligand (12.0 mol %), a base (1.5 equiv), TFE (1.0 mL), RT, 10 h. The yield was determined by <sup>1</sup>H NMR analysis of the crude product with $\mathrm { C H } _ { 2 } \mathrm { B r } _ { 2 }$ as an internal standard. <sup>b</sup>Run for 0.5 h. <sup>c</sup>One-pot oxidation conditions: 1a (0.2 mmol), Cu(MeCN) BF (10.0 mol %), L3 (12.0 mol %), Et N (1.5 equiv), TFE (2.0 mL), 60 °C, 0.5 h; then evaporation followed by addition of sulfur powder (0.5 equiv) and DMF (1.0 mL), 160 ${ } ^ { \circ } \dot { C } ,$ 3 h. Isolated yield.

Under the above optimized conditions, a range of EECs were examined for this Cu-catalyzed dimerization process (Scheme 1). Substitution at the ortho, meta, and para positions

![](images/ef3bf2a7babaebb50033189c408984377a3b5d0f0e8e25b2285ac0e139f0c715.jpg)  
<sup>a</sup>Standard conditions: 1 (0.2 mmol), Cu(MeCN) BF (10.0 mol %), L3 (12.0 mol %), $\mathrm { E t } _ { 3 } \mathrm { N }$ (1.5 equiv), TFE (2.0 mL), 60 ${ } ^ { \circ } \mathrm { C } ,$ 0.5 h. Isolated yields.

of the side benzene rings successfully delivered the desired products in good to high yields with excellent selectivity. Substrates with diferent electronic properties were suitable, with a limited influence on the reaction eficiency. The structure of 2a was confirmed by X-ray crystallography (CCDC 2303604). It is worth noting that heteroarenes, such as thiophene and furan, could also be incorporated into the substrates, which resulted in the formation of oligofuran/ thiophenes 2q and 2r bearing four such rings connected consecutively. Compared with the conventional strategies that couple each ring in a stepwise manner, our protocol is much more convergent and eficient.

We also examined the generality of the one-pot oxidative protocol for the direct formation of oligofurans (Scheme 2). A series of oligofurans (2a-F−2e-F) were successfully obtained from the corresponding EECs. It is worth noting that this is the first synthesis of 2d-F and 2e-F, where four consecutive furan/ thiophene rings are connected at positions 2 and 3. It would not be straightforward to access such skeletons by conventional strategies.<sup>18−20</sup> Notably, these highly conjugated structures themselves show diferent colors, suggesting their potential in photophysical applications. To further demonstrate the utility of the oligofuran products, we also studied a Diels−Alder reaction between 2a-F and in situ-generated benzyne. This reaction initially aforded adduct 3, but upon treatment of TMSCl and NaI, it was further transformed into substituted binaphthyl 4, a valuable unit in organic synthesis and materials science.<sup>38−41</sup>

The capability of our protocol in conveniently accessing diferently substituted oligofurans promoted us to quantitatively study their photophysical properties. As shown in Figure 2a, the UV−vis absorption properties of these structures were examined. While their absorption wavelengths turned out to be

Scheme 2. One-Pot Oxidative Synthesis of Oligofurans and Further Derivatization<sup>a</sup>

![](images/1b2e660bf9864fb16dfc0d34d97f08b062837066393a2f30d1c11de5549e8e86.jpg)

<sup>a</sup>Standard conditions: 1 (0.2 mmol), $\mathrm { C u } ( \mathrm { M e C N } ) _ { 4 } \mathrm { B F } _ { 4 }$ (10.0 mol %), L3 (12.0 mol %), Et N (1.5 equiv), TFE (2.0 mL), 60 °C, 0.5 h; then evaporation followed by addition of sulfur powder (0.5 equiv) and DMF (1.0 mL), 160 °C, 3 h. Isolated yield.  
![](images/2695379f850aed5434601495caad3caf66db09ac0df3e87ae56455b8a9692774.jpg)  
Figure 2. Photophysical properties of the oligofuran products. (a) UV−vis absorption spectra in DCM $( 1 \times 1 0 ^ { - 5 } \mathrm { ~ M } )$ . (b) Emission spectra in DCM $( 1 \overset { \cdot } { \times } 1 0 ^ { - 5 } \mathrm { \bf ~ M } )$ . (c) PL lifetime in DCM $( 1 \times 1 0 ^ { - 5 }$ M).

similar in the range of 250−320 nm, electron-rich 2e-F has a notably stronger absorption compared to other oligofurans. The emission properties of these compounds were also investigated. A significant red-shift for 2e-F and 2c-F was observed, but thiophene-substituted oligofuran 2d-F did not exhibit a pronounced efect on the optical properties (Figure 2b). Photoluminescence (PL) lifetimes of these oligofurans were also determined (Figure 2c). The PL lifetimes of 2a-F− 2e-F are 1.02, 1.09, 4.66, 1.00, and 1.77 ns, respectively. The solubility of oligofuran 2e-F was found to be higher than those of other oligofurans/thiophenes, indicative of better processability.<sup>18−20</sup> These preliminary results indicated that our products hold promise for the development of new organic materials. The convenient synthesis from simple substrates is expected to allow further modification and optimization of their properties.

A possible mechanism is depicted in Scheme 3. In the presence of a base, the substrate alkyne can easily generate copper(I) acetylide species A, which undergoes decarboxylation to form copper allenylidene B by eliminating CO . Subsequently, another molecule of substrate 1 may serve as a nucleophile to attack the carbene motif, generating conjugated allenyl alkyne C. A similar decarboxylation may take place to form cumulative allene D, in which copper(I) serves as a π-acid to trigger a cyclization from one alkoxide motif together with isomerization and protodecupration to form furan-substituted allenylic alcohols 5. Then, the $\mathrm { { C u } ( I ) }$ catalyst can further activate the allene motif to trigger another intramolecular cyclization to form observed dimerization product 2.<sup>42−44</sup>

Scheme 3. Proposed Mechanism  
![](images/292323014ce5d2575b7fe8e5da3ab08d2ffc0e05c0a1f989099b4f546a9aa126.jpg)

To gain more insight into the proposed mechanism, we carried out a series of control experiments (Scheme 4). In the

Scheme 4. Control Experiments  
![](images/e71ebab9607fc8e05763bceb98be832e4af855d451f6bf443fad7d2b883171b1.jpg)

absence of a base, we were able to isolate a small amount of allenyl alkyne int-a (Scheme $4 , \ \mathsf { a } )$ , presumably from direct protonation of intermediate C. Moreover, with methanol as a solvent, the reaction of 1a could generate 5a as the major product (Scheme 4, b). Importantly, both int-a and 5a are chemically competent for the generation of dimerization product 2a under the standard conditions. int-a was cleanly converted into observed dimerization product 2a under the standard conditions (Scheme $4 , { \mathfrak { c } } )$ . Similarly, the reaction of 5a provided 2a in 76% yield (Scheme $4 , \mathrm { d } )$ . We were also curious about whether the cyclization takes place prior to the linking of two molecules, which would involve coupling with the initially formed furan with another molecule of alkyne. Thus, 3- phenylfuran and substrate 2b was mixed under the modified conditions that are specific for the generation of the direct coupling intermediate, furyl allenylic alcohol. Unfortunately, only homodimerization product 5b was observed, but no crossover product $\mathbf { 5 6 ^ { \prime } } .$ . This observation is consistent with the proposed mechanism involving cyclization after intermolecular C−C bond formation (Scheme 4, e).

In fact, furan-substituted allenylic alcohols could be useful synthetic building blocks, but general access to furansubstituted allenylic alcohols has previously been lacking.<sup>45−49</sup> The study presented above suggested that these compounds could be generated from this dimerization reaction. Thus, we optimized the conditions specifically for the formation of this type of product on purpose (see the Supporting Information for details). Indeed, with L6 as the ligand and MeOH as the solvent, the reaction of 1a could aford allenol 5a in 71% isolated yield (Scheme 5). The scope of this protocol was also briefly examined. Diferent substituted EECs also proceeded smoothly to form the desired furyl allenol products as the major products.

Scheme 5. Synthesis of Furyl Allenols $5 ^ { a }$  
![](images/3216dc2c97fbc266ba7e756f1a765cda654b0b4fb7bf60d5cb00e984ab5dcb5b.jpg)  
<sup>a</sup>Standard conditions: 1 (0.2 mmol), Cu(MeCN) BF (10 mol %), L6 (12 mol %), DBU (1.5 equiv), MeOH (2.0 mL), 40 ${ } ^ { \circ } \mathrm { C } ,$ 1.5 h. Isolated yield.

In summary, we have developed a new de novo synthesis of oligofurans from readily available alkyne substrates. In contrast to the conventional strategies, no preinstallation of crosscoupling functionalities (such as halide and stannyl groups) or presynthesis of the advanced linear enyne precursors is needed. The intrinsically controlled C−C bond formation and cyclization allowed convenient access to oligofurans, a type of valuable subunit in organic materials. The photophysical properties of these products were studied, suggesting the potential of this protocol in generating previously limitedly accessible but useful conjugated molecules of this type. Control experiments provided important insight into the reaction mechanism, which likely involves the formation of intermolecular C−C bonds prior to cyclization. The related study also permitted the establishment of a protocol for the synthesis of furan-substituted allenylic alcohols, another family of important building blocks.

## ■ ASSOCIATED CONTENT

## Data Availability Statement

The data underlying this study are available in the published article and its Supporting Information.

## \*sı Supporting Information

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acs.orglett.5c02955.

Experimental procedure, characterization data, crystal data for 2a, and NMR spectra (PDF)

## Accession Codes

Deposition Number 2303604 contains the supplementary crystallographic data for this paper. These data can be obtained free of charge via the joint Cambridge Crystallographic Data Centre (CCDC) and Fachinformationszentrum Karlsruhe Access Structures service.

## ■ AUTHOR INFORMATION

## Corresponding Authors

Jingrui Ye − Jiangsu Key Laboratory of Advanced Catalytic Materials & Technology, School of Petrochemical Engineering, Changzhou University, Changzhou 213164, P. R. China; orcid.org/0000-0003-4887-7795; Email: yejr@cczu.edu.cn

Hai Huang − Jiangsu Key Laboratory of Advanced Catalytic Materials & Technology, School of Petrochemical Engineering, Changzhou University, Changzhou 213164, P. R. China; orcid.org/0000-0002-9732-1454; Email: huanghai@cczu.edu.cn

## Authors

Zhengyu Han − Jiangsu Key Laboratory of Advanced Catalytic Materials & Technology, School of Petrochemical Engineering, Changzhou University, Changzhou 213164, P. R. China; orcid.org/0000-0001-8317-6439

Biao Zhu − Jiangsu Key Laboratory of Advanced Catalytic Materials & Technology, School of Petrochemical Engineering, Changzhou University, Changzhou 213164, P. R. China

Yuxuan Liu − School of Chemistry of Chemical Engineering, Shaanxi Normal University, Xi’an, Shaanxi 710062, P. R. China

Luyao Wei − Jiangsu Key Laboratory of Advanced Catalytic Materials & Technology, School of Petrochemical Engineering, Changzhou University, Changzhou 213164, P. R. China

Lixia Xu − Jiangsu Key Laboratory of Advanced Catalytic Materials & Technology, School of Petrochemical Engineering, Changzhou University, Changzhou 213164, P. R. China

Xiaolin Zhu − School of Chemistry of Chemical Engineering, Shaanxi Normal University, Xi’an, Shaanxi 710062, P. R. China; orcid.org/0000-0001-6568-0308

Jianwei Sun − Jiangsu Key Laboratory of Advanced Catalytic Materials & Technology, School of Petrochemical Engineering, Changzhou University, Changzhou 213164, P. R. China; Department of Chemistry, The Hong Kong University of Science and Technology, Kowloon, Hong Kong SAR 999077, P. R. China; orcid.org/0000-0002-2470- 1077

Complete contact information is available at:

https://pubs.acs.org/10.1021/acs.orglett.5c02955

## Author Contributions

Z.H. and B.Z. contributed equally to this work. Z.H. and B.Z. designed the experiments and analyzed the data. L.W. and L.X. contributed to the preparation of substrates and ligands. Y.L., X.Z., and J.Y. performed the photophysical test. J.S., Z.H., and H.H. supervised the project and wrote the manuscript. All authors contributed to discussions and comments on the manuscript.

## Notes

The authors declare no competing financial interest.

## ■ ACKNOWLEDGMENTS

This work was supported by the NSFC (22201023 and 22271242), the Jiangsu Key Laboratory of Advanced Catalytic Materials and Technology (BM2012110), and the Changzhou Sci&Tech Program (CZ20240027).

## ■ REFERENCES

(1) Liang, Y. Y.; Yu, L. P. A new class of semiconducting polymers for bulk heterojunction solar cells with exceptionally high performance. Acc. Chem. Res. 2010, 43, 1227−1236.

(2) Oniwa, K.; Kanagasekaran, T.; Jin, T.; Akhtaruzzaman, M.; Yamamoto, Y.; Tamura, H.; Hamada, H.; Shimotani, H.; Asao, N.; Ikeda, S.; Tanigaki, K. Single crystal biphenyl end-capped furanincorporated oligomers: influence of unusual packing structure on carrier mobility and luminescence. J. Mater. Chem. C 2013, 1, 4163− 4170.

(3) Shang, H.; Shimotani, H.; Ikeda, S.; Kanagasekaran, T.; Oniwa, K.; Jin, T.; Asao, N.; Yamamoto, Y.; Tamura, H.; Abe, K.; Kanno, M.; Yoshizawa, M.; Tanigaki, K. Comparative study of single and dual gain-narrowed emission in thiophene/furan/phenylene co-oligomer single crystals. J. Phys. Chem. C 2017, 121, 2364−2368.

(4) Koskin, I. P.; Mostovich, E. A.; Benassi, E.; Kazantsev, M. S. Transition-metal-free continuous-flow synthesis of 2,5-diaryl furans: access to medicinal building blocks and optoelectronic materials. Chem. Commun. 2018, 54, 7235−7238.

(5) Kazantsev, M. S.; Beloborodova, A. A.; Kuimov, A. D.; Koskin, I. P.; Frantseva, E. S.; Rybalova, T. V.; Shundrina, I. K.; Becker, C. S.; Mostovich, E. A. Synthesis, luminescence and charge transport properties of furan/phenylene co-oligomers: The study of conjugation length effect. Org. Electron. 2018, 56, 208−215.

(6) Megret-Bonilla, A.; Neu, J.; Oh, J.; You, W. Achieving closedloop recycling of a semi-conjugated polymer through the incorporation of ester linkers along the backbone. ChemSusChem 2025, 18, No. e202401376.

(7) Shanahan, J.; Yan, L.; Olanrewaju, Y.; Kashani, S.; Ade, H.; So, F.; You, W. Acid-triggered side chain cleavage leads to doped conjugated polymers of high conductivity. J. Am. Chem. Soc. 2024, 146, 32243−32248.

(8) Bunz, U. H. α-Oligofurans: molecules without a twist. Angew. Chem., Int. Ed. 2010, 49, 5037−5040.

(9) Gidron, O.; Dadvand, A.; Sheynin, Y.; Bendikov, M.; Perepichka, D. F. Towards “green” electronic materials. α-Oligofurans as semiconductors. Chem. Commun. 2011, 47, 1976−1978.

(10) Gidron, O.; Bendikov, M. α-Oligofurans: an emerging class of conjugated oligomers for organic electronics. Angew. Chem., Int. Ed. 2014, 53, 2546−2555.

(11) Mulay, S. V.; Bogoslavky, B.; Galanti, I.; Galun, E.; Gidron, O. Bifuran-imide: a stable furan building unit for organic electronics. J. Mater. Chem. C 2018, 6, 11951−11955.

(12) Pachariyangkun, A.; Suda, M.; Hadsadee, S.; Jungsuttiwong, S.; Nalaoh, P.; Pattanasattayavong, P.; Sudyoadsuk, T.; Yamamoto, H. M.; Promarak, V. Effect of thiophene/furan substitution on organic

field effect transistor properties of arylthiadiazole based organic semiconductors. J. Mater. Chem. C 2020, 8, 17297−17306.

(13) Okada, M.; Tachikawa, K.; Aoi, K. Biodegradable polymers based on renewable resources. III. copolyesters composed of 1,4:3,6- dianhydro-D-glucitol, 1,1-bis(5-carboxy-2-furyl)ethane and aliphatic dicarboxylic acid units. J. Appl. Polym. Sci. 1999, 74, 3342−3350.

(14) Gidron, O.; Diskin-Posner, Y.; Bendikov, M. α-Oligofurans. J. Am. Chem. Soc. 2010, 132, 2148−2150.

(15) Fallon, T.; Willis, A. C.; Rae, A. D.; Paddon-Row, M. N.; Sherburn, M. S. β-Oligofurans. Chem. Sci. 2012, 3, 2133−2137.

(16) Cui, X.; Xu, X.; Wojtas, L.; Kim, M. M.; Zhang, X. P. Regioselective synthesis of multisubstituted furans via metalloradical cyclization of alkynes with α-diazocarbonyls: construction of functionalized α-oligofurans. J. Am. Chem. Soc. 2012, 134, 19981− 19984.

(17) Zhang, H.; Wakamiya, A.; Yamaguchi, S. Highly electrondonating 3,3′-diaryl-1,1′-bi(isobenzofuran)s synthesized by photochemical exocyclic [2 + 2 + 2] cycloaddition. Org. Lett. 2008, 10, 3591−3594.

(18) Song, C.; Sun, D.; Peng, X.; Bai, J.; Zhang, R.; Hou, S.; Wang, J.; Xu, Z. Dimerization of cyclopropenes to bifurans using tandem metal relay catalysis. Chem. Commun. 2013, 49, 9167−9169.

(19) Song, C.; Ju, L.; Wang, M.; Liu, P.; Zhang, Y.; Wang, J.; Xu, Z. From cyclopropenes to tetrasubstituted furans: tandem isomerization/alkenylation sequence with Cu/Pd relay catalysis. Chem. - Eur. J. 2013, 19, 3584−3589.

(20) Qi, J.; Teng, Q.; Thirupathi, N.; Tung, C.-H.; Xu, Z. Diastereoselective synthesis of polysubstituted spirocyclopenta[c]- furans by gold-catalyzed cascade reaction. Org. Lett. 2019, 21, 692− 695.

(21) Chen, Y.; Shen, P.; Cao, T.; Chen, H.; Zhao, Z.; Zhu, S. Bottom-up modular synthesis of well-defined oligo(arylfuran)s. Nat. Commun. 2021, 12, 6165.

(22) Wei, Z.; Chen, Y.; Wang, J.; Yang, T.; Zhao, Z.; Zhu, S. De novo synthesis of α-oligo(arylfuran)s and its application in OLED as hole-transporting material. Chem. - Eur. J. 2023, 29, No. e202203444.

(23) Garcia-Garrido, S. E. Catalytic Dimerization of Alkynes. In Modern Alkyne Chemistry; Trost, B. M., Li, C.-J., Eds.; Wiley: Weinheim, Germany, 2015; pp 301−334.

(24) Trost, B. M.; Masters, J. T. Transition metal-catalyzed couplings of alkynes to 1,3-enynes: modern methods and synthetic applications. Chem. Soc. Rev. 2016, 45, 2212−2238.

(25) Temkin, O. N. ″Golden Age″ of homogeneous catalysis cchemistry of alkynes: dimerization and oligomerization of alkynes. Kinet. Catal. 2019, 60, 689−732.

(26) Babon, J. C.; Esteruelas, M. A.; Lopez, A. M. Homogeneous catalysis with polyhydride complexes. Chem. Soc. Rev. 2022, 51, 9717−9758.

(27) O’Broin, C. Q.; Guiry, P. J. Advances in decarboxylative palladium-catalyzed reactions of propargyl electrophiles. J. Org. Chem. 2020, 85, 10321−10333.

(28) Detz, R. J.; Hiemstra, H.; vanMaarseveen, J. H. Catalyzed propargylic substitution. Eur. J. Org. Chem. 2009, 2009, 6263−6276.

(29) Miyake, Y.; Uemura, S.; Nishibayashi, Y. Catalytic propargylic substitution reactions. ChemCatChem. 2009, 1, 342−356.

(30) Ding, C.-H.; Hou, X.-L. Catalytic asymmetric propargylation. Chem. Rev. 2011, 111, 1914−1937.

(31) Nishibayashi, Y. Recent advances in photoacid catalysis for organic synthesis. Synthesis 2012, 2012, 489−503.

(32) Roh, S. W.; Choi, K.; Lee, C. Transition metal vinylidene- and allenylidene-mediated catalysis in organic synthesis. Chem. Rev. 2019, 119, 4293−4356.

(33) You, Y.; Zhang, Y.-P.; Wang, Z.-H.; Zhao, J.-Q.; Yin, J.-Q.; Yuan, W.-C. Recent advances in copper-catalyzed decarboxylative reactions of propargylic cyclic carbonates/carbamates. Chem. Commun. 2023, 59, 7483−7505.

(34) Kong, H.-H.; Zhu, C.; Deng, S.; Xu, G.; Zhao, R.; Yao, C.; Xiang, H.-M.; Zhao, C.; Qi, X.; Xu, H. Remote enantioselective [4 +

1] annulation with copper vinylvinylidene intermediates. J. Am. Chem. Soc. 2022, 144, 21347−21355.

(35) Sun, Y.-Z.; Ren, Z.-Y.; Yang, Y.-X.; Liu, Y.; Lin, G.-Q.; He, Z.-T. Asymmetric substitution by alkynyl copper driven dearomatization and rearomatization. Angew. Chem., Int. Ed. 2023, 62, No. e202314517.

(36) Garcia-Roca, A.; Pérez-Soto, R.; Stoica, G.; Benet-Buchholz, J.; Maseras, F.; Kleij, A. W. Comprehensive mechanistic scenario for the Cu-mediated asymmetric propargylic sulfonylation forging tertiary carbon stereocenters. J. Am. Chem. Soc. 2023, 145, 6442−6452.

(37) You, Y.; Li, T.-T.; Sun, T.-J.; Zhang, Y.-P.; Wang, Z.-H.; Zhao, J.-Q.; Yuan, W.-C. Enantioselective construction of vicinal quaternarytetrasubstituted carbon stereocenters by copper-catalyzed decarboxylative propargylic substitution. Org. Lett. 2022, 24, 7671−7676.

(38) Fisher, J. M.; Williams, M. L.; Palmer, J. R.; Powers-Riggs, N. E.; Young, R. M.; Wasielewski, M. R. Long-lived charge separation in single crystals of an electron donor covalently linked to four acceptor molecules. J. Am. Chem. Soc. 2024, 146, 9911−9919.

(39) Yamaguchi, R.; Hiroto, S.; Shinokubo, H. Synthesis of oxygensubstituted hexa-peri-hexabenzocoronenes through Ir-catalyzed direct borylation. Org. Lett. 2012, 14, 2472−2475.

(40) Cui, S.; Zhuang, G.; Lu, D.; Huang, Q.; Jia, H.; Wang, Y.; Yang, S.; Du, P. A three-dimensional capsule-like carbon nanocage as a segment model of capped zigzag [12,0] carbon nanotubes: synthesis, characterization, and complexation with C . Angew. Chem., Int. Ed. 2018, 57, 9330−9335.

(41) Morita, F.; Nogami, J.; Araujo Dias, A. J.; Kinoshita, S.; Nagashima, Y.; Tanaka, K. Regiodivergent synthesis and π-stackinginduced chiral self-recognition of hexabenzocoronene-based [6]- helicenes. Eur. J. Org. Chem. 2022, 2022, No. e202200690.

(42) Zhou, L.; Zhang, M.; Li, W.; Zhang, J. Furan-based oquinodimethanes by gold-catalyzed dehydrogenative heterocyclization of 2-(1-alkynyl)-2-alken-1-ones: a modular entry to 2,3-furan-fused carbocycles. Angew. Chem., Int. Ed. 2014, 53, 6542−6545.

(43) Wang, Y.; Zhang, Z.-M.; Liu, F.; He, Y.; Zhang, J. Ming-Phos/ gold(I)-catalyzed diastereo- and enantioselective synthesis of indolyl substituted cyclopenta[c]furans. Org. Lett. 2018, 20, 6403−6406.

(44) Zhou, L.; Zhang, M.; Li, W.; Zhang, J. Furan-based oquinodimethanes by gold-catalyzed dehydrogenative heterocyclization of 2-(1-alkynyl)-2-alken-1-ones: a modular entry to 2,3-furan-fused carbocycles. Angew. Chem., Int. Ed. 2014, 53, 6542−6545.

(45) Ye, J.; Ma, S. Palladium-catalyzed cyclization reactions of allenes in the presence of unsaturated carbon-carbon bonds. Acc. Chem. Res. 2014, 47, 989−1000.

(46) Ma, S. Electrophilic addition and cyclization reactions of allenes. Acc. Chem. Res. 2009, 42, 1679−1688.

(47) Yu, S.; Ma, S. Allenes in catalytic asymmetric synthesis and natural product syntheses. Angew. Chem., Int. Ed. 2012, 51, 3074− 3112.

(48) Alonso, J. M.; Almendros, P. Deciphering the chameleonic chemistry of allenols: breaking the taboo of a onetime esoteric functionality. Chem. Rev. 2021, 121, 4193−4252.

(49) Fan, X.; He, Y.; Zhang, X. Recent advances in the reactions of 1,2-allenic ketones and α-allenic alcohols. Chem. Rec. 2016, 16, 1635− 1646.