pubs.acs.org/OrgLett

Letter

# Access to Conjugated Dienes and Cyclic Allenes via a Diazo-Dithiane Rearrangement Cascade

Zhuzhu Zhang, Xiaomeng Gong, Yingze Jin, Rui-Peng Li,\* and Shouchu Tang\*

![](images/06dac4a69f170f9220fa65d5d709dc0d84cccac17e2ed2c85d675f6c0613bd5e.jpg)

ACCESS

![](images/be4095840e86e89287c5b093ee7c08c5445fdd89198b7af41861eb207ebe4a97.jpg)  
ABSTRACT: A transition-metal-free, base-promoted cascade between alkynyl-1,3-dithianes and α-diazodiesters has been developed. The reaction proceeds through an anion relay chemistry (ARC) featuring a selective 1,3-sulfur rearrangement, enabling divergent access to eight-membered sulfur-containing conjugated dienes and cyclic allenes in a one-pot fashion. This transformation unveils new diazo reactivity beyond classical carbene pathways and highlights the synthetic utility of sulfur-based anionic processes.

S ulfur-containing heterocycles are ubiquitous structural motifs in pharmaceuticals, agrochemicals, natural products, and functional materials.<sup>1</sup> While small sulfur heterocycles such as thiophenes are well established synthetically,<sup>2</sup> the preparation of medium-sized (8−10-membered) sulfur rings remains a formidable challenge owing to transannular strain and conformational rigidity.<sup>3,4</sup> Despite their unique electronic and three-dimensional features, such scafolds are rarely explored in drug discovery due to the lack of eficient synthetic methods.<sup>5</sup> Therefore, developing general and eficient strategies to access medium-sized sulfur heterocycles under mild conditions is of considerable importance in synthetic and medicinal chemistry.

To date, several strategies have been developed for the construction of medium-sized sulfur-containing heterocycles, including intramolecular transition-metal-catalyzed cyclization, radical-mediated processes, and ring-expansion reactions (Scheme 1a).<sup>6</sup> Among sulfur-rich building blocks, 1,3-dithianes are particularly attractive due to their stability and versatile reactivity beyond their traditional role as carbonyl protecting groups.<sup>7</sup> Early work by Oku demonstrated ring expansion of thioacetals via sulfonium ylide intermediates,<sup>6b</sup> and Terada later achieved an enantioselective variant using chiral phosphoric acid (CPA) catalysis.<sup>6f</sup> Among medium-sized sulfur heterocycles, cyclic allenes and conjugated dienes have attracted particular interest due to their structural uniqueness and potential applications. While significant progress has been made, methods for their general and selective synthesis remain limited. Wang and co-workers reported an Au-catalyzed rearrangement of propargylic 1,3-dithianes to cyclic allenes, with conjugated dienes formed only when specific substituents were present at the 2-position of the dithiane ring .<sup>8a</sup> Similarly, Yucel described a base-mediated rearrangement of 1,3- dithianyl-substituted propargylamines, delivering nine-membered sulfur-containing heterocycles bearing an internal conjugated diene motif under mild conditions.<sup>8b</sup> Although these studies represent elegant contributions, existing strategies remain largely metal-catalyzed and are often limited to specific substrate types. Consequently, the development of transitionmetal-free approaches that provide broader synthetic flexibility remains highly desirable.

Diazo compounds have been extensively studied; however, transition-metal-free couplings between diazo species and heteroatom-stabilized carbanions remain underexplored.<sup>9</sup> Metal-free diazo transformations are synthetically appealing because they circumvent potential metal contamination and often proceed under milder conditions. Building on our previous studies of base-promoted anion relay chemistry (ARC) and 1,3-sulfur rearrangements,<sup>10</sup> we envisioned that the nucleophilic anion generated from alkynyl-1,3-dithianes could undergo a carbene-free anionic coupling with α- diazodiesters, followed by a 1,3-sulfur rearrangement to furnish structurally diverse sulfur heterocycles (Scheme 1c). Herein, we disclose a transition-metal-free, base-promoted cascade reaction between alkynyl-1,3-dithianes and α-diazodiesters that proceeds through an anion relay process. Depending on the electrophilic quencher, this cascade selectively yields eightmembered sulfur-containing conjugated dienes or cyclic allenes, providing a rare example of diazo-dithiane coupling via a concerted anionic rearrangement under mild conditions.

![](images/021d8c065574a20262bac85dbae084df36ee50bee9429b79b93da90992920ffe.jpg)

Scheme 1. Background for This Study  
a) Syntheses of sulfur-containing heterocycles  
![](images/41ead9213f9a6da050346192e073fab461110d603678f639b8c59833fe63f1cd.jpg)  
Table 1. Optimization of the Reaction Conditions<sup>a</sup>

![](images/d1cb02ab2b366f71cf61e2915ac8eb9f2a7df4a4f79087fd56d6796ae4cba26c.jpg)

<table><tr><td>Entry</td><td>Deviation from standard conditions</td><td>Yield  $\left( \% \right) ^ { b }$ </td></tr><tr><td>1</td><td>none</td><td>88</td></tr><tr><td>2</td><td>Without KOBu</td><td>N.R.</td></tr><tr><td>3</td><td>NaOBu instead of KOBu</td><td>39</td></tr><tr><td>4</td><td>DBU instead of KOBu</td><td>N.R.</td></tr><tr><td>5</td><td> ${ \mathrm { C s } } _ { 2 } { \mathrm { C O } } _ { 3 }$  instead of KOBu</td><td>N.R.</td></tr><tr><td>6</td><td>THF instead of DMSO</td><td>N.R.</td></tr><tr><td>7</td><td>DMF instead of DMSO</td><td>65</td></tr><tr><td>8</td><td> $6 0 ~ ^ { \circ } \mathrm { C }$  instead of rt</td><td>45</td></tr></table>

<sup>a</sup>Standard conditions: 1a (0.1 mmol), 2a (0.1 mmol), and KO<sup>t</sup>Bu (0.15 mmol) dissolved in DMSO (2.0 mL), rt, followed by quenching with $\mathrm { H } _ { 2 } \mathrm { O }$ to give conjugated diene product 3a. All entries were quenched with $_ \mathrm { H } _ { 2 } \mathrm { O }$ unless otherwise noted; <sup>b</sup>Isolated yields. ${ \bf N } . { \bf R } = { \bf N } _ { 0 }$ Reaction.

Using alkynyl-1,3-dithiane 1a and α-diazodiester 2a as model substrates (Table 1), we identified KO<sup>t</sup>Bu (1.5 equiv) as the optimal base in DMSO at room temperature, afording the conjugated diene 3a in 88% yield (Entry 1). Control experiments confirmed the essential role of base and solvent: no conversion was observed without base (Entry 2), weaker bases such as NaO<sup>t</sup>Bu reduced the yield (39%) (Entry 3), while DBU and ${ \mathrm { C s } } _ { 2 } { \mathrm { C O } } _ { 3 }$ were inefective (Entries 4 and 5). Among solvents, only DMSO enabled efective conversion; THF completely suppressed reactivity, and DMF led to a moderate yield of 65% (Entries 6 and 7). This unique DMSO efect can be attributed to its ability to generate a nucleophilic DMSO-derived carbanion under basic conditions, thereby initiating the anionic relay, whereas other aprotic solvents fail to provide such activation. Elevated temperature $( 6 0 ~ ^ { \circ } \mathrm { C } )$ led to decomposition, emphasizing the importance of maintaining mild conditions for this anionic cascade (Entry 8).

With optimized conditions, a wide range of aryl-substituted alkynyl-1,3-dithianes underwent smooth transformation to conjugated dienes $\mathbf { 3 a - 3 g }$ in 75−88% yield (Scheme 2). Electron-donating, electron-withdrawing, and sterically hindered substituents were all well-tolerated. Extended aromatic systems (benzofuranyl, piperonyl, naphthyl) also participated smoothly (3h−3j, 77−81%). In contrast, alkyl-substituted dithianes failed to produce detectable product 3k, underscoring the stabilizing role of aryl substituents in the intermediate anions. Diverse α-diazodiesters were also compatible, furnishing products 3l−3s in 80−87% yield. The structure of 3l was unambiguously confirmed by X-ray crystallography (CCDC 2427670).

Remarkably, the reaction outcome could be significantly modulated by the choice of quenching reagent. Replacement of $_ { \mathrm { H } _ { 2 } \mathrm { O } }$ with electrophilic alkyl halides (e.g., methyl iodide, benzyl bromide, ethyl bromoacetate, 1-iodononane, and iodocyclopentane) led to sulfur-containing cyclic allenes 4a−4i in 71− 86% yield (Scheme 3). This switchable reactivity underscores the tunability of the anionic relay pathway and ofers a concise, operationally simple approach to cyclic allene frameworks, which serve as valuable intermediates for complex molecule synthesis.

Scheme 2. Substrate Scope of Conjugated Dienes  
![](images/a49f2b30f0fcde5eae0e2529da5a95ffe532366ceb565fbd7299581d02350ffb.jpg)  
<sup>a</sup>Reaction conditions: 1 (0.1 mmol), 2 (0.1 mmol), KO<sup>t</sup>Bu (0.15 mmol) in DMSO (2.0 mL), rt, then quenched with $\mathrm { H } _ { 2 } \mathrm { O } .$ Isolated yields. ${ \boldsymbol { \mathbf { \mathit { \Sigma } } } } ^ { b } \mathrm { N D \ : = \ : \left( \mathbf { \bar { \Sigma } } \right) }$ Not Detected.

The transformation was readily scaled up to gram scale, afording 3a in 80% yield (Scheme 4a). The conjugated diene product was further diversified through selective functionalization (Scheme 4b). Reduction of the ester group using DIBAL-H at diferent temperatures aforded the corresponding primary alcohol 5a in 56% yield or the aldehyde 5b in 53% yield. Furthermore, treatment of 3a with Raney-Ni under an air atmosphere led to eficient desulfurization and hydrogenation, yielding the saturated compound 5c in 72% yield. In addition, oxidation of the dithiane unit with m-CPBA enabled a mild and selective conversion to the sulfoxide derivative 5d in 78% yield.

Radical inhibition experiments with TEMPO showed no efect, ruling out radical pathways.<sup>8b</sup> The reaction of 97% deuterated-1,3-dithiane D-1a with α-diazodiesters 2a gave product D-3a1 with 9% D incorporation at the vinylic position. When the crude reaction mixture was quenched with $\mathrm { D } _ { 2 } \mathrm { O } ,$ product D-3a2 was obtained with 96% D incorporation at the same position. In contrast, quenching with $\mathrm { D M S O - } d _ { 6 }$ aforded D-3a3 with only 6% D incorporation. Deuterium-labeling studies revealed that deprotonation of $^ { 1 , 3 \cdot }$ -dithiane at the α-

Scheme 3. Substrate Scope of Cyclic Allenes<sup>a</sup>  
![](images/37e3215bc5e964c90143336270ac20c70830c1e8029d47a0f79ea20347e5c0f8.jpg)

<sup>a</sup>Reaction conditions: 1 (0.1 mmol), 2 (0.1 mmol), KO<sup>t</sup>Bu (0.15 mmol) in DMSO (2.0 mL), rt, then quenched with electrophiles (0.15 mmol) to trap the reactive intermediate. Isolated yields.

Scheme 4. Scale-up Experiments and Synthetic Utility

a) Large-scale reaction

![](images/0b81e3c268040693b9c94e0c943528e503d4f741fe6f45a50ed83b5a1d01ce7a.jpg)

![](images/73d0e2c0dbe10eb6ff31b9be8ee3ec419f6da4ac465ac98f161be8335915bd5f.jpg)

position precedes coupling, and the protonation occurs exclusively during the quenching step. These results support an anionic mechanism involving sequential deprotonation, cyclization, and sulfur migration (Scheme 5).

A plausible mechanism consistent with the experimental observations is depicted in Scheme 6. Deprotonation of alkynyl-1,3-dithiane 1 generates an alkynyl anion, which rapidly equilibrates to the allenyl anion A. Nucleophilic attack of A to the α-diazodiester 2 furnishes intermediate $\mathbf { B } ,$ followed by an intramolecular nucleophilic attack to aford C. Subsequent extrusion of $\Nu _ { 2 }$ forms anion D, which undergoes an anion-relay process, triggering fragmentation of the $^ { 1 , 3 \cdot }$ dithiane scafold to generate a sulfur-centered anion E. A 1,3- sulfur rearrangement, driven by the reorganization of the C−S bonds, converts E into the conjugated diene anion F. Protonation of F during aqueous workup furnishes the

## Scheme 5. Mechanism Investigation

a) Control experiment

![](images/1760886c61af3034c0c706395652d6e3fe7a577701730a6383d70445ce039d02.jpg)

b) Deuterium labeling experiments

![](images/639b15fcd59854bd284baec9b05692ade5025a498e8bae28c717bbf6edc54800.jpg)

Scheme 6. Proposed Mechanism

![](images/381a55594c0aff8ecdb825d07b017e962d0b3da8fa15161209999c4f49ceaa3d.jpg)

observed diene 3. Alternatively, anion F can tautomerize to the allenyl anion $\mathbf { G } ,$ whose interception by an external electrophile leads to the formation of the cyclic allene 4.

In summary, we have developed a transition-metal-free, anion-relay cascade reaction between alkynyl-1,3-dithianes and α-diazodiesters that enables the divergent synthesis of conjugated dienes and cyclic allenes. This transformation features a distinctive 1,3-sulfur rearrangement under mild basic conditions, exhibits broad substrate scope with tunable selectivity controlled by the electrophilic quencher, and proceeds with operational simplicity and scalability. Importantly, this work expands diazo chemistry beyond conventional carbene reactivity into the realm of anionic processes, demonstrating the potential of sulfur-based anionic cascades for the eficient construction of medium-sized heterocycles and ofering a new conceptual framework for transition-metal-free diazo coupling chemistry.

## ■ ASSOCIATED CONTENT

## Data Availability Statement

The data underlying this study are available in the published article and its Supporting Information.

## \*sı Supporting Information

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acs.orglett.5c04254.

Experimental details, characterization data, X-ray crystallographic data of 3l, and copies of <sup>1</sup>H and $^ { 1 3 } \dot { \mathrm { C } }$ NMR spectra (PDF)

## Accession Codes

Deposition Number 2427670 contains the supplementary crystallographic data for this paper. These data can be obtained free of charge via the joint Cambridge Crystallographic Data Centre (CCDC) and Fachinformationszentrum Karlsruhe Access Structures service.

## ■ AUTHOR INFORMATION

## Corresponding Authors

Rui-Peng Li − School of Basic Medical Sciences, Ningxia Medical University, Yinchuan 750004, P. R. China; Email: liruipeng@nxmu.edu.cn

Shouchu Tang − School of Pharmacy, and State Key Laboratory of Nature Product Chemistry, Lanzhou University, Lanzhou 730000, P. R. China; orcid.org 0000-0002-5394-7156; Email: tangshch@lzu.edu.cn

## Authors

Zhuzhu Zhang − School of Pharmacy, and State Key Laboratory of Nature Product Chemistry, Lanzhou University, Lanzhou 730000, P. R. China

Xiaomeng Gong − School of Pharmacy, and State Key Laboratory of Nature Product Chemistry, Lanzhou University, Lanzhou 730000, P. R. China

Yingze Jin − School of Pharmacy, and State Key Laboratory of Nature Product Chemistry, Lanzhou University, Lanzhou 730000, P. R. China

Complete contact information is available at: https://pubs.acs.org/10.1021/acs.orglett.5c04254

## Author Contributions

Z.Z. and X.G. contributed equally to this work. All authors have given approval to the final version of the manuscript.

## Notes

The authors declare no competing financial interest.

## ■ ACKNOWLEDGMENTS

We are grateful to the Fundamental Research Funds for the Central Universities (No. lzujbky-2025-it13) and the Optical Joint Research Center of Lanzhou University and Constar group for financial support.

## ■ REFERENCES

(1) (a) Clayden, J.; MacLellan, P. Asymmetric Synthesis of Tertiary Thiols and Thioethers. Beilstein J. Org. Chem. 2011, 7, 582−595. (b) Benetti, S.; De Risi, C.; Pollini, G. P.; Zanirato, V. Synthetic Routes to Chiral Nonracemic and Racemic Dihydro- And Tetrahydrothiophenes. Chem. Rev. 2012, 112 (4), 2129−2163. (c) Chauhan, P.; Mahajan, S.; Enders, D. Organocatalytic Carbon− Sulfur Bond-Forming Reactions. Chem. Rev. 2014, 114 (18), 8807− 8864. (d) Barbarella, G.; Zangoli, M.; Di Maria, F. Synthesis and Applications of Thiophene Derivatives as Organic Materials. Adv. Heterocycl. Chem. 2017, 123, 105−167. (e) Pathania, S.; Narang, R. K.; Rawal, R. K. Role of Sulphur-Heterocycles in Medicinal Chemistry: An Update. Eur. J. Med. Chem. 2019, 180, 486−508. (f) Koning, N. R.; Sundin, A. P.; Strand, D. Total Synthesis of (−)-Glionitrin A and B Enabled by an Asymmetric Oxidative Sulfenylation of Triketopiperazines. J. Am. Chem. Soc. 2021, 143 (50), 21218−21222.

(2) (a) Wang, M.; Fan, Q.; Jiang, X. Transition-Metal-Free Diarylannulated Sulfide and Selenide Construction via Radical/ Anion-Mediated Sulfur−Iodine and Selenium−Iodine Exchange. Org. Lett. 2016, 18 (21), 5756−5759. (b) Mal, K.; Naskar, S.; Sen, S. K.; Natarajan, R.; Das, I. Tandem Chemoselective 1,2-/1,4-Migration of the Thio Group in Keto Thioesters: An Efficient Approach to Substituted Butenolides. Adv. Synth Catal 2016, 358 (20), 3212− 3230. (c) Yuan, T.; Ryckaert, B.; Van Hecke, K.; Hullaert, J.; Winne, J. M. Stereoselective Gold(I)-Catalyzed Vinylcyclopropanation via Generation of a Sulfur-Substituted Vinyl Carbene Equivalent. Angew. Chem. Int. Ed 2021, 60 (8), 4070−4074.

(3) (a) Cope, A. C.; Martin, M. M.; McKervey, M. A. Transannular reactions in medium-sized rings. Q. Rev. Chem. Soc. 1966, 20, 119− 152. (b) Michaut, A.; Rodriguez, J. Selective Construction of Carbocyclic Eight-Membered Rings by Ring-Closing Metathesis of Acyclic Precursors. Angew. Chem. Int. Ed 2006, 45 (35), 5740−5750. (4) (a) Yet, L. Metal-Mediated Synthesis of Medium-Sized Rings. Chem. Rev. 2000, 100 (8), 2963−3008. (b) Choury, M.; Lopes, A. B.; Blond, G.; Gulea, M. Synthesis of Medium-Sized Heterocycles by Transition-Metal-Catalyzed Intramolecular Cyclization. Molecules 2020, 25, 3147. (c) Reyes, R. L.; Iwai, T.; Sawamura, M. Construction of Medium-Sized Rings by Gold Catalysis. Chem. Rev. 2021, 121 (14), 8926−8947.

(5) (a) Tatsuta, T.; Hosono, M.; Rotinsulu, H.; Wewengkang, D. S.; Sumilat, D. A.; Namikoshi, M.; Yamazaki, H. Lissoclibadin 1, a Polysulfur Aromatic Alkaloid from the Indonesian Ascidian Lissoclinum Cf. Badium, Induces Caspase-Dependent Apoptosis in Human Colon Cancer Cells and Suppresses Tumor Growth in Nude Mice. J. Nat. Prod. 2017, 80 (2), 499−502. (b) Chang, S.; Cai, M.; Xiao, T.; Chen, Y.; Zhao, W.; Yu, L.; Shao, R.; Jiang, W.; Zhang, T.; Gan, M.; Si, S.; Chen, M. Prenylemestrins A and B: Two Unexpected Epipolythiodioxopiperazines with a Thioethanothio Bridge from Emericella Sp. Isolated by Genomic Analysis. Org. Lett. 2022, 24 (32), 5941−5945.

(6) (a) Nickon, A.; Rodriguez, A. D.; Shirhatti, V.; Ganguly, R. Bicyclic Vinyl Sulfides by Ring Expansions of Spirocyclic Dithioketal Systems. J. Org. Chem. 1985, 50 (22), 4218−4226. (b) Mori, T.; Sawada, Y.; Oku, A. Ring-Expansion of Thioacetal Ring via Bicyclosulfonium Ylide. Effect of Protic Nucleophile on Ylide Intermediate. J. Org. Chem. 2000, 65 (12), 3620−3625. (c) Zhou, H.; Xing, Y.; Liu, L.; Hong, J. Sulfur as a Bridge: Synthesis of Medium Rings via a Bicyclic Sulfonium Ion. Adv. Synth Catal 2011, 353 (17), 3146−3150. (d) Aldrich, L. N.; Kuo, S.-Y.; Castoreno, A. B.; Goel, G.; Kuballa, P.; Rees, M. G.; Seashore-Ludlow, B. A.; Cheah, J. H.; Latorre, I. J.; Schreiber, S. L.; Shamji, A. F.; Xavier, R. J. Discovery of a Small-Molecule Probe for V-ATPase Function. J. Am. Chem. Soc. 2015, 137 (16), 5563−5568. (e) Law, J. M.; Stark, S. C.; Liu, K.; Liang, N. E.; Hussain, M. M.; Leiendecker, M.; Ito, D.; Verho, O.; Stern, A. M.; Johnston, S. E.; Zhang, Y.-L.; Dunn, G. P.; Shamji, A. F.; Schreiber, S. L. Discovery of 8-Membered Ring Sulfonamides as Inhibitors of Oncogenic Mutant Isocitrate Dehydrogenase 1. ACS Med. Chem. Lett. 2016, 7 (10), 944−949. (f) Li, F.; Korenaga, T.; Nakanishi, T.; Kikuchi, J.; Terada, M. Chiral Phosphoric Acid Catalyzed Enantioselective Ring Expansion Reaction of 1,3-Dithiane Derivatives: Case Study of the Nature of Ion-Pairing Interaction. J. Am. Chem. Soc. 2018, 140 (7), 2629−2642. (g) Palate, K. Y.; Epton, R. G.; Whitwood, A. C.; Lynam, J. M.; Unsworth, W. P. Synthesis of Macrocyclic and Medium-Sized Ring Thiolactones via the Ring Expansion of Lactams. Org. Biomol. Chem. 2021, 19 (6), 1404−1411. (h) Yang, Z.; Zalessky, I.; Epton, R. G.; Whitwood, A. C.; Lynam, J. M.; Unsworth, W. P. Ring Expansion Strategies for the Synthesis of Medium Sized Ring and Macrocyclic Sulfonamides. Angew. Chem. Int. Ed 2023, 62 (13), No. e202217178. (i) Zalessky, I.; Wootton, J. M.; Tam, J. K. F.; Spurling, D. E.; Glover-Humphreys, W. C.; Donald, J. R.; Orukotan, W. E.; Duff, L. C.; Knapper, B. J.; Whitwood, A. C.; Tanner, T. F. N.; Miah, A. H.; Lynam, J. M.; Unsworth, W. P. A Modular Strategy for the Synthesis of Macrocycles and Medium-Sized Rings via Cyclization/Ring Expansion Cascade Reactions. J. Am. Chem. Soc. 2024, 146 (8), 5702−5711.

(7) (a) Smith, A. B.; Adams, C. M. Evolution of Dithiane-Based Strategies for the Construction of Architecturally Complex Natural Products. Acc. Chem. Res. 2004, 37, 365−377. (b) Deng, Y.; Smith, A. B. Evolution of Anion Relay Chemistry: Construction of Architecturally Complex Natural Products. Acc. Chem. Res. 2020, 53, 988−1000.

(8) (a) Zhao, X.; Zhong, Z.; Peng, L.; Zhang, W.; Wang, J. Au (PPh ) Cl−AgSbF -Catalyzed Rearrangement of Propargylic 1,3- Dithianes: Formation of 8-Membered 1,3-Bisthio-Substituted Cyclic Allenes. Chem. Commun. 2009, 18, 2535. (b) Dinc, M.; Ismailoglu, E.; Mert, Z.; Kaya, K.; Tayanc, M.; Yucel, B. Base-Mediated Rearrangement of α-Dithioacetyl Propargylamines via Expansion of Dithioacetyl Ring: Synthesis of Medium-Sized S, S -Heterocycles. Org. Lett. 2023, 25 (22), 4028−4032.

(9) (a) Davies, H. M. L.; Denton, J. R. Application of Donor/ Acceptor-Carbenoids to the Synthesis of Natural Products. Chem. Soc. Rev. 2009, 38 (11), 3061. (b) Davies, H. M. L.; Morton, D. Guiding Principles for Site Selective and Stereoselective Intermolecular C−H Functionalization by Donor/Acceptor Rhodium Carbenes. Chem. Soc. Rev. 2011, 40 (4), 1857. (c) Zhao, X.; Zhang, Y.; Wang, J. Recent Developments in Copper-Catalyzed Reactions of Diazo Compounds. Chem. Commun. 2012, 48 (82), 10162. (d) Xiao, Q.; Zhang, Y.; Wang, J. Diazo Compounds and N -Tosylhydrazones: Novel Cross-Coupling Partners in Transition-Metal-Catalyzed Reactions. Acc. Chem. Res. 2013, 46 (2), 236−247. (e) Cheng, Q.-Q.; Deng, Y.; Lankelma, M.; Doyle, M. P. Cycloaddition Reactions of Enoldiazo Compounds. Chem. Soc. Rev. 2017, 46 (17), 5425−5443.

(f) Dasgupta, A.; Stefkova, K.; Babaahmadi, R.; Gierlichs, L.; Ariafard, A.; Melen, R. L. Triarylborane-Catalyzed Alkenylation Reactions of Aryl Esters with Diazo Compounds. Angew. Chem. Int. Ed 2020, 59 (36), 15492−15496. (g) Dasgupta, A.; Babaahmadi, R.; Slater, B.; Yates, B. F.; Ariafard, A.; Melen, R. L. Borane-Catalyzed Stereoselective C−H Insertion, Cyclopropanation, and Ring-Opening Reactions. Chem. 2020, 6 (9), 2364−2381. (h) Chen, N.; He, M.; Zhou, T.; Zhu, Y.; Zhang, H.; Peng, S. Recent Advances in the Tandem Cyclization/Cycloaddition of Allene Intermediates from Copper-Catalyzed Cross-Coupling of Diazo Compounds with Terminal Alkynes. Synthesis 2021, 53 (04), 611−622. (i) Wang, J. Diazo Compounds: Recent Applications in Synthetic Organic Chemistry and Beyond. Tetrahedron Lett. 2022, 108, No. 154135.

(10) (a) Li, R.-P.; Chen, X.; Xu, X.; Tang, Y.; Wang, H.; Tang, S. Stereoselective Synthesis of Highly Substituted 1,3-Dienes through Dual 1,3-Sulfur Rearrangement of Dithianes with Alkynylsilanes. Org. Lett. 2024, 26 (3), 581−585. (b) Li, R.-P.; Xu, X.; Zhang, Z.; Gong, X.; Tang, S. Anion Relay Chemistry Enables Stereoselective Carbonyl Alkyne Metathesis Reactions. Org. Lett. 2024, 26 (36), 7601−7606. (c) Gong, X.; Li, R.-P.; Xu, X.; Tang, G.; Tang, S. Stereoselective Alkyne−Alkene [2 + 2] Cycloaddition Enabled by Anion Relay Chemistry for Fully C-Substituted Cyclobutene Synthesis. Org. Lett. 2025, 27 (7), 1590−1595. (d) Zhang, Z.; Li, R.-P.; Gong, X.; Zhang, W.; Tang, S. Dithiane-Initiated Cascade to Eight-Membered Sulfur-Containing Pyrazoles via Decarboxylative Aromatization. Chem. Commun. 2025, 61 (66), 12401−12404.