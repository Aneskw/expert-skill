pubs.acs.org/OrgLett

Letter

# Total Syntheses of Plocabulin and Its C2-Analogues

Shunfa Liu, Bin Li, Xin Gao, Fenglin Wang, Xuan Li, Juxi Wang, Yuzhong Kuang, Luai Ji, Lu Gao, Wanshu Wang, Qifeng Chen,\* Yong Qin, and Zhenlei Song\*

![](images/7dc2946b29d07700c15e98475bde37dc2bbb0e16d1eb0c1e39f6b68138a856e1.jpg)

Cite This: Org. Lett. 2025, 27, 4788−4793

![](images/16d4f7a963e78a4e776cd119dd737e1aea0a3427f714fa03eea559be350092fb.jpg)

## ACCESS

Metrics & More

ABSTRACT: Plocabulin is a structurally unique marine natural product with potent antitumor activity, making it a promising candidate for the development of antibody−drug conjugates (ADCs). However, its extremely low natural abundance has limited further research and therapeutic exploration. In this study, we present a convergent synthetic strategy for plocabulin and its C2-analogues. Our approach enabled the synthesis of 1.23 g of plocabulin through a longest linear sequence of 12 steps and a total of 24 steps, achieving an overall yield of 19.7%.

product isolated from the sponge Lithoplocamia lithistoides, collected in Madagascar by Cuevas and co-workers (Scheme 1).<sup>1</sup> It acts as a potent microtubule-destabilizing

Scheme 1. Structures of Plocabulin and Previous Biological, Clinical, Chemical Synthetic and SAR Studies

![](images/c2ce8140e64ce608220fe5f4520c3e141124f431d49623e2395d9830f67a432c.jpg)

agent, exhibiting picomolar-level cytotoxicity against cancer cell lines. In certain models, plocabulin is 1,000 to 10,000 times more efective than paclitaxel and vinblastine.<sup>2</sup> It also overcomes P-glycoprotein-mediated multidrug resistance in vivo, highlighting its potential in resistant cancer types. Plocabulin binds to a unique site on β-tubulin, partially overlapping with maytansine but distinct from vinblastine, taxanes, and eribulin.<sup>4</sup> This suggests a novel mechanism of action. Currently evaluated in clinical trials for various tumors,<sup>5</sup> plocabulin holds promise for developing next-generation antibody−drug conjugates (ADCs).<sup>6</sup>

Plocabulin is naturally scarce, making large-scale extraction impractical. PharmaMar isolated only 2.6 mg of plocabulin from 7.66 kg of frozen sponge material, corresponding to a yield of 0.00003%.<sup>1</sup> To date, only two synthetic routes have been reported. Cuevas’ approach involves an 18-step longest

Article Recommendations

\*sı Supporting Information

![](images/4bbfd720aceb32ffe1a3871445ef7b6760cc5c3cfa7ab3db701db86bb47f46ca.jpg)

linear sequence (LLS) and 33 total steps (TS), producing 58 mg of plocabulin with a 3.9% overall yield.<sup>1b</sup> Li and Wang adopted a similar strategy, achieving comparably low eficiency (Scheme 1).<sup>7</sup> Structural studies by Steinmetz revealed a key pharmacophoric interaction between plocabulin’s C2-methoxy group and β-tubulin Lys105 through hydrogen bonding.<sup>4</sup> However, synthetic challenges have limited structure−activity relationship (SAR) studies on C2 modifications, despite extensive investigations of other molecular regions.<sup>3,8</sup> Therefore, it is demanding to develop eficient synthetic strategies that not only enable scalable production of plocabulin but also provide access to structurally diverse analogues.

We present a convergent synthesis of plocabulin and its C2 analogues (Scheme 2). A key feature of our strategy is the synthesis of the C1−C8 fragment, which employs a TiCl - chelated Hosomi−Sakurai allylation to establish the syn-C5/ C6 stereochemistry, followed by a sequential Mukaiyama aldollactonization process to form the α,β-unsaturated lactone with varied C2 substitutions. The eficiency of this route is demonstrated by the gram-scale synthesis of plocabulin (1.23 g) with a 19.7% overall yield in the 12 longest linear sequence (LLS) steps and 24 total steps (TS). This strategy also enabled the synthesis of five C2 analogues, which exhibit antiacute myeloid leukemia (AML) activity comparable to plocabulin. These findings provide valuable insights for the structural optimization of the lactone moiety and the development of improved analogues.

![](images/9847dccba03ee12f254a14f89d209877d8e8200bcfd6b80e09dacdb7b617bff6.jpg)

Scheme 2. Gram-Scale Total Synthesis of Plocabulin and Its C2-Analogues

![](images/8cfa0b1e51ee9668e81e657bbf9eb574c6ac7158f91e2ed7420e22cf6d32059b.jpg)

The synthesis of the C1−C8 fragment began with a $\mathrm { T i C l } _ { 4 } { \mathrm { - } }$ promoted Hosomi−Sakurai allylation of aldehyde 1, which contains a 1,3-dithiane at its β-position, using the known chiral allenylsilane $\left( R _ { a } \right) - 2 ^ { 9 }$ (Scheme 3). $\left( R _ { a } \right) - 2$ can be synthesized on 20 g-scale in an overall yield of 62% through a three-step

## Scheme 3. Synthesis of the C1−C8 Fragment

process starting from (R)-but-3-yn-2-ol S3 (see Supporting Information for details). Allylation of α-unsubstituted alkyl aldehydes with allenylsilanes typically results in poor diastereoselectivity, yielding syn/anti ratios between 2:1 and $4 { : } 1 . ^ { 1 0 }$ However, in our case, the dithiane moiety in 1 not only served as a masked aldehyde for subsequent transformations but also played a key role in achieving a high syn-selectivity. The reaction likely proceeded via a Ti(IV)-chelation model (3),<sup>11</sup> afording homopropargyl alcohol 4 in 60% yield with a syn/anti ratio exceeding 20:1. The absolute S-configuration at C5 of 4 was confirmed by Mosher ester analysis (see SI for details).<sup>12</sup> Acetylation of 4, followed by deprotection of the 1,3-dithiane with MeI $/ \mathrm { C a C O } _ { 3 } , ^ { 1 3 }$ provided β-acetoxy aldehyde 5 in 95% yield.

The attempted transformation of β-acetoxy aldehyde 5 via Keck’s method,<sup>14</sup> employing the lithium enolate of methyl 2- methoxyacetate (6) in THF, failed to aford the desired $\alpha { , } \beta { - }$ unsaturated lactone 12a (Scheme 3). This outcome is consistent with Keck’s observation that such transformations are efective only for α-unsubstituted lithium enolates. When

![](images/ec321ab96c77f448b80d3c37846635768078099948c292c22bbad41b8e38908d.jpg)  
aYields of Mukaiyama aldol. bYields of lactonization. Yields of hydrostannation

<table><tr><td>entry</td><td>base (1.5 eq)</td><td>T (C)</td><td>yieldª</td></tr><tr><td>1</td><td>LDA</td><td>-78 to -20</td><td>45%</td></tr><tr><td>2</td><td>LiHMDS</td><td>-78 to -20</td><td>44%</td></tr><tr><td>3</td><td>NaHMDS</td><td>-78 to -20</td><td>47%</td></tr><tr><td>4</td><td>KHMDS</td><td>-78 to -20</td><td>52%</td></tr><tr><td>5</td><td>KOt-Bu</td><td>-78 to -20</td><td>57%</td></tr><tr><td>6</td><td>KOt-Bu</td><td>-78 to 0</td><td>60%</td></tr><tr><td>7</td><td>KOt-Bu</td><td>-78 to 25</td><td>65%</td></tr></table>

ªThe yields were determined by 1H NMR

![](images/2f59e8ffcaab51f73b147ad42918e51707e26813a508a99c82c5fea67c86ba96.jpg)

Scheme 4. Synthesis of the C9−C25 Fragment  
![](images/ba90fc2e3904d1310c5bec1619a9668d1ebded052e9493da99fac98f78a6d54f.jpg)  
Scheme 5. Completion of the Synthesis of Plocabulin and Its C2-Analogues, and the Cytotoxicity of C2-Substituted Derivatives against Four Aggressive Acute Myeloid Leukemia (AML) Cell Lines (MV4-11, MOLM-13, THP-1, and OCI-AML3)

■Connection of 13 and 25 to syntheize plocabulin (3 LS, 70% overall yield) and its C2-analogues

<table><tr><td rowspan="2">Compound</td><td colspan="4">IC50 (nM)</td></tr><tr><td>MV4-11</td><td>MOLM-13</td><td>THP-1</td><td>OCI-AML-3</td></tr><tr><td>Plocabulin</td><td>0.0416 ± 0.0042</td><td>0.0232 ± 0.0203</td><td>0.426 ± 0.148</td><td>0.225 ± 0.049</td></tr><tr><td>PA-1</td><td> $0 . 0 4 2 4 \pm 0 . 0 2 8 0$ </td><td> $0 . 0 8 7 9 \pm 0 . 0 1 2 2$ </td><td> $0 . 5 8 8 \pm 0 . 3 2 3$ </td><td> $0 . 3 6 6 \pm 0 . 1 2 9$ </td></tr><tr><td>PA-2</td><td>0.0424 ± 0.0172</td><td> $0 . 0 2 9 9 \pm 0 . 0 0 6 9$ </td><td> $0 . 8 9 0 \pm 0 . 1 4 4$ </td><td> $0 . 8 3 9 \pm 0 . 2 4 4$ </td></tr><tr><td>PA-3</td><td> $0 . 0 6 7 3 \pm 0 . 0 3 2 1$ </td><td> $0 . 1 9 0 0 \pm 0 . 0 3 1 1$ </td><td> $0 . 8 8 1 \pm 0 . 2 0 8$ </td><td> $1 . 1 1 \pm 0 . 3 7 0$ </td></tr><tr><td>PA-4</td><td> $0 . 0 7 7 7 \pm 0 . 0 2 8 4$ </td><td> $0 . 0 7 2 3 \pm 0 . 0 2 3 0$ </td><td> $0 . 4 3 8 \pm 0 . 1 7 4$ </td><td> $0 . 4 2 3 \pm 0 . 2 1 0$ </td></tr><tr><td>PA-5</td><td> $0 . 1 1 9 \pm 0 . 0 1 7 2$ </td><td> $0 . 2 4 6 \pm 0 . 0 0 6 8 1$ </td><td> $0 . 5 6 7 \pm 0 . 2 0 3$ </td><td> $0 . 4 3 6 \pm 0 . 0 3 7 5$ </td></tr></table>

the lithium enolate of methyl propionate was used, steric hindrance at the nucleophilic center significantly hindered the aldol reaction. Instead, the enolate acted as a base, triggering proton transfer from the aldehyde methylene, followed by elimination. To address this limitation, we developed a twostep approach. First, a $\mathrm { B F } _ { 3 } { \cdot } \mathrm { O E t } _ { 2 }$ -promoted Mukaiyama aldol reaction<sup>15</sup> between 5 and silyl enol ether 7a produced 8a in 97% yield. In the subsequent lactonization step, KOt-Bu was the most efective base among those tested, enabling the formation of lactone $1 2 { \tt a } ^ { 1 6 }$ in 60% yield via sequential acyl migration, lactonization, and elimination (9 to 11). This strategy was broadly applicable, allowing the synthesis of lactones 12 with diverse C2 substituents, including OBn, Et, and alkyl chains. Finally, cis-hydrostannation of the alkyne converted 12 into E-vinyltributylstannane $1 3 . ^ { 1 7 }$ Using this streamlined approach, the C1−C8 fragment of plocabulin (13a, 2.3 g) was synthesized over 9 linear steps, achieving an overall yield of 19.2%.

The C9−C25 fragment was constructed by coupling dienyl carboxylic acid 17 (C9−C13) with amine 24 (C14−C25) via C13−N14 amide bond formation. The C9−C13 fragment was synthesized from ethyl propiolate (14) following Nicolaou’s protocol (Scheme 4).<sup>18</sup> Treatment of 14 with NaI in AcOH yielded vinyl iodide 15 in 95% yield with a >20:1 Z/E ratio. Ester reduction generated a labile aldehyde, which immediately underwent a Still-Gennari reaction $\mathrm { a t - 7 8 ~ ^ { \circ } C }$ , afording dienyl ester 16 in 70% overall yield with a 17:1 Z/E ratio. Saponification with LiOH in MeOH/H O provided carboxylic acid 17 in 91% yield, which was used directly without purification.

The C14−C25 fragment synthesis began with aldehyde 18, either commercially available or accessible via a known threestep route (Scheme 4).<sup>19</sup> A sequential Wittig olefination strategy was employed, using nonstabilized ylides in THF�a dipolar aprotic solvent. The conditions favor formation of the cis-oxaphosphetane intermediate under kinetic control, resulting in high Z-selectivity at both the C18−C19 and C23−C24 alkene positions.<sup>20</sup> The first Wittig reaction of aldehydes 18 with (iodomethyl)triphenylphosphonium iodide furnished 19 in 57% yield with a Z/E ratio of 10:1.<sup>21</sup> Subsequent DIBAL-H reduction followed by a second Wittig reaction with ethyltriphenylphosphonium iodide aforded 21 in 75% yield with >20:1 Z/E selectivity. This three-step sequential Wittig strategy significantly improved eficiency compared to Cuevas eight-step method.<sup>1b</sup> Cross-coupling of 21 with primary amide 22 using copper-catalysis developed by Li and Wang<sup>7</sup> gave 23 in 89% yield. Boc-deprotection of 23 produced primary amine 24, which was then condensed with C9−C13 fragment 17, afording amide 25 in 80% yield. Overall, the C9−C25 fragment of plocabulin (25, 1.1 g) was synthesized in 6 linear steps with an overall yield of 37%. The final assembly of plocabulin was achieved through a CuTC-mediated Stille cross-coupling<sup>22</sup> (condition-1) between 13a and 25, giving 26a in 87% yield on a near-gram-scale (911.6 mg prepared; Scheme 5). Desilylation of 26a produced alcohol 27a, which underwent carbamoylation with trichloroacetyl isocyanate (TCAI) to aford plocabulin in a 98% yield. The highly eficient final three-step sequence enabled us to obtain 1.23 g of plocabulin, which is suficient to meet the clinical trial requirements for approximately 75 cancer patients based on current dosing protocols.<sup>5</sup> In total, our synthesis of plocabulin was completed in 12 longest linear sequence (LLS) steps and 24 total steps (TS) with an overall yield of 19.7%. The analytical data for our synthetic plocabulin, including <sup>1</sup>H and <sup>13</sup>C NMR spectroscopy, high-resolution mass spectrometry, and optical rotation, closely matched those reported for the natural product and previously synthesized samples.<sup>1b,</sup> <sup>7</sup> The final three-step transformation was also applied to the synthesis of plocabulin C2-analogues (PA-1 to PA-5). Notably, variations in the C2 substituent significantly influenced the eficiency of the Stille crosscoupling reaction. For example, CuTC-mediated coupling of C2-OBn-substituted 13b with 25 resulted in substantial recovery of unreacted starting material, yielding 26b in only 37% even after an extended reaction time of 4 days (Scheme 5). Drawing inspiration from Fürstner’s work,<sup>23</sup> we adopted Pd(PPh ) catalysis (condition-2), which significantly improved the yield of 26b to 64%.

The lactone ring is a well-established pharmacophore essential for plocabulin’s antitumor activity. However, the impact of structural modifications at the C2 position remains largely unexplored. To address this, we assessed the cytotoxicity of C2-substituted derivatives against four aggressive acute myeloid leukemia (AML) cell lines (MV4- 11, MOLM-13, THP-1, and OCI-AML3). As shown in Scheme 5, all derivatives exhibited antiproliferative activity comparable to plocabulin, maintaining significant potency at the picomolar level. Notably, there was no substantial diference in activity between derivatives with hydrophobic substituents (benzyloxy, ethyl, and phenethyl; PA-1, PA-2, and PA-3) and those with terminal hydrophilic groups (methoxy and carbamate; PA-4, and PA-5). These findings indicate that C2 modifications have minimal impact on plocabulin’s antitumor activity, ofering valuable insight for future structural simplification and optimization eforts.

In summary, we have developed a concise gram-scale synthesis of plocabulin. Our approach eficiently assembles the C1−C8, C9−C13, and C14−C25 fragments in a highly convergent manner. Key steps include a TiCl -chelated Hosomi−Sakurai allylation to install the syn-C5/C6 stereochemistry, followed by a sequential Mukaiyama aldol/ lactonization process to construct the α,β-unsaturated lactone core with diverse C2 substitutions. Our approach not only addresses the supply challenges of plocabulin, supporting the current clinical studies and exploration of new therapeutic indications, but also ofers a promising platform for developing improved analogues with enhanced therapeutic potential.

## ■ ASSOCIATED CONTENT

## Data Availability Statement

The data underlying this study are available in the published article and its Supporting Information.

## \*sı Supporting Information

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acs.orglett.5c01284.

Experimental procedures, spectra data, and crystallographic data (12a) for products (PDF)

## Accession Codes

Deposition Number 2432987 contains the supplementary crystallographic data for this paper. These data can be obtained free of charge via the joint Cambridge Crystallographic Data Centre (CCDC) and Fachinformationszentrum Karlsruhe Access Structures service.

## ■ AUTHOR INFORMATION

## Corresponding Authors

Qifeng Chen − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, Sichuan Engineering Laboratory for Plant-Sourced

Drug and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China; Email: qfchen@scu.edu.cn

Zhenlei Song − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, Sichuan Engineering Laboratory for Plant-Sourced Drug and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China; orcid.org/ 0000-0002-7228-1572; Email: zhenleisong@scu.edu.cn

## Authors

Shunfa Liu − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, Sichuan Engineering Laboratory for Plant-Sourced Drug and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China

Bin Li − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, Sichuan Engineering Laboratory for Plant-Sourced Drug and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China

Xin Gao − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, Sichuan Engineering Laboratory for Plant-Sourced Drug and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China

Fenglin Wang − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, Sichuan Engineering Laboratory for Plant-Sourced Drug and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China

Xuan Li − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, Sichuan Engineering Laboratory for Plant-Sourced Drug and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China

Juxi Wang − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, Sichuan Engineering Laboratory for Plant-Sourced Drug and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China

Yuzhong Kuang − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, Sichuan Engineering Laboratory for Plant-Sourced Drug and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China

Luai Ji − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, Sichuan Engineering Laboratory for Plant-Sourced Drug and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China

Lu Gao − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan

Province, Sichuan Engineering Laboratory for Plant-Sourced Drug and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China

Wanshu Wang − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, Sichuan Engineering Laboratory for Plant-Sourced Drug and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China

Yong Qin − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, Sichuan Engineering Laboratory for Plant-Sourced Drug and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China; orcid.org/ 0000-0003-3434-5747

Complete contact information is available at: https://pubs.acs.org/10.1021/acs.orglett.5c01284

## Notes

The authors declare no competing financial interest.

## ■ ACKNOWLEDGMENTS

We are grateful for financial support from National Key R&D Program of China (2022YFC2804202), the National Natural Science Foundation of China (21921002, 22171191), Science and Technology Department of Sichuan Province (2020YFS0186), Science and Technology Major Project of Tibetan Autonomous Region of China (XZ202201ZD0001G), and Sichuan University and Luzhou Municipal People’s Government Strategic Cooperation Project (2023CDLZ-5) for financial support.

## ■ REFERENCES

(1) (a) Martín López, M. J. Antitumoral Dihydropyran-2-one Compounds. WO 2007/144423 A1, 2007. (b) Martín, M. J.; Coello, L.; Fernández, R.; Reyes, F.; Rodríguez, A.; Murcia, C.; Garranzo, M.; Mateo, C.; Sánchez-Sancho, F.; Bueno, S.; de Eguilior, C.; Francesch, A.; Munt, S.; Cuevas, C. Isolation and First Total Synthesis of PM050489 and PM060184, Two New Marine Anticancer Compounds. J. Am. Chem. Soc. 2013, 135, 10164−10171.

(2) Pera, B.; Barasoain, I.; Pantazopoulou, A.; Canales, A.; Matesanz, R.; Rodriguez-Salarichs, J.; García-Fernandez, L. F.; Moneo, V.; Jiménez-Barbero, J.; Galmarini, C. M.; Cuevas, C.; Peñalva, M. A.; Díaz, J. F.; Andreu, J. M. New Interfacial Microtubule Inhibitors of Marine Origin, PM050489/PM060184, with Potent Antitumor Activity and a Distinct Mechanism. ACS Chem. Biol. 2013, 8, 2084−2094.

(3) Martínez-Díez, M.; Guillén-Navarro, M. J.; Pera, B.; Bouchet, B. P.; Martínez-Leal, J. F.; Barasoain, I.; Cuevas, C.; Andreu, J. M.; García-Fernández, L. F.; Díaz, J. F.; Avilés, P.; Galmarini, C. M. PM060184, a New Tubulin Binding Agent with Potent Antitumor Activity Including P-Glycoprotein Over-Expressing Tumors. Biochem. Pharmacol. 2014, 88, 291−302.

(4) Prota, A. E.; Bargsten, K.; Diaz, J. F.; Marsh, M.; Cuevas, C.; Liniger, M.; Neuhaus, C.; Andreu, J. M.; Altmann, K.-H.; Steinmetz, M. O. A New Tubulin-Binding Site and Pharmacophore for Microtubule-Destabilizing Anticancer Drugs. Proc. Natl. Acad. Sci. U. S. A. 2014, 111, 13817−13821.

(5) (a) The data of clinical trials for Plocabulin is available under accession number NCT01299636, NCT02533674, NCT03427268, and can be obtained free of charge from the National Center for Biotechnology Information via 2024 https://clinicaltrials.gov/. (b) The data of clinical trials for Plocabulin is available under accession

number EudraCT 2015-002395-24, and can be obtained free of charge from the EU Clinical Trials Register via 2024 https://www. clinicaltrialsregister.eu/.

(6) Domínguez, J. M.; Pérez-Chacón, G.; Guillén, M. J.; Muñoz-Alonso, M. J.; Somovilla-Crespo, B.; Cibrián, D.; Acosta-Iborra, B.; Adrados, M.; Muñoz-Calleja, C.; Cuevas, C.; Sánchez-Madrid, F.; Avilés, P.; Zapata, J. M. CD13 as a New Tumor Target for Antibody-Drug Conjugates: Validation with the Conjugate MI130110. J. Hematol. Oncol. 2020, 13, 32.

(7) Wang, L.; Lei, X.; Wang, Q.; Li, Y. Copper-Catalyzed Cross-Coupling of Amino Acid-Derived Amides with (Z)-Vinyl Iodides: Unexpected Solvent Effect and Preparation of Plocabulin. Tetrahedron 2021, 83, 131953.

(8) (a) Wang, L.; Li, X.; Cui, H.; Lei, X.; Liu, H.; Wang, Q.; Li, Y. Synthesis of the Analogs of Plocabulin and Their Preliminary Structure-Activity Relationship Study. Bioorg. Med. Chem. Lett. 2021, 51, 128355. (b) Mateo Urbano, M. C. Antitumoral Compounds. WO 2023/067132 A1, 2023.

(9) Bahadoor, A. B.; Flyer, A.; Micalizio, G. C. A Pentenyl Dianion-Based Strategy for Convergent Synthesis of Ene-1,5-diols. J. Am. Chem. Soc. 2005, 127, 3694−3695.

(10) (a) Danheiser, R. L.; Carini, D. J.; Kwasigroch, C. A. Scope and Stereochemical Course of the Addition of (Trimethylsilyl)allenes to Ketones and Aldehydes. A Regiocontrolled Synthesis of Homopropargylic Alcohols. J. Org. Chem. 1986, 51, 3870−3878. (b) Brawn, R. A.; Panek, J. S. Preparation and Use of Enantioenriched Allenylsilanes for the Stereoselective Synthesis of Homopropargylic Ethers. Org. Lett. 2007, 9, 2689−2692. (c) Cai, B.; Evans, R. W.; Wu, J.; Panek, J. S. Total Synthesis of Nuclear Factor of Activated T-Cells-68 (NFAT-68): Sequential Use of Chiral Allenylsilane and Titanium Alkoxide Mediated Reductive Coupling Bond Construction. Org. Lett. 2016, 18, 4304−4307.

(11) Wang, L.; Gong, J.; Deng, L.; Xiang, Z.; Chen, Z.; Wang, Y.; Chen, J.; Yang, Z. Formal Total Synthesis of N-Methylmaysenine. Org. Lett. 2009, 11, 1809−1812.

(12) (a) Hoye, T. R.; Jeffrey, C. S.; Shao, F. Mosher Ester Analysis for the Determination of Absolute Configuration of Stereogenic (Chiral) Carbinol Carbons. Nat. Protoc. 2007, 2, 2451−2458.

(b) Ohtani, I.; Kusumi, T.; Kashman, Y.; Kakisawa, H. High-Field FT NMR Application of Mosher’s Method. The Absolute Configurations of Marine Terpenoids. J. Am. Chem. Soc. 1991, 113, 4092−4096.

(13) Tanaka, K.; Fujimori, Y.; Saikawa, Y.; Nakata, M. Diastereoselective Synthesis of Useful Building Blocks by Crotylation of β- Branched α-Methylaldehydes with Potassium Crotyltrifluoroborates. J. Org. Chem. 2008, 73, 6292−6298.

(14) Keck, G. E.; Li, X.-Y.; Knutson, C. E. A Versatile Preparation of α,β-Unsaturated Lactones from Homoallylic Alcohols. Org. Lett. 1999, 1, 411−414.

(15) (a) Panek, J. S.; Jain, N. F. Total Synthesis of Rutamycin B and Oligomycin C. J. Org. Chem. 2001, 66, 2747−2756. (b) Mukaiyama, T.; Narasaka, K.; Banno, K. New Aldol Type Reaction. Chem. Lett. 1973, 2, 1011−1014.

(16) The crystallographic data for compound 12a is available under accession number CCDC 2432987, and can be obtained free of charge from the Cambridge Crystallographic Data Centre via www. ccdc.cam.ac.uk/data\_request/cif; 2024.

(17) Yan, R.; Bian, C.; Yu, X. Total Synthesis of Herbimycin A. Org. Lett. 2014, 16, 3280−3283.

(18) Nicolaou, K. C.; Krieger, J.; Murhade, G. M.; Subramanian, P.; Dherange, B. D.; Vourloumis, D.; Munneke, S.; Lin, B.; Gu, C.; Sarvaiaya, H.; Sandoval, J.; Zhang, Z.; Aujay, M.; Purcell, J. W.; Gavrilyuk, J. Streamlined Symmetrical Total Synthesis of Disorazole B1 and Design, Synthesis, and Biological Investigation of Disorazole Analogues. J. Am. Chem. Soc. 2020, 142, 15476−15487.

(19) Guo, Q.; Yang, Y.; Zhang, H.; Wang, D.; Li, B.; Jiang, D.; Tu, X.; Gao, X.; Zhang, C.; Qin, Y.; Gao, L.; Wang, W.; Song, Z. Total Syntheses of Bryostatins 1, 7, 9 and 9-N . Angew. Chem., Int. Ed. 2025, 64, e202423465.

(20) Strategic Applications of Named Reactions in Organic Synthesis; Kürti, L., Czakó, B.; Ed.; Academic Press/Elsevier Science: Amsterdam, Netherlands, 2005; 486−487.

(21) Stork, G.; Zhao, K. A Stereoselective Synthesis of (Z)-1-Iodo-1- alkenes. Tetrahedron Lett. 1989, 30, 2173−2174.

(22) Allred, G. D.; Liebeskind, L. S. Copper-Mediated Cross-Coupling of Organostannanes with Organic Iodides at or below Room Temperature. J. Am. Chem. Soc. 1996, 118, 2748−2749.

(23) Fürstner, A.; Funel, J.-A.; Tremblay, M.; Bouchez, L. C.; Nevado, C.; Waser, M.; Ackerstaff, J.; Stimson, C. C. A Versatile Protocol for Stille-Migita Cross Coupling Reactions. Chem. Commun. 2008, 2873−2875.