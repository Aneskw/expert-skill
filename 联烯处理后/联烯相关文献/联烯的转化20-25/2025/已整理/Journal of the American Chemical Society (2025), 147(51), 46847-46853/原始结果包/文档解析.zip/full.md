pubs.acs.org/JACS

# Copper-Catalyzed Asymmetric Alkynylation of $s { p } ^ { 2 }$ Allenic C−H Bonds for the Synthesis of Skipped Diynes

Ping Zhao, Yunshun Deng, Pinhong Chen, and Guosheng Liu\*

![](images/1997e30ab443600b7bf17340c961f263b5c9aea2bdaa59c3f16b682d9776d918.jpg)

Cite This: J. Am. Chem. Soc. 2025, 147, 46847−46853

Read Online

ACCESS

Metrics & More

Article Recommendations

\*sı Supporting Information

ABSTRACT: Herein, we established a copper-catalyzed asymmetric alkynylation of the $s p ^ { 2 } \mathsf { C - H }$ bond of silylallenes, which was presented as an eficient method for the synthesis of enantioenriched skipped diynes with excellent enantioselectivity. The reaction was initiated by hydrogen atom abstraction of $s p ^ { 2 }$ allenic C−H bonds, in which the resonance forms of allenic and propargylic radicals were chemo- and enantioselectively trapped by chiral alkynyl- $\cdot \mathrm { { C u } ( I I ) }$ species to deliver a variety of skipped diynes. The method features a broad substrate scope and robust functional group tolerance, accommodating both alkynyl silanes and boronic esters. Moreover, the resulting skipped diynes serve as versatile key synthons for incorporating enantiomerically enriched enynes, alkynes, alkanes, and their derivatives, which could be applied in the concise synthesis of several bioactive molecules.

Scheme 1. Synthesis of Chiral Skipped Diynes

(A)  
![](images/d4c99d42904618d05812526584fe832c9b3c321a73564541ff1a293e8008004d.jpg)  
skipped dienes

![](images/ea38ec3f3652a1492b611bc91a223898ef860b432cfd6173112b1ce2d189da28.jpg)

![](images/3701c7a62bc7f8482eaeba761c120c24590cb7d7a0008c75d65a3c51c2f3d784.jpg)

(B) Hypothesized pathway on the asymmetric synthesis skipped diynes kipped diynes�structures characterized by two alkyne groups bonded to a single carbon atom�are recognized as a key moiety in medicinal discovery and organic synthesis.<sup>1</sup> For instance, skipped diyne architectures have been positioned as key pharmacophoric elements in rational drug design.<sup>2</sup> Meanwhile, skipped diynes also serves as a pivotal synthon for the synthesis of skipped dienes via selective reduction, which extensively exists in natural products and bioactive compounds,<sup>3</sup> such as phorbasin $\mathrm { C } ^ { 4 }$ and the arachidonoyl ethanolamide (AEA) analogue exhibiting exceptional rCB1 receptor afinity.<sup>5</sup> Moreover, full reduction of chiral skipped diynes presents an efective approach for the construction of enantiomerically enriched tertiary alkyl C-centers�structural units extensively pervasive in natural products and pharmaceuticals, such as sex pheromones,<sup>6</sup> methanophenazine,<sup>7</sup> and thromboxane synthase inhibitor CGS23005.<sup>8</sup> Therefore, exploiting eficient methods for the synthesis of optically pure skipped diynes is highly demanded.

![](images/edea4b881498bed030caa0657a0d2a5fd965f7a323b52cfbecd6487049466fd9.jpg)

![](images/9d2b3e26413779a288ed9cc44547b7906e825df2f71bebfebc7373b458085ead.jpg)

Over the past decades, substantial eforts have led to numerous methods for synthesizing functionalized skipped diynes,<sup>9</sup> including those based on Lewis acid,<sup>10</sup> metal catalysis,<sup>11</sup> and others.<sup>12</sup> Despite these advances, their asymmetric synthesis remains a significant challenge. For example, nucleophilic substitution of skipped diynes is challenged due to the steric and electronic bias of the two alkyne moieties (path $\mathbf { a } ,$ Scheme 1B). Alternatively, coupling two diferent alkynes ofers a promising pathway, exemplified by the asymmetric coupling of propargylic radicals with alkynyl−metal species (pathway b).<sup>13</sup> In this context, generating propargylic radicals via hydrogen atom transfer (HAT) is particularly attractive, as it enables asymmetric alkynylation of C−H bonds. Herein, we report a copper-catalyzed asymmetric alkynylation of allenes for the synthesis of enantioenriched skipped diynes, in which the coupling partner of the resonance forms of allenic and propargylic radicals<sup>14</sup> is derived from abstraction of $s p ^ { 2 }$ allenic C−H bonds (Scheme 1B).

![](images/30dce36e79b72040d4d0bab357c020e51d45978a08f393743eedfc5e24408d2d.jpg)

Scheme 2. A. Site- and Enantioselective Allenic sp<sup>2</sup> C−H Alkynylation Reaction of 1aa with Alkynylation Reagent 2a and 4a: (i) Ligand Screening; (ii) Further Optimizing Reaction Conditions; B. The Reaction of1ba with Alkyl-Substituted Alkynyl Reagents 2b and 4b  
![](images/bff4d182a6c949ea4db7df75a6d81a78c85b5461d794b233334fc2354d908eea.jpg)  
<sup>a</sup>Reaction conditions: CuOAc (1 mol %), L6 (2 mol %), 1aa (0.2 mmol), 2a (0.6 mmol), NF-1 (0.6 mmol), Li CO (0.6 mmol), $\mathrm { C } _ { 6 } \mathrm { F } _ { 6 }$ (0.4 mL), $\mathbf { r t } ,$ under Ar for 96 h. The crude <sup>1</sup>H NMR yields were determined by using TCE as an internal standard, and ee values were determined by HPLC on a chiral stationary phase. <sup>b</sup>NF-1 was replaced NF-2. <sup>c</sup>10 °C. <sup>d</sup>CuOAc (5.0%), L6 (6.0%).

Building on our ongoing interest in asymmetric C−H functionalization, we have developed a copper-catalyzed radical relay strategy for this goal.<sup>15</sup> Recently, we disclosed an enantioselective C−H cyanation of allenes, in which siteselective HAT of the allenic $s p ^ { 2 } \thinspace \mathrm { C - H }$ bond of $^ { 1 , 3 \cdot }$ -allenes was achieved.<sup>16a</sup> In these studies, the resulting resonance forms of allenic radical and propargylic radical are quenched by a chiral Cu(II) cyanide species, where the coupling process often exclusively occurred at the allenic radical position to deliver allene products.<sup>16−18</sup> With a similar pathway, site-selective alkynylation of $s p ^ { 2 } \thinspace \mathrm { C - H }$ bond allenes has been established as well.<sup>16b</sup> Therefore, we hypothesized that, if this coupling process could be switched to the propargylic radical position in an enantioselective manner, an asymmetric C−H alkynylation of allenes would provide access to enantiomerically enriched skipped diynes.

Inspired by our recent $\mathrm { s t u d y } , ^ { \mathrm { 1 6 d } }$ our initial investigation focused on the reaction of silyl-substituted allene 1aa and trimethoxysilyl-alkyne 2a, using NF-1 as an N-radical precursor and $\mathrm { L i } _ { 2 } \mathrm { C O } _ { 3 }$ as a base in perfluorobenzene/DMA (5:1 v/v).

Pleasingly, a catalyst system involving CuOAc and Box ligands enabled allenic $s p ^ { 2 } \thinspace \mathrm { C - H }$ alkynylation for the synthesis of the skipped diynes 3a with excellent chemoselectivity, while completely suppressing the formation of other coupling products (e.g., alkynyl-allene) derived from the allenic radical.<sup>16b</sup> More importantly, excellent site-selective HAT exclusively occurred at the allenic $s p ^ { 2 } \mathrm { C - H } ^ { 1 }$ bond, contributed by the fact that introducing a silyl group could significantly weaken the allenic $s p ^ { 2 } \mathrm { C - } \check { \mathrm { H } }$ bond.<sup>19</sup> Of the ligands evaluated, Box L5 proved to be the most efective, delivering product 3a in 45% yield and 62% ee (Scheme 2A-i). Further solvent screening indicated that replacing perfluorobenzene with solvents such as dichloromethane or acetone failed to improve the yield and led to a substantial erosion in enantioselectivity (entries 1−3, Scheme 2A-ii). Therefore, further modification ofligand Box L5 by introducing a phenyl group into the oxazoline ring markedly increased the enantioselectivity to 96% ee but with a decreased yield (39%, entry 4). Subsequently, evaluation of oxidants revealed that the reaction with NF-2 could increase the yield to 56% with 96% ee (entry 5). Moreover, when the temperature was lowered to $1 0 ^ { \circ } \mathrm C ,$ a slight increase in enantioselectivity (97% ee) and a slight decrease in yield (50%) were observed, accompanied by an improved mass balance (entry 6). Distinct from our previous study,<sup>20a,b</sup> the removal of cosolvent DMAc gave a similar result (entry 7). Finally, the slightly low yield could be compensated by increasing the catalyst loading to 5 mol ${ \% } ,$

## Scheme 3. Substrate Scope on the Asymmetric Alkynylation of $s p ^ { 2 } \mathbf { C } \mathrm { - } \mathbf { H }$ of Allenes: the Reaction Was Conducted on a 0.2 mmol Scale

![](images/7ab5c5814c197b77bd31da06e25328b87c9a223f307c261de6df0e089dbb616c.jpg)  
<sup>a</sup>The reaction using silyl-substituted alkynyl reagent 2 (conditions see Scheme 2A-ii, entry 8). <sup>b</sup>The reaction using boronic ester-substituted alkynyl reagent 4 (conditions see Scheme 2B, entry 11). <sup>c</sup>5 mmol scale. <sup>d</sup>0.5 mmol scale. ${ } ^ { e } \mathrm { a t } \ i \ { } ^ { \circ } \mathrm { C }$

afording the best results in 77% yield with 97% ee (entry 8). Encouraged by the study of Kramer,<sup>20c</sup> we also investigated the reactivity of the alternative alkynyl boronate ester 4a, demonstrating that it was also efective for the asymmetric C− H alkynylation. In this case, the addition of DMAc as a cosolvent is beneficial for a higher yield. A similar result (76% yield with 97% ee) was obtained in a mixture of CH CN and DMAc (entries 9−11).

Finally, alkyl-substituted alkynyl reagents 2b and 4b were also surveyed in the reaction of allene 1ba, and these reactions proceeded smoothly under the above reaction conditions, afording the desired skipped diyne 5a with excellent enantioselectivity (88−90% ee) (Scheme 2B). In this case, the reaction with alkynyl boronic ester 4b provided better performance over the related silyl reagent 2b.

With the optimized reaction conditions in hand, the substrate scope was investigated with diverse allenes and alkynyl reagent 2a (Scheme 3A). Allene substrates bearing simple alkyl chains aforded the corresponding products 3a and 3b in both excellent yields (73−80%) and excellent enantioselectivities (96−97% ee). Moreover, various functional groups, such as halides (3c− 3e), ether (3f), and ester (3g), were compatible to aford the

Scheme 4. Synthetic Transformations $( [ \mathbf { S i } ] = \mathbf { S i P h } _ { 2 } \mathbf { M e } ) ^ { a }$

![](images/2be8bd2e4bab4bc8308b3f3cd57a3d38981f9079e53a681a6b78a94fbecaacdc.jpg)  
<sup>a</sup>Reaction conditions: (a) CuTc (10 mol %), $\mathrm { A r S O } _ { 2 } \mathrm { N } _ { 3 } ,$ in toluene, rt. (b) Lindlar’s catalyst in EA, H , rt. (c) Dibal-H in THF, 70 °C. (d) (1) Pd/C in $\mathrm { C H C l } _ { 3 } , \mathrm { H } _ { 2 } , \mathrm { r t . } \left( 2 \right)$ TBAF in THF, rt. (e) (1) Pd/C in MeOH, $\mathrm { H } _ { 2 } ,$ rt. (2) TBAF, KF, ${ \mathrm { K H C O } } _ { 3 } ,$ and $\mathrm { H } _ { 2 } \mathrm { O } _ { 2 } . \left( \mathrm { f } \right)$ TEA in THF, 0 $^ \circ \mathbf { C } .$

corresponding products. Notably, allenes with other silyl groups, such as tert-butyldimethylsilyl (TBS, 3d) and trimethylsilyl (TMS, 3e), were compatible with the asymmetric C−H alkynylation conditions, afording the desired products with excellent yields (>85%) and enantioselectivities (>95% ee). More importantly, when allene substrates contained other active $s p ^ { 3 } \ : \mathrm { C - \hat { H } }$ bonds, such as benzylic (3h−3n), propargylic (3o), and allylic (3p) C−H bonds, the HAT reaction still exclusively occurred at the allenic $s p ^ { 2 } \thinspace \mathrm { C - H }$ position, afording the related products with excellent enantioselectivity (88−99% ee). Particularly, heteroarenes, such as thiophene (3m) and furan (3n), were also tolerated under the standard conditions. In addition, alkynyl reagent 4a also exhibited a broad substrate scope, afording a variety of skipped diynes (3a, 3d, 3h, 3i, 3k, 3o, and 3p) in comparable yields and enantioselectivities.

We turned our attention to investigating various alkylsubstituted alkyne reagents for asymmetric allenic $s p ^ { 2 }$ C−H akynylation. The results in Scheme 3B indicated that alkynyl silyl reagent 2a was less efective than its boronic ester counterpart 4a. Considering the superior performance, coupled with their greater stability and ease of synthesis, alkynyl boronic esters were chosen as the superior substrate class for subsequent scope investigation. Variants of alkyl-substituted boronic esters, such as a long-chain derivative (5c) and propargyl (5b, 5i), were proven to be good candidates, afording the desired skipped diynes in good yields (70−72%) with excellent enantioselectivities (94−96% ee). Other functional groups in alkynyl reagents, such as halogen (5d) and ether (5e), were also well tolerated under the standard reaction conditions. Remarkably, the alkynyl reagent with ketal groups (5f) exhibited excellent performance, with an 83% yield and 98% ee, where the HAT of hydrogen at the active ketal moiety was not observed. More importantly, the reactions employing terminal alkynyl reagents (5g, 5h, 5s, 5t) also proceeded eficiently, afording excellent results. Moreover, the process could be scaled up without erosion of eficiency or enantioselectivity. The desired products allow for further terminal alkynyl transformations.

Moreover, we also examined various phenyl-substituted alkynyl boronic esters with diferent allenes. Compared to reagent 4a with a phenyl group (5j, 5k), the alkynyl reagents with various functionalized aryl groups provided a better performance on the enantioselectivity. For instance, reagents with aryl groups bearing ortho- and para-methyl (5l, 5r), tertbutyl (5m), meta-methoxy (5n), naphthyl (5o), and trifluoromethyl (5q) aforded the corresponding skipped diynes in good yields with excellent enantioselectivities (92−96%). Meanwhile, a thiophene derivative (5p) was also compatible, providing product in 64% yield with 96% ee at $0 ~ ^ { \circ } \mathrm { C } .$ For the allene substrates bearing heterocyclic (5t, 5v) and high-strain rings (5u) the reactions performed well under standard conditions. Notably, the absolute stereoconfiguration of (R)- 5s was confirmed by X-ray difraction (XRD).

In general, skipped diyne products are recognized as versatile synthons in organic synthesis. As demonstrated in Scheme 4, the alkynylation product ${ \pmb 5 } { \bf g }$ was readily converted to 1-sulfonyl-1,2,3-triazole 6 via the click reaction in 88% yield without enantiomeric erosion. In addition, site-selective semihydroge nation of 5g either on acetylene or silyl-protected acetylene was achieved, afording enynes 7 in 93% yield (94% ee) using Lindlar’s catalyst, or Z-8 in 72% yield (94% ee) using diisobutylaluminum hydride (DIBAL-H), respectively. Moreover, the selective full hydrogenation of acetylene in 5g was also conducted using Pd/C in ${ \bar { \mathrm { C H C l } } } _ { 3 } ,$ followed by desilylation to give chiral terminal alkyne 9 in 85% yield with 95% ee. By prolonging the reaction time with $\operatorname { P d } / C$ in MeOH, both triple bonds in 5g could be fully hydrogenated, followed by C−Si bond oxidation using hydrogen peroxide, afording the enantiomerically enriched alcohol 10 in 92% yield with 91% ee. Finally, the isomerization of ${ \pmb 5 } { \bf q }$ is conducted by adding triethylamine, afording thermodynamically more stable allene 11 in 90% yield with 95% ee.

To demonstrate the synthetic utility of the method, as shown in Scheme 5, the formal synthesis of bioactive compounds or natural products was conducted using the current method as a key step. As an example, endocannabinoid probe 17, an anandamide (AEA) analogue with exceptional CB1 receptor afinity, was synthesized using compound 15 as a key intermediate. The synthesis commenced with an asymmetric alkynylation of the $s \dot { p } ^ { 2 }$ C−H bond in 1aq with reagent 4c, which provided skipped diyne 12. Subsequent sequential desilylation and cross-coupling converted 13 into the corresponding tetrayne 14. Finally, a selective semihydrogenation aforded the skipped tetraene, delivering probe 15 in 22% overall yield and 90% ee of 4 steps, which is much more eficient than the reported method from compound 16 with 12 steps, even in a similar overall yield.<sup>5a</sup> Second, the synthesis of sex pheromone 20 commenced from allene 1bw and alkynyl reagent 4w. Notably, this route required a streamlined, four-step sequence� asymmetric alkynylation, deprotection, Sonogashira coupling, and hydrogenation�to furnish the target molecule in 55% overall yield. This represents a substantial improvement in eficiency over the reported Zhong’s method, which required eight steps from chiral propylene peroxide and delivered the product in only 7% overall yield.<sup>21</sup> Finally, for the chiral thromboxane synthase inhibitor CGS23005, its key intermediate 22 was concisely synthesized from allene 1bx and alkynyl boronic ester 4x, with the following reduction and oxidation. The 45% overall yield with 90% ee contrasts sharply with the reported 10-step procedure for the synthesis of racemic product in 21% overall yield.<sup>8</sup>

## Scheme 5. Synthetic Applications

![](images/ef10e6a6f42f8fe4ba7dc4b9aa173cdb56b6a2543111b079759d669bef5d07aa.jpg)

In summary, we have developed a copper-catalyzed asymmetric alkynylation of $s p ^ { 2 } \mathrm { C - } \dot { \mathrm { H } }$ bonds in silyl-substituted allenes. This method provides eficient access to chiral skipped diynes in high yields with excellent enantioselectivities. The method features a broad substrate scope and robust functional group tolerance, accommodating both alkynyl silanes and boronic esters. Moreover, the resulting skipped diynes serve as versatile key synthons for incorporating enantiomerically enriched enynes, alkynes, alkanes, and their derivatives, which could be applied in the concise synthesis of several bioactive molecules.

## ■ ASSOCIATED CONTENT

## \*sı Supporting Information

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/jacs.5c19257.

Experimental procedures and characterization data (PDF)

## Accession Codes

Deposition Number 2497731 contains the supplementary crystallographic data for this paper. These data can be obtained free of charge via the joint Cambridge Crystallographic Data Centre (CCDC) and Fachinformationszentrum Karlsruhe Access Structures service.

## ■ AUTHOR INFORMATION

## Corresponding Author

Guosheng Liu − Chang-Kung Chuang Institute, East China Normal University, Shanghai 200062, China; New Cornerstone Science Laboratory, State Key Laboratory of Organometallic Chemistry, and Shanghai Hongkong Joint Laboratory in Chemical Synthesis, Shanghai Institute of Organic Chemistry, Chinese Academy of Sciences, Shanghai 200032, China; orcid.org/0000-0003-0572-9370; Email: gliu@mail.sioc.ac.cn

## Authors

Ping Zhao − Chang-Kung Chuang Institute, East China Normal University, Shanghai 200062, China

Yunshun Deng − New Cornerstone Science Laboratory, State Key Laboratory of Organometallic Chemistry, and Shanghai Hongkong Joint Laboratory in Chemical Synthesis, Shanghai Institute of Organic Chemistry, Chinese Academy of Sciences, Shanghai 200032, China

Pinhong Chen − New Cornerstone Science Laboratory, State Key Laboratory of Organometallic Chemistry, and Shanghai Hongkong Joint Laboratory in Chemical Synthesis, Shanghai Institute of Organic Chemistry, Chinese Academy of Sciences, Shanghai 200032, China; orcid.org/0000-0001-5048- 1445

Complete contact information is available at:

https://pubs.acs.org/10.1021/jacs.5c19257

## Notes

The authors declare no competing financial interest.

## ■ ACKNOWLEDGMENTS

We are grateful for the financial support provided by the National Key R&D Program of China (2021YFA1500100), the Strategic Priority Research Program of the Chinese Academy of Sciences (No. XDB0610000) and the National Naturale Science Foundation of China (Nos. 22331012, 92256301, and 22171279). P.C. also thanks the Youth Innovation Promotion Association of the Chinese Academy of Sciences (No. Y2022074). G.L. acknowledges support from the Tencent Foundation through the New Cornerstone Science Foundation.

## ■ REFERENCES

(1) (a) Kim, J.; Lim, Y.; Im, K.; Jung, J. H.; Shim, C. J.; Lee, C. H.; Hong, J.; Lee, H. Cytotoxic Polyacetylenes from the Marine Sponge Petrosia sp. J. Nat. Prod. 1999, 62, 554−559. (b) Chill, L.; Miroz, A.; Kashman, Y. Haliclonyne, a New Highly Oxygenated Polyacetylene from the Marine Sponge Haliclona Species. J. Nat. Prod. 2000, 63, 523− 526. (c) Lim, Y.; Lee, C.-O.; Hong, J.; Kim, D.-K.; Im, K.; Jung, J. H. Cytotoxic Polyacetylenic Alcohols from the Marine Sponge Petrosia Species. J. Nat. Prod. 2001, 64, 1565−1567. (d) Nuzzo, G.; Ciavatta, M.; Villani, G.; Manzo, E.; Zanfardino, A.; Varcamonti, M.; Gavagnin, M. Fulvynes, antimicrobial polyoxygenated acetylenes from the Mediterranean sponge Haliclona fulva. Tetrahedron 2012, 68, 754−

760. (e) Scott, L. T.; Cooney, M. J.; Otte, C.; Puls, C.; Haumann, T.; Boese, R.; Smith, A. B., III; Carrol, P. J.; de Meijere, A. J. Enhancement of Through-Space and Through-Bond.pi.-Orbital Interactions. Syntheses and Properties of Permethylated and Perspirocyclopropanated Cyclotetradeca-1,3,6,9,12-pentayne. J. Am. Chem. Soc. 1994, 116, 10275−10283. (f) Maurette, L.; Godard, C.; Frau, S.; Lepetit, C.; Soleihavoup, M.; Chauvin, R. On Ring Carbomers of Cyclobutane, Cyclopentane, and Cyclodecane and Cyclization Reactions through Bis(alkynyl-propargyl) Coupling. Chem.�Eur. J. 2001, 7, 1165−1170.

(2) (a) Miyahara, S.; Hiroyuki, U.; Shoki, H.; Yoshio, O. Preparation ofsulfonamide compounds as ribonucleotide reductase inhibitors. PCT Int. Appl. WO/2017/209155 A1, Dec. 17, 2017. (b) Molino, B. F.; Yang, Z. Preparation of cyclosporin alkynes as pharmaceutical agents. U.S. Patent 0074015 A1. Apr. 06, 2006. (c) Sun, H.; Xu, X.; Zhou, M.; Harran, S.; Hanson, G. J. Dimeric Smac mimetics for promoting apoptosis, and pharmaceutical compositions containing the same. PCT Int. Appl. WO/2011/059763. May 19, 2011. (d) Lahm, G. P.; Kar, M. N-(4-Quinolinylmethyl) sulfonamide derivatives and their use as anthelmintics and their preparation. PCT Int. Appl. WO/2013/ 081783, June 06, 2013.

(3) For reviews on skipped dienes, see: (a) Petruncio, G.; Shellnutt, Z.; Elahi-Mohassel, S.; Alishetty, S.; Paige, M. Skipped dienes in natural product synthesis. Nat. Prod. Rep. 2021, 38, 2187−2213. (b) Renzi, P.; Lanfranco, A.; Pazderová, L.; Rusconi, M.; Scarfiello, J.; Deagostino, A. Synthetic methodologies to access skipped dienes: a focus on the catalytic systems. Org. Biomol. Chem. 2025, 23, 6052−6099. (c) Sato, T.; Suto, T.; Nagashima, Y.; Mukai, S.; Chida, N. Total Synthesis of Skipped Diene Natural Products. Asian J. Org. Chem. 2021, 10, 2486− 2502.

(4) McNally, M.; Capon, R. J. Phorbasin B and C: Novel Diterpenes from a Southern Australian Marine Sponge. Phorbas Species. J. Nat. Prod. 2001, 64, 645−647.

(5) (a) Liu, Y.; Ji, L.; Eno, M.; Kudalkar, S.; Li, A.-L.; Schimpgen, M.; Benchama, O.; Morales, P.; Xu, S.; Hurst, D.; Wu, S.; Mohammad, K. A.; Wood, J. T.; Zvonok, N.; Papahatjis, D. P.; Zhou, H.; Honrao, C.; Mackie, K.; Reggio, P.; Hohmann, A. G.; Marnett, L. J.; Makriyannis, A.; Nikas, S. P. (R)-N-(1-Methyl 2-hydroxyethyl)-13-(S)-methylarachidonamide (AMG315): A Novel Chiral Potent Endocannabinoid Ligand with Stability to Metabolizing Enzymes. J. Med. Chem. 2018, 61, 8639−8657. (b) Nikas, S. P.; Ji, L.; Liu, Y.; Georgiadis, M.-O.; Dopeshwarkar, A.; Straiker, A.; Kudalkar, S.; Sadybekov, A. V.; Dvorakova, M.; Katritch, V.; Mackie, K.; Marnett, L.; Makriyannis, A. Chiral Me-2-arachidonoyl Glycerols: The First Potent Endocannabinoid Glyceride Templates with Stability to COX-2. ACS Med. Chem. Lett. 2024, 15, 965−971.

(6) Bello, J. E.; McElfresh, J. S.; Millar, J. G. Isolation and determination of absolute configurations of insect-produced methylbranched hydrocarbons. Proc. Natl. Acad. Sci. U.S.A. 2015, 112, 1077− 1082.

(7) Beifuss, U.; Tietze, M.; Bäumer, S.; Deppenmeier, U. Methanophenazine: Structure, Total Synthesis, and Function of a New Cofactor from Methanogenic Archaea. Angew. Chem., Int. Ed. 2000, 39, 2470−2472.

(8) Bhagwat, S. S.; Gude, C.; Boswell, C.; Contardo, N.; Cohen, D. S.; Dotson, R.; Mathis, J.; Lee, W.; Furness, P.; Zoganas, H. Thromboxane receptor antagonism combined with thromboxane synthase inhibition. 4. 8-[[(4-Chlorophenyl)sulfonyl]amino]-4-[3-(3-pyridinyl)propyl]- octanoic acid and analogs. J. Med. Chem. 1992, 35, 4373−4383.

(9) (a) Roth, W. R.; Kowalczik, U.; Maier, G.; Reisenauer, H. P.; Sustmann, R.; Müller, W. 2,2-Dimethyl-4,5-dimethylene-l,3-yclopentanediy. Angew. Chem., Int. Ed. Engl. 1987, 26, 1285−1287. (b) Tedeschi, C.; Saccavini, C.; Maurette, L.; Soleilhavoup, M.; Chauvin, R. 1,4- Diynes from alkynyl propargyl coupling reactions. J. Organomet. Chem. 2003, 670, 151−169.

(10) (a) Schwier, T.; Rubin, M.; Gevorgyan, V. B(C F ) -Catalyzed Allylation of Propargyl Acetates with Allylsilanes. Org. Lett. 2004, 6, 1999−2001. (b) Wang, T.; Ma, R.-D.; Liu, L.; Zhan, Z.-P. Solvent-free solid acid-catalyzed nucleophilic substitution of propargylic alcohols: a

green approach for the synthesis of 1,4-diynes. Green Chem., 2010, 12, 1576−1579.

(11) (a) Anand, N. K.; Carreira, E. M. A Simple, Mild, Catalytic, Enantioselective Addition of Terminal Acetylenes to Aldehydes. J. Am. Chem. Soc. 2001, 123, 9687−9688. (b) Montel, F.; Beaudegnies, R.; Kessabi, J.; Martin, B.; Muller, E.; Wendeborn, S.; Jung, P. M. J. New Method Based on 1-(Trimethysilyl)alk-1-yne To Prepare 1,4-Skipped Diynes. Org. Lett. 2006, 8, 1905−1908. (c) Paioti, P. H. S.; Abboud, K. A.; Aponick, A. Catalytic Enantioselective Synthesis of Amino Skipped Diynes. J. Am. Chem. Soc. 2016, 138, 2150−2153. (d) Chen,J.; Gao, S.; Chen, M. Cu-catalyzed C-C bond formation of vinylidene cyclopropanes with carbon nucleophiles. Chem. Sci. 2019, 10, 10601−10606.

(12) (a) Caruso, T.; Spinella, A. Cs CO Promoted coupling reactions for the preparation of skipped diynes. Tetrahedron 2003, 59, 7787− 7790. (b) Qi, L.; Meijler, M. M.; Lee, S.-H.; Sun, C.; Janda, K. D. Solid-Phase Synthesis of Anandamide Analogues. Org. Lett. 2004, 6, 1673− 1675. (c) Kessabi, J.; Beaudegnies, R.; Jung, P. M. J.; Martin, B.; Montel, F.; Wendeborn, S. Copper-Free Synthesis of Skipped Diynes via Cross-Coupling Reactions of Alkynylalanes with Propargylic Electrophiles. Org. Lett. 2006, 8, 5629−5632. (d) Liu, S.; Tormena, C. F.; Hammond, G. B.; Xu, B. Broadly Applicable Ion Pair-Assisted Nucleophilic Substitution of sp3-Carbon Electrophiles with Alkynyltrifluoroborates. Org. Lett. 2022, 24, 6298−6303.

(13) (a) Dong, X.-Y.; Zhang, Y.-F.; Ma, C.-L.; Gu, Q.-S.; Wang, F.-L.; Li, Z.-L.; Jiang, S.-P.; Liu, X.-Y. A general asymmetric copper-catalysed Sonogashira C(sp<sup>3</sup>)−C(sp) coupling. Nat. Chem. 2019, 11, 1158− 1166. (b) Xin, S.; Liao, J.; Tang, Q.; Feng, X.; Liu, X. Photoinduced copper-catalyzed asymmetric cyanoalkylalkynylation of alkenes, terminal alkynes, and oximes. Chem. Sci. 2024, 15, 18557−18563.

(14) (a) Muresan, M.; Subramanian, H.; Sibi, M. P.; Green, J. R. Propargyl Radicals in Organic Synthesis. Eur. J. Org. Chem. 2021, 2021, 3359−3375. (b) Xiao, B.-Y.; Huang, W.; Zhang, F.-H. Recent Advances in the Formation and Transformation of Propargyl Radical. Eur. J. Org. Chem. 2025, 28, e202500302.

(15) (a) Wang, F.; Chen, P.; Liu, G. Copper-Catalyzed Radical Relay for Asymmetric Radical Transformations. Acc. Chem. Res. 2018, 51, 2036−2046. (b) Zhang, Z.; Chen, P.; Liu, G. Copper-catalyzed radical relay in C(sp3)−H functionalization. Chem. Soc. Rev. 2022, 51, 1640− 1658. (c) Li, J.; Blockhaus, T.; Liu, G. Metal-Bound Heteroatom Radicals: Advancing Site-Selective C−H Functionalization. J. Am. Chem. Soc. 2025, 147, 22269−22283.

(16) (a) Cheng, Z.; Yang, T.; Li, C.; Deng, Y.; Zhang, F.; Chen, P.; Lin, Z.; Ma, S.; Liu, G. Site-Selective sp<sup>2</sup> C−H Cyanation of Allenes via Copper-Catalyzed Radical Relay. J. Am. Chem. Soc. 2023, 145, 25995− 26002. (b) Cheng, Z.; Zhang, J.; Li, C.; Li, X.; Chen, P.; Liu, G. Copper-Catalyzed sp2 C-H Arylation and Alkynylation of Allenes via Hydrogen Atom Abstraction. J. Am. Chem. Soc. 2024, 146, 24689−24698. (c) Wei, Y.; Wang, Z.; Wang, K.; Qiu, J.-K.; Wang, Z.; Li, H.; Duan, X.; Guo, K.; Bao, X.; Wu, X. Copper-Catalyzed Radical Allene C(sp2)-H Cyanation. Angew. Chem., Int. Ed. 2024, 63, No. e2023171. (d) Cheng, Z.; Zhang, G.; Deng, Y.; Zhang, Y.; Li, X.; Chen, P.; Liu, G. Copper-Catalyzed Asymmetric Cyanation of Propargylic Radicals Derived From Silyl-Substituted Allenes and Alkynes. Angew. Chem., Int. Ed. 2025, 64, No. e202505939.

(17) (a) Wang, F.; Wang, D.; Zhou, Y.; Liang, L.; Lu, R.; Chen, P.; Lin, Z.; Liu, G. Divergent Synthesis of CF -Substituted Allenyl Nitriles by Ligand-Controlled Radical 1,2- and 1,4-Addition to 1,3-Enynes. Angew. Chem., Int. Ed. 2018, 57, 7140−7145. (b) Ye, C.; Li, Y.; Zhu, X.; Hu, S.; Yuan, D.; Bao, H. Copper-catalyzed 1,4-alkylarylation of 1,3-enynes with masked alkyl electrophiles. Chem. Sci. 2019, 10, 3632−3636. (c) Zhang, K.-F.; Bian, K.-J.; Li, C.; Sheng, J.; Li, Y.; Wang, X.-S. Nickel-Catalyzed Carbofluoroalkylation of 1,3-Enynes to Access Structurally Diverse Fluoroalkylated Allenes. Angew. Chem., Int. Ed. 2019, 58, 5069−5074. (d) Zeng, Y.; Chiou, M.-F.; Zhu, X.; Cao, J.; Lv, D.; Jian, W.; Li; Zhang, X.; Bao, H. Copper-Catalyzed Enantioselective Radical 1,4-Difunctionalizationof 1,3-Enynes. J. Am. Chem. Soc. 2020, 142, 18014−18021. (e) Dong, X.-Y.; Zhan, T.-Y.; Jiang, S.-P.; Liu, X.-D.; Ye, L.; Li, Z.-L.; Gu, Q.-S.; Liu, X.-Y. Copper-Catalyzed Asymmetric Coupling of Allenyl Radicals with Terminal Alkynes to Access

Tetrasubstituted Allenes. Angew. Chem., Int. Ed. 2021, 60, 2160− 2164. (f) Lu, R.; Yang, T.; Chen, X.; Fan, W.; Chen, P.; Lin, Z.; Liu, G. Enantioselective Copper-Catalyzed Radical Cyanation of Propargylic C-H Bonds: Easy Access to Chiral Allenyl Nitriles. J. Am. Chem. Soc. 2021, 143, 14451−14457.

(18) Yu, J.; Xia, Y.; Dey, S.; Zhu, J.; Cheung, K. S.; Geib, S. J.; Wang, Y.-M. Iridium-Catalyzed Propargylic C-H Trifluoromethylthiolation and Related Processes. J. Am. Chem. Soc. 2024, 146, 27998−28004.

(19) Sabbasani, V. R.; Lee, H.; Xia, Y.; Lee, D. Complementary Iron(II)-Catalyzed Oxidative Transformations of Allenes with Different Oxidants. Angew. Chem., Int. Ed. 2016, 55, 1151−1155.

(20) (a) Fu, L.; Zhang, Z.; Chen, P.; Lin, Z.; Liu, G. Enantioselective Copper-Catalyzed Alkynylation of Benzylic C−H Bonds via Radical Relay. J. Am. Chem. Soc. 2020, 142, 12493−12500. (b) Fu, L.; Zhou, S.; Wan, X.; Chen, P.; Liu, G. Enantioselective Trifluoromethylalkynylation of Alkenes via Copper Catalyzed Radical Relay. J. Am. Chem. Soc. 2018, 140, 10965−10969. (c) Buendia, M. B.; Balin, J.-G. J.; Andersen, M. E.; Lian, Z.; Kramer, S. Copper-Catalyzed Alkynylation of Benzylic C−H Bonds with Alkyn ylboronic Esters. Synlett 2022, 33, 150−154.

(21) Yu, S.; Wu, J.; Bian, Q.; Wang, M.; Zhong, J. Asymmetric Synthesis of the Contact Sex Pheromone of the Emerald Ash Borer. Agrilus planipennis Fairmaire. ChemistrySelect 2023, 8, No. e202302084.