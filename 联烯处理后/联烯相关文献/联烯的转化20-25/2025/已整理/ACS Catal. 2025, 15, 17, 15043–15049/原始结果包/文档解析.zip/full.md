pubs.acs.org/acscatalysis

Letter

# Head-to-Tail Selective [2 + 2 + 2] Cycloadditions of Bisallenes Enabled by Ligand-Free Nickel(0)

Stuart C. D. Kennington,<sup>†</sup> Mou Mandal,<sup>†</sup> Roger Monreal-Corona, Arijit Saha, Albert Poater, Anna Roglans,\* and Anna Pla-Quintana\*

![](images/0f933f134309cc862b2cf18abf7b24e4892048982ffefebe6795bc9adde043f9.jpg)

Cite This: ACS Catal. 2025, 15, 15043−15049

![](images/88b94239cad1235ecb328b86a6a4205b004dd61e921935d78396182cd28cd2de.jpg)

Read Online

ACCESS

Metrics & More

ABSTRACT: A ligand-free Ni(0) catalyst enables highly chemoand regioselective [2 + 2 + 2] cycloadditions between 1,5-bisallenes and acetylenes, afording 6,6-fused hexahydroisoquinoline frameworks under mild conditions. DFT studies reveal that head-to-tail selectivity arises from competing oxidative cyclization pathways with metallacycle geometry dictating product formation. This work highlights how simple nickel complexes can achieve precise molecular construction without the need for ancillary ligands.

Article Recommendations

\*sı Supporting Information

![](images/f45892a0b52fa3ee760d50fc983b65398f485cf7546feb68cbd14e4a6e9c701e.jpg)

KEYWORDS: 1,5-bisallenes, alkynes, [2 + 2 + 2] cycloaddition, Ni(0) catalysis, hexahydroisoquinoline

## ■ INTRODUCTION

Controlling reaction selectivity is challenging. Transition metal catalysts can guide reactants chemoselectively, and fine-tuning these catalysts to access diferent pathways from the same starting materials ofers a powerful strategy for developing new transformations. Transition-metal-catalyzed $[ 2 { \it \Delta \phi } + { \bf \bar { \Delta } } 2 { \it \Delta \bar { \Delta } } + { \bf \Delta } 2 ]$ cycloadditions involving diferent unsaturations are invaluable tools for synthesizing both carbo- and heterocyclic complex skeletons from simple linear substrates in a single and highly atom-economical process.<sup>2</sup> Among the substrates, those featuring allenes,<sup>3,4</sup> particularly 1,5-bisallenes, have demonstrated significant promise in undergoing transition-metalcatalyzed cyclizations into structurally distinct scafolds.<sup>5</sup> The versatility of the latter arises from the diferent ways in which the four double bonds of the two allenes can participate in the cycloaddition or cyclization process: either head-to-head, headto-tail, tail-to-head, or tail-to-tail. Therefore, bisallenes, when reacted with a third unsaturation, can give rise to scafolds containing five-, six-, or seven-membered rings. However, cycloisomerizations of 1,5-bisallenes, or their cyclizations with a third component, are scarce. When they occur, they typically proceed via tail-to-tail<sup>6</sup> or head-to-head<sup>7</sup> modes of cyclization in a symmetrical fashion.

Our group has already demonstrated that diferent final products can be obtained from the same 1,5-bisallenes by modifying the catalyst and/or the nature of the third unsaturation. When 1,5-bisallenes were reacted with dimethyl acetylenedicarboxylate (DMAD) under rhodium catalysis using two diferent types of ligands, a bisphosphine<sup>8</sup> or an N-heterocyclic carbene (NHC),<sup>9</sup> the cyclization of the bisallene occurred head-to-head in both cases even though the reaction follows diferent pathways, yielding fivemembered-ring derivatives (Figure 1a,b). Remarkably, the use of a hemilabile thioether-functionalized NHC ligand favored the [2 + 2 + 2] cycloaddition reaction involving the two internal double bonds of the bisallene<sup>9</sup> (Figure 1b). However, when the third unsaturation was an alkene, the mode of cyclization of the starting bisallene under a Rh/bisphosphine catalytic system switched to the tail-to-tail mode of cyclization, generating derivatives with a seven-membered ring<sup>10</sup> (Figure 1c,d). Our group has also reported the completely intramolecular cycloaddition of an allene−yne−allene linear substrate to deliver a cross-conjugated diene with complete head-to-head mode of cyclization.<sup>11</sup> Aside from our work on head-to-head Rh-catalyzed $\left[ 2 + 2 + 2 \right]$ cycloadditions of 1,5- bisallenes with alkynes (Figure 1b),<sup>9</sup> the only other reported examples of [2 + 2 + 2] cycloaddition of bisallenes, to the best of our knowledge, are by Ma et al.<sup>12</sup> In their studies, 1,5- bisallenes underwent Rh-catalyzed [2 + 2 + 2] cycloaddition with an external allene, proceeding through a head-to-tail cyclization and leading to 6,6-fused ring systems (Figure 1e). A related [2 + 2 + 2] cycloaddition involving 1,5-allenynes and allenes afording 6,6-fused polycyclic structures under nickel catalysis was reported by Arai et al.<sup>13</sup> (Figure 1f). The outcome was strongly influenced by the steric bulk of the R<sup>1</sup> group: with methyl, ethyl, or isopropyl, only 6,6-fused bicyclic derivatives were obtained. In contrast, when $\mathbb { R } ^ { 1 }$ was hydrogen, the proximal $\mathrm { C } { = } \mathrm { C }$ bond became more reactive, giving a competing pathway leading to five-membered-ring formation (Figure 1f).

![](images/4cdc689980e1d07b5fe4df11f31e5ff36d90ea16e3e04b89eaf7640470469c6d.jpg)

![](images/db9e1a7c2c0b7ec2e885f128b60ae4f61f53b1a738215f7d45581e31a94e9e44.jpg)  
Figure 1. State-of-art of cyclization reactions of 1,5-bisallenes under transition metal catalysis.

In this paper, we present the synthesis of $^ { 6 , 6 \cdot }$ -fused bicyclic hexahydroisoquinoline derivatives from head-to-tail cyclization of 1,5-bisallenes under nickel catalysis using alkynes as the coupling partners in the absence of any additional ligand. Additionally, a comprehensive mechanistic study using density functional theory (DFT) calculations provides insight into the origins of the observed chemo- and regioselectivity of this transformation.

## ■ RESULTS AND DISCUSSION

We initiated our study by evaluating the reaction of N-tosyltethered 1,5-bisallene 1a with DMAD (2a). Given our interest in using more abundant, relatively inexpensive, and less toxic first-row transition metal complexes, we started with ligandfree $\left[ \mathrm { N i } ( \mathrm { C O D } ) _ { 2 } \right] ^ { 1 4 }$ in dichloromethane (DCM) at room temperature. We observed the formation of a single product 3a related to bisallene 1a that incorporated DMAD and a further byproduct arising from the nickel-catalyzed trimerization of DMAD, a process already described under Ni catalysis by Coleman and Guan.<sup>15</sup> By NMR spectroscopy, we were able to confirm the sole formation of the $^ { 6 , 6 \cdot }$ -fused bicyclic product 3a upon the highly chemoselective metallocyclization involving the head-to-tail mode of cyclization of 1a with 2a. After some process optimization (screening of solvents, equiv of DMAD, and Ni complexes; see Table S1), the best reaction conditions were found to be 1 equiv of bisallene 1a and 5 equiv of DMAD using 10 mol % of $\mathrm { N i } ( \mathrm { C O D } ) _ { 2 }$ in DCM/DME (1:1, 0.15 M) at room temperature. Finally, we scaled up the reaction to a 1 mmol scale for the synthesis of 3a, which gave an identical yield of 71%, proving the scalability of the reaction.

In order to probe the generality of the reaction, we investigated the reactivity of several functionalized $^ { 1 , 5 \mathrm { - } }$ bisallenes (1a−1l) as well as the compatibility of a variety of alkynes (2a−2p) under the optimized reaction conditions (Scheme 1). Aryl sulfonamide-tethered bisallenes with electron-donating groups (p-Me and p-OMe), electron-withdrawing groups $\scriptstyle ( p - \mathrm { N O } _ { 2 }$ and $\phantom { 0 } { o } \mathrm { - C F } _ { 3 } )$ , and halo groups (p-chloro and m,m′-difluoro) on the aryl ring underwent the $\left[ 2 + 2 + 2 \right]$ cycloaddition reactions with excellent chemo- and regioselectivity, leading to the desired $^ { 6 , 6 }$ -fused bicyclic hexahydroisoquinoline derivatives 3a−3f in 61−72% isolated yield. Sulfonamide tethers with a heteroaromatic ring such as thiophene (1g) or aliphatic substitution (<sup>t</sup>butyl, 1h) were also eficient, delivering cycloadducts 3g and 3h in 57% and 59% yield, respectively. With regard to the tether, not only sulfonamides but also other N-substituted tethers such as tertbutylcarbamate and 4-methylbenzyl bisallenes reacted with $^ { 2 \mathrm { a } , }$ giving compounds 3i and 3j in 58 and 45% yield, respectively. We then explored whether bisallenes with a tether other than nitrogen could also yield favorable reactions. An oxygen linkage could also be used in the cycloaddition, and the final product 3k was obtained in 66% yield. Finally, diethyl malonate was tested as the tethering unit in the bisallene, providing a 60% yield of derivative 3l. Thus, the electronic bias $^ { 1 , 5 \cdot }$ bisallene functionality had virtually no efect on the reaction outcome.

Scheme 1. Substrate Scope of the [2 + 2 + 2] Cycloaddition of 1,5-Bisallenes and Acetylenes  
![](images/99aa4a829b47e2051c084d8ca2d601026492529544561b8e4710a5b6b2684f33.jpg)

![](images/b49cb4720306974664cc210cde45b041079c8e8f6ddaab982cf82752a06dffa1.jpg)  
Figure 2. DFT-computed lowest-energy path for the formation of the head-to-tail product P.

To further illustrate the synthetic diversity, a wide array of structurally and electronically distinct alkynes were tested. The cycloaddition reaction of 1a with other acetylenedicarboxylate esters 2b (Et), 2c (<sup>n</sup>Bu), 2d (<sup>t</sup>Bu), and 2e (Bn) was then carried out and delivered moderate to good yields (3m−3p,

35−67%). It is notable that the yield decreased with increasing steric bulk of the ester moiety. It is also noteworthy that the alkyne with the ethyl ester 2b produced an inseparable mixture of the cycloadduct 3m and the diethyl acetylenedicarboxylate trimer byproduct in a 1:0.6 ratio. Not only 1,2-disubstituted alkynes but also monosubstituted alkynes (2f−2k) are relevant partners in this domino cycloaddition, unveiling exclusive regioselectivity in which the substituent is at the β-position with respect to the exocyclic methylidene. In this context, methyl propiolate (2f), propargyl acetate (2g), propargyl alcohol (2h), 5-chloro-1-pentyne (2i), 1-hexyne (2j), and tosyl-protected propargylamine (2k) were well-tolerated under the optimized reaction conditions, afording a range of peripherally decorated hexahydroisoquinolines 3q−3v in yields between 31% and 70%. Similarly, terminal alkynes with aryl s u b s t i t u e n t s s u c h a s p h e n y l a c e t y l e n e ( 2 l ) , p-<sup>t</sup>butylphenylacetylene (2m), and p-N,N-dimethylaminophenylacetylene (2n) also proved to be reactive, delivering the corresponding products 3w−3y in 59−63% yield. The molecular topology of the exclusive regioisomer was further confirmed by the X-ray crystallographic analysis of compound 3y (CCDC 2449331). The methodology was also compatible with 2-alkynylpyridine (2o), afording product 3z in 67% yield without afecting the regioselectivity. Finally, the use of an unsymmetrical disubstituted acetylene (2p) led to an inseparable mixture of two regioisomers (3za and 3zb) in a 70:30 ratio, favoring the methyl ester at the β-position relative to the methylidene group.

![](images/eb1efd71a1893ac46de93c9fe74b329fe8ddb945ca7d5b3877d27f1410d9f1a6.jpg)  
Figure 3. 3D structures of (A) square-planar Ni and (B) octahedral Rh metallacyclopentene intermediates.

To determine the main factors favoring the observed headto-tail selectivity, a series of DFT calculations were carried out at the B3LYP-D3/cc-pVTZ-SMD(DCM)//B3LYP-D3/ccpVDZ level of theory (Figure 2) (see the Supporting Information for further details and for the complete set of reaction pathways studied). The first step was to determine the nature of the active catalytic species. Upon mixing Ni(COD) , the alkyne, and the bisallene in the presence of dimethoxyethane (dme)�explicitly modeled, as it is crucial for eficient ligand exchange�two main species are generated: the 16- electron species A2 and the 18-electron species Ni(dme)- (alkyne) (see Figure S2). Optimization of these key species in both the singlet and triplet spin states revealed that the singlet state is lower in energy. Therefore, the singlet state was considered for all subsequent mechanistic studies. On the other hand, Ni(dme)(alkyne) is unproductive for the observed transformation but accounts for the formation of minor amounts of alkyne cyclotrimerization product (see Figure S3), observed during reaction optimization. Intermediate A2 can undergo oxidative cyclization to form five distinct intermediates, depending on the unsaturated bonds involved (see Figure S4). These include both intramolecular transformations engaging only the bisallene substrate and intermolecular processes involving the alkyne and bisallene. The three intramolecular oxidative cyclization modes (head-tohead, head-to-tail, and tail-to-tail) are energetically higher than the two intermolecular cyclizations. Therefore, oxidative cyclization involving the alkyne and the bisallene proceeds via TSA2A4 $\left( \Delta G ^ { \ddagger } = 1 4 . 1 \right.$ kcal·mol<sup>−1</sup>), where the tail double bond of the allene reacts, or via TSA2A3 $( \Delta G ^ { \ddagger } = 1 3 . 6$ kcal· mol<sup>−1</sup>), where the head double bond is involved. These results indicate that the oxidative cyclization step is not the head-to tail selectivity-determining step. Furthermore, within the intermolecular scenario. reaction at the head double bond of the allene is only marginally favored over the tail (by 0.5 kcal· mol<sup>−1</sup>), implying that both pathways could be productive. Consequently, both were further explored to understand the formation of the experimentally observed head-to-tail product. The full reaction pathways involving TSA2A3 and TSA2A4 are shown in Figures S5 and S6, respectively, with a schematic summary in Figure 2. In both cases, after oxidative cyclization, dme coordinates to the nickelcyclopentene intermediate, forming A3dme and A4dme. There is a slight trend between the kinetic cost and the buried volume at the Ni center (see Table S2).<sup>16</sup> This coordination stabilizes the intermediates and efectively renders the previous step irreversible, especially for A4. The subsequent allene insertion is the regioselectivitydetermining step. For A3, the tail double bond of the second allene inserts preferentially via TSA3A11dme (21.0 kcal· mol<sup>−1</sup>), afording the head-to-tail nickelacycle A11dme (−55.6 kcal·mol<sup>−1</sup>). An alternative pathway leading to the head-tohead product has a higher activation barrier (29.6 kcal·mol<sup>−1</sup>), 8.6 kcal·mol<sup>−1</sup> above TSA3A11dme, and is therefore kineti cally disfavored (see Figure S5). From A4dme, the pathway toward the head-to-tail product proceeds via TSA4A8dme (12.2 kcal·mol<sup>−1</sup>). In contrast, formation of the unobserved tail-to-tail product requires a much higher activation barrier (26.3 kcal·mol<sup>−1</sup>) and is thus not favored (see Figure S6). The reaction then proceeds via reductive elimination: from A11dme via TSA11Pdme (17.7 kcal·mol<sup>−1</sup>) and from A8dme via TSA8Pdme (12.2 kcal·mol<sup>−1</sup>), both delivering the same head-to-tail product P at −94.0 kcal·mol<sup>−1</sup>. Overall, the transformation is both kinetically accessible and highly exergonic along both pathways. Comparing the two, oxidative cyclization is more favorable for the pathway initiated at the head double bond, although the subsequent steps are more favorable for the pathway starting at the tail. Given the small energy diference between TSA2A3 and TSA2A4 and the irreversible nature of the oxidative cyclization, both intermolecular pathways are considered productive. Finally, we examined the diferent selectivity observed in the reactions between bisallenes and alkynes catalyzed by the Rh-NHC hemilabile thioether ligand system<sup>9</sup> and by the ligand-free nickel catalyst. In both cases, the pathway proceeds via oxidative cyclization between the alkyne and the allene. However, the resulting metallacyclopentene intermediate has markedly diferent geometries: while the Rh intermediate adopts an octahedral geometry, the Ni intermediate is squareplanar (Figure 3). This geometrical diference influences the preferred mode of allene insertion. Therefore, further eforts to control the selectivity in this reaction should focus on tuning the geometry of the metallacyclopentene intermediates.

## ■ SUMMARY

We have developed a ligand-free Ni(0)-catalyzed [2 + 2 + 2] cycloaddition of 1,5-bisallenes with mono- and disubstituted alkynes, afording 6,6-fused bicyclic hexahydroisoquinolines with excellent chemo- and regioselectivity under mild conditions. Notably, head-to-tail bisallene cyclization predominates, and high regioselectivity is observed for monosub stituted alkynes. Furthermore, DFT studies suggest that the observed head-to-tail selectivity arises from two competing pathways, both initiated by oxidative cyclization between the allene and the alkyne. Finally, the geometry of the metallacyclopentene intermediate plays a key role in directing the reactivity and selectivity, underscoring the importance of catalyst design in future eforts to control the regioselectivity in these transformations.

## ■ ASSOCIATED CONTENT

## \*sı Supporting Information

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acscatal.5c04046.

Experimental procedures, characterization data, X-ray crystallographic data, and NMR spectra for all new compounds (PDF)

Cartesian coordinates (XYZ)

Crystallographic data for compound 3y (CIF)

## Accession Codes

Crystallographic data for compound 3y (CCDC 2449331) can be downloaded free of charge from the Cambridge Crystallographic Data Centre (www.ccdc.cam.ac.uk).

## ■ AUTHOR INFORMATION

## Corresponding Authors

Anna Roglans − Institut de Química Computacional i Catalisi ̀ (IQCC) and Departament de Química, Facultat de Ciencies,̀ Universitat de Girona (UdG), 17003 Girona, Catalunya, Spain; orcid.org/0000-0002-7943-5706; Email: anna.roglans@udg.edu

Anna Pla-Quintana − Institut de Química Computacional i Catalisi ̀ (IQCC) and Departament de Química, Facultat de Ciencies, ̀ Universitat de Girona (UdG), 17003 Girona, Catalunya, Spain; orcid.org/0000-0003-2545-9048; Email: anna.plaq@udg.edu

## Authors

Stuart C. D. Kennington − Institut de Química Computacional i Catalisì (IQCC) and Departament de Química, Facultat de Ciencies,̀ Universitat de Girona (UdG), 17003 Girona, Catalunya, Spain; orcid.org/0000-0001- 6804-7794

Mou Mandal − Institut de Química Computacional i Catalisì (IQCC) and Departament de Química, Facultat de Ciencies,̀ Universitat de Girona (UdG), 17003 Girona, Catalunya, Spain

Roger Monreal-Corona − Institut de Química Computacional i Catalisì (IQCC) and Departament de Química, Facultat de Ciencies,̀ Universitat de Girona (UdG), 17003 Girona, Catalunya, Spain; orcid.org/0000-0003-3071-9887

Arijit Saha − Institut de Química Computacional i Catalisì (IQCC) and Departament de Química, Facultat de Ciencies, ̀ Universitat de Girona (UdG), 17003 Girona, Catalunya, Spain; orcid.org/0000-0003-1354-814X

Albert Poater − Institut de Química Computacional i Catalisì (IQCC) and Departament de Química, Facultat de Ciencies,̀ Universitat de Girona (UdG), 17003 Girona, Catalunya, Spain; orcid.org/0000-0002-8997-2599

Complete contact information is available at: https://pubs.acs.org/10.1021/acscatal.5c04046

## Author Contributions

<sup>†</sup>S.C.D.K. and M.M. contributed equally to this work. The manuscript was written through contributions of all authors. All of the authors approved the final version of the manuscript. Notes

The authors declare no competing financial interest.

## ■ ACKNOWLEDGMENTS

We are grateful for the financial support from the Spanish Ministerio de Ciencia, Innovación y Universidades (Projects P I D 2 0 2 3 - 1 4 6 8 4 9 N B - I 0 0 / M I C I U /AE I / 1 0 . 1 3 0 3 9 / 501100011033/FEDER, UE, RED2022-134939-T, PID-2021- 127423NB-I00, predoctoral FPU20/00707 grant to R.M.-C., and Margarita Salas Grant (NextGenerationEU) to S.C.D.K.), a Beatriu de Pinós−AGAUR Postdoctoral Grant (2022 BP00051) to A.S., and the Generalitat de Catalunya (Project 2021-SGR-623). M.M. thanks the Ministerio de Ciencia, Innovación y Universidades for her fellowship (PID2021- 127423NB-I00).

## ■ REFERENCES

(1) (a) Wang, Y.; Lu, H.; Xu, P.-F. Asymmetric Catalytic Cascade Reactions for Constructing Diverse Scaffolds and Complex Molecules. Acc. Chem. Res. 2015, 48, 1832−1844. (b) Afagh, N. A.; Yudin, A. K. Chemoselectivity and the Curious Reactivity Preferences of Functional Groups. Angew. Chem., Int. Ed. 2010, 49, 262−310. (c) Shenvi, R. A.; O’Malley, D. P.; Baran, P. S. Chemoselectivity: The Mother of Invention in Total Synthesis. Acc. Chem. Res. 2009, 42, 530−541.

(2) For a monograph, see: (a) Tanaka, K. Transition-Metal-Mediated Aromatic Ring Construction, 1st ed.; John Wiley & Sons: Hoboken, NJ, 2013. For recent and selected reviews, see: (b) Matton, P.; Huvelle, S.; Haddad, M.; Phansavath, P.; Ratovelomanana-Vidal, V. Recent Progress in Metal-Catalyzed $[ 2 + 2 + 2 ]$ Cycloaddition Reactions. Synthesis 2022, 54, 4−32. (c) Roglans, A.; Pla-Quintana, A.; Sola,̀ M. Mechanistic Studies of Transition-Metal-Catalyzed [2 + 2 + 2] Cycloaddition Reactions. Chem. Rev. 2021, 121, 1894−1979. (d) Stará, G.; Stary,́ I. Helically Chiral Aromatics: The Synthesis of Helicenes by [2 + 2 + 2] Cycloisomerization of π-Electron Systems. Acc. Chem. Res. 2020, 53, 144−158. (e) Nagata, T.; Obora, Y.

Transition-Metal-Mediated/Catalyzed Synthesis of Pyridines, Pyrimidines, and Triazines by $[ 2 + 2 + 2 ]$ Cycloaddition Reactions. Asian J. Org. Chem. 2020, 9, 1532−1547. (f) Pla-Quintana, A.; Roglans, A. Chiral Induction in $[ 2 + 2 + 2 ]$ Cycloaddition Reactions. Asian J. Org. Chem. 2018, 7, 1706−1718. (g) Kotha, S.; Lahiri, K.; Sreevani, G. Design and Synthesis of Aromatics through [2 + 2 + 2] Cyclotrimerization. Synlett 2018, 29, 2342−2361. (h) Yamamoto, Y. Recent Topics of Cp\*RuCl-Catalyzed Annulation Reactions. Tetrahedron Lett. 2017, 58, 3787−3794. (i) Jungk, P.; Täufer, T.; Thiel, I.; Hapke, M. Synthesis of Chiral Indenylcobalt(I) Complexes and their Evaluation in Asymmetric $[ 2 ~ + ~ 2 ~ + ~ 2 ]$ Cycloaddition Reactions. Synthesis 2016, 48, 2026−2035. (j) Amatore, M.; Aubert, C. Recent Advances in Stereoselective $[ 2 + 2 + 2 ]$ Cycloadditions. Eur. J. Org. Chem. 2015, 2015, 265−286. (k) Broere, D. L. J.; Ruijter, E. Recent Advances in Transition-Metal-Catalyzed $[ 2 ~ + ~ 2 ~ + ~ 2 ] .$ Cyclo(co)trimerization Reactions. Synthesis 2012, 44, 2639−2672.

(3) For a monograph, see: (a) Krause, N.; Hashmi, A. S. K. Modern Allene Chemistry; Wiley-VCH: Weinheim, Germany, 2004. (b) Garner, M. H.; Hoffmann, R.; Rettrup, S.; Solomon, G. C. Coarctate and Möbius: The Helical Orbitals of Allene and Other Cumulenes. ACS Cent. Sci. 2018, 4, 688−700. (c) Hoffmann-Röder, A.; Krause, N. Synthesis and Properties of Allenic Natural Products and Pharmaceuticals. Angew. Chem., Int. Ed. 2004, 43, 1196−1216. (d) Soriano, E.; Fernández, I. Allenes and Computational Chemistry: from Bonding Situations to Reaction Mechanisms. Chem. Soc. Rev. 2014, 43, 3041−3105.

(4) (a) Lledó, A.; Pla-Quintana, A.; Roglans, A. Allenes, Versatile Unsaturated Motifs in Transition-Metal-Catalysed $[ 2 ~ + ~ 2 ~ + ~ 2 ]$ Cycloaddition Reactions. Chem. Soc. Rev. 2016, 45, 2010−2023. (b) Domínguez, G.; Pérez-Castells, J. Alkenes in [2 + 2 + 2] Cycloadditions. Chem.�Eur. J. 2016, 22, 6720−6739. (c) Alonso, J. M.; Almendros, P. Highlighting the Rich Chemistry of the Allenone Moiety. Adv. Synth. Catal. 2023, 365, 1332−1384. (d) Bates, R. W.; Satcharoen, V. Nucleophilic Transition Metal Based Cyclization of Allenes. Chem. Soc. Rev. 2002, 31, 12−21. (e) López, F.; Mascareñas, J. L. Allenes as Three-Carbon Units in Catalytic Cycloadditions: New Opportunities with Transition-Metal Catalysts. Chem.�Eur. J. 2011, 17, 418−428. (f) Ma, S. Some Typical Advances in the Synthetic Applications of Allenes. Chem. Rev. 2005, 105, 2829−2872.

(g) Zimmer, R.; Dinesh, C. U.; Nandanan, E.; Khan, F. A. Palladium-Catalyzed Reactions of Allenes. Chem. Rev. 2000, 100, 3067−3126. (h) Bai, T.; Ma, S.; Jia, G. Insertion Reactions of Allenes with Transition Metals Complexes. Coord. Chem. Rev. 2009, 253, 423−448. (i) Santhoshkumar, R.; Cheng, C.-H. Fickle Reactivity of Allenes in Transition-Metal-Catalyzed C-H Functionalizations. Asian J. Org. Chem. 2018, 7, 1151−1163. (j) Aubert, C.; Fensterbank, L.; Garcia, P.; Malacria, M.; Simonneau, A. Transition Metal Catalyzed Cycloisomerizations of 1,n-Allenynes and -Allenenes. Chem. Rev. 2011, 111, 1954−1993.

(5) (a) Chen, G.; Jiang, X.; Fu, C.; Ma, S. The Diversified Reactivities of 1,5-Bisallenes. Chem. Lett. 2010, 39, 78−81. (b) Alcaide, B.; Almendros, P.; Aragoncillo, C. Cyclization Reactions of Bis(allenes) for the Synthesis of Polycarbo(hetero)cycles. Chem. Soc. Rev. 2014, 43, 3106−3135.

(6) (a) Park, J. H.; Kim, E.; Kim, H.-M.; Choi, S. Y.; Chung, Y. K. Cobalt/Rhodium Heterobimetallic Nanoparticle-Catalyzed Carbonylative $[ 2 ~ + ~ 2 ~ + ~ 1 ]$ Cycloaddition of Allenes and Bisallenes to Pauson−Khand-Type Reaction Products. Chem. Commun. 2008, 2388−2390. (b) Kawamura, T.; Inagaki, F.; Narita, S.; Takahashi, Y.; Hirata, S.; Kitagaki, S.; Mukai, C. Rhodium(I)-Catalyzed Intramolecular Carbonylative $[ 2 ~ + ~ 2 ~ + ~ 1 ]$ Cycloadditions and Cycloisomerizations of Bis(sulfonylallene)s. Chem.�Eur. J. 2010, 16, 5173−5183. (c) Inagaki, F.; Narita, S.; Hasegawa, T.; Kitagaki, S.; Mukai, C. Rhodium(I)-Catalyzed Intramolecular Carbonylative [2 + 2 + 1] Cycloaddition of Bis(allene)s: Bicyclo[6.3.0]undecadienones and Bicyclo[5.3.0]decadienones. Angew. Chem., Int. Ed. 2009, 48, 2007−2011. (d) Deng, Y.; Shi, Y.; Ma, S. An Efficient Synthesis of 2,5-Dihydrofuran-Fused Bicyclic Skeletons via the Pd(II)-Catalyzed Tandem-Cyclization Reaction of 1,ω-Bisallenols. Org. Lett. 2009, 11,

1205−1208. (e) Deng, Y.; Fu, C.; Ma, S. Ma. Selectivity Manipulation of Bicyclization Reactions of 1,5-Bis(1,2-allenylketone)s: Pd Versus Rh and Electronic Effect. Chem.�Eur. J. 2011, 17, 4976−4980. (f) Quirós, M. T.; Hurtado-Rodrigo, C.; Muñoz, M. P. Nucleophile Dependent Formation of 6- and 7-Membered N-Heterocycles by Platinum-Catalysed Cyclisation of 1,5-Bisallenes. Org. Biomol. Chem. 2017, 15, 6731−6737. (g) Zhu, C.; Yang, B.; Qiu, B.; Bäckvall, J.-E. Highly Selective Construction of Seven-Membered Carbocycles by Olefin-Assisted Palladium-Catalyzed Oxidative Carbocyclization− Alkoxycarbonylation of Bisallenes. Angew. Chem., Int. Ed. 2016, 55, 14405−14408. (h) Zhu, C.; Yang, B.; Mai, B. Y.; Palazzotto, S.; Qiu, Y.; Gudmundsson, A.; Ricke, A.; Himo, F.; Bäckvall, J.-E. Highly Selective Palladium-Catalyzed Hydroborylative Carbocyclization of Bisallenes to Seven-Membered Rings. J. Am. Chem. Soc. 2018, 140, 14324−14333. (i) Lu, P.; Ma, S. Observation of New Cycloisomerization Pattern of 1,5-Bisallenes. Catalyst and Substituent Effects. Org. Lett. 2007, 9, 2095−2097.

(8) Vila, J.; Vinardell, R.; Sola,̀ M.; Pla-Quintana, A.; Roglans, A. A Rh(I)-Catalyzed Cascade Cyclization of 1,5-Bisallenes and Alkynes for the Formation of cis-3,4-Arylvinyl Pyrrolidines and Cyclopentanes. Adv. Synth. Catal. 2022, 364, 206−217.

(9) Vila, J.; Sola,̀ M.; Achard, T.; Bellemin-Laponnaz, S.; Pla-Quintana, A.; Roglans, A. Rh(I) Complexes with Hemilabile Thioether-Functionalized NHC Ligands as Catalysts for [2 + 2 + 2] Cycloaddition of 1,5-Bisallenes and Alkynes. ACS Catal. 2023, 13, 3201−3210.

(10) (a) Artigas, A.; Vila, J.; Lledó, A.; Sola,̀ M.; Pla-Quintana, A.; Roglans, A. A Rh-Catalyzed Cycloisomerization/Diels-Alder Cascade Reaction of 1,5-Bisallenes for the Synthesis of Polycyclic Heterocycles. Org. Lett. 2019, 21, 6608−6613. (b) Vila, J.; Sola,̀ M.; Pla-Quintana, A.; Roglans, A. Highly Selective Synthesis of Seven-Membered Azaspiro Compounds by a Rh(I)-Catalyzed Cycloisomerization/Diels-Alder Cascade of 1,5-Bisallenes. J. Org. Chem. 2022, 87, 5279−5286.

(11) (a) Haraburda, E.; Torres, O<sup>̀</sup>.; Parella, T.; Sola,̀ M.; Pla-Quintana, A. Stereoselective Rhodium-Catalysed $[ 2 ~ + ~ 2 ~ + ~ 2 ]$ Cycloaddition of Linear Allene-Ene/Yne-Allene Substrates: Reactivity and Theoretical Mechanistic Studies. Chem.�Eur. J. 2014, 20, 5034− 5045. (b) Haraburda, E.; Fernández, M.; Gifreu, A.; Garcia, J.; Parella, T.; Pla-Quintana, A.; Roglans, A. Chiral Induction in Intramolecular Rhodium-Catalyzed $[ 2 + 2 + 2 ]$ Cycloadditions of Optically Active Allene-ene/yne-allene Sustrates. Adv. Synth. Catal. 2017, 359, 506− 512.

(12) (a) Lu, P.; Ma, S. Rh-Catalyzed Triple Allene Approach to Bicyclo[4.4.0]decene Derivatives and Its Application for the Stepwise Synthesis of Steroid-Like Tetracyclic Skeletons. Org. Lett. 2007, 9, 5319−5321. (b) Ma, S.; Lu, P.; Lu, L.; Hou, H.; Wei, J.; He, Q.; Gu, Z.; Jiang, X.; Jin, X. What Can a Metal Catalyst Do with Allenes? One-Step Formation of Steroid Scaffolds from Readily Available Starting Materials. Angew. Chem., Int. Ed. 2005, 44, 5275−5278. (c) Ma, S.; Lu, L. Rh<sup>I</sup>-Catalyzed Bimolecular Cyclization between Two Different

1,5-Bisallenes: A Combinatorial One-Step Approach to Heterosteroids and Mechanistic Implications. Chem.�Asian J. 2007, 2, 199− 204.

(13) Arai, S.; Izaki, A.; Amako, Y.; Nakajima, M.; Uchiyama, M.; Nishida, A. Regioselective [2 + 2 + 2] Cycloaddition Reaction Using Allene-ynes with Simple Allenes under Nickel Catalysis. Adv. Synth. Catal. 2019, 361, 4882−4887.

(14) Thakur, A.; Louie, J. Advances in Nickel-Catalyzed Cycloaddition Reactions to Construct Carbocycles and Heterocycles. Acc. Chem. Res. 2015, 48, 2354−2365.

(15) Rodrigo, S. K.; Powell, I. V.; Coleman, M. G.; Krause, J. A.; Guan, H. Efficient and Regioselective Nickel-Catalyzed [2 + 2 + 2] Cyclotrimerization of Ynoates and Related Alkynes. Org. Biomol. Chem. 2013, 11, 7653−7657.

(16) (a) Escayola, S.; Bahri-Laleh, N.; Poater, A. %V Index and Steric Maps: From Predictive Catalysis to Machine Learning. Chem. Soc. Rev. 2024, 53, 853−882. (b) Dorta, R.; Stevens, E. D.; Scott, N. M.; Costabile, C.; Cavallo, L.; Hoff, C. D.; Nolan, S. P. Steric and Electronic Properties of N-Heterocyclic Carbenes (NHC): A Detailed Study on Their Interaction with Ni(CO) . J. Am. Chem. Soc. 2005, 127, 2485−2495. (c) Falivene, L.; Cao, Z.; Petta, A.; Serra, L.; Poater, A.; Oliva, R.; Scarano, V.; Cavallo, L. Towards the Online Computer-Aided Design of Catalytic Pockets. Nat. Chem. 2019, 11, 872−879.