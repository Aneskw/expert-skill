pubs.acs.org/OrgLett

Letter

# Palladium-Catalyzed Substrate-Controlled Regiodivergent Hydroamination of gem-Difluoroallenes

Bao-Xin Liu, Shi-Cun Li, Han-Wen Rao, Qian-Qian Yang,\* Wei Du,\* and Ying-Chun Chen\*

![](images/cb87fe576d83ffe73cd80f380fd0428ba3e0f304c814210221b23350ef2d5179.jpg)

Cite This: Org. Lett. 2025, 27, 8288−8292

Read Online

ACCESS

Metrics & More

Article Recommendations

\*sı Supporting Information

![](images/0372351124e30fe6f7cf0d3ef5dd76bf2a64610af95309deca5584dd6b5b7c83.jpg)  
ABSTRACT: We report palladium-catalyzed regiodivergent hydroamination reactions of gem-difluoroallenes. Employing indolines as the nucleophiles leads to the formation of enantioenriched γ-addition products, while the use of 2-indole-carboxylate-type substrates switches the selectivity, delivering β-addition E-alkenes exclusively. This protocol provides eficient access to diverse difluoroalkylated indole derivatives, showing substantial substrate scope and broad functional group compatibility.

gem-Difluoroalkenes and alkanes have gained significant attention in pharmaceutical chemistry owing to their enhanced metabolic properties and improved lipophilicity.<sup>1</sup> Among these, N-difluoropropylindoles and N-difluoroethylindoles have demonstrated considerable potential for broad bioactivities, including inhibitors of ASH, MAGL, and PAD, as well as serving as p53 isosteres (Scheme $1 \mathsf { a } ) . ^ { 2 }$ As a result, the incorporation of difluoroalkyl groups into the indole frameworks has received growing interest, as it provides valuable opportunities for the development of novel therapeutic agents.

Traditional methods for the synthesis of gem-difluoroalkylated indoles typically employ nucleophilic substitution reactions between NH-free indoles and halogenated difluoroalkenes under basic conditions (Scheme 1b).<sup>3</sup> However, this approach is not atom-economical, as it results in the loss of a halogen atom and the use of excess bases. In contrast, transition metal-catalyzed hydroamination reaction of 1,1- difluoroallenes ofers an eficient strategy for the introduction of difluoroallylic groups.<sup>4</sup> Although the reaction is promising, the asymmetric variants remain limited.<sup>5</sup> Notably, Shi and Wang developed a rhodium-catalyzed asymmetric hydroamination reaction of 1,1-difluoroallenes via exclusive γ- regioselective addition, whereas only one enantioenriched difluoroallylated indoline was furnished (Scheme 1c).<sup>6</sup>

With our continuous interest in Pd-catalyzed hydrofunctionalization of unsaturated hydrocarbons,<sup>7</sup> here we would like to present regiodivergent hydroamination reactions of 1,1-difluoroallenes by tuning the nucleophiles. This method enabled the asymmetric synthesis of γ-regioselective adducts when indolines were used as the nucleophiles, while β- regioselective products were obtained with the 2-indolecarboxylate-type substrates. The current strategy ofered a versatile and eficient approach for constructing diverse difluoroalkylated indole derivatives, facilitating the rapid synthesis of structurally varied bioactive analogues.

The initial attempt was conducted by using 1,1-difluoroallene 1a and indoline 2a as the model substrates, under the catalysis of Pd (dba) and L1 [(S)-Segphos)] in toluene at 80 °C (Table 1, entry 1). While product 3a was generated with exclusive γ-regioselectivity, the reaction sufered from low yield and enantioselectivity. It was found that product 3a gradually decomposed during the reaction, giving unidentified side products. Then a variety of chiral ligands were tested, but phosphine-based ones generally led to poor yields.<sup>8</sup> In contrast, using bis(oxazoline) (BOX) ligand L2 provided significantly improved enantiocontrol (entry 2). Notably, higher reactivity was observed with indane-derived ligands (L3−5) (entries 3− 5), and a good ee value was obtained with L5 having bulkier substituents (entry 5). Subsequently, some solvents were screened (entries 6−9), and DCM turned out to be the optimal one (entry 6). The reaction still proceeded well at a lower temperature, and slightly increased enantioselectivity was gained at $\mathrm { ~ \textit ~ { ~ O ~ } ~ } ^ { \circ } C$ (entries 10 and 11). Additionally, a lower concentration was found to be beneficial for the yield, and the addition of 4 Å molecular sieves (MS) further improved the results (entries 12 and 13). Finally, other Pd sources, such as Pd(PPh ) and Pd(OAc) , proved to be inefective (entries 14 and 15).

![](images/7b91fc89acf8c74373d2ae4575406237121454352f3280b25202d57b41a9a8b8.jpg)

![](images/6368a1a17ad692d58486d0b000221e9c7c22ed025216f2c7fd4b428754f9e60f.jpg)

## Scheme 1. Biologically Active gem-Difluoroalkylated Indoles and Related Synthetic Strategies

a) Representative biologically active gem-difluoroalkylated indoles

![](images/95e8ec7f1a1552488c59967bf8a539b7afdc536bd75400005b962f230273a5a1.jpg)

With the optimized conditions in hand, we then evaluated the substrate scope of the γ-regioselective asymmetric hydroamination of gem-difluoroallenes 1 and indolines 2 under the catalysis of $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ and ligand L5. As shown in Scheme $^ { 2 , }$ excellent γ-regioselectivity was generally observed. Initial examples with diverse indoline derivatives revealed broad functional group tolerance. Both electron-donating and electron-withdrawing substituents on the aryl ring, including halogen atoms, were well accommodated, delivering γ-selective adducts $\mathbf { 3 6 - g }$ with good to excellent enantioselectivity.<sup>9</sup> Notably, excellent enantioselectivity was maintained on a 1.0 mmol scale (product 3a). Nevertheless, simple anilines and aliphatic secondary amines did not yield the desired products under the current reaction conditions.<sup>8</sup> Next, we explored various gem-difluoroallenes bearing diverse aryl substituents in the reactions with indoline 2a. Substrates with a variety of substituents underwent the asymmetric transformation smoothly, furnishing enantioenriched products ${ \bf 3  h - w }$ in moderate to good yields with uniformly high enantioselectivity. Importantly, a range of functional groups, including protected phenols, acetals, esters, and ketones, were well tolerated. Furthermore, simple alkyl-substituted allenes proved compatible, afording ${ \bf 3 x { - z } }$ in moderate yields with good enantioselectivity. In addition, more complex substrates derived from citronellal and diosgenin were employed, and corresponding products 3aa and 3ab were furnished in good yields and stereoselectivity.

Interestingly, when 2-indole-carboxylates 4 were employed in the reactions with gem-difluoroallene 1a, the regioselectivity was completely switched under the catalysis of $\mathrm { P d } _ { 2 } ( \mathrm { d b a } ) _ { 3 }$ and

Table 1. Condition Optimizations for the γ-Regioselective Asymmetric Hydroamination

<table><tr><td>entry</td><td>[Pd]</td><td>L</td><td>solvent</td><td> $T \ ( ^ { \circ } \mathrm { C } )$ </td><td>yield  ${ \bigl ( } \% { \bigr ) } ^ { b }$ </td><td>ee (%)c</td></tr><tr><td>1</td><td> $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ </td><td>L1</td><td>toluene</td><td>80</td><td>33</td><td>4</td></tr><tr><td>2</td><td> $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ </td><td>L2</td><td>toluene</td><td>80</td><td>30</td><td>50</td></tr><tr><td>3</td><td> $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ </td><td>L3</td><td>toluene</td><td>80</td><td>36</td><td>26</td></tr><tr><td>4</td><td> $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ </td><td>L4</td><td>toluene</td><td>80</td><td>58</td><td>77</td></tr><tr><td>5</td><td> $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ </td><td>L5</td><td>toluene</td><td>80</td><td>55</td><td>80</td></tr><tr><td>6</td><td> $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ </td><td>L5</td><td>DCM</td><td>80</td><td>53</td><td>83</td></tr><tr><td>7</td><td> $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ </td><td>L5</td><td>EtOAc</td><td>80</td><td>46</td><td>65</td></tr><tr><td>8</td><td> $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ </td><td>L5</td><td>THF</td><td>80</td><td>63</td><td>42</td></tr><tr><td>9</td><td> $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ </td><td>L5</td><td>EtOH</td><td>80</td><td>messy</td><td>/</td></tr><tr><td>10</td><td> $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ </td><td>L5</td><td>DCM</td><td>40</td><td>50</td><td>82</td></tr><tr><td>11</td><td> $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ </td><td>L5</td><td>DCM</td><td>0</td><td>50</td><td>88</td></tr><tr><td> $1 2 ^ { d }$ </td><td> $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ </td><td>L5</td><td>DCM</td><td>0</td><td>65</td><td>88</td></tr><tr><td> $1 3 ^ { d , e }$ </td><td> $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ </td><td>L5</td><td>DCM</td><td>0</td><td>70</td><td>91</td></tr><tr><td>14</td><td> $\mathrm { P d } ( \mathrm { P P h } _ { 3 } ) _ { 4 }$ </td><td>L5</td><td>DCM</td><td>0</td><td>&lt;5</td><td>/</td></tr><tr><td>15</td><td> $\mathrm { P d } ( \mathrm { O A c } ) _ { 2 }$ </td><td>L5</td><td>DCM</td><td>0</td><td>&lt;5</td><td>/</td></tr></table>

<sup>a</sup>Unless noted otherwise, the reaction was performed with 1a (0.2 mmol), 2a (0.1 mmol), $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathsf { a } ) _ { 3 }$ (5 mol %) and L (10 mol %) in solvent (1.0 mL) at $8 0 ~ ^ { \circ } \mathrm { C }$ for 12 h under $\mathbf { A r } .$ $\boldsymbol { b } _ { \mathrm { Y i e l d } }$ of the isolated product. <sup>c</sup>Determined by HPLC analysis on a chiral stationary phase. ${ } ^ { \dot { a } } \mathbf { I n }$ DCM (2.0 mL). <sup>e</sup>With 4 Å MS (10 mg).

$_ { r a c - \mathbf { L 1 } , \mathbf { \xi } ^ { 8 } }$ delivering β-selective hydroamination product $\mathfrak { s a - c }$ in moderate yields with exclusive E-selectivity (Scheme 3). Subsequent exploration revealed that a variety of substrates having relatively strong acidic NH groups well participated in similar hydroamination reaction, furnishing adducts $\bar { \mathfrak { s d } } { \ - } \mathbf { h }$ in good to excellent yields. Importantly, a tetrasubstituted allene was applied to give 5i in a high yield eficiently. Moreover, the reaction was compatible for diverse gem-difluoroallenes 1, consistently afording products ${ \mathfrak { s j } } - { \mathfrak { p } }$ with good eficiency.

To exhibite the synthetic utility of this methodology, several transformations with the hydroamination products were conducted (Scheme 4). Using gem-difluoroallene 1a as the precursor, γ-selective adduct 3a from indoline and β-selective product 5d from 2-indole-carboxylate 4a could be produced under Pd catalysis, and valuable N-difluoropropylindole 6 and N-difluoroethylindole 7, respectively, were accessed via simple transformations, showcasing the power of current protocol to construct structurally divergent difluoroalkylated indoles from the same starting material. Furthermore, adduct 3a served as a versatile synthon for furnishing diverse fluorine-containing scafolds. α-Fluorovinyl thioether 8 was obtained in a high yield with exclusive E-selectivity by simple treatment with ethyl thiol,<sup>10</sup> and trifluoromethyl product 9 was eficiently yielded via addition of $\mathrm { T B A F . } ^ { \mathrm { 1 i } ^ { \prime } }$ In addition, controllable hydrodefluorination using either LiAlH or Cu/bis(pinacolato)- diboron $\left( \mathrm { B } _ { 2 } \mathrm { p i n } _ { 2 } \right)$ selectively provided E- and Z-monofluor-12 oalkenes 10 and 11, respectively, with retained ee values. These transformations established complementary routes to

## Scheme 2. Substrate Scope for the Asymmetric γ-Selective Addition to gem-Difluoroallenes with Indolines

![](images/1263b1c71ad2ad99127757346b2869eeddc8daa6badeaa943f6f3835212d81f8.jpg)

various fluorinated alkenes from a single precursor, significantly expanding the synthetic utility of our methodology.

To gain more insight into the Pd-catalyzed reactions, some control experiments were conducted. In the case of γ- regioselective amination, Pd(II) proved inefective (Table 1, entry 15), suggesting the reaction is initiated by Pd(0) species. When deuterium-labeled d-2a was applied to the asymmetric hydroamination reaction with $\mathrm { P } \hat { \mathrm { d } } _ { 2 } \big ( \mathrm { d } \mathbf { b } \mathbf { a } \big ) _ { 3 } / \mathbf { L } \mathbf { 5 } ,$ d-3a was aforded with 31% D-incorporation, along with recovered undeuterated 1a (Scheme 5a). Given that indoline 2a is a weak

## Scheme 5. Mechanism Studies and the Proposed Mechanism of Hydroamination Reaction

![](images/cce428d16ddddc3453bf776f78f86c387f314dc1abdf81e97570485477b9fb16.jpg)

acid, the related H−Pd species (via oxidative addition) is unlikely involved in this transformation.<sup>13</sup> As a result, it is proposed that gem-difluoroallene 1a first coordinates to Pd(0), followed by protonation<sup>14</sup> with 2a via transition state TS-1 to generate π-allylpalladium intermediate INT-1, which then is attacked by indoline anion from the bottom face to aford product 3a (Scheme 5b).<sup>15</sup> In contrast, the β-regioselective amination exhibited diferent behavior. When 1a reacted with d-4a under the catalysis of Pd (dba) /rac-L1, high Dincorporation at α-site was observed. The results align with a ligand-to-ligand hydrogen transfer (LLHT) process<sup>16</sup> via TS-2, forming σ-vinyl-Pd intermediate INT-2, which subsequently undergoes reductive elimination to yield product 5a.

In conclusion, we have investigated Pd-catalyzed regiodi vergent hydroamination reactions of gem-difluoroallenes that demonstrated high nucleophile-dependent regioselectivity, eficiently constructing two distinct classes of valuable difluoroalkylated indole derivatives. By employing indolines as the nucleophiles, enantioenriched γ-addition products were obtained through a proposed Pd-mediated protonation pathway followed by asymmetric allylic amination, while 2- indole-carboxylate-type nucleophiles favored β-addition products likely via a LLHT process. This regiodivergent protocol provided a versatile synthetic platform for the rapid construction of structurally diverse difluoroalkylated indole derivatives, which might be applied as pharmaceutically relevant scafolds in drug discovery.

## ■ ASSOCIATED CONTENT

## Data Availability Statement

The data underlying this study are available in the published article and its online Supporting Information.

## \*sı Supporting Information

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acs.orglett.5c02471.

Complete experimental procedures and characterization of new products, synthetic transformations of the products, NMR and HRMS spectra, and HPLC chromatograms (PDF)

## ■ AUTHOR INFORMATION

## Corresponding Authors

Qian-Qian Yang − State Key Laboratory of Southwestern Chinese Medicine Resources, School of Pharmacy, Chengdu University of Traditional Chinese Medicine, Chengdu 611137, China; Email: yangqq@cdutcm.edu.cn

Wei Du − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China; orcid.org/ 0000-0003-4162-1471; Email: duweiyb@scu.edu.cn

Ying-Chun Chen − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China; orcid.org/ 0000-0003-1902-0979; Email: ycchen@scu.edu.cn

## Authors

Bao-Xin Liu − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China

Shi-Cun Li − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China

Han-Wen Rao − Key Laboratory of Drug-Targeting and Drug Delivery System of the Education Ministry and Sichuan Province, and Sichuan Research Center for Drug Precision Industrial Technology, West China School of Pharmacy, Sichuan University, Chengdu 610041, China

Complete contact information is available at: https://pubs.acs.org/10.1021/acs.orglett.5c02471

## Funding

We are grateful for the financial support from the NSFC (22371191), Sichuan Science and Technology Program (2025NSFJQ0055), and Open Research Fund of State Key

Laboratory of Southwestern Chinese Medicine Resources (SKLTCM202409).

## Notes

The authors declare no competing financial interest.

## ■ REFERENCES

(1) For selected examples, see: (a) Sap, J. B. I.; Meyer, C. F.; Straathof, N. J. W.; Iwumene, N.; am Ende, C. W.; Trabanco, A. A.; Gouverneur, V. Late-Stage Difluoromethylation: Concepts, Develop ments and Perspective. Chem. Soc. Rev. 2021, 50, 8214−8247.

(b) Zafrani, Y.; Yeffet, D.; Sod-Moriah, G.; Berliner, A.; Amir, D.; Marciano, D.; Gershonov, E.; Saphier, S. Difluoromethyl Bioisostere: Examining the “Lipophilic Hydrogen Bond Donor” Concept. J. Med. Chem. 2017, 60, 797−804. (c) Liu, J.-Y.; Tao, X.-Z.; Zou, Z.-L.; Xu, J.; Shu, H.; Pan, Y.; Zhang, W.-G.; Ni, S.-Y.; Wang, Y. Modular and Practical Synthesis of gem-Difluoroalkenes via Consecutive Ni-Catalyzed Reductive Cross-Coupling. Chin. Chem. Lett. 2025, 36, 110461−110467. (d) Wu, F.; Li, X.; Chang, J.-B.; Bai, D.-C. Palladium-Catalyzed Multi Components Oxy-aminofluorination and Aminofluorination ofgem-Difluoroalkenes. Chin. Chem. Lett. 2024, 35, 109155−109161.

(2) (a) Grembecka, J.; Cierpicki, T.; Rogawski, D.; Borkin, D.; Klossowski, S.; Zhuang, J.; Montgomery, D.; Deng, J.; Szewczyk, M.; Li, H. ASH1L Inhibitors and Methods of Treatment Therewith. WO2017197240A1, 2017. (b) Zhang, Y.-M.; Connolly, P. J.; Lin, S.- C.; Macielag, M. J. Amino-Pyrrolidine-Azetidine Diamides as Monoacylglycerol Lipase Inhibitors. WO2012054721A1, 2012. (c) Vu, B.; Dominique, R.; Li, H.-J.; Fahr, B. A. Methods and Compounds for Restoring Mutant p53 Function Cross-Reference. WO2021061643A1, 2021.

(3) (a) Bauer, M. R.; Jones, R. N.; Baud, M. G. J.; Wilcken, R.; Boeckler, F. M.; Fersht, A. R.; Joerger, A. C.; Spencer, J. Harnessing Fluorine−Sulfur Contacts and Multipolar Interactions for the Design of p53 Mutant Y220C Rescue Drugs. ACS Chem. Biol. 2016, 11, 2265−2274. (b) Hitchcock, S.; Monenschein, H.; Reichard, H.; Sun, H.; Kikuchi, S.; Macklin, T.; Hopkins, M. 5HT3 Receptor Antagonists. WO2014014962A1, 2014. (c) Hallur, G.; Duraiswamy, A. J.; Purra, B. R.; Rao, N. V. S. K. Heterocyclic Compounds as Pad Inhibitors Technical Field of the Invention. WO2019058393A1, 2019.

(4) (a) Fuchibe, K.; Abe, M.; Sasaki, M.; Ichikawa, J. Gold-Catalyzed Electrophilic Activation of 1,1-Difluoroallenes: α- and γ-Selective Addition of Heteroatom Nucleophiles. J. Fluorine Chem. 2020, 232, 109452−109458. (b) Li, Z.-Q.; Tang, H.-J.; Wang, Z.-X.; Wang, C.- Q.; Feng, C. Multi-Substituted Trifluoromethyl Alkene Construction via Gold-Catalyzed Fluoroarylation of gem-Difluoroallenes. Chem. Sci. 2024, 15, 3524−3529. (c) Li, W.; Wang, C.; Xiao, M.-D.; Cheng, L.-J. Copper-Catalyzed Protoarylation of gem-Difluoroallenes. Org. Lett. 2024, 26, 525−529. (d) Li, Y.-Y.; Gao, B. Rhodium-Catalyzed Enantioselective N-Allylation of Sulfoximines. Org. Lett. 2023, 25, 2756−2760. (e) Fuchibe, K.; Ueda, M.; Yokota, M.; Ichikawa, J. γ- Selective Addition to 1,1-Difluoroallenes: Three-component Coupling Leading to 2,2-Disubstituted 1,1-Difluoroalkenes. Chem. Lett. 2012, 41, 1619−1621.

(5) (a) Ji, D.-Q.; Qi, Z.-S.; Li, X.-W. Palladium-Catalyzed Regio- and Enantioselective Hydrophosphination of gem-Difluoroallenes. Org. Lett. 2023, 25, 5957−5962. (b) Han, X.-W.; Wang, M.-Y.; Liang, Y.; Zhao, Y.; Shi, Z.-Z. Regio- and Enantioselective Nucleophilic Addition to gem-Difluoroallenes. Nat. Synth. 2022, 1, 227−234.

(6) Han, X.-W.; Zhao, Y.; Shi, Z.-Z.; Wang, M.-Y. Rhodium-Catalyzed Asymmetric Hydroamination of gem-Difluoroallenes with Anilines. Tetrahedron Chem. 2022, 3, 100023−100035.

(7) (a) Li, Y.-F.; Gui, W.-T.; Pi, F.; Chen, Z.; Zhu, L.; Ouyang, Q.; Du, W.; Chen, Y.-C. Palladium(0) and Brønsted Acid Co-Catalyzed Enantioselective Hydro-Cyclization of 2,4-Dienyl Hydrazones and Oximes. Angew. Chem., Int. Ed. 2024, 136, No. e202407682. (b) Yan, X.; Yang, X.-M.; Yan, P.; Zhao, B.; Zeng, R.; Pan, B.; Chen, Y.-C.; Zhu, L.; Ouyang, Q. A Metal π-Lewis Base Activation Model for Pd-Catalyzed Hydroamination of Amines and 1,3-Dienes. Chem. Sci.

2023, 14, 4597. (c) Chen, Z.; Wang, X.-J.; Pi, F.; Li, Y.-F.; Tan, S.-Z.; Zhu, L.; Ouyang, Q.; Du, W.; Chen, Y.-C. Asymmetric Intramolecular Hydroamination to Construct Diverse N−N/C−N Indole Atropisomers via Cooperative Pd(0) and Chiral Phosphoric Acid Catalysis. Org. Lett. 2025, 27, 3302−3307.

(8) For more details, see the Supporting Information.

(9) The absolute configuration of (R)-3a was assigned based on analysis of experimental and calculated electronic circular dichroism (ECD) spectra; see the Supporting Information). The other products were assigned by analogy.

(10) Ma, Y.; Reddy, B. R. P.; Bi, X.-H. Coupling of Trifluoroacetaldehyde N-Triftosylhydrazone with Organoboronic Acids for the Synthesis of gem-Difluoroalkenes. Org. Lett. 2019, 21, 9860−9863.

(11) Yang, R.-Y.; Wang, H.; Xu, B. Base Promoted gem-Difluoroolefination of Alkyl Triflones. Chem. Commun. 2021, 57, 4831−4834.

(12) (a) Li, Y.; Zhang, W.-S.; Yang, S.-N.; Wang, X.-Y.; Liu, Y.; Ji, D.-W.; Chen, Q.-A. Nickel-Catalyzed Unsymmetrical Bis-Allylation of Alkynes. Angew. Chem., Int. Ed. 2023, 62, No. e202300036. (b) See ref 5b.

(13) (a) Bernar, I.; Fiser, B.; Blanco-Ania, D.; Gomez-Bengoa, E.; Rutjes, F. P. J. T. Pd-Catalyzed Hydroamination of Alkoxyallenes with Azole Heterocycles: Examples and Mechanistic Proposal. Org. Lett. 2017, 19, 4211−4214. (b) Leoni, P.; Sommovigo, M.; Pasquali, M.; Midollini, S.; Braga, D.; Sabatino, P. Coordinated Water/Anion Hydrogen Bonds and Pd-H Bond Acidity in Cationic Palladium(II) Aquo Hydrides and the X-ray Crystal and Molecular Structures of Trans-[(Cy P) Pd(H)(H O)]BF (Cy = cyclohexyl). Organometallics 1991, 10, 1038−1044. (c) Grushin, V. V. Hydrido Complexes of Palladium. Chem. Rev. 1996, 96, 2011−2034. (d) Amatore, C.; Jutand, A.; Meyer, G.; Carelli, I.; Chiarotto, I. Reversible Formation of a Cationic Palladium(II) Hydride [HPd(PPh ) ]<sup>+</sup> in the Oxidative Addition of Acetic or Formic Acid to Palladium(0) in DMF. Eur. J. Inorg. Chem. 2000, 2000, 1855−1859.

(14) (a) Zhu, M.; Wang, P.; Zhang, Q.; Tang, W.; Zi, W. Diastereodivergent Aldol-Type Coupling of Alkoxyallenes with Pentafluorophenyl Esters Enabled by Synergistic Palladium/Chiral Lewis Base Catalysis. Angew. Chem., Int. Ed. 2022, 61, No. e202207621. (b) Wu, Z.; Zhang, M.; Shi, Y.; Huang, G. Mechanism and Origins of Stereo- and Enantioselectivities of Palladium-Catalyzed Hydroamination of Racemic Internal Allenes via Dynamic Kinetic Resolution: A Computational Study. Org. Chem. Front. 2020, 7, 1502−1511.

(15) The low D-incorporation might result from the protonation with trace amounts of water in the system.

(16) (a) Zhang, Q.-L.; Dong, D.-F.; Zi, W.-W. Palladium-Catalyzed Regio- and Enantioselective Hydrosulfonylation of 1,3-Dienes with Sulfinic Acids: Scope, Mechanism, and Origin of Selectivity. J. Am. Chem. Soc. 2020, 142, 15860−15869. (b) Jiu, A. Y.; Slocumb, H. S.; Yeung, C. S.; Yang, X.-H.; Dong, V. M. Enantioselective Addition of Pyrazoles to Dienes. Angew. Chem., Int. Ed. 2021, 60, 19660−19664. (c) Yang, S.-Q.; Han, A.-J.; Liu, Y.; Tang, X.-Y.; Lin, G.-Q.; He, Z.-T. Catalytic Asymmetric Hydroalkoxylation and Formal Hydration and Hydroaminoxylation of Conjugated Dienes. J. Am. Chem. Soc. 2023, 145, 3915−3925. (d) Cheng, L.; Li, M.-M.; Li, M.-L.; Xiao, L.-J.; Xie, J.-H.; Zhou, Q.-L. Nickel-Catalyzed Regio- and Enantioselective Hydroarylation of 1,3-Dienes with Indoles. CCS Chem. 2022, 4, 2612−2619.