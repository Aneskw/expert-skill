![](images/0233380680d9e0a290a6ab39c88d98a1d3dfd4ac8dfbeca6c3d75707920e8ad4.jpg)  
ABSTRACT: The vast majority of transition metal (TM) catalyzed borylative transformations rely on $\mathrm { T M - B } ( \operatorname { s p } ^ { 2 } )$ complexes. Contrastingly, the chemistry $\operatorname { o f } { \dot { \mathrm { T M } } } \mathrm { - B } ( \operatorname { s p } ^ { 3 } )$ species and their potential in catalytic borylation remain surprisingly underdeveloped, due probably to the lack of suitable $\mathsf { b o r o n } ( \mathsf { s p } ^ { 3 } )$ reagents. Herein, we employ our recently developed $\mathsf { s p } ^ { 2 } \mathrm { - } \mathsf { s p } ^ { 3 }$ diboron reagent to successfully enable a copper-catalyzed hydroboration of allenes for $\mathrm { C - B } ( \mathsf { s p } ^ { 3 } )$ bond formation. A comprehensive mechanistic study, including the isolation and structural characterization of $\texttt { a } \mathrm { C u - B } ( \mathrm { s p } ^ { 3 } )$ complex, substantiates the presence of a $\mathrm { C u - B } ( \mathrm { s p } ^ { 3 } )$ intermediate in the catalytic cycle.

pubs.acs.org/JACS

# Copper-Catalyzed C−B(sp<sup>3</sup>) Bond Formation through the Intermediacy of Cu−B(sp<sup>3</sup>) Complex

Zhanqiang $\mathrm { Y e } , ^ { \ S }$ Chun Yin Kwok,<sup>§</sup> Sze Lam Lam, Linlin ${ \mathrm { W u } } , ^ { * }$ and Hairong Lyu\*

![](images/a88030cce852c549ac2c831e9729aeb7baab1e9cb9a387001756c1b06899ccbc.jpg)

Cite This: J. Am. Chem. Soc. 2025, 147, 14915−14923

![](images/beac5e32dce987e7102834cb647263818a904c1cc9ba6b61e9db0aa5935293b4.jpg)

Read Online

ACCESS

Metrics & More

Article Recommendations

![](images/41736ea650b0b37e480571d5525c444c1742049de99ef6779c2341e2c56e81cd.jpg)

\*sı Supporting Information

Scheme 1. Transition-Metal Catalyzed $\mathbf { C } \mathrm { - } \mathbf { B } ( \mathbf { s } \mathbf { p } ^ { 3 } )$ Bond Formation and the Use of $\mathbf { s } \mathbf { p } ^ { 2 } \mathbf { - s } \mathbf { p } ^ { 3 }$ Diboron Reagent in Transition-Metal Catalysis

a. Rh-catalyzed hydroboration of alkene with borane trimethylamine complex

![](images/ba75fd975254e37b4da8fc2c4a2f05282cc93c49850babb141f91616094d3253.jpg)

b. transition-metal catalyzed carbene insertion into B-H bonds

![](images/cf1d51e3ab836348911e566c5dcc3629f9d964f8a077872d4b347f64addfdf59.jpg)

![](images/6530fdc1b7d1e5dd65176781fef5982819f477653b9e76fd5f12f11fbc1555db.jpg)

c. transition-metal catalyzed borylation using Santos' sp²-sp³ diboron reagent

![](images/2500ec72664c47ec100a7a22f1512e9b3c2bd5493d0c551bd1bd833483b56525.jpg)

d. Cu-catalyzed regioselective C-B(sp³) bond formation using (NHC)BH2Bpin through the intermediacy of TM-B(sp³) complex (this work)

• tunable ligand effects • good air/moisture stability

TM-B(sp³) • C(sp²)-B(sp³) formation • good regioselectivity

![](images/4874a41a9b6e43384b265a9559aa69516803e497082ee2bc03ce61f190d44835.jpg)  
(CuBH2L)4, orange crystal

![](images/527c97d4ac4b4a447871064808dd05ce497a6c8d67dec312f848f38a9c5427f6.jpg)  
X-ray structure

O <sup>rganoboron</sup> <sup>compounds</sup> <sup>have</sup> <sup>found</sup> <sup>widespread</sup> <sup>appli-</sup>1 2 cations in synthetic chemistry, biomedicine, and material science.<sup>3</sup> Considerable synthetic methods have been developed to prepare a diverse range of organoboron compounds. Among these methods, C−B bond formation reactions, which ofer a straightforward strategy for directly introducing boron into organic molecules, have been extensively studied over the past decades and led to considerable progress.<sup>4,5</sup> Among all the achievements, transition-metal (TM) catalysis has proved to be one of the irreplaceable strategies due to its versatility in diferent reaction modes, broad substrate compatibility, and excellent selectivity control.<sup>5</sup> This has facilitated the eficient creation of organoboron compounds with diverse structures, thereby enriching the library of organoborons with potential functionalities.

Nevertheless, compared to the extensive reports on $\mathrm { C } -$ $\mathrm { B } \left( \mathrm { s p } ^ { 2 } \right)$ bond formation, transition-metal-catalyzed borylation for the direct incorporation of an $\mathsf { s p } ^ { 3 }$ boron moiety into organic molecules is less explored. On the other hand, as the result of $\mathrm { C - B } ( \mathsf { s p } ^ { 3 } )$ bond construction, four-coordinate organoborons are expected to have better air and moisture stability than their three-coordinate counterparts.<sup>6</sup> For example, some $\mathrm { C - B } ( \mathsf { s p } ^ { 2 } )$ species, such as C2-borylated pyridines and acylboranes,<sup>7</sup> still face stability issues and are often structurally identified by masking with N-methyliminodiacetic acid (MIDA) or converting to borate salts, where the boron center is four-coordinated.<sup>8</sup>

In many transition-metal-mediated/catalyzed borylative reactions, the generation of a metal boryl complex<sup>9</sup> is a key step for transferring boron into substrates. $\mathrm { T M - \bar { B } } ( \mathrm { s p } ^ { 2 } )$ species

![](images/b578676e8bfda5a74864dbcdf8d6fc94e1297473f8f2374cd255c74f31eeabe2.jpg)

## Scheme 2. Efects of $\mathbf { s } \mathbf { p } ^ { 2 } \mathbf { - s } \mathbf { p } ^ { 3 }$ Diboron Reagents and Allenes on Reaction Selectivity

a. evaluation of reactions between allene 1a and different $\mathsf { s p } ^ { 2 } \mathsf { - s p } ^ { 3 }$ diboron reagents

![](images/870041ca637d6f6dd24420f243712fabe66ede7f505703c17e51f0c95ddb70dd.jpg)

b. reaction between allene 1b and diboron reagent 2c under standard conditions  
![](images/eaba1eeeeabda01cf23d04f6e998193fb44b56899de4b699049015a06604d69b.jpg)

are well-documented as key intermediates in some $\mathrm { C - B } ( \mathsf { s p } ^ { 2 } )$ bond construction reactions. $\mathrm { 9 g - m }$ In contrast, the generation or detection of $\mathrm { T M - B } ( \mathrm { s p } ^ { 3 } )$ complexes in borylation reactions remains elusive.<sup>10</sup> The lack of an empty p orbital on $\mathsf { s p } ^ { 3 }$ boron reduces the potential for π-back bonding from metal to boron, leading to a relatively weak $\mathrm { T M - B } ( \mathrm { s p } ^ { 3 } )$ bond.<sup>11</sup> Additionally, suitable boron reagents or precursors for the generation of versatile $\mathrm { T M - B } ( \mathrm { s p } ^ { 3 } )$ species are scarce.

Weller’s early research provides an example of Rh-catalyzed hydroboration of tert-butyl ethene by amine-boranes (Scheme $1 \mathrm { \dot { a } } ) . ^ { 1 2 }$ Although further evidence for Rh−B bond formation is needed, this seminal work supports the theoretical basis for four-coordinate organoboron preparation via metal catalysis.<sup>13</sup> Later, the Curran group and the Zhu and Zhou group independently pioneered the transition-metal-catalyzed carbene insertion into B−H bonds of Lewis base-coordinated boranes (Scheme 1b).<sup>14</sup> Although a $\mathrm { T M - B } ( \mathrm { s p } ^ { 3 } )$ intermediate is not present in the reaction pathway, the research sparks interest in using this approach for $\mathrm { C - B } ( \mathsf { s p } ^ { 3 } )$ bond construction.<sup>15</sup> However, the requirement for diazo compounds or other carbene precursors limits the method’s applicability to other types of organic molecules.

Considering the established methods of producing TM− $\mathrm { B } \big ( \mathrm { s p } ^ { 2 } \big )$ species from diboron reagents such as bis(pinacolato)- diboron $\mathrm { \bar { ( B _ { 2 } p i n _ { 2 } ) } } .$ , we propose employing the $\mathsf { s p } ^ { 2 } \mathrm { - } \mathsf { s p } ^ { 3 }$ diboron reagent as the $\bar { \mathrm { T M } } { - } \mathrm { B } \bar { ( } \mathrm { s p } ^ { 3 } \bar { ) }$ precursor. Among the reported $\mathsf { s p } ^ { 2 } -$ $\mathsf { s p } ^ { 3 }$ diboron reagent, only Santos’ reagent $\mathrm { \Delta P D I P A } ^ { \mathrm { \prime } _ { \mathrm { 1 6 } } }$ and its derivative<sup>17</sup> have been used in transition-metal catalysis as a borylation agent. However, this approach results in the formation of a $\mathrm { T M - B } ( \operatorname { s p } ^ { 2 } )$ intermediate, with the $\mathsf { s p } ^ { 3 }$ boryl being sacrificed during the transmetalation process. Recently, we reported a neutral $\mathsf { \bar { s p } } ^ { 2 } \mathrm { - } \mathsf { s p } ^ { 3 }$ diboron reagent, (I<sup>i</sup>Pr)BH Bpin. This reagent exhibits unique electronic and steric properties and distinct reactivities compared to existing boron reagents. 18 Here, we initiate research on exploring the potential of this neutral $\mathsf { s p } ^ { 2 } \mathsf { - s p } ^ { 3 }$ diboron reagent as a precursor of $\mathrm { T M - B } ( \mathrm { s p } ^ { 3 } )$ species, as well as its efects on the reactivity and selectivity in transition-metal-catalyzed $\mathrm { C - B } ( \mathsf { s p } ^ { 3 } )$ formation reactions (Scheme 1c). After many attempts, a copper-catalyzed hydroboration of allenes with an $\mathsf { s p } ^ { \hat { 2 } } \mathrm { - } \mathsf { s p } ^ { 3 }$ diboron reagent has been achieved. More importantly, the successful isolation and structural characterization of a $\mathrm { { \dot { T } M - B } } ( \mathrm { s p } ^ { 3 } )$ complex evidence a new potential pathway for transition-metal-catalyzed $\mathrm { C } -$ $\mathsf { B } \big ( \mathsf { s p } ^ { 3 } \big )$ formation reactions. The detailed experimental results are compiled in this communication.

To investigate the reactivity and selectivity of the $\mathsf { s p } ^ { 2 } \mathsf { - s p } ^ { 3 }$ diboron reagents in transition-metal catalysis, we conducted its reactions with allenes, which are known for their challenging regioselectivity control in hydroboration reactions.<sup>19</sup> The reaction of $\mathrm { { \dot { s p } } } ^ { 2 } { \cdot } \mathrm { s p } ^ { 3 }$ diboron reagents 2 with 1-phenyl-3- phenethyl-disubstituted allene 1a using copper catalysis was studied. Diferent diboron reagents 2a-2d with various NHCs (NHC = N-heterocyclic carbene) on the $\mathsf { s p } ^ { 3 }$ boron were evaluated (Scheme 2a). Under optimal reaction conditions (for detailed condition screening, see the Supporting Information, Table S1), the reaction of allene 1a with (I<sup>i</sup>Pr)BH Bpin 2c aforded vinyl borane Z-3c in 84% <sup>1</sup>H NMR yield, along with 11% stereoisomer E-3c, resulting in a

## Scheme 3. Mechanistic Study

a. isolation and structural characterization of the Cu-B(sp³) complex

![](images/bf419127056e1b66e239585b83d23aced76313fe06b090a660e1f3b69e2853fe.jpg)

Z/E ratio of around 8/1. When the R group on NHC was replaced by methyl or mesityl groups, both the stereoselectivity and the yield were decreased, leading to a mixture of stereoisomers 3a or 3d. Interestingly, in the reaction with diboron 2b, where the R group on NHC was a cyclohexyl group, another regioisomer 4b was observed alongside expected Z-3b and E-3b. Although further studies are ongoing to understand this unexpected phenomenon, the above results suggest that modifying the structure of the $\mathsf { s p } ^ { 2 } \mathsf { - s p } ^ { 3 }$ diboron reagent can significantly influence the reactivity and selectivity.

Later, we found that replacing the alkyl group on the allene with a bulkier cyclohexyl group improved the Z/E selectivity to ${ > } 2 0 / 1$ (Scheme 2b). Control experiments proved the crucial role of the copper catalyst, the base NaO<sup>t</sup>Bu, and <sup>t</sup>BuOH. Screening of other ligands did not further promote the eficiency and selectivity (Table S3). These results suggest that in addition to the structures of both the allene substrates and boron reagents, the ligands on the metal catalyst also play a role in determining the reaction eficiency and selectivity.

To gain insight into the reaction mechanism and explore the hypothesized $\mathrm { \bar { T } M - B } ( \mathrm { s p } ^ { 3 } )$ species in the reaction pathway, a stoichiometric amount of $\mathbf { S I M e s C u O } ^ { t } \mathbf { B u }$ was reacted with $\mathsf { s p } ^ { 2 } -$ $\mathsf { s p } ^ { 3 }$ diboron ${ \displaystyle 2 \mathbf e } ,$ aiming to aford the key $\mathrm { C u - B } ( \mathrm { s p } ^ { 3 } )$ intermediate. Unexpectedly, an orange crystal was isolated and characterized by X-ray difraction as $\mathrm { C u } { - } \mathrm { B } ( \mathrm { s p } ^ { 3 } )$ complex ${ \mathfrak { s } } ,$ featuring a tetrameric structure. As shown in Scheme 3a, 5 features a nearly square-planar, centro-symmetric, eightmembered $\mathrm { ( C u B ) _ { 4 } }$ ring, with $\mathrm { B - C u - B }$ angle of $1 5 8 . 0 4 ( ^ { \circ } ) ^ { \circ }$ NMR data confirmed the presence of two hydrogen atoms on the $\mathsf { s p } ^ { 3 }$ boron center. Such a tetrameric structure can be found in $\mathrm { { C u } ( I ) - N }$ complexes,<sup>20</sup> while being distinct from the welldocumented monomeric $\mathrm { C u } ( \mathrm { I } ) { - } \mathrm { B } ( \mathrm { s } \mathbf { \bar { p } } ^ { 2 } )$ complexes.<sup>9d</sup> In the tetrameric structure, a bonding picture can be easily deduced. The molecular formula indicates that eight valence electrons are responsible for bonding among the four copper centers and four boron centers. Thus, it is reasonable to assume the presence of four 3-center-2-electron (3c-2e) bonds, with each $\mathrm { C u - B - C u }$ triangle having one such delocalized bond. To support this bonding picture, we carried out fragment-aligned

Table 1. Substrate scope<sup>a</sup>

![](images/7a852edfda6705c665413fb187574a59c031ed65937c513edb41848abf397db6.jpg)  
<sup>a</sup>Reaction conditions: reactions were conducted with 1 (0.10 mmol, 1.0 equiv), 2 (0.15 mmol, 1.5 equiv), IMesCuCl (0.01 mmol, 10 mol %), NaO<sup>t</sup>Bu (0.15 mmol, 1.5 equiv), and <sup>t</sup>BuOH (0.80 mmol, 8.0 equiv) in 1,4-dioxane (2.0 mL) under argon for 16 h. All yields are isolated yields. $^ { b } \mathrm { T h e } \ \mathrm { R } ^ { 2 }$ in allene 1w is a methylbenzoate group.

molecular orbital (FAMO) analysis<sup>21</sup> to obtain the four FAMOs accommodating the eight valence electrons by aligning the occupied canonical molecular orbitals (CMOs) of the tetramer against the occupied fragment CMOs of 4 Cu<sup>+</sup> and 4 $[ \mathrm { H } _ { 2 } \mathrm { B } ( \mathrm { N H C } ) ] ^ { + }$ cations. Then, Pipek-Mezey localization<sup>22</sup> was performed on the four FAMOs, resulting in the formation of four localized 3c-2e bonds, as presented in

Scheme 3b. The Wiberg bond index (WBI) of 5 also supports the idea and is consistent with the crystal structure data (Figure S7). Interestingly, the Cu···Cu distance is 2.4049(6) Å, significantly shorter than the sum of the van der Waals radii of Cu $( 1 . 4 0 \mathrm { ~ \normalfont ~ \AA ~ } ) ^ { 2 3 }$ and also much shorter than cuprophilic interactions observed in other ligand-supported tetrameric

## Scheme 4. Transformations of 3

a. C-B(sp³) bond transformatior  
![](images/378096f0f2d1bf7f0c0545887760e43e1b862cf8b55880c72415449403317639.jpg)

![](images/0b0a7767cd7f86c75b54316ab9a5389a5e1f69cc75f9376acced2e3e2234405d.jpg)

b. synthesis of diborylalkanes via hydroboration of E-3at  
![](images/dc4e4f07d5d9a556308e959f676f69edbafdfef04682c9e02d40dfaa77daa040.jpg)

![](images/1f908f3c2061178fdff3f824309633ff0d8aa87f2ba5ab78fdc04f6f0d17a48c.jpg)

![](images/41a4c89bbd1d82e0844687a1f304f9699536cbe615938a5943f92cfe4f16881e.jpg)

(Cu) complexes,<sup>20</sup> while comparable to those found in related dimeric complexes.<sup>24</sup>

Subsequently, a stoichiometric reaction of complex 5 with allene 1b was carried out in the presence of IMes ligand (Scheme 3c). The borylation products Z-6 and E-6 were obtained in 10% and 4% yields, respectively. The decreased yield and stereoselectivity were likely attributed to the poor stability and solubility of complex 5. When complex 5 was used as the catalyst, along with 10 mol % IMes, the reaction of 1b with diboron 2e underwent smoothly to form Z-6 in 82% yield with a Z/E ratio of 96/4 (Scheme 3d). These results support the involvement of a $\mathrm { C u } { \mathrm { - } } \mathrm { B } ( \mathrm { s p } ^ { 3 } )$ intermediate in the reaction pathway.

A proposed catalytic cycle is illustrated in Scheme 3f $\left( \mathrm { L } _ { \mathrm { M } } = \right.$ ligand on metal; $\mathrm { L _ { B } } = \mathrm { l i g a n d }$ on boron). Transmetalation of $\mathrm { L } _ { \mathrm { M } } \mathrm { C u O }$ <sup>t</sup>Bu with $\mathsf { s p } ^ { 2 } \mathsf { - s p } ^ { 3 }$ diboron initially generates $\mathrm { C u } { - } \mathrm { B } ( \mathrm { s p } ^ { 3 } )$ intermediate IM1. Then the allene undergoes Cu−B bond insertion to form borylcupration intermediate IM2. Finally, $\gamma \mathrm { - }$ protonation of IM2 produces the desired vinyl borane and regenerates the $\mathrm { { C u } ( I ) }$ catalyst. To verify the protonation step, a deuterium experiment was performed using $d _ { 4 } .$ methanol as the proton source, resulting in Z-3e-D in 16% yield and 80% deuterium incorporation at the benzylic position (Scheme 3e).

Subsequently, we examined the scope of diverse $^ { 1 , 3 - }$ disubstituted allenes (Table 1). Allene 1 bearing −F (Z-3f,

$Z \mathbf { - } 3 \mathbf { h } , Z \mathbf { - } 3 \mathbf { k } )$ and −Cl $\left( Z { \cdot } 3 \mathbf { g } , Z { \cdot } 3 \mathbf { i } \right)$ on the phenyl group reacted well with diboron $^ { 2 \mathbf { c } , }$ resulting in $\mathrm { C - B } ( \mathrm { s p } ^ { \bar { 3 } } )$ formation product in high yields $( 7 6 \% \sim 8 9 \% )$ with good stereoselectivity (Z/E > 95/5). The −Br group led to a decrease in both yield and selectivity (Z-3j). Substituents, such as trifluoromethyl (Z-3l to ${ \cal Z } { \cdot } 3 { \bf n } )$ , alkyls $\left( Z { \cdot } 3 p , \ Z { \cdot } 3 { \bf q } , \ Z { \cdot } 3 { \bf u } \right)$ , biphenyl (Z-3r), trifluoromethoxy $\left( Z { \cdot } 3 \mathbf { s } \right)$ , and benzodioxane (Z-3t), were wellcompatiable, afording the desired vinyl boranes in Z/E selectivity larger than 95/5. Slightly decreased selectivity was observed when allenes with electron-donating methoxy groups were used (Z-3o, Z-3v). Both ester and amide groups were tolerated while providing a low yield (Z-3w) or compromised selectivity (Z-3x). In addition, naphthalene- and phenanthrene-derived vinyl boranes $Z \mathbf { - } 3 \mathbf { y }$ and Z-3z were synthesized in 66% and 79% yields, respectively. Besides, heterocycles, such as pyridine (Z-3aa), quinoline (Z-3ab), thiophene $\left( Z { - } 3 { \mathsf { a c } } \right) _ { i }$ benzothiophene (Z-3ad), and carbazole (Z-3ae), were also tolerated with this Cu-catalyzed hydroboration. Additionally, compound Z-3af, derived from drug molecule adapalene, was successfully prepared in 62% yield.

Allenes with various alkyl substituents were also tested. In general, branched alkyls such as <sup>i</sup>Pr and <sup>t</sup>Bu performed better than linear groups (Z-3ag and Z-3ah versus $Z – 3 c$ and Z-3ai) in eficiency and selectivity. Vinyl boranes bearing cycloalkyl groups with diferent ring sizes (Z-3aj to Z-3al) were prepared under the standard conditions. In addition, the piperidine group was well-tolerated, yielding Z-3am stereoselectively. Furthermore, complex substrates derived from drug molecules naproxen and gemfibrozil as well as natural products dehydroabietic acid and lithocholic acid reacted well with 2c to aford derivatives Z-3an to Z-3aq containing the $\mathrm { C - B } ( \mathsf { s p } ^ { 3 } )$ moiety.

It is noteworthy that when using allene 1b with a bulkier cyclohexyl group as the substrate, diboron reagents 2 with various NHC ligands all provided corresponding borylation products with approximately 95/5 Z/E-selectivity (Z-6, Z-3ar, and Z-3as), further highlighting the influence of substrates’ structure on the reaction selectivity (3ar vs 3a, 3as vs 3d). The reaction of 1,3-diphenyl-allene resulted in a diferent selectivity, providing vinyl borane E-3at as the main product.

The newly formed $\mathrm { C - B } ( \mathsf { s p } ^ { 3 } )$ bond in vinyl borane Z-3e underwent further transformations, allowing for the introduction of diverse functional groups including ketones (7), aryls (10), and azides (11). The NHC boryl group in compound Z-3e was readily converted into a more reactive $\mathsf { s p } ^ { 2 }$ boronic ester (9) through a reaction with NCS (N-chlorosuccinimide) followed by hydrolysis. When HCl was used in place of NCS, reduction of compound Z-3e occurred, resulting in the formation of alkyl boronic ester 8 in a high yield (Scheme 4a). This reduction is proposed to proceed via alkene protonation, followed $\boldsymbol { \mathrm { b y } }$ a hydride shift (see Supporting Information for the proposed mechanism), which is supported by deuterium labeling experiments (Scheme 4a, bottom). Furthermore, hydroboration of vinyl borane E-3at led to the introduction of an $\mathsf { s p } ^ { 2 }$ boryl group, afording the diborylalkanes 12 and $_ { 1 2 } \cdot$ as two regioisomers (Scheme 4b). Additionally, the $\mathsf { s p } ^ { 3 }$ boryl can undergo further transformations based on the B− H bond. As shown in Scheme 4c, an eficient hydroboration of styrene using ${ \cal Z } { \cdot } 3 { \bf q }$ and $Z \mathbf { - } 3 \mathbf { e }$ led to the synthesis of difunctionalized four-coordinate boranes 13 and 14, respectively. More importantly, 14 was proved to undergo a Zweifeltype reaction,<sup>25</sup> afording the formal intramolecular C−C bond formation product 15 in 55% yield. This highlights a useful transformation that is not achievable with the Bpin analogues.

In summary, the $\mathsf { s p } ^ { 2 } \mathsf { - s p } ^ { 3 }$ diboron reagent (NHC)BH Bpin has been demonstrated as an $\mathsf { s p } ^ { 3 } .$ -borylation agent in transitionmetal catalysis for the first time. It enables the formation of an unprecedented $\mathrm { C u } { - } \mathrm { B } ( \mathrm { s p } ^ { 3 } )$ tetrameric species featuring the Cu−B−Cu three-center-two-electron bonds, paving a versatile avenue to $\mathrm { C - B } ( \mathrm { s p } ^ { 3 } )$ bond construction and four-coordinate organoboron compound synthesis. Detailed mechanistic studies and DFT calculations are currently underway to gain deeper insight into the selectivity control of $\mathrm { T M - B } ( \mathrm { s p } ^ { 3 } )$ species involved in borylation reactions. Further application of the $\mathsf { s p } ^ { 2 } \mathsf { - s p } ^ { 3 }$ diboron reagent in the borylation of diverse organic molecules and the efects of its structure on reactivity and selectivity are under investigation in our group.

## ■ ASSOCIATED CONTENT

## \*sı Supporting Information

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/jacs.5c00974.

Experimental procedures, characterization data for new compounds, computational details, and NMR spectra (PDF)

X-ray crystallographic information (ZIP)

## Accession Codes

Deposition Numbers 2417675−2417676 contain the supplementary crystallographic data for this paper. These data can be obtained free of charge via the joint Cambridge Crystallographic Data Centre (CCDC) and Fachinformationszentrum Karlsruhe Access Structures service.

## ■ AUTHOR INFORMATION

## Corresponding Authors

Linlin Wu − Hunan Provincial Key Laboratory of Micro & Nano Materials Interfaces Science, College of Chemistry and Chemical Engineering, Central South University, Changsha 410083, P. R. China; Email: chemwll@csu.edu.cn

Hairong Lyu − Department of Chemistry, The Chinese University of Hong Kong, Hong Kong, SAR 999077, P. R. China; orcid.org/0000-0002-0476-0352; Email: hrlyu@ cuhk.edu.hk

## Authors

Zhanqiang Ye − Department of Chemistry, The Chinese University of Hong Kong, Hong Kong, SAR 999077, P. R. China

Chun Yin Kwok − Department of Chemistry, The Chinese University of Hong Kong, Hong Kong, SAR 999077, P. R. China

Sze Lam Lam − Department of Chemistry, The Chinese University of Hong Kong, Hong Kong, SAR 999077, P. R. China

Complete contact information is available at: https://pubs.acs.org/10.1021/jacs.5c00974

## Author Contributions

<sup>§</sup>Zhanqiang Ye and Chun Yin Kwok contributed equally to this work.

## Notes

The authors declare the following competing financial interest(s): A patent application has been filed (applicant: the Chinese University of Hong Kong; name of inventor(s):

Hairong Lyu, Weixuan Sun, Junjie Yang, Xiangyu Lou, Zhanqiang Ye, Hongyi Tao; application number 63/714184; status of application, pending; specific aspect of manuscript covered in patent application, New $\mathsf { s p } ^ { 2 } \mathsf { - s p } ^ { 3 }$ diboron reagents). The remaining authors declare no competing interests.

## ■ ACKNOWLEDGMENTS

The authors acknowledge the research start-up fund (No. 4933621) from the Chinese University of Hong Kong, grants from the Research Grants Council of HKSAR (Nos. 24307423 and 14307424), National Natural Science Foundation of China/RGC Joint Research Scheme (No. N\_CUHK452-24), and support from the State Key Laboratory of Synthetic Chemistry and Croucher Foundation. The authors also thank the Natural Science Foundation of Hunan Province (No. 2024JJ6489) for financial support. We appreciate the insightful and helpful discussions with Prof. Zhenyang Lin and Prof. Yangjian Quan from Hong Kong University of Science and Technology. We thank the resources from the High Performance Computing Center of Central South University. We sincerely thank Dr. Yao Luo and Dr. Siqiang Fang for assistance with manuscript revision. Ms. Hoi Shan Bella Chan is acknowledged for X-ray crystallography. Mr. Hongyi Tao is thanked for checking the experimental procedure. Mr. Hongyi Tao and Mr. Xiangyu Lou are thanked for checking the NMR spectra.

## ■ REFERENCES

(1) (a) Davidson, M. G.; Hughes, A. K.; Marder, T. B.; Wade, K. Organic Contemporary Boron Chemistry; Royal Society of Chemistry, Cambridge, 2000. (b) Ramachandran, P. V. Organoboranes for Syntheses; American Chemical Society: Washington, DC, 2001. (c) Ali, H. A.; Dembitsky, V. M.; Srebnik, M. Contemporary Aspects ofBoron: Chemistry and Biological Applications; Elsevier: Boston, 2005; Vol. 22. (d) Fernández, E.; Whiting, A. Synthesis and Application of Organoboron Compounds; Springer: Berlin, 2015; Vol. 49, p VII, 331. (e) Fyfe, J. W. B.; Watson, A. J. B. Recent Developments in Organoboron Chemistry: Old Dogs, New Tricks. Chem. 2017, 3, 31− 55. (f) Lennox, A. J. J.; Lloyd-Jones, G. C. Selection of Boron Reagents for Suzuki-Miyaura Coupling. Chem. Soc. Rev. 2014, 43, 412−443. (g) Marotta, A.; Adams, C. E.; Molloy, J. J. The Impact of Boron Hybridisation on Photocatalytic Processes. Angew. Chem., Int. Ed. 2022, 61, No. e202207067. (h) Smith, K. Preparation of Organoboranes: Reagents for Organic Synthesis. Chem. Soc. Rev. 1974, 3, 443−465. (i) Suzuki, A. Organoboranes in Organic Syntheses Including Suzuki Coupling Reaction. 2010, 80, 15. (j) Xu, L.; Zhang, S.; Li, P. Boron-Selective Reactions as Powerful Tools for Modular Synthesis of Diverse Complex Molecules. Chem. Soc. Rev. 2015, 44, 8848−8858.

(2) (a) Baker, S. J.; Ding, C. Z.; Akama, T.; Zhang, Y. K.; Hernandez, V.; Xia, Y. Therapeutic Potential of Boron-Containing Compounds. Future Med. Chem. 2009, 1, 1275−1288. (b) Diaz, D. B.; Yudin, A. K. The Versatility of Boron in Biological Target Engagement. Nat. Chem. 2017, 9, 731−742. (c) Marsden, S. Boronic Acids. Preparation, Applications in Organic Synthesis and Medicine. Edited by Dennis G. Hall. Angew. Chem., Int. Ed. 2006, 45, 2005− 2006. (d) Messner, K.; Vuong, B.; Tranmer, G. K. The Boron Advantage: The Evolution and Diversification of Boron’s Applications in Medicinal Chemistry. Pharmaceuticals (Basel) 2022, 15, 264.

(3) (a) Aydin, M. Recent Advances in Boron-Containing Materials; IntechOpen: London, 2020. (b) Cheng, F.; Jäkle, F. Boron-Containing Polymers as Versatile Building Blocks for Functional Nanostructured Materials. Polym. Chem. 2011, 2, 2122−2132. (c) Huang, Z.; Wang, S.; Dewhurst, R. D.; Ignat’ev, N. V.; Finze, M.; Braunschweig, H. Boron: Its Role in Energy-Related Processes and Applications. Angew. Chem., Int. Ed. 2020, 59, 8800−8816. (d) Ji,

L.; Griesbeck, S.; Marder, T. B. Recent Developments in and Perspectives on Three-Coordinate Boron Materials: a Bright Future. Chem. Sci. 2017, 8, 846−863.

(4) For selected reviews, see: (a) Collins, B. S. L.; Wilson, C. M.; Myers, E. L.; Aggarwal, V. K. Asymmetric Synthesis of Secondary and Tertiary Boronic Esters. Angew. Chem., Int. Ed. 2017, 56, 11700− 11733. (b) Cuenca, A. B.; Shishido, R.; Ito, H.; Fernández, E. Transition-Metal-Free B-B and B-Interelement Reactions with Organic Molecules. Chem. Soc. Rev. 2017, 46, 415−430. (c) Hartwig, J. F. Borylation and Silylation of C−H bonds: a Platform for Diverse C−H Bond Functionalizations. Acc. Chem. Res. 2012, 45, 864−873. (d) Iqbal, S. A.; Pahl, J.; Yuan, K.; Ingleson, M. J. Intramolecular (Directed) Electrophilic C−H Borylation. Chem. Soc. Rev. 2020, 49, 4564−4591. (e) Kubota, K.; Iwamoto, H.; Ito, H. Formal Nucleophilic Borylation and Borylative Cyclization of Organic Halides. Org. Biomol. Chem. 2017, 15, 285−300. (f) Matteson, D. S.; Collins, B. S. L.; Aggarwal, V. K.; Ciganek, E. The Matteson Reaction. Org. React. 2021, 105, 427−860. (g) Peng, T.-Y.; Zhang, F.- L.; Wang, Y.-F. Lewis Base-Boryl Radicals Enabled Borylation Reactions and Selective Activation of Carbon−Heteroatom Bonds. Acc. Chem. Res. 2023, 56, 169−186. (h) Rej, S.; Chatani, N. Regioselective Transition-Metal-Free C(sp<sup>2</sup>)−H Borylation: A Subject of Practical and Ongoing Interest in Synthetic Organic Chemistry. Angew. Chem., Int. Ed. 2022, 61, No. e202209539. (i) Ros, A.; Fernández, R.; Lassaletta, J. M. Functional Group Directed C−H Borylation. Chem. Soc. Rev. 2014, 43, 3229−3243. (j) Wang, M.; Shi, Z. Methodologies and Strategies for Selective Borylation of C−Het and C−C Bonds. Chem. Rev. 2020, 120, 7348−7398. (k) Wang, X.; Wang, Y.; Huang, W.; Xia, C.; Wu, L. Direct Synthesis of Multi(boronate) Esters from Alkenes and Alkynes via Hydroboration and Boration Reactions. ACS Catal. 2021, 11, 1−18. (l) Zweifel, G.; Brown, H. C. Hydration of Olefins, Dienes, and Acetylenes via Hydroboration. Org. React. 1963, 13, 1.

(5) For selected reviews of transition metal catalyzed borylation reactions, see: (a) Chow, W. K.; Yuen, O. Y.; Choy, P. Y.; So, C. M.; Lau, C. P.; Wong, W. T.; Kwong, F. Y. A Decade Advancement of Transition Metal-Catalyzed Borylation of Aryl Halides and Sulfonates. RSC Adv. 2013, 3, 12518−12539. (b) Crudden, C. M.; Edwards, D. Catalytic Asymmetric Hydroboration: Recent Advances and Applications in Carbon−Carbon Bond-Forming Reactions. Eur. J. Org. Chem. 2003, 2003, 4695−4712. (c) Geier, S. J.; Vogels, C. M.; Melanson, J. A.; Westcott, S. A. The Transition Metal-Catalysed Hydroboration Reaction. Chem. Soc. Rev. 2022, 51, 8877−8922. (d) Hassan, M. M. M.; Guria, S.; Dey, S.; Das, J.; Chattopadhyay, B. Transition Metal-Catalyzed Remote C−H Borylation: An Emerging Synthetic Tool. Sci. Adv. 2023, 9, 3311. (e) Hu, J.; Ferger, M.; Shi, Z.; Marder, T. B. Recent Advances in Asymmetric Borylation by Transition Metal Catalysis. Chem. Soc. Rev. 2021, 50, 13129−13188. (f) Li, B.; Liang, H.; Vignesh, A.; Zhou, X.; Liu, Y.; Ke, Z. Updated Progress of the Copper-Catalyzed Borylative Functionalization of Unsaturated Molecules. Molecules 2023, 28, 2252. (g) Magre, M.; Szewczyk, M.; Rueping, M. s-Block Metal Catalysts for the Hydroboration of Unsaturated Bonds. Chem. Rev. 2022, 122, 8261−8312. (h) Obligacion, J. V.; Chirik, P. J. Earth-Abundant Transition Metal Catalysts for Alkene Hydrosilylation and Hydroboration: Opportunities and Assessments. Nat. Rev. Chem. 2018, 2, 15−34. (i) Yang, X.; Ge, S. Recent Progress in Cobalt-Catalyzed Enantioselective Hydrogenation and Hydroboration Reactions of Alkenes. Curr. Opin. Green Sustain. Chem. 2021, 31, 100542. (j) Yoshida, H. Borylation of Alkynes under Base/Coinage Metal Catalysis: Some Recent Developments. ACS Catal. 2016, 6, 1799−1811. (k) Yu, I. F.; Wilson, J. W.; Hartwig, J. F. Transition-Metal-Catalyzed Silylation and Borylation of C−H Bonds for the Synthesis and Functionalization of Complex Molecules. Chem. Rev. 2023, 123, 11619−11663.

(6) (a) Curran, D. P.; Solovyev, A.; Makhlouf Brahmi, M.; Fensterbank, L.; Malacria, M.; Lacote, E. Synthesis and Reactions of N-heterocyclic Carbene Noranes. Angew. Chem., Int. Ed. 2011, 50, 10294−10317. (b) Guo, Y.; Zu, B.; Du Chen, C.; He, C. Boron-Stereogenic Compounds: Synthetic Developments and Opportunities.

Chin. J. Chem. 2024, 42, 2401−2411. (c) Staubitz, A.; Robertson, A. P. M.; Sloan, M. E.; Manners, I. Amine- and Phosphine-Borane Adducts: New Interest in Old Molecules. Chem. Rev. 2010, 110, 4023−4078. (d) Taniguchi, T. Substituent Effects of Tetracoordinate Boron in Organic Synthesis. Chem.-Eur. J. 2022, 28, No. e202104333. (e) Zhang, X.; Wang, S.; Jiang, Z.; Li, Y.; Jing, X. Boronic Ester Based Vitrimers with Enhanced Stability via Internal Boron-Nitrogen Coordination. J. Am. Chem. Soc. 2020, 142, 21852−21860.

(7) (a) Cook, X. A. F.; de Gombert, A.; McKnight, J.; Pantaine, L. R. E.; Willis, M. C. The 2-Pyridyl Problem: Challenging Nucleophiles in Cross-Coupling Arylations. Angew. Chem., Int. Ed. 2021, 60, 11068− 11091. (b) Scharnagl, F. K.; Bose, S. K.; Marder, T. B. Acylboranes: Synthetic Strategies and Applications. Org. Biomol. Chem. 2017, 15, 1738−1752. (c) Wu, D.; Taguchi, J.; Tanriver, M.; Bode, J. W. Synthesis of Acylboron Compounds. Angew. Chem., Int. Ed. 2020, 59, 16847−16858.

(8) (a) Dick, G. R.; Woerly, E. M.; Burke, M. D. A General Solution for the 2-Pyridyl Problem. Angew. Chem., Int. Ed. 2012, 51, 2667− 2672. (b) Eghbarieh, N.; Hanania, N.; Masarwa, A. Stereodefined Polymetalloid Alkenes Synthesis via Stereoselective Boron-Masking of Polyborylated Alkenes. Nat. Commun. 2023, 14, 2022. (c) Molander, G. A.; Sandrock, D. L. Potassium Trifluoroborate Salts as Convenient, Stable Reagents for Difficult Alkyl Transfers. Curr. Opin Drug Discov Devel 2009, 12, 811−823. (d) Noda, H.; Bode, J. W. Synthesis and Chemoselective Ligations of MIDA Acylboronates with O-Me Hydroxylamines. Chem. Sci. 2014, 5, 4328−4332. (e) Noguchi, H.; Hojo, K.; Suginome, M. Boron-Masking Strategy for the Selective Synthesis of Oligoarenes via Iterative Suzuki−Miyaura Coupling. J. Am. Chem. Soc. 2007, 129, 758−759.

(9) For selected reviews and examples of metal boryl complexes, see: (a) Braunschweig, H. Transition Metal Complexes of Boron. Angew. Chem., Int. Ed. 1998, 37, 1786−1801. (b) Kaur, U.; Saha, K.; Gayen, S.; Ghosh, S. Contemporary Developments in Transition Metal Boryl Complexes: An overview. Coord. Chem. Rev. 2021, 446, 214106. (c) Nöth, H.; Schmid, G. Synthesis of Compounds with Covalent Metal−Boron Bonds. Angew. Chem., Int. Ed. 1963, 2, 623−623. (d) Laitar, D. S.; Müller, P.; Sadighi, J. P. Efficient Homogeneous Catalysis in the Reduction of CO to CO. J. Am. Chem. Soc. 2005, 127, 17196−17197. (e) Segawa, Y.; Yamashita, M.; Nozaki, K. Boryl Anion Attacks Transition-Metal Chlorides To Form Boryl Complexes: Syntheses, Spectroscopic, and Structural Studies on Group 11 Borylmetal Complexes. Angew. Chem., Int. Ed. 2007, 46, 6710−6713. (f) Lin, T.-P.; Peters, J. C. Boryl−Metal Bonds Facilitate Cobalt/ Nickel-Catalyzed Olefin Hydrogenation. J. Am. Chem. Soc. 2014, 136, 13672−13683. For selected reviews and examples of TM-B(sp<sup>2</sup>) complexes in borylation reactions, see: (g) Iverson, C. N.; Smith, M. R. Stoichiometric and Catalytic B−C Bond Formation from Unactivated Hydrocarbons and Boranes. J. Am. Chem. Soc. 1999, 121, 7696−7697. (h) Sagawa, T.; Asano, Y.; Ozawa, F. Synthesis and Reactions of cis-Silyl(boryl)platinum(II) Complexes. Organometallics 2002, 21, 5879−5886. (i) Teltewskoi, M.; Panetier, J. A.; Macgregor, S. A.; Braun, T. A Highly Reactive Rhodium(I)-Boryl Complex as a Useful Tool for C−H Bond Activation and Catalytic C−F Bond Borylation. Angew. Chem., Int. Ed. 2010, 49, 3947−3951. (j) Tsuji, Y.; Fujihara, T. Copper-Catalyzed Transformations Using Cu−H, Cu−B, and Cu−Si as Active Catalyst Species. Chem. Rec. 2016, 16, 2294− 2313. (k) Waltz, K. M.; Hartwig, J. F. Selective Functionalization of Alkanes by Transition-Metal Boryl Complexes. Science 1997, 277, 211−213. (l) Yun, J. Copper(I)-Catalyzed Boron Addition Reactions of Alkynes with Diboron Reagents. Asian J. Org. Chem. 2013, 2, 1016−1025. (m) Takahashi, K.; Ishiyama, T.; Miyaura, N. A borylcopper Species Generated from Bis(pinacolato)diboron and its Additions to α,β-Unsaturated Carbonyl Compounds and Terminal Alkynes. J. Organomet. Chem. 2001, 625, 47−53.

(10) For selected reviews and examples of TM-B(sp<sup>3</sup>) complexes (not presented in borylation reactions), see: (a) Böser, R.; Haufe, L. C.; Freytag, M.; Jones, P. G.; Hörner, G.; Frank, R. Completing the Series of Boron-Nucleophilic Cyanoborates: Boryl Anions of Type NHC−B(CN) <sup>−</sup>. Chem. Sci. 2017, 8, 6274−6280. (b) Braunschweig,

H.; Kollann, C.; Rais, D. Transition-Metal Complexes of Boron� New Insights and Novel Coordination Modes. Angew. Chem., Int. Ed. 2006, 45, 5254−5274. (c) Elliot, D. J.; Levy, C. J.; Puddephatt, R. J.; Holah, D. G.; Hughes, A. N.; Magnuson, V. R.; Moser, I. M. A Bridged Cobaltaborane Complex: the First Structural Characterization of a Transition Metal−BH Bond. Inorg. Chem. 1990, 29, 5014−5015. (d) Ruiz, D. A.; Ung, G.; Melaimi, M.; Bertrand, G. Deprotonation of a Borohydride: Synthesis of a Carbene-Stabilized Boryl Anion. Angew. Chem., Int. Ed. 2013, 52, 7590−7592. (e) Yasue, T.; Kawano, Y.; Shimoi, M. Proton-Induced Change of the Coordination Mode of a Boron Group: Boryl Complexes [Mn-$\left( \mathrm { C O } \right) _ { 4 } \left( \mathrm { P R } _ { 3 } \right) \left( \mathrm { B H } _ { 2 } { \cdot } \mathrm { P M e } _ { 3 } \right) ]$ and Cationic Borane σ Complexes [Mn-$( \mathrm { C O } ) _ { 4 } ( \mathrm { P R } _ { 3 } ^ { - } ) ( \eta ^ { \mathrm { 1 } } { \cdot } \mathrm { B H } _ { 3 } { \cdot } \mathrm { P } \dot { \mathrm { M e } } _ { 3 } ) ]$ . Angew. Chem., Int. Ed. 2003, 42, 1727− 1730.

(11) Guo, X.; Yang, T.; Sheong, F. K.; Lin, Z. Beyond the Nucleophilic Role of Metal−Boryl Complexes in Borylation Reactions. ACS Catal. 2021, 11, 5061−5068.

(12) Sewell, L. J.; Chaplin, A. B.; Weller, A. S. Hydroboration of an Alkene by Amine-Boranes Catalysed by a $[ \mathrm { R h } ( \mathrm { P R } _ { 3 } ) _ { 2 } ] ^ { + }$ Fragment. Mechanistic Insight and Tandem Hydroboration/Dehydrogenation. Dalton Trans. 2011, 40, 7499−7501.

(13) (a) Tang, Q.; Li, S.-J.; Ye, X.; Yuan, T.; Zhao, K.; He, Y.; Shan, C.; Wojtas, L.; Richardson, D.; Lan, Y.; Shi, X. Design and Synthesis of Stable Four-Coordinated Benzotriazole-Borane with Tunable Fluorescence Emission. Chem. Sci. 2022, 13, 5982−5987.

(b) Toure, M.; Chuzel, O.; Parrain, J.-L. Asymmetric Rhodium-Directed anti-Markovnikov Regioselective Boracyclopentannulation. J. Am. Chem. Soc. 2012, 134, 17892−17895.

(14) (a) Li, X.; Curran, D. P. Insertion of Reactive Rhodium Carbenes into Boron-Hydrogen Bonds of Stable N-Heterocyclic Carbene Boranes. J. Am. Chem. Soc. 2013, 135, 12076−12081. (b) Cheng, Q.-Q.; Zhu, S.-F.; Zhang, Y.-Z.; Xie, X.-L.; Zhou, $\mathrm { Q . ^ { - I } }$ Copper-Catalyzed B−H Bond Insertion Reaction: A Highly Efficient and Enantioselective C−B Bond-Forming Reaction with Amine-Borane and Phosphine-Borane Adducts. J. Am. Chem. Soc. 2013, 135, 14094−14097.

(15) (a) Chen, D.; Zhang, X.; Qi, W.-Y.; Xu, B.; Xu, M.-H. Rhodium(I)-Catalyzed Asymmetric Carbene Insertion into B−H Bonds: Highly Enantioselective Access to Functionalized Organoboranes. J. Am. Chem. Soc. 2015, 137, 5268−5271. (b) Huang, M.-Y.; Zhu, S.-F. Uncommon Carbene Insertion Reactions. Chem. Sci. 2021, 12, 15790−15801. (c) Kan, S. B. J.; Huang, X.; Gumulya, Y.; Chen, K.; Arnold, F. H. Genetically Programmed Chiral Organoborane Synthesis. Nature 2017, 552, 132−136. (d) Zhang, G.; Zhang, Z.; Hou, M.; Cai, X.; Yang, K.; Yu, P.; Song, Q. Construction of Boron-Stereogenic Compounds via Enantioselective Cu-Catalyzed Desymmetric B-H Bond Insertion Reaction. Nat. Commun. 2022, 13, 2624. (e) Zhao, X.; Wang, G.; Hashmi, A. S. K. Carbene B−H Insertion Reactions for C−B Bond Formation. ChemCatChem. 2021, 13, 4299− 4312.

(16) Gao, M.; Thorpe, S. B.; Santos, W. L. sp<sup>2</sup>-sp<sup>3</sup> Hybridized Mixed Diboron: Synthesis, Characterization, and Copper-Catalyzed $\beta \mathrm { - }$ Boration of $\alpha { , } \beta { - }$ Unsaturated Conjugated Compounds. Org. Lett. 2009, 11, 3478−3481.

(17) Smith, J. R.; Collins, B. S. L.; Hesse, M. J.; Graham, M. A.; Myers, E. L.; Aggarwal, V. K. Enantioselective Rhodium(III)- Catalyzed Markovnikov Hydroboration of Unactivated Terminal Alkenes. J. Am. Chem. Soc. 2017, 139, 9148−9151.

(18) Lou, X.; Lin, J.; Kwok, C. Y.; Lyu, H. Stereoselective Unsymmetrical 1,1-Diborylation of Alkynes with a Neutral $\mathsf { s p } ^ { 2 } \mathsf { - s p } ^ { 3 }$ Diboron Reagent. Angew. Chem., Int. Ed. 2023, 62, No. e202312633.

(19) For selected reviews and examples, see: (a) Burks, H. E.; Liu, S.; Morken, J. P. Development, Mechanism, and Scope of the Palladium-Catalyzed Enantioselective Allene Diboration. J. Am. Chem. Soc. 2007, 129, 8766−8773. (b) Chen, M.; Roush, W. R. Enantioconvergent Hydroboration of a Racemic Allene: Enantioselective Synthesis of (E)-δ-Stannyl-anti-homoallylic Alcohols via Aldehyde Crotylboration. J. Am. Chem. Soc. 2011, 133, 5744−5747. (c) Jang, H.; Jung, B.; Hoveyda, A. H. Catalytic Enantioselective

Protoboration of Disubstituted Allenes. Access to Alkenylboron Compounds in High Enantiomeric Purity. Org. Lett. 2014, 16, 4658− 4661. (d) Lei, Y.; Kong, Y.; Rong, $Z . - \mathrm { { Q } . ; }$ Zhao, W. Asymmetric Dihydroboration of Allenes Enabled by Ligand Relay Catalysis. Nat. Commun. 2024, 15, 8186. (e) Li, C.; Yang, Z.; Wang, L.; Guo, Y.; Huang, Z.; Ma, S. Cobalt-Catalyzed Regio- and Stereoselective Hydroboration of Allenes. Angew. Chem., Int. Ed. 2020, 59, 6278− 6283. (f) Li, Z.; Zhang, L.; Nishiura, M.; Luo, G.; Luo, Y.; Hou, Z. Enantioselective Cyanoborylation of Allenes by N-Heterocyclic Carbene-Copper Catalysts. ACS Catal. 2020, 10, 11685−11692. (g) Meng, F.; McGrath, K. P.; Hoveyda, A. H. Multifunctional Organoboron Compounds for Scalable Natural Product Synthesis. Nature 2014, 513, 367−374. (h) Nagashima, Y.; Sasaki, K.; Suto, T.; Sato, T.; Chida, N. Stereodivergent Hydroboration of Allenes. Chem.- Asian J. 2018, 13, 1024−1028. (i) Ozawa, Y.; Endo, K.; Ito, H. Regio and Stereoselective Synthesis of Multi-Alkylated Allylic Boronates through Three-Component Coupling Reactions between Allenes, Alkyl Halides, and a Diboron Reagent. J. Am. Chem. Soc. 2021, 143, 13865−13877. (j) Thorpe, S. B.; Guo, X.; Santos, W. L. Regio- and Stereoselective Copper-Catalyzed β-Borylation of Allenoates by a Preactivated Diboron. Chem. Commun. 2011, 47, 424−426. (k) Wu, C.; Ge, S. Ligand-Controlled Cobalt-Catalyzed Regiodivergent Hydroboration of Aryl, Alkyl-Disubstituted Internal Allenes. Chem. Sci. 2020, 11, 2783−2789. (l) Yang, X.; Yuan, C.; Ge, S. Ligand Enabled Stereodivergence in Nickel-Catalyzed Regioselective Hydroboration of Internal Allenes. Chem. 2023, 9, 198−215. (m) Yang, Y.; Zeng, J.-H.; Zhan, Z.-P. Regio-Divergent Hydroboration of Terminal Allenes Controlled by Nickel and Cobalt Catalysts. Org. Chem. Front. 2021, 8, 2537−2542. (n) Yuan, W.; Ma, S. Ligand Controlled Highly Selective Copper-Catalyzed Borylcuprations of Allenes with Bis-(pinacolato)diboron. Adv. Synth. Catal. 2012, 354, 1867−1872. (o) Zhou, Y.; You, W.; Smith, K. B.; Brown, M. K. Copper-Catalyzed Cross-Coupling of Boronic Esters with Aryl Iodides and Application to the Carboboration of Alkynes and Allenes. Angew. Chem., Int. Ed. 2014, 53, 3475−3479. (p) Hu, H.; Ji, G.-C.; Jiang, L.; Bi, S.; Jiang, Y.- Y.; Liu, Y. Ligand-Controlled Regiodivergent Cyanoboration of Internal Allenes by Copper Catalysis. Angew. Chem., Int. Ed. 2022, 61, No. e202210338. (q) Semba, K.; Fujihara, T.; Terao, J.; Tsuji, Y. Copper-Catalyzed Borylation of α-Alkoxy Allenes with Bis-(pinacolato)diboron: Efficient Synthesis of 2-Boryl 1,3-Butadienes. Angew. Chem., Int. Ed. 2013, 52, 12400−12403. (r) Yeung, K.; Ruscoe, R. E.; Rae, J.; Pulis, A. P.; Procter, D. J. Enantioselective Generation of Adjacent Stereocenters in a Copper-Catalyzed Three Component Coupling of Imines, Allenes, and Diboranes. Angew. Chem., Int. Ed. 2016, 55, 11912−11916.

(20) (a) Hartmann, E.; Strähle, J. Synthese und Struktur von 1,3- Bis(4-trifluormethylphenyl)triazenido-Komplexen des Kupfer(I) und Silber(I)/Synthesis and Structure of 1,3-Bis(4-trifluormethylphenyl)- triazenido Complexes of Copper(I) and Silver(I). Z. Naturforsch. B 1988, 43, 818−824. (b) Hartmann, E.; Strähle, J. 1,3-Bis(4- fluorphenyl)triazenido-Komplexe von Kupfer und Silber. Synthese und Kristallstruktur von $[ \mathrm { C u ( F - C _ { 6 } H _ { 4 } N _ { 3 } C _ { 6 } H _ { 4 } - F ) } ] _ { 4 } , ~ [ \mathrm { A g ( F - }$ $\begin{array} { r l } { \mathrm { ~ C } _ { 6 } \mathrm { H } _ { 4 } \mathrm { N } _ { 3 } \mathrm { C } _ { 6 } \mathrm { H } _ { 4 } \mathrm { - F } ) ] . } \end{array}$ und $\big [ \mathrm { C u } \big ( \mathrm { F } { - } \mathrm { C } _ { 6 } \mathrm { H } _ { 4 } \mathrm { N } _ { 3 } \mathrm { C } _ { 6 } \mathrm { H } _ { 4 } { - } \mathrm { F } \big ) \big ( \mathrm { O C H } _ { 3 } \big ) \big ] _ { 4 } ^ { \circ } . ~ \mathrm { Z } .$ Anorg. Allg. Chem. 1990, 583, 31−40. (c) Jiang, X.; Bollinger, J. C.; Baik, M.-H.; Lee, D. Copper Clusters Built on Bulky Amidinate Ligands: Spin Delocalization via Superexchange Rather Than Direct Metal−Metal Bonding. Chem. Commun. 2005, 1043−1045. (d) Osei, M. K.; Mirzaei, S.; Bogetti, X.; Castro, E.; Rahman, M. $\mathbf { A } . ;$ Saxena, S.; Hernández Sánchez, R. Synthesis of Square Planar Cu4 Clusters. Angew. Chem., Int. Ed. 2022, 61, No. e202209529. (e) Robinson, T. P.; Price, R. D.; Davidson, M. G.; Fox, M. A.; Johnson, A. L. Why are the $\{ \mathrm { C u _ { 4 } N _ { 4 } } \}$ Rings in Copper(I) Phosphinimide Clusters $[ \mathrm { C u } \{ \mu { \bf - N } =$ PR }] (R = NMe or Ph) Planar? Dalton Trans. 2015, 44, 5611− 5619.

(21) Sheong, F. K.; Zhang, J.-X.; Lin, Z. Fragment Aligned Molecular Orbital Analysis: An Innovative Tool for Analyzing Atypical Chemical Bonding. J. Chem. Theory Comput. 2024, 20, 6569−6577.

(22) Pipek, J.; Mezey, P. G. A Fast Intrinsic Localization Procedure Applicable for Ab Initio and Semiempirical Linear Combination of Atomic Orbital Wave Functions. J. Chem. Phys. 1989, 90, 4916−4926.

(23) Bondi, A. van der Waals Volumes and Radii. J. Phys. Chem. A 1964, 68, 441−451.

(24) Johnson, A. L.; Willcocks, A. M.; Richards, S. P. Synthesis and Structures of Group 11 Metal Triazenide Complexes: Ligand Supported Metallophilic Interactions. Inorg. Chem. 2009, 48, 8613− 8622.

(25) (a) Zweifel, G.; Arzoumanian, H.; Whitney, C. C. A Convenient Stereoselective Synthesis of Substituted Alkenes via Hydroboration-Iodination of Alkynes. J. Am. Chem. Soc. 1967, 89, 3652−3653. (b) Brown, H. C.; Iyer, R. R.; Mahindroo, V. K.; Bhat, N. G. Chiral Synthesis via Organoboranes. 31. A Simple Synthesis of Enantiomerically Pure (Z)- and (E)-Alkenes, (Z)-RCH = CHR\* and (E)-RCH = CHR. Tetrahedron: Asymmetry 1991, 2, 277−286.