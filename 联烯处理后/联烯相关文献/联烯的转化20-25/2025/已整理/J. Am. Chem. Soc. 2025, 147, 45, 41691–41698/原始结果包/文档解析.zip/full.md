pubs.acs.org/JACS

Article

# Copper-Catalyzed Enantioselective Synthesis of N‑Heterocycle-Substituted Quaternary Carbon Stereogenic Centers

Minjeong Seo and Hyunwoo Kim\*

![](images/75beb55037fc9fae842c6d6a537edbfecfeb9556cde5a001f65b8a0f0c0eac1c.jpg)

Cite This: J. Am. Chem. Soc. 2025, 147, 41691−41698

![](images/4682ae6669890f1ddb49edc6e76a660f230aaa3f28adc0aee384d46b8adbada6.jpg)

Read Online

## ACCESS

Metrics & More

ABSTRACT: The enantioselective construction of all-carbon quaternary stereogenic centers adjacent to N-heterocycles remains a long-standing challenge in asymmetric catalysis. Herein we report a copper-catalyzed enantioselective hydropyridylation of 1,1- disubstituted allenes with 2-halopyridines that proceeds via a nucleophilic aromatic substitution $( S _ { \mathrm { { N } } } \mathbf { A r } )$ pathway. This transformation enables the eficient synthesis of α-quaternary Nheterocyclic compounds with a broad substrate scope in high yields (up to 96%) with excellent enantioselectivities (up to 99% ee). The methodology is compatible with various functional groups and N-heterocycles and can be extended to copper-catalyzed ee). The methodology is compatible with various functional groups boropyridylation, afording versatile alkenylboronates. Mechanistic studies, including deuterium labeling, kinetic isotope efect analysis, and DFT calculations, support a 2,3-hydrocupration followed by a stereodetermining S Ar step. This strategy provides a analysis, and DFT calculations, support a 2,3-hydrocupration follow practical and general approach for constructing structurally diverse azaarene-containing quaternary centers, which are potentially valuable for drug dis

Article Recommendations

\*sı Supporting Information

![](images/cef885db7ab095805cae60318adc1efbb6318a3a66f71bc9c3895a44fec8ed2e.jpg)  
valuable for drug discovery and development.

## ■ INTRODUCTION

N-Heterocyclic compounds in which an N-heterocycle is attached to a quaternary stereogenic carbon center represent privileged structural motifs that are widely distributed in biologically active natural products and serve as key pharmacophores in medicinal chemistry (Figure 1a).<sup>1</sup> The construction of such architecturally complex motifs is of considerable synthetic importance, as the introduction of a quaternary carbon stereocenter adjacent to a nitrogencontaining heterocycle imparts significant conformational rigidity and can markedly influence the biological and physicochemical properties of the resulting molecules. Over the past few decades, substantial eforts have been devoted to the development of eficient and stereoselective methods for accessing these challenging stereocenters.

Among the established strategies, stereospecific crosscoupling reactions using enantioenriched substrates<sup>2−5</sup> as well as α-functionalization of prochiral compounds containing azaarene motifs<sup>6,7</sup> have emerged as efective tools. However, these methodologies often exhibit limitations with respect to substrate scope, particularly in accommodating diverse heterocyclic frameworks, and tend to require multistep preparation of the starting materials or stoichiometric chiral auxiliaries (Figure 1b, left). In this context, asymmetric transition metal catalysis has provided a robust platform to address the inherent challenges associated with the formation of all-carbon quaternary stereocenters adjacent to nitrogen atoms. In particular, nickel-catalyzed asymmetric heteroaryla tion has been reported as a promising strategy for the stereoselective α-functionalization of azaarenes.<sup>8</sup> Despite its efectiveness, this approach typically requires high reaction temperatures and is predominantly limited to substrates with preassembled cyclic backbones, thereby restricting structural diversification (Figure 1b, right).

Alternatively, copper catalysis has emerged as a sustainable and cost-efective approach to asymmetric catalysis. Recent advances have showcased the potential of copper-catalyzed transformations involving π-unsaturated systems�such as alkenes, dienes, and allenes�for the construction of quaternary carbon stereocenters.<sup>9</sup> In our previous work, we explored copper-catalyzed diene functionalization;<sup>10</sup> however, steric congestion around the reaction site impeded the formation of quaternary centers.<sup>11</sup> Allenes, by contrast, have shown considerable promise in copper-catalyzed coupling reactions with carbonyl and imine electrophiles, enabling the formation of fully substituted carbon centers under mild conditions.<sup>9c,12</sup> Nevertheless, despite their synthetic potential, the application of allene-based methodologies to azaarenederived substrates remains scarcely explored, with only a single report to date describing a limited example involving indazole derivatives<sup>13</sup> (Figure 1c).

![](images/5263fbabdb40d053bb35d463a67faf6cc65a3b749592c6e4af8ab2b5002f8aab.jpg)

![](images/189d7883159984dfb6649092605241dbd0ce4312ceadfcddf8028f067489b1f7.jpg)  
Figure 1. Previous work on the construction of quaternary stereogenic centers containing an N-heterocycle.

Motivated by these findings, we envisioned a new approach that would enable the stereoselective construction of α- quaternary N-heterocycles through copper-catalyzed allene functionalization. Central to our design is the innate coordinating ability of the nitrogen atom within the azaarene ring, which we anticipated could serve to both activate the substrate and direct the catalytic transformation with high regio- and stereocontrol. Herein we report the development of a copper-catalyzed stereoselective synthesis of N-heterocyclic compounds bearing an all-carbon quaternary stereogenic center through the regio- and stereocontrolled functionalization of allenes. This transformation not only expands the synthetic utility of copper catalysis in constructing highly congested stereocenters but also ofers a general and eficient route to structurally diverse azaarene derivatives that may be of value in drug discovery and related fields.

## ■ RESULTS AND DISCUSSION

We initiated our investigation of copper-catalyzed hydropyridylation using 1-phenyl-1-methylallene (1a) and 2- fluoropyridine (2a) in the presence of CuOAc (4 mol %), (S,S)-Ph-BPE (4.4 mol %), NaOTMS (2.0 equiv), and Ph SiH (2.0 equiv) in THF at room temperature for 16 h. Screening a series of chiral phosphine ligands�including (S,S)-Ph-BPE, (R)-p-Tol-BINAP, and (R)-SEGPHOS�yielded the desired product 3a in 76%, 31%, and 68% yield with 94%, 64%, and 44% enantiomeric excess (ee), respectively (Table 1, entries 1−

Table 1. Reaction Optimization<sup>a</sup>
<table><tr><td></td><td><img src="images/0d9bebfed60a92f71d278780f802b7bff979b6aed782e6c5832092f048886e47.jpg"/></td><td colspan="2"></td><td></td></tr><tr><td>entry</td><td>ligande</td><td>silane</td><td>X yield (%)b</td><td>ee (%)c</td></tr><tr><td>1 2</td><td>(S,S)-Ph-BPE</td><td>Ph3SiH</td><td>F</td><td>94</td></tr><tr><td></td><td>(R)-Tol-BINAP</td><td>Ph3SiH</td><td>F</td><td>76 31</td></tr><tr><td>3</td><td>(R)-SEGPHOS</td><td>Ph3SiH</td><td>F</td><td>64 68 44</td></tr><tr><td>4</td><td>(S,S)-Ph-BPE</td><td>Ph2MeSiH</td><td>F</td><td>77 94</td></tr><tr><td>5</td><td>(S,S)-Ph-BPE</td><td>PhMe2SiH</td><td>F</td><td>75 93</td></tr><tr><td>6</td><td>(S,S)-Ph-BPE</td><td>(EtO)₂MeSiH</td><td>F</td><td>88</td></tr><tr><td> $7 ^ { d }$ </td><td>(S,S)-Ph-BPE</td><td>Ph2MeSiH</td><td>F</td><td>33</td></tr><tr><td> $8 ^ { d }$ </td><td>(S,S)-Ph-BPE</td><td>Ph2MeSiH</td><td>Cl</td><td>86 73</td></tr><tr><td> $9 ^ { d }$ </td><td>(S,S)-Ph-BPE</td><td>Ph2MeSiH</td><td>Br</td><td>70</td></tr><tr><td> $1 0 ^ { d }$ </td><td>(S,S)-Ph-BPE</td><td>Ph2MeSiH</td><td>I</td><td>60</td></tr><tr><td>ªReactions were performed with 1a (0.2 mmol), 2a (0.6 mmol),</td><td></td><td></td><td></td><td></td></tr></table>

3). Among these, (S,S)-Ph-BPE aforded the highest yield and enantioselectivity. Replacing $\mathrm { P h } _ { 3 } \mathrm { S i H }$ with Ph MeSiH slightly improved the yield to 77%, whereas use of (EtO) MeSiH resulted in a markedly diminished yield (33%) and reduced enantioselectivity (88% ee), accompanied by the formation of 2-ethoxypyridine as a side product (Table 1, entries 4-6; see Table S2). Notably, switching the solvent to 1,4-dioxane led to an increased yield of 86% (Table 1, entry 7). To evaluate the influence of the leaving group on the pyridine electrophile, various 2-halopyridines were examined. While the enantioselectivity remained largely consistent, a decreasing trend in yield was observed in the order $\mathbf { I } > \mathbf { B } \mathbf { r } > \mathbf { C } \mathbf { l }$ , which may correlate with increasing steric hindrance of the halogen substituents (Table 1, entries 8−10). Despite the reduced reactivity with bulkier halides, the reactions proceeded with moderate eficiency (60−73% yield), suggesting the broader applicability of this method to a range of azaarene substrates.

We next investigated the substrate scope of the reaction under the optimized conditions, beginning with a series of allene derivatives (Scheme 1). The position of the substituents on the aryl moiety of the allenes was found to exert a pronounced influence on the reactivity and enantioselectivity. When the substituent was located at the ortho position (3b), significant steric hindrance during the hydrocupration step led to diminished reactivity (56% yield, 81% ee), in contrast to the meta- (3c, 83% yield, 97% ee) and para-substituted analogues (3d, 93% yield, 97% ee). The reaction proceeded eficiently with a variety of functional groups, afording excellent yields (up to 95%) and enantioselectivities (up to 98% ee) for substrates bearing either electron-withdrawing substituents, such as halogens (3b−3e), or electron-donating groups,

## Scheme 1. Allene Substrate Scope<sup>a</sup>

![](images/cb4d47cf890ff6a60031187bea1210a6d8433b4b21e78c57d810c441df60e0fa.jpg)  
<sup>a</sup>Reaction conditions: 1 (0.2 mmol), 2a (0.6 mmol), CuOAc (4 mol %), (S,S)-Ph-BPE (4.4 mol %), NaOTMS (0.4 mmol), and Ph MeSiH (0.4 mmol) in 1,4-dioxane (0.1 mL) at rt for 16 h. Isolated yields are shown. Enantiomeric excess was determined by HPLC. <sup>b</sup>The reaction was carried out $\mathrm { a t } - 1 0 \ ^ { \circ } \mathrm { C }$ for 24 h. <sup>c</sup>The reaction was carried out at 45 °C for 24 h.

including alkyl (3f, 3g) and alkoxy groups (3h, 3i). A naphthylsubstituted allene aforded the desired product 3j in 76% yield with 97% ee. An exocyclic allene also proved to be compatible, delivering the product 3k in 70% yield with 90% ee.

Extension of the alkyl chain length on the allene (3l−3n) resulted in slightly reduced yields (60−70%), while the enantioselectivity remained consistently high (94−97% ee). In the case of a monosubstituted allene, β-hydride elimination led to the formation of trisubstituted alkene byproducts. Performing the reaction at $- 1 0 \mathrm { ~ \\ } ^ { \circ } \mathrm { C }$ suppressed this side reaction, enabling the formation of the desired product 3o bearing a tertiary stereogenic center in moderate yield and enantioselectivity (55% yield, 87% ee; see Table S5). A dialkylsubstituted allene displayed low reactivity, likely due to its reduced nucleophilicity. Increasing the reaction temperature to 45 °C improved the conversion, afording the product 3p in moderate yield (55%) and enantioselectivity (86% ee) (see Table S6).

We subsequently examined the scope of pyridine substrates amenable to the reaction conditions (Scheme 2). Substituents at the 3-, 4-, and 5-positions of the pyridine ring were welltolerated, afording the corresponding products 4a−4c in moderate to good yields (62−88%) with high enantioselectivities (93−96% ee). In contrast, 2,6-difluoropyridine delivered the monofunctionalized product 4d in high yield (80%) but with markedly reduced enantioselectivity (61% ee). Moreover,

## Scheme 2. N-Heterocycle Substrate Scope<sup>a</sup>

![](images/a4b21426d0e5555ec5b334f1792c73b977b2f2aa5818ec6e6fee32d61aa20fcf.jpg)  
<sup>a</sup>Reaction conditions: 1a (0.2 mmol), 2 (0.6 mmol), CuOAc (4 mol %), (S,S)-Ph-BPE (4.4 mol %), NaOTMS (0.4 mmol), and Ph MeSiH (0.4 mmol) in 1,4-dioxane (0.1 mL) at rt for 16 h. Isolated yields are shown. Enantiomeric excess was determined by HPLC. <sup>b</sup>Enantiomeric excess was determined by <sup>1</sup>H NMR with NMR shift reagents.

2-fluoro-6-methylpyridine gave the product 4e in a similarly high yield (70%) but with even poorer enantioselectivity (35% ee). While substitution at the 3- or 5-position maintained a high ee, substitution at the sterically demanding 6-position consistently diminished it. This decrease became more pronounced as the size of the 6-substituent increased, suggesting that the steric congestion at this position interferes with the pyridine insertion step.<sup>10</sup> The reaction exhibited

Scheme 3. Gram-Scale Synthesis and Application of Products

![](images/2e0098362457b76344c04e0db349627ababeb35dd8072efce48167a00cbe62c7.jpg)  
<sup>a</sup>Isolated yields are shown. Enantiomeric excess was determined by HPLC.

## Scheme 5. Mechanistic Experiments

![](images/7a072348fab7400de6ebbbe8dedf3e3ae35c85fda40507c1e5b7720e5268ee87.jpg)

broad functional group tolerance, accommodating halogen, alkyl, and alkoxy substituents, which furnished the desired products (4f−4k) in up to 95% yield with up to 98% ee. A variety of 5-substituted pyridines�including those with methyl, halogens, and trifluoromethyl substituents�were also compatible, providing the corresponding products 4l−4o in good yields (72−85%) with high enantioselectivities (90− 95% ee). Although ethyl 6-chloronicotinate yielded the product 4p in high yield (80%), it exhibited low enantioselectivity (61% ee), presumably because the ester group interfered with efective coordination between the pyridine nitrogen and the copper catalyst.

We further evaluated the applicability of this method to other nitrogen-containing heterocycles. Isoquinoline, pyrazine, and pyrimidine substrates all underwent the transformation smoothly, afording the corresponding products 4q−4s in good yields (72−86%) with excellent enantioselectivities (93− 99% ee). Benzimidazole and benzothiazole derivatives also participated efectively, delivering the desired products 4t−4w in high yields (56−96%). However, these substrates exhibited slightly diminished enantioselectivities (73−84% ee), possibly due to increased steric hindrance around the reactive site. Notably, 2-bromothiazole furnished the product 4x in good yield (69%) with excellent enantioselectivity (97% ee).

To further demonstrate the functional group compatibility of this methodology, the reaction was applied to pyridine substrates bearing complex natural-product-derived moieties, including estrone and menthol. In line with previous observations for ester-containing pyridines (e.g., 4p), the estrone-derived substrate aforded the desired product 4y in 82% yield but with diminished enantioselectivity (61% ee). In contrast, the menthol-derived substrate delivered the product 4z in 60% yield with high enantioselectivity (95% ee).

We next assessed the scalability of the reaction under the optimized conditions (Scheme 3a). The desired product 3a was successfully synthesized on a gram scale, afording 1.27 g of material with excellent enantioselectivity (96% ee). Given the synthetic versatility of the pyridine moiety bearing a terminal alkene, further functionalization of 3a was explored (Scheme 3b). Hydrogenation and hydroboration−oxidation of

∆G (kcal/mol)

![](images/1f9a2215e5604bbc5769bbea73fa522e79766f930c53213a34bf01934b000811.jpg)  
Figure 2. (a) Energy profile of the total reaction pathway. Transition states marked \* were not located explicitly but were estimated. (b) Four transition states of the pyridine insertion step. All energies are in kcal/mol with respect to $\mathrm { L } ^ { \ast } \mathrm { C u H } ,$ 1a, and 2a. DFT calculations were performed at the B3LYP-D3/SDD-6-311+G(d,p)/SMD(1,4-dioxane)//B3LYP-D3/LANL2DZ-6-31G(d,p) level of theory (see the Supporting Information for details).

the terminal alkene provided the corresponding saturated (5a) and alcohol (5b) derivatives, respectively, both in good yields with retention of enantioselectivity. Heck coupling furnished the internal alkene product 5c with moderate stereoselectivity $\left( E { : } Z ~ = ~ 3 . 6 { : } 1 \right)$ while maintaining high enantioselectivity. Rhodium-catalyzed hydroformylation yielded the corresponding aldehyde 5d in 76% yield with 96% ee. In addition, the halide functionality was exploited in a Suzuki cross-coupling of 4m, afording the coupled product 5e in 75% yield with 95% $e e ,$ with no erosion of enantioselectivity. Finally, hydroamination of ${ \mathbf { 3 0 } } ,$ which bears both a tertiary stereogenic center and a terminal alkene, aforded the antihistamine drug pheniramine (5f) in 70% yield with moderate enantioselectivity (87% ee) (Scheme 3c).<sup>14</sup>

Our strategy was also applicable to the boropyridylation of allenes (Scheme 4). Under conditions analogous to those used for hydropyridylation�replacing $\mathrm { P h } _ { 2 } \mathrm { M e S i H }$ with $\mathrm { B } _ { 2 } \mathrm { n e o p } _ { 2 } -$ alkenylboron-containing products were obtained (see Tables $S 7 { - } S 9 )$ . In contrast, the use of $\mathsf { B } _ { 2 } \mathsf { p i n } _ { 2 }$ or $\mathsf { B } _ { 2 } \mathsf { c a t } _ { 2 }$ did not yield the desired products. CuOAc and 1,4-dioxane were identified as the optimal catalyst and solvent combination. Subsequent oxidation or bromination of the resulting boronates furnished ketone products (6a−6g) and an alkenyl bromide (7a), each bearing a quaternary stereogenic center, in moderate yields (41−53%) with good enantioselectivity (80−95% ee)

Next, we conducted a series of mechanistic studies to gain insight into the reaction mechanism (Scheme 5). When Ph MeSiD was used in place of Ph MeSiH, the deuterated product 3a-d was obtained in 84% NMR yield with 99% deuterium incorporation (Scheme 5a). The deuterium was incorporated at C2 of the allene, consistent with a 1,2- hydrocupration pathway, as previously reported.<sup>12,13</sup> A kinetic isotope efect (KIE) experiment revealed a KIE value of 1.79, indicating that either the silane or copper hydride is involved in the rate-determining step (Scheme 5b). Further initial rate kinetic studies confirmed that both the copper and silane contribute to the rate-determining step, supporting that copper hydride generation is turnover-limiting (Scheme 5c).<sup>10,15</sup>

To investigate the origin of the enantioselectivity, we performed density functional theory (DFT) calculations. The proposed mechanism involves a sequence of hydrocupration, isomerization, and nucleophilic aromatic substitution (Figure 2a). Consistent with previously reported pathways,<sup>12b,13</sup> the reaction proceeds via a 2,3-hydrocupration pathway to generate intermediate (Z)-Cu-2a (see Figure S9 and S10). The transition state leading to (Z)-Cu-2a is at least 1 kcal/mol lower in energy than any other 1,2- or 2,3-hydrocupration transition state, indicating its kinetic favorability. Although halopyridines are known to engage in oxidative addition with transition metals,<sup>8,16</sup> our calculations revealed that the oxidative addition pathway involving 2-fluoropyridine has a prohibitively high activation barrier of 59.7 kcal/mol from the (S)-Cu-2b intermediate, efectively ruling out this pathway.

Following hydrocupration, 1,3-allylic rearrangement of (Z)- Cu-2a leads to the formation of multiple intermediates: (Z)- Cu-2a, (E)-Cu-2a, (R)-Cu-2b, and (S)-Cu-2b. Based on the observed stereochemical outcome of product 3a, the $\mathrm { S _ { N } A r }$ pathways involving (R)-Cu-2b and (S)-Cu-2b were excluded. When (Z)-Cu-2a and (E)-Cu-2a engage in S Ar with 2- fluoropyridine, four possible transition states (TS-2a−TS-2d) can be considered, leading to either (S)-3a or (R)-3a. Among these, transition state TS-2a, derived from (E)-Cu-2a, was calculated to be the most favorable, with an energy of −9.4 kcal/mol. This is significantly lower than those of TS-2b (−4.3 kcal/mol), TS-2c (−6.7 kcal/mol), and TS-2d (0.0 kcal/mol). Accordingly, the (E)-Cu-2a intermediate undergoes S Ar through TS-2a to furnish the product (S)-3a (Figure 2b). In TS-2a, steric repulsions between the ligand and substrate are minimized, and an additional stabilizing C−H···π interaction is observed,<sup>17</sup> contributing to its favorable energetics. In contrast, TS-2b, TS-2c, and TS-2d all sufer from significant steric repulsion, making them less favorable (Figure 2b).

## ■ CONCLUSION

In summary, we have developed a copper-catalyzed enantioselective strategy for the construction of all-carbon quaternary stereogenic centers adjacent to N-heterocycles via the hydropyridylation of 1,1-disubstituted allenes. This transformation proceeds under mild conditions with broad functional group tolerance and delivers a wide array of Nheterocycle-substituted products in high yields with excellent enantioselectivities (up to 99% ee). The methodology was further extended to copper-catalyzed boropyridylation, enabling access to synthetically versatile alkenylboronates that can be readily transformed into ketones, alcohols, or halogenated derivatives without erosion of the enantioselectivity. Gram-scale synthesis and derivatizations�including hydrogenation, hydroboration−oxidation, hydroformylation, and hydroamination�underscore the robustness and synthetic utility of this platform.

Mechanistic studies, including deuterium-labeling studies, kinetic isotope efect measurements, and initial rate kinetic experiments, indicate that copper hydride formation is turnover-limiting. DFT calculations support a reaction pathway involving regioselective 2,3-hydrocupration followed by a stereodefining nucleophilic aromatic substitution $( S _ { \mathrm { { N } } } \mathbf { A r } )$ step. The origin of enantioselectivity is attributed to favorable noncovalent interactions and minimized steric repulsion in the key transition state. Together, these findings establish a robust platform for the synthesis of highly congested azaarene architectures and open new avenues for asymmetric catalysis via nucleophilic aromatic substitution.

## ■ ASSOCIATED CONTENT

## \*sı Supporting Information

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/jacs.5c13377.

Detailed experimental procedures, spectral data, and analytical data (PDF)

## Accession Codes

Deposition number 2370657 contains the supplementary crystallographic data for this paper. These data can be obtained free of charge via the joint Cambridge Crystallographic Data Centre (CCDC) and Fachinformationszentrum Karlsruhe Access Structures service.

## ■ AUTHOR INFORMATION

## Corresponding Author

Hyunwoo Kim − Department of Chemistry, Korea Advanced Institute of Science and Technology (KAIST), Daejeon 34141, Korea; orcid.org/0000-0001-5030-9610; Email: hwkim@kaist.edu

## Author

Minjeong Seo − Department of Chemistry, Korea Advanced Institute of Science and Technology (KAIST), Daejeon 34141, Korea

Complete contact information is available at: https://pubs.acs.org/10.1021/jacs.5c13377

## Notes

The authors declare no competing financial interest.

## ■ ACKNOWLEDGMENTS

This work was funded by the following (to H.K.): National Research Foundation of Korea (NRF) Grants RS-2023- 00219859 and RS-2024-00356952 and the KAIST Grand Challenge 30 Project (KC30) in 2025 (N11250034).

## ■ REFERENCES

(1) (a) Dwivedi, A. R.; Jaiswal, S.; Kukkar, D.; Kumar, R.; Singh, T. G.; Singh, M. P.; Gaidhane, A. M.; Lakhanpal, S.; Prasad, K. N.; Kumar, B. A decade of pyridine-containing heterocycles in US FDA approved drugs: a medicinal chemistry-based analysis. RSC Med. Chem. 2025, 16, 12−36. (b) Marshall, C. M.; Federice, J. G.; Bell, C. N.; Cox, P. B.; Njardarson, J. T. An Update on the Nitrogen Heterocycle Compositions and Properties of U.S. FDA-Approved

Pharmaceuticals (2013−2023). J. Med. Chem. 2024, 67, 11622− 11655.

(2) For reviews of stereospecific coupling, see: (a) Xue, W.; Jia, X.; Wang, X.; Tao, X.; Yin, Z.; Gong, H. Nickel-catalyzed formation of quaternary carbon centers using tertiary alkyl electrophiles. Chem. Soc. Rev. 2021, 50, 4162−4184. (b) Pound, S. M.; Watson, M. P. Asymmetric synthesis via stereospecific C-N and C-O bond activation of alkyl amine and alcohol derivatives. Chem. Commun. 2018, 54, 12286−12301. (c) Rygus, J. P. G.; Crudden, C. M. Enantiospecific and Iterative Suzuki-Miyaura Cross-Couplings. J. Am. Chem. Soc. 2017, 139 (50), 18124−18137. (d) Leonori, D.; Aggarwal, V. K. Stereospecific couplings of secondary and tertiary boronic esters. Angew. Chem., Int. Ed. 2015, 54, 1082−1096.

(3) Odachowski, M.; Bonet, A.; Essafi, S.; Conti-Ramsden, P.; Harvey, J. N.; Leonori, D.; Aggarwal, V. K. Development of Enantiospecific Coupling of Secondary and Tertiary Boronic Esters with Aromatic Compounds. J. Am. Chem. Soc. 2016, 138 (30), 9521− 9532.

(4) (a) Rani, S.; Dash, S. R.; Bera, A.; Alam, M. N.; Vanka, K.; Maity, P. Phosphite mediated asymmetric N to C migration for the synthesis of chiral heterocycles from primary amines. Chem. Sci. 2021, 12, 8996−9003. (b) Motaleb, A.; Rani, S.; Das, T.; Gonnade, R. G.; Maity, P. Phosphite-Catalyzed C-H Allylation of Azaarenes via an Enantioselective [2,3]-Aza-Wittig Rearrangement. Angew. Chem., Int. Ed. 2019, 58, 14104−14109.

(5) Potter, B.; Edelstein, E. K.; Morken, J. P. Modular, Catalytic Enantioselective Construction of Quaternary Carbon Stereocenters by Sequential Cross-Coupling Reactions. Org. Lett. 2016, 18, 3286− 3289.

(6) For selected examples in organocatalysis, see: (a) Fu, Q.; Cao, S.; Wang, J.; Lv, X.; Wang, H.; Zhao, X.; Jiang, Z. Enantioselective [2π+2σ] Cycloadditions of Bicyclo[1.1.0]butanes with Vinylazaarenes through Asymmetric Photoredox Catalysis. J. Am. Chem. Soc. 2024, 146, 8372−8380. (b) Tian, D.; Shi, W.; Sun, X.; Zhao, X.; Yin, Y.; Jiang, Z. Catalytic asymmetric [4 + 2] dearomative photocycloadditions of anthracene and its derivatives with alkenylazaarenes. Nat. Commun. 2024, 15, No. 4563. (c) Wei, W.; Li, C.; Fan, Y.; Chen, X.; Zhao, X.; Qiao, B.; Jiang, Z. Catalytic Asymmetric Redox-Neutral [3 + 2] Photocycloadditions of Cyclopropyl Ketones with Vinylazaarenes Enabled by Consecutive Photoinduced Electron Transfer. Angew. Chem., Int. Ed. 2024, 63, No. e202406845. (d) Yin, Y.; Li, Y.; Goncalves, T. P.; Zhan, Q.; Wang, G.; Zhao, X.; Qiao, B.; Huang, K. W.; Jiang, Z. All-Carbon Quaternary Stereocenters alpha to Azaarenes via Radical-Based Asymmetric Olefin Difunctionalization. J. Am. Chem. Soc. 2020, 142, 19451−19456. (e) Izquierdo, J.; Landa, A.; Bastida, I.; Lopez, R.; Oiarbide, M.; Palomo, C. Base-Catalyzed Asymmetric alpha-Functionalization of 2-(Cyanomethyl)azaarene N-Oxides Leading to Quaternary Stereocenters. J. Am. Chem. Soc. 2016, 138, 3282−3285.

(7) For selected examples in transition metal catalysis, see: (a) Tian, K.; Jin, Z.; Liu, X. L.; He, L.; Liu, H. F.; Yu, P. K.; Chang, X.; Dong, X. Q.; Wang, C. J. Stereodivergent assembly of delta-valerolactones with an azaarene-containing quaternary stereocenter enabled by Cu/Ru relay catalysis. Chem. Sci. 2025, 16, 1233−1240. (b) Song, G.; Sun, R.; Liu, X.; Sa, Y.; Yang, M.; Kong, D. Stereodivergent Ruthenium/ Copper Relay Catalysis for Modular Access to delta-Lactones with Two Nonadjacent Carbon Stereocenters. Org. Lett. 2025, 27, 4859− 4864. (c) Wang, Z.-Q.; Liu, Z.-C.; Huang, X.; Yin, L. Construction of halogenated tetrasubstituted carbon centers through copper(I)- catalyzed asymmetric alkylation of 2-azaarylesters. Cell Rep. Phys. Sci. 2024, 5, No. 101822. (d) Chang, X.; Zhang, J.; Cheng, X.; Lv, X.; Guo, C. Ni/Cu Dual-Catalyzed Propargylation for the Stereodivergent Synthesis of Methohexital. Adv. Sci. 2024, 11, No. 2406764. (e) He, Z. T.; Jiang, X.; Hartwig, J. F. Stereodivergent Construction of Tertiary Fluorides in Vicinal Stereogenic Pairs by Allylic Substitution with Iridium and Copper Catalysts. J. Am. Chem. Soc. 2019, 141, 13066−13073.

(8) (a) Gu, X.; Liu, K.; Yang, L.; Xie, C.; Li, M.; Wang, J. J. Nickelcatalyzed enantioselective alpha-heteroarylation of ketones via C-F

bond activation to construct all-carbon quaternary stereocenters. Chem. Sci. 2022, 13, 12498−12502. (b) Ge, S.; Hartwig, J. F. Nickelcatalyzed asymmetric alpha-arylation and heteroarylation of ketones with chloroarenes: effect of halide on selectivity, oxidation state, and room-temperature reactions. J. Am. Chem. Soc. 2011, 133, 16330− 16333.

(9) For selected reviews and examples, see: (a) Li, B.-J.; Sun, X. Acyclic Quaternary Carbon Stereocenters through Transition-Metal-Catalyzed Enantioselective Functionalization of Unsaturated Hydrocarbons. Synthesis 2022, 54, 2103−2118. (b) Blieck, R.; Taillefer, M.; Monnier, F. Metal-Catalyzed Intermolecular Hydrofunctionalization of Allenes: Easy Access to Allylic Structures via the Selective Formation of C-N, C-C, and C-O Bonds. Chem. Rev. 2020, 120, 13545−13598. (c) Pulis, A. P.; Yeung, K.; Procter, D. J. Enantioselective copper catalysed, direct functionalisation of allenes via allyl copper intermediates. Chem. Sci. 2017, 8, 5240−5247. (d) Ren, K.; Yuan, R.; Gui, Y.-Y.; Chen, X.-W.; Min, S.-Y.; Wang, B.- Q.; Yu, D.-G. Cu-catalyzed reductive aminomethylation of 1,3-dienes with N,O-acetals: facile construction of β-chiral amines with quaternary stereocenters. Org. Chem. Front. 2023, 10, 467−472. (e) Knippel, J. L.; Ye, Y.; Buchwald, S. L. Enantioselective C2- Allylation of Benzimidazoles Using 1,3-Diene Pronucleophiles. Org. Lett. 2021, 23, 2153−2157.

(10) Seo, M.; Seo, S.; Jung, J.; Kim, H. Copper-Catalyzed Regioselective and Enantioselective Hydropyridylation of Dienes for the Synthesis of Chiral Diaryl Compounds via Concerted Nucleophilic Aromatic Substitution. Angew. Chem., Int. Ed. 2025, 64, No. e202420918.

(11) (E)-Penta-2,4-dien-2-ylbenzene aforded the product in 3% yield. DFT calculations revealed that the S Ar transition state containing two axial substituents is 5.5 kcal/mol higher in energy than the corresponding transition state involving (E)-buta-1,3-dien-1- ylbenzene (see Figures S1 and S12)

(12) For selected examples of allene functionalization, see: (a) Feng, S.; Buchwald, S. L. CuH-Catalyzed Regio- and Enantioselective Hydrocarboxylation of Allenes: Toward Carboxylic Acids with Acyclic Quaternary Centers. J. Am. Chem. Soc. 2021, 143, 4935−4941.

(c) Han, J.; Zhou, W.; Zhang, P.-C.; Wang, H.; Zhang, R.; Wu, H.- H.; Zhang, J. Design and Synthesis of WJ-Phos, and Application in Cu-Catalyzed Enantioselective Boroacylation of 1,1-Disubstituted Allenes. ACS Catal. 2019, 9, 6890−6895. (d) Qiu, J.; Gao, S.; Li, C.; Zhang, L.; Wang, Z.; Wang, X.; Ding, K. Construction of All-Carbon Chiral Quaternary Centers through Cu<sup>I</sup>-Catalyzed Enantioselective Reductive Hydroxymethylation of 1,1-Disubstituted Allenes with CO . Chem.�Eur. J. 2019, 25, 13874−13878. (e) Rae, J.; Yeung, K.; McDouall, J. J.; Procter, D. J. Copper-Catalyzed Borylative Cross-Coupling of Allenes and Imines: Selective Three-Component Assembly of Branched Homoallyl Amines. Angew. Chem., Int. Ed. 2016, 55, 1102−1107.

(13) Ye, Y.; Kevlishvili, I.; Feng, S.; Liu, P.; Buchwald, S. L. Highly Enantioselective Synthesis of Indazoles with a C3-Quaternary Chiral Center Using CuH Catalysis. J. Am. Chem. Soc. 2020, 142, 10550− 10556.

(14) For selected examples of previous multistep synthetic approaches to pheniramine, see: (a) Zhu, S.; Qin, J.; Wang, F.; Li, H.; Chu, L. Photoredox-catalyzed branch-selective pyridylation of alkenes for the expedient synthesis of Triprolidine. Nat. Commun. 2019, 10, No. 749. (b) Yin, Y.; Dai, Y.; Jia, H.; Li, J.; Bu, L.; Qiao, B.; Zhao, X.; Jiang, Z. Conjugate Addition-Enantioselective Protonation of N-Aryl Glycines to α-Branched 2-Vinylazaarenes via Cooperative Photoredox and Asymmetric Catalysis. J. Am. Chem. Soc. 2018, 140, 6083−6087. (c) Paul, B.; Shee, S.; Panja, D.; Chakrabarti, K.; Kundu, S. Direct Synthesis of N,N-Dimethylated and β-Methyl N,N-Dimethylated Amines from Nitriles Using Methanol: Experimental and Computational Studies. ACS Catal. 2018, 8, 2890−2896. (d) Prat, L.; Dupas, G.; Duflos, J.; Quéguiner, G.; Bourguignon, J.;

Levacher, V. Deracemization of alkyl diarylmethanes using (−)-sparteine or a chiral proton source. Tetrahedron Lett. 2001, 42, 4515− 4518. (e) Botteghi, C.; Chelucci, G.; Del Ponte, G.; Marchetti, M.; Paganelli, S. New Synthetic Route to Pheniramines via Hydroformylation of Functionalyzed Olefins. J. Org. Chem. 1994, 59, 7125− 7127. (f) Botteghi, C.; Del Ponte, G.; Marchetti, C. Synthesis of an optically active pheniramine by enantioselective hydrogenation catalyzed by BINAP-ruthenium(II) compelxes. J. Mol. Catal. 1993, 83, L1−L4.

(15) (a) Wang, Y.; Yin, J.; Li, Y.; Yuan, X.; Xiong, T.; Zhang, Q. Copper-Catalyzed Asymmetric Conjugate Addition of Alkene-Derived Nucleophiles to Alkenyl-Substituted Heteroarenes. ACS Catal. 2022, 12, 9611−9620. (b) Xi, Y.; Hartwig, J. F. Mechanistic Studies of Copper-Catalyzed Asymmetric Hydroboration of Alkenes. J. Am. Chem. Soc. 2017, 139, 12758−12772.

(16) (a) Lu, J.; Schley, N. D.; Paci, I.; Leitch, D. C. Mechanisms and Site Selectivity of (Het)Ar−X Oxidative Addition to Pd(0) Are Controlled by Frontier Molecular Orbital Symmetry. Organometallics 2024, 43, 3192−3203. (b) Blackburn, J. M.; Roizen, J. L. Catalytic Strategies to Convert 2-Halopyridines to 2-Alkylpyridines. Asian J. Org. Chem. 2019, 8, 920−930. (c) Yuan, C.; Zhang, L.; Zhao, Y. Cu(II)-Catalyzed C-N Coupling of (Hetero)aryl Halides and N-Nucleophiles Promoted by α-Benzoin Oxime. Molecules 2019, 24, No. 4177. (d) Kortman, G. D.; Hull, K. L. Copper-Catalyzed Hydroarylation of Internal Alkynes: Highly Regio- and Diastereoselective Synthesis of 1,1-Diaryl, Trisubstituted Olefins. ACS Catal. 2017, 7, 6220−6224.

(17) (a) Li, J. F.; Pan, D.; Wang, H. R.; Zhang, T.; Li, Y.; Huang, G.; Ye, M. Enantioselective C2-H Alkylation of Pyridines with 1,3-Dienes via Ni-Al Bimetallic Catalysis. J. Am. Chem. Soc. 2022, 144, 18810− 18816. (b) Krenske, E. H.; Houk, K. N. Aromatic Interactions as Control Elements in Stereoselective Organic Reactions. Acc. Chem. Res. 2013, 46, 979−989.

![](images/f4caf5177d441609e015987ff26de4eeea447c704e2efac06bcf0e2d0d6ad234.jpg)

CAS BIOFINDER DISCOVERY PLATFORMTM

# BRIDGE BIOLOGY AND CHEMISTRY FOR FASTER ANSWERS

Analyze target relationships, compound effects, and disease pathways

Explore the platform