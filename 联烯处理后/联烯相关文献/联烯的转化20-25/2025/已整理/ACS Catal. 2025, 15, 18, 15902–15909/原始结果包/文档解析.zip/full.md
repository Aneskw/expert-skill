![](images/3cc43caaa0b7267660a3a0f49aeca246104aa04b93572678598ca6eab2763318.jpg)

pubs.acs.org/acscatalysis

# Regio- and Stereoselectivities for Alkylation and Boronization of Allenes through Metal−Support Electron Interactions of Single-Atom Catalysts

Shicheng Ren,<sup>∥</sup> Song Lin,<sup>∥</sup> Zeyu Ren, Yang Li, Quanzhou He, Mao-Rui Wang, Fei-Hu Cui, Wen-Hao Li, Hai-Tao Tang,\* and Ying-Ming Pan\*

![](images/226ab2ab3b435d4a380ed230496a5cb5b329a200acd21f75a173c5e052626c66.jpg)

Cite This: ACS Catal. 2025, 15, 15902−15909

![](images/585502e0f83b3b22f065ffc07c7516640d822a59c7e29bc3686edd043d0ed89f.jpg)

Read Online

ACCESS

Metrics & More

Article Recommendations

\*sı Supporting Information

ABSTRACT: In synthetic chemistry, controlling the regio- and stereoselectivities, especially nontraditional selectivities, of multicomponent tandem reactions has always been challenging. In organic reactions, single-atom catalysts (SACs) possess fixed coordination structures and adjustable metal−support interactions and frequently generate products possessing well-defined regio- and stereoselectivities. Herein, a silicon carbide (SiC)-supported copper SAC (CuCl @O−SiC) was synthesized using increased copper content and the interaction between the metal support and SiC was regulated through oxygen-based surface modification. Allenes underwent nontraditional β,γ-addition, exclusively generating Z-configured alkylboronization products. These findings revealed the β,γ-selectivity pattern in

![](images/c518aafbab0e1c6c5925252033082e9ca03f832df6532594d3d8150de4a0a6cc.jpg)

allene addition reactions, which advances the application of SACs in chemical catalysis. This work ofers the potential for further developments in selective synthesis.

KEYWORDS: regio- and stereoselectivities addition, allenes, carboboration, silicon carbide support, β,γ-addition, single-atom catalysts

## ■ INTRODUCTION

Even for experienced synthetic chemists, rapid, eficient, and cost-efective synthesis of structurally simple multisubstituted olefins remains challenging;<sup>1−4</sup> however, multicomponent synthesis holds tremendous promise for synthesizing multi substituted olefins.<sup>5−7</sup> Nevertheless, the simultaneous integration of diverse substrates within a single step inevitably amplifies the risk of side reactions and exacerbates the complexity of controlling olefinic stereochemistry .<sup>8−13</sup> Because of their distinctive dual perpendicular π-orbital structures and inherent reactivities, allenes have attracted considerable interest in organic synthesis.<sup>14−19</sup> Presently, precisely controlled α,β-additions of allenes through homogeneous copper/ ligand catalytic systems are invaluable for directly fabricating sophisticated multisubstituted olefinic frameworks. 20−23 Among these reactions, the difunctionalization α,β-addition of allenes, at α-sp<sup>2</sup>- and β-sp-hybridized carbon atoms, catalyzed by nucleophilic Cu−B species and predicated on borohydride reaction mechanisms, has emerged as a fervently discussed topic in synthetic chemistry (Figure 1A).<sup>24−27</sup> Despite recent advancements enabling the synthesis of various β,γ-addition products via α,β-addition rearrangements, copper predominantly metallates with α-carbon atoms.<sup>28</sup> Consequently, the multicomponent boron functionalization of allenes, generating branched products via β,γ-addition, remains exceptionally rare.

Navigating these challenges, the generation of internal alkynes from allenes in situ represents a promising approach for atypical selective additions.<sup>29</sup> However, this requires the simultaneous conquering of three pivotal hurdles: First, the conversion from allenes to alkynes must be expedited to suppress unnecessary α,β-addition of allenes to copper−boron intermediates. Second, during rearrangement and addition, the activity of copper catalysts must be sustained to prevent catalyst aggregation and deactivation for the completion of a single catalytic cycle. Finally, to finely tune the reaction’s stereoselectivity, copper catalysts possessing befitting electronic efects must be developed.<sup>30</sup> In such intricate reactions, the catalyst must delicately balance sustained coordination stability and demanding chemo- and stereoselective regulations, which is dificult to achieve using traditional homogeneous metal/ligand catalytic systems (Figure 1B).<sup>31</sup>

In organic synthesis, the development of single-atom catalysts (SACs) is an important advancement in catalyst design.<sup>32−42</sup> Over the past decade, SACs have demonstrated remarkable chemical selectivities and superior catalytic activities because of their unique coordination structures and diverse fundamental characteristics derived from heterogeneous catalytic systems.<sup>43−53</sup> Chemists have sought to deeply understand the structure−catalytic activity dynamics of SACs and the manner in which the carrier regulates the electronic efects of metal catalytically active centers. Consequently, the mechanisms by which SACs coordinate and determine the stereoselectivities of organic reactions have gradually been elucidated.<sup>54</sup> SACs’ distinct inherent coordination abilities make them suitable for satisfying conflicting chemical selectivity requirements, and their robust coordination structures and remarkable catalytic activities prevent catalyst aggregation during tandem reactions, thus substantially improving the catalytic eficiency. By modulating the electronic interplay between the metal and support, SACs may enable the control of the stereoselective addition of Cu−B intermediates, ofering an alternative approach to form β,γ-addition products. (Figure 1C).

![](images/1a83377d3bc756d9175713092c5963085bec45f2775df422d59f15d90403d5e6.jpg)

![](images/3a6dd516186c42a7a3fb30d7b0fb1bd6b628a3d6d5025728b0b2708f5dc16ea8.jpg)  
Figure 1. Metal-catalyzed selective alkylation and boronization of allenes.

## ■ METHODS

To demonstrate the catalyst’s eficacy, a series of experiments were conducted using a homogeneous catalytic system; however, the results were unsatisfactory (Table S1, entries 1−8). To determine the efects of various transition-metal carbides on the selectivity and catalytic activity of alkyne hydroboration, a series of metal-carbide-supported Cu-based SACs was synthesized to evaluate their catalytic activities. The experimental results revealed that during the reaction, diferent metal-carbide supports exhibited distinct selectivities,<sup>55</sup> suggesting that the interaction between the metal support and catalyst plays a crucial role in modulating the regioselectivity of the reaction. Evidently, although both the chromium carbide (CrC) and titanium carbide (TiC) catalysts exhibited low selectivities, their diferent dispersibilities in the solvent hindered suficient contact with the reaction substrates, considerably constraining their catalytic activities (Table S1, entries 9 and 10). After 72 h, the SiC catalyst carrier produced only a relatively low reaction yield of 50% (Table S1, entry 11). To investigate this peculiarity, the catalyst was characterized using inductively coupled plasma−optical emission spectroscopy (ICP−OES). The experimental results revealed that the catalyst’s Cu content was as low as 0.011 wt % because of the high stability of the SiC support, which prevented surface oxidation, and the absence of electrostatic or coordination interactions between the Cu and SiC surface. Therefore, we performed a simple oxygen modification on the surface of SiC to increase the loading of copper atoms. The experimental results revealed that under classical reaction conditions, CuCl @O−SiC possessed the optimal catalytic activity, producing an isolated yield of up to 75% of only the $\beta , \gamma \mathrm { - }$ addition product (2a) (Table S1, entry 12). The selectivity control of $\mathrm { S i O } _ { 2 } \ \mathrm { o r } \ g { \mathrm { - } } \mathrm { C } _ { 3 } \mathrm { N } _ { 4 }$ on the reaction was minimal (Table $^ { \mathrm { S 1 , } }$ entries 13 and 14). The replacement of CuCl with CuCl diminished both the reaction yield and the selectivity (Table S1, entry 15). Furthermore, when activated charcoal was employed as a carrier, the anticipated outcomes were not obtained (Table S1, entry 16), indicating that the interaction between the metal support and SiC was the primary factor influencing the regulation of the reaction selectivity.

![](images/1c1c8762ef8519d7cb783b99d7e77fceae898d014184368caa4b6bfc363f8d38.jpg)

![](images/bf6d900d1bb50a7e933a411559231de525eb7abf55475db35091668dd8687444.jpg)

![](images/e374c58e0f84fee4bfe89f32e0656902cd5d7e67fb1d70a70d23d12492bb11d0.jpg)

![](images/5f0d820acf9e93de1464a7f8523903797213ecd5c963246009045d781ae4dad2.jpg)  
Figure 2. Structural characterization and spectroscopic analysis of $\mathrm { C u C l } _ { 2 } @ \mathrm { O - S i C } .$ . (A) HR−TEM image of the CuCl @O−SiC. (B) AC HAADF STEM image of the CuCl @O−SiC. The white particles are Cu SACs. (C) EDS mapping of the CuCl @O−SiC. (D) Cu K-edge normalized XANES spectra. (E) FT of the k<sup>3</sup>-weighted EXAFS spectra. (F) Cu 2p XPS spectra of the CuCl @O−SiC.

Although the catalyst’s efectiveness has been demonstrated, $\mathrm { C u C l } _ { 2 } @ \bar { \mathrm { O } } - \mathrm { S i C }$ must be comprehensively characterized to evaluate its catalytic activity. ICP−OES revealed that in $\mathrm { C u C l } _ { 2 } @ \mathrm { O - S i C } ,$ the copper loading was only 0.449 wt % (Figure S1). High-resolution transmission electron microscopy (HR−TEM) revealed that no clusters formed during the $\mathrm { C u C l } _ { 2 } @ \mathrm { O - S i C }$ synthesis (Figure 2A). The lattice spacing, measured using HR−TEM, was approximately 0.32 nm. Moreover, HR−TEM clearly revealed that the SiC support possessed lattice fringes. Aberration-corrected high-angle annular dark-field scanning transmission electron microscopy (AC HAADF−STEM) revealed that in CuCl @O−SiC, copper atoms were uniformly dispersed, the density had increased, and no aggregates had formed (Figure 2B). Energydispersive spectrometry mapping (EDS mapping) revealed that in $\mathrm { C u C l } _ { 2 } @ \mathrm { O - S i C } , \mathrm { C u } , \mathrm { S i } ,$ and C were uniformly dispersed and that the low Cu content was highly dispersed, consistent with the ICP−OES results (Figure 2C). Collectively, these results indicate the absence of copper clusters in the catalyst. The Xray difraction (XRD) patterns of both the $\mathrm { C u C l } _ { 2 } @ \mathrm { O - S i C }$ and SiC support were nearly identical and did not exhibit any obvious peaks corresponding to copper nanoparticles, further indicating the absence of copper particles in the catalyst (Figure S2). To gain deep insights into the catalyst’s surface oxidation structure, the catalyst was characterized using Fourier transform infrared spectroscopy (FT-IR) and temperature-programmed desorption (TPD). The FT-IR spectrum exhibited distinct broad absorption peaks at 3411 and 1589 $\mathrm { c m ^ { - 1 } }$ , assigned to hydroxyl group vibrations, suggesting the formation of abundant hydroxyl functionalities on the oxidized catalyst surface (Figure S3). The ${ \mathrm { N H } } _ { 3 } – \mathrm { T P D }$ spectrum of the O−SiC exhibited a distinct desorption peak at $5 3 7 ^ { \circ } \mathrm { C } ,$ which was attributed to the acidic sites of the surface hydroxyl groups. Notably, following metal loading, diferent desorption peaks, probably associated with the interaction between the metallic copper and oxygen atoms of the support, emerged at 160 and 351 °C (Figure S4).<sup>56</sup>

To further investigate the microstructural coordination of the catalyst, we conducted X-ray absorption near-edge structure (XANES) spectroscopy, revealing that CuCl @O− SiC contained both ${ \dot { \mathrm { C u } } } ^ { 2 + }$ and ${ \mathrm { C u } } ^ { + }$ species, as confirmed by comparison with standard copper oxide (CuO) and ${ \mathrm { C u } } _ { 2 } { \mathrm { O } }$ reference spectra. In addition to electronic states, the Cu microstructural coordination environment in the SAC was investigated using Fourier-transformed extended X-ray absorption fine structure (FT-EXAFS) spectroscopy (Figure 2D and Table S2), revealing that in the catalyst, Cu atoms coordinated with four oxygen atoms on average. In R-space, the fitting results revealed that Cu−O and $_ \mathrm { C u - O - S i }$ coordinations were predominant in the first and second shells, respectively (Figure 2E). X-ray photoelectron spectroscopy (XPS) revealed that after the oxygen-based modification of the catalyst surface, the

A. DFT Calculation profiles  
![](images/d394f12f83d4018f8b75e6838bd3111ac5bbee8221df546566377fe53cf84c86.jpg)  
Figure 3. (A) DFT calculations for $\beta , \gamma$ -addition. (B) Structural diagrams of 1h and 1h′.

O-SiC spectrum exhibited Si $2 p$ peaks at binding energies of 102.3 and 100.8 $\mathrm { e V , }$ indicating that Si 2p orbitals were in distinct chemical environments, corresponding to the silicon atoms in $\mathrm { S i O } _ { 2 }$ and SiC, respectively. Simultaneously, the O 1s peaks appeared at 533.1 and 532.3 eV, which were assigned to abundant hydroxyl groups and $\mathrm { S i O } _ { 2 } ,$ respectively. Notably, when copper was loading into the catalyst, a diferent O 1s peak appeared at 531.2 eV, and the Si $2 \mathrm { p }$ binding energy shifted because Cu−O bond formation disrupted the original Si−O bond equilibrium (Figure S5). Additionally, in the Cu 2p XPS spectrum of $\mathrm { C u C l } _ { 2 } @ \mathrm { O - S i C } ,$ peaks at 933.3 and 952.8 eV correspond to the $\mathrm { C u } 2 p _ { 3 / 2 }$ peaks of ${ \mathrm { C u } } ^ { + }$ , while those at 934.9 and 954.8 eV represented ${ \bar { \mathrm { C } } } \mathrm { u } ^ { 2 + }$ characteristic peaks (Figure 2F), indicating that ${ \mathrm { C u } } ^ { 2 + }$ and ${ \mathrm { C u } } ^ { + }$ coexisted on the surface of the chemically modified $\mathrm { C u C l } _ { 2 } @ \mathrm { O - S i C }$ . To elucidate the catalysts’ $\mathrm { C u } ^ { \dot { + } }$ source, we loaded the copper into the unmodified carriers and characterized the same using XPS. The spectra only exhibited peaks corresponding to ${ \mathrm { C u } } ^ { 2 + }$ species (Figure S6), confirming electronic interactions between the Cu and Si/O carriers in the oxygen-modified catalysts, which efectively modulated the electron density distribution and valence state of the Cu catalytic centers.

To further corroborate the experimental measurements, first-principles density functional theory (DFT) calculations were performed to optimize the theoretical steady-state structures of the $\mathrm { C u C l } _ { 2 } (  { \bar { \alpha } }  { \mathrm { O } } -  { \mathrm { S i C } } \  { \mathrm { S A C s } }$ . Before the reaction, structural optimization revealed that copper atoms adsorbed on oxygen atoms were more stable than those adsorbed on silicon atoms, producing a $\mathrm { C u - O _ { 4 } }$ Cu coordination environment $( { \mathrm { F i g u r e ~ } } \dot { \mathrm { S 7 } } ) , \dot { \bar { \ } } 7$ which is highly consistent with the EXAFS fitting.

Studies of the reaction mechanism have revealed that the generation of internal alkyne intermediates from allenes in situ is a crucial first step in controlling the reaction selectivity (Figure S8). Because allenes possess a multitude of potential active sites, extensive computational modeling was conducted to investigate the energy diferences among the various reaction intermediates. This study aims to reveal the specific role of the catalyst in promoting the generation of internal alkynes in situ. When copper is bound to the carbon atoms at the $\beta \mathrm { - }$ and γ-positions of allenes, the formed structure

B. Structural diagrams of 1h and 1h'

possessed the most stable energy, facilitating the formation of internal alkynes (Figure S9). Calculations revealed that the energy required for this transformation was 0.59 eV (Figure S10). The plausibility of the proposed theory was experimentally confirmed. The crude product was reacted with allenes for 1 h under standard conditions and then characterized using $^ { 1 3 } \mathrm { C }$ NMR spectroscopy, which displayed diagnostic peaks for the alkyne moiety, including a methyl carbon atomic signal at δ 4.04 and sp-hybridized carbon atomic resonances at δ 85.58 and 79.46 (Figure S11). The signal coincided with the chemical shift of the alkyne intermediate, providing direct evidence of its in situ generation. Furthermore, the binding of copper catalysts to boron plays a key role in achieving high selectivity for internal alkynes, which is also one of the important factors that enables the reaction to proceed smoothly. Because reaction selectivity control depended entirely on the boronization of the Cu-metal catalytic center with alkynes, the Cu−Bpin reactive species produced diferent alkyne intermediates because of the diferent attack directions. Using the basic computational model of Cu SAC, we systematically investigated the energy diferences of various reaction intermediates during copper borylation and in the presence of an iodoalkane, revealing the regulatory role of the catalyst in reaction selectivity. Theoretical calculations revealed that when the copper active center coordinated to the γ-position of the alkyne and reacted with the iodoalkane, the activation energy barrier for the formation of the target product was only 0.91 eV. Conversely, when copper bound to the β-position of the alkyne and reacted with the iodoalkane, a substantially higher activation energy barrier (1.67 eV) hindered target product formation, indicating that the catalyst controlled the reaction selectivity. The theoretical calculations and experimental measurements agreed, confirming that the catalyst system’s exclusively feasible pathway only generated $\beta , \gamma \cdot$ -addition products (Figures 3 and S12). In parallel, we investigated the kinetics of the reaction between allenes (1a) and iodohydrocarbons and found that the reaction rate depended on the concentration of either the catalyst and the electrophile (1-iodobutane), indicating that the reaction followed first-order kinetics (Figures S13 and S14). As the reaction rate law was consistent with the mechanism proposed based on the DFT calculation, these results together support the proposed mechanism.

![](images/2613ef19f58fb813e59b70be201f66a3edf00040e74348cf849884e329b46359.jpg)  
Figure 4. Scope of copper-catalyzed highly selective synthesis, alkylation, and boronization of allenes. <sup>a</sup>Reaction conditions: 1a (0.2 mmol), iodohydrocarbons (0.6 mmol), B source (0.26 mmol), CuCl @O−SiC (10 mg), NaO<sup>t</sup>Bu (0.3 mmol), and KO<sup>t</sup>Bu (0.3 mmol) in DMF (2 mL) at 45 °C for 7 h. Yields of the isolated products. <sup>b</sup>Yield of 2a isolated from a large-scale reaction.

## ■ EXPERIMENTAL SECTION

We began by investigating the butylboronization of allenes (1a) with 1-iodobutane and bis(pinacolato)diboron under diferent basic (Table S3) and temperature (Table S4) conditions. The results showed that the optimal conditions were 1a (0.2 mmol), iodohydrocarbons (0.6 mmol), B source (0.26 mmol), CuCl @O−SiC (10 mg), NaO<sup>t</sup>Bu (0.3 mmol), and KO<sup>t</sup>Bu (0.3 mmol) in N,N-dimethylformamide (DMF) (2 mL) at 45 °C for 7 h.

Under the optimized conditions, we investigated the range of allenes suitable for the reaction. Allene substrates containing electron-donating groups (Figure 4, 2b−2f, 2j), electronabsorbing groups (Figure 4, 2g−2i), naphthalene rings (Figure 4, 2k), and heterocyclic rings (Figure 4, 2l) produced excellent yields of the target products. Moreover, when these substituents were at diferent positions in the benzene ring, they only minimally influenced the reaction yields (Figure 4, 2b−2d). Notably, when internal allenes were used, both the reaction selectivity and yield slightly decreased, which may be related to allenes’ structure (Figure 4, 2m). To further extend the applicability of the catalyst, we chose high-yield 1e as the reaction feedstock and attempted to use iodocarbons (Figure 4, 2n−2t) and diferent B sources (Figure 4, 2u−2v) for the reaction. The results revealed that the catalyst functioned well with these substrates. In addition, we attempted the reaction using a drug molecule as an organic compound fragment and produced compound 2w. Selected examples of unsuccessful attempts are compiled in Table S5.

To systematically evaluate the catalytic eficiency and industrial application potential of this catalyst, we conducted a large-scale reaction, revealing that both the product yield and the selectivity remained virtually unchanged. Similarly, to assess the catalyst reusability, the heterogeneous catalyst was recovered by washing and filtration after each run. Remarkably, the catalyst could be efectively reused for at least six consecutive cycles without losing any of its catalytic eficiency (Figure S15). After the reaction, the catalysts were analyzed using various characterization means, such as HR-TEM (Figure S16A), STEM (Figure S16B), EDS mapping (Figure S16C−F), AC HAADF-STEM (Figure S17), XPS (Figure S18) and EXAFS (Figure S19), revealing that the catalysts morphology, composition, and structure negligibly changed, thereby substantiating the catalysts’ stability under the prevailing reaction conditions.

## ■ CONCLUSIONS

Overall, the synthesis of complex multisubstituted olefins presents formidable challenges, particularly in accelerating reactions, maintaining catalyst stability, and fine-tuning the reaction stereoselectivity. To overcome these challenges, we synthesized a SiC-supported copper SAC (CuCl @O−SiC) containing increased Cu loadings via oxygen-based surface modification and used the catalyst in the multicomponent boronization of special β,γ-addition-associated branched olefins. These findings should advance research on the synthesis of complex multisubstituted olefins and provide more possibilities for advances and breakthroughs in synthetic chemistry.

## ■ ASSOCIATED CONTENT

## \*sı Supporting Information

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acscatal.5c03915.

Experiment procedures and <sup>1</sup>H and <sup>13</sup>C NMR spectra of products (PDF)

## ■ AUTHOR INFORMATION

## Corresponding Authors

Hai-Tao Tang − Key Laboratory for Chemistry and Molecular Engineering of Medicinal Resources (Ministry of Education of China), School of Chemistry and Pharmaceutical Sciences, Guangxi Normal University, Guilin 541004, China; orcid.org/0000-0001-7531-0458; Email: httang@ gxnu.edu.cn

Ying-Ming Pan − Key Laboratory for Chemistry and Molecular Engineering of Medicinal Resources (Ministry of Education of China), School of Chemistry and Pharmaceutical Sciences, Guangxi Normal University, Guilin 541004, China; Guangxi Key Laboratory of Drug Discovery and Optimization, Guangxi Engineering Research Center for Pharmaceutical Molecular Screening and Druggability Evaluation, Key Laboratory of Medical Biotechnology and Translational Medicine, School of Pharmacy, Guilin Medical University, Guilin 541199, China; orcid.org/0000-0002- 3625-7647; Email: panym@mailbox.gxnu.edu.cn

## Authors

Shicheng Ren − Key Laboratory for Chemistry and Molecular Engineering of Medicinal Resources (Ministry of Education of China), School of Chemistry and Pharmaceutical Sciences, Guangxi Normal University, Guilin 541004, China; orcid.org/0009-0001-3460-5257

Song Lin − Key Laboratory for Chemistry and Molecular Engineering of Medicinal Resources (Ministry of Education of China), School of Chemistry and Pharmaceutical Sciences, Guangxi Normal University, Guilin 541004, China; orcid.org/0009-0007-7218-934X

Zeyu Ren − Key Laboratory for Chemistry and Molecular Engineering of Medicinal Resources (Ministry of Education of China), School of Chemistry and Pharmaceutical Sciences, Guangxi Normal University, Guilin 541004, China

Yang Li − Key Laboratory for Chemistry and Molecular Engineering of Medicinal Resources (Ministry of Education of China), School of Chemistry and Pharmaceutical Sciences, Guangxi Normal University, Guilin 541004, China

Quanzhou He − Key Laboratory for Chemistry and Molecular Engineering of Medicinal Resources (Ministry of Education of China), School of Chemistry and Pharmaceutical Sciences, Guangxi Normal University, Guilin 541004, China

Mao-Rui Wang − Key Laboratory for Chemistry and Molecular Engineering of Medicinal Resources (Ministry of Education of China), School of Chemistry and Pharmaceutical Sciences, Guangxi Normal University, Guilin 541004, China; orcid.org/0009-0009-8159-9804

Fei-Hu Cui − Key Laboratory for Chemistry and Molecular Engineering of Medicinal Resources (Ministry of Education of China), School of Chemistry and Pharmaceutical Sciences, Guangxi Normal University, Guilin 541004, China; orcid.org/0000-0001-5811-9811

Wen-Hao Li − College of Sciences, Northeastern University, Shenyang 110819, China; orcid.org/0000-0001-9869- 145X

Complete contact information is available at: https://pubs.acs.org/10.1021/acscatal.5c03915

## Author Contributions

<sup>∥</sup>S.R. and S.L. contributed equally to this work. Conceptualization: H.-T.T. and Y.-M.P. Sample preparation, characterization, and theoretical calculation: Z.R., Y.L., and Q.H. Project guidance: M.-R.W., F.-H.C., and W.-H.L. Analyzing data and writing: S.R. and S.L. All authors have approved the final version of the article before submission.

## Funding

This work was supported by the National Natural Science Foundation of China (22201049, 22471046), Guangxi Natural Science Foundation of China (2021GXNSFFA220005), the Ba-Gui Youth Top-notch Talents Project of Guangxi, and the National High-Level Personnel of Special Support Program for Young Top-notch Talents (ninth batch) for financial support.

## Notes

The authors declare no competing financial interest.

## ■ ACKNOWLEDGMENTS

We thank the 1W1B beamlines of Beijing Synchrotron Radiation Facility (BSRF) measurement for providing beam time to support this work. The authors extend their gratitude to Mr. Liao Jian-Liang from Shiyanjia Lab (www.shiyanjia. com) for providing invaluable assistance with the XAFS analysis.

## ■ REFERENCES

(1) Lu, M.-Z.; Goh, J.; Maraswami, M.; Jia, Z.; Tian, J.-S.; Loh, T.-P. Recent Advances in Alkenyl sp<sup>2</sup> C−H and C−F Bond Functionaliza-

tions: Scope, Mechanism, and Applications. Chem. Rev. 2022, 122, 17479−17646.

(2) Nevesely,́ T.; Wienhold, M.; Molloy, J. J.; Gilmour, R. Advances in the E → Z Isomerization of Alkenes Using Small Molecule Photocatalysts. Chem. Rev. 2022, 122, 2650−2694.

(3) Zhang, Z.; Chen, Y.; Gu, X.; Ho, C.-Y. (NHC)Ni(II)-Directed Insertions and Higher Substituted Olefin Synthesis from Simple Olefins. Acc. Chem. Res. 2023, 56, 1070−1086.

(4) Fu, J.; Zanoni, G.; Anderson, E. A.; Bi, X. α-Substituted vinyl azides: an emerging functionalized alkene. Chem. Soc. Rev. 2017, 46, 7208−7228.

(5) Ma, X.; Li, L.; Tan, M.; Zhong, Z.; Liang, J.; Li, P.; Song, Q. Modular assembly of versatile tetrasubstituted alkenyl monohalides from alkynyl tetracoordinate borons. Chem 2023, 9, 1164−1181.

(6) Huang, X.-Y.; Chen, H.; Huang, Z.-Z.; Xu, Y.-L.; Li, F.-Y.; Ma, X.-L.; Chen, Y.-Y. Visible Light-Induced Difunctionalization of Alkynes: The Synthesis of Thiazoles and 1,1-Dibromo-1-en-3-ynes. J. Org. Chem. 2019, 84, 15283−15293.

(7) Domanski,́ S.; Chaładaj, W. A Broadly Applicable Method for Pd-Catalyzed Carboperfluoro-alkylation of Terminal and Internal Alkynes: A Convenient Route to Tri- and Tetrasubstituted Olefins. ACS Catal. 2016, 6, 3452−3456.

(8) Pradhan, T. R.; Paudel, M.; Feoktistova, T.; Cheong, P. H. Y.; Park, J. K. Silaborative Assembly of Allenamides and Alkynes: Highly Regio- and Stereocontrolled Access to Bi- or Trimetallic Skipped Dienes. Angew. Chem., Int. Ed. 2022, 134, No. e202116154.

(9) Huang, Y.; Torker, S.; Li, X.; Pozo, J.; Hoveyda, A. H. Racemic Vinylallenes in Catalytic Enantioselective Multicomponent Processes: Rapid Generation of Complexity through 1,6-Conjugate Additions. Angew. Chem., Int. Ed. 2019, 131, 2711−2717.

(10) Kortman, G. D.; Hull, K. L. Copper-Catalyzed Hydroarylation of Internal Alkynes: Highly Regio- and Diastereoselective Synthesis of 1,1-Diaryl, Trisubstituted Olefins. ACS Catal. 2017, 7, 6220−6224.

(11) Zhu, C.; Chen, H.; Yue, H.; Rueping, M. Electrochemical chemo- and regioselective arylalkylation, dialkylation and hydro-(deutero)alkylation of 1,3-enynes. Nat. Synth. 2023, 2, 1068−1081.

(12) Zhu, C.; Yue, H.; Rueping, M. Nickel catalyzed multicomponent stereodivergent synthesis of olefins enabled by electrochemistry, photocatalysis and photo-electrochemistry. Nat. Commun. 2022, 13, No. 3240.

(13) Pinkert, T.; Das, M.; Schrader, M. L.; Glorius, F. Use of Strain-Release for the Diastereoselective Construction of Quaternary Carbon Centers. J. Am. Chem. Soc. 2021, 143, 7648−7654.

(14) López, F.; Mascareñas, J. L. [4 + 2] and [4 + 3] catalytic cycloadditions of allenes. Chem. Soc. Rev. 2014, 43, 2904−2915.

(15) Krause, N.; Winter, C. Gold-Catalyzed Nucleophilic Cyclization of Functionalized Allenes: A Powerful Access to Carbo- and Heterocycles. Chem. Rev. 2011, 111, 1994−2009.

(16) Huang, X.; Ma, S. Allenation of Terminal Alkynes with Aldehydes and Ketones. Acc. Chem. Res. 2019, 52, 1301−1312.

(17) Campeau, D.; Rayo, D. F. L.; Mansour, A.; Muratov, K.; Gagosz, F. Gold-Catalyzed Reactions of Specially Activated Alkynes, Allenes, and Alkenes. Chem. Rev. 2021, 121, 8756−8867.

(18) Adams, C. S.; Weatherly, C. D.; Burke, E. G.; Schomaker, J. M. The conversion of allenes to strained three-membered heterocycles. Chem. Soc. Rev. 2014, 43, 3136−3163.

(19) Kim, M.; Kim, S.; Lee, Y.; Lee, Y.; Seo, S.; Jung, B. Synthesis of (Z)-Allylsilanes by Cu-Catalyzed Regioselective Protosilylation of Allenes via a Single-Electron Process. ACS Catal. 2025, 15, 2380− 2388.

(20) Chen, S.; He, X.; Jin, Y.; Lan, Y.; Shen, X. Copper-catalyzed regio- and stereo-selective hydrosilylation of terminal allenes to access (E)-allylsilanes. Nat. Commun. 2022, 13, No. 3691.

(21) Li, S.; Xu, J.-L.; Xu, Y.-H. Copper-Catalyzed Enantioselective Hydrosilylation of Allenes to Access Axially Chiral (Cyclohexylidene)- ethyl Silanes. Org. Lett. 2022, 24, 6054−6059.

(22) Blieck, R.; Bahri, J.; Taillefer, M.; Monnier, F. Copper-Catalyzed Hydroamination of Terminal Allenes. Org. Lett. 2016, 18, 1482−1485.

(23) Zhu, N.; Wang, F.; Chen, P.; Ye, J.; Liu, G. Copper-Catalyzed Intermolecular Trifluoromethylazidation and Trifluoromethylthiocyanation of Allenes: Efficient Access to CF -Containing Allyl Azides and Thiocyanates. Org. Lett. 2015, 17, 3580−3583.

(24) Hu, H.; Ji, G. C.; Jiang, L.; Bi, S.; Jiang, Y. Y.; Liu, Y. Ligand-Controlled Regiodivergent Cyanoboration of Internal Allenes by Copper Catalysis. Angew. Chem., Int. Ed. 2022, 61, No. e202210338.

(25) Yuan, W.; Ma, S. Ligand Controlled Highly Selective Copper-Catalyzed Borylcuprations of Allenes with Bis(pinacolato)diboron. Adv. Synth. Catal. 2012, 354, 1867−1872.

(26) Piñeiro-Suárez, M.; A<sup>́</sup>lvarez-Constantino, A. M.; Fañanás-Mastral, M. Copper-Catalyzed Enantioselective Borylative Allyl−Allyl Coupling of Allenes and Allylic gem-Dichlorides. ACS Catal. 2023, 13, 5578−5583.

(27) Semba, K.; Bessho, N.; Fujihara, T.; Terao, J.; Tsuji, Y. Copper-Catalyzed Borylative Allyl−Allyl Coupling Reaction. Angew. Chem., Int. Ed. 2014, 53, 9007−9011.

(28) Fujihara, T.; Sawada, A.; Yamaguchi, T.; Tani, Y.; Terao, J.; Tsuji, Y. Boraformylation and Silaformylation of Allenes. Angew. Chem., Int. Ed. 2017, 56, 1539−1543.

(29) Feng, J.; Xia, Y.; Shen, M.; Wang, J.; Fan, W.; Zhang, S.; Li, M.- B. Electrochemical Allene C−H Functionalization via Carbanion Sampling. Angew. Chem., Int. Ed. 2025, No. e202508369.

(30) Meng, F.; Li, X.; Torker, S.; Shi, Y.; Shen, X.; Hoveyda, A. H. Catalytic enantioselective 1,6-conjugate additions of propargyl and allyl groups. Nature 2016, 537, 387−393.

(31) Yang, D.; Li, J.; Xiao, M.; Liu, C.; Xing, W.; Zhu, J. Atomically dispersed metal catalysts towards nitrogen reduction for Ammonia: From homogeneous to heterogeneous. Chem. Eng. J. 2023, 468, No. 143778.

(32) Wang, A.; Li, J.; Zhang, T. Heterogeneous single-atom catalysis. Nat. Rev. Chem. 2018, 2, 65−81.

(33) Li, W.-H.; Yang, J.; Wang, D.; Li, Y. Striding the threshold of an atom era of organic synthesis by single-atom catalysis. Chem 2022, 8, 119−140.

(34) Zhang, L.; Zhou, M.; Wang, A.; Zhang, T. Selective Hydrogenation over Supported Metal Catalysts: From Nanoparticles to Single Atoms. Chem. Rev. 2020, 120, 683−733.

(35) Liu, P.; Huang, X.; Mance, D.; Copéret, C. Atomically dispersed iridium on MgO(111) nanosheets catalyses benzene− ethylene coupling towards styrene. Nat. Catal. 2021, 4, 968−975.

(36) Wu, H.; Wang, Q.; Zhao, Y.; Gao, Z.; Lin, Y.; Zheng, L.; Li, D.; Feng, J. Coupling Cross-Dimensional Ru −Ru Sites in Confined Nanoislands to Overcome the Limitation of Coadsorption and Diffusion in Tandem Reactions. ACS Catal. 2024, 14, 1584−1594.

(37) Bai, R.; He, G.; Li, J.; Li, L.; Zhang, T.; Wang, X.; Zhang, W.; Zou, Y.; Zhang, J.; Mei, D.; Corma, A.; Yu, J. Heteroatoms-Stabilized Single Palladium Atoms on Amorphous Zeolites: Breaking the Tradeoff between Catalytic Activity and Selectivity for Alkyne Semihydrogenation. Angew. Chem., Int. Ed. 2024, 63, No. e202410017.

(38) Saptal, V. B.; Ruta, V.; Bajada, M. A.; Vilé, G. Single-Atom Catalysis in Organic Synthesis. Angew. Chem., Int. Ed. 2023, 62, No. e202219306.

(39) Chen, Z.; Liu, J.; Koh, M. J.; Loh, K. P. Single-Atom Catalysis: From Simple Reactions to the Synthesis of Complex Molecules. Adv. Mater. 2021, 34, No. 2103882.

(40) Dery, S.; Mehlman, H.; Hale, L.; Carmiel-Kostan, M.; Yemini, R.; Ben-Tzvi, T.; Noked, M.; Toste, F. D.; Gross, E. Site-Independent Hydrogenation Reactions on Oxide-Supported Au Nanoparticles Facilitated by Intraparticle Hydrogen Atom Diffusion. ACS Catal. 2021, 11, 9875−9884.

(41) Moutsiou, A.; Olivati, A.; Cipriano, L. A.; Sivo, A.; Collins, S. M.; Ramasse, Q. M.; Kwon, I. S.; Di Liberto, G.; Kanso, M.; Wojcieszak, R.; Pacchioni, G.; Petrozza, A.; Vilé, G. Tracking Charge Dynamics in a Silver Single-Atom Catalyst During the Light-Driven Oxidation of Benzyl Alcohol to Benzaldehyde. ACS Catal. 2025, 15, 5601−5613.

(42) Bajada, M. A.; Tschulkow, M.; Vilé, G. Sustainability Assessment of Single-Atom Catalysts in the Transition to Greener Chemical Processes. Cell Rep. Sustainability 2025, 2, No. 100286.

(43) He, X.; He, Q.; Deng, Y.; Peng, M.; Chen, H.; Zhang, Y.; Yao, S.; Zhang, M.; Xiao, D.; Ma, D.; et al. A versatile route to fabricate single atom catalysts with high chemoselectivity and regioselectivity in hydrogenation. Nat. Commun. 2019, 10, No. 3663.

(44) Wang, X.-Y.; Pan, Y.-Z.; Yang, J.; Li, W.-H.; Gan, T.; Pan, Y.- M.; Tang, H.-T.; Wang, D. Single-Atom Iron Catalyst as an Advanced Redox Mediator for Anodic Oxidation of Organic Electrosynthesis. Angew. Chem., Int. Ed. 2024, 63, No. e202401295.

(45) Ren, S.; Lin, S.; Ren, Z.; Wang, M.; Yang, Y.; Tang, H.-T.; Chen, P.; Zhou, L.; Pan, Y.-M. Single-Site Palladium “Microreactor” for Carbon Dioxide Coupling/Cyclization Reactions. ACS Sustainable Chem. Eng. 2025, 13, 2001−2010.

(46) Zhao, J.-X.; Chen, C.-Q.; Xing, C.-H.; Jiao, Z.-F.; Yu, M.-T.; Mei, B.-B.; Yang, J.; Zhang, B.-Y.; Jiang, Z.; Qin, Y. Selectivity Regulation in Au-Catalyzed Nitroaromatic Hydrogenation by Anchoring Single-Site Metal Oxide Promoters. ACS Catal. 2020, 10, 2837−2844.

(47) Zhao, L.; Qin, X.; Zhang, X.; Cai, X.; Huang, F.; Jia, Z.; Diao, J.; Xiao, D.; Jiang, Z.; Lu, R.; et al. A Magnetically Separable Pd Single-Atom Catalyst for Efficient Selective Hydrogenation of Phenylacetylene. Adv. Mater. 2022, 34, No. 2110455.

(48) Cheng, Y.-T.; Peng, J.-Z.; Lai, G.-T.; Yue, X.; Li, F.-Z.; Wang, Q.; Chen, L.-N.; Gu, J. Edge-Site Co−N Model Single-Atom Catalysts for CO Electroreduction. ACS Catal. 2024, 14, 8446−8455.

(49) Pan, Y.; Zhang, X.; Sun, G.; Li, Y.; Liu, B. Single-Atom-Alloy Catalysts for Enhanced Hydrogenation Reaction Process: Mechanism, Regulation Strategy, and Design Principle. ACS Catal. 2025, 15, 3674−3698.

(50) Li, B.; Ju, C.-W.; Wang, W.; Gu, Y.; Chen, S.; Luo, Y.; Zhang, H.; Yang, J.; Liang, H.-W.; Bonn, M.; et al. Heck Migratory Insertion Catalyzed by a Single Pt Atom Site. J. Am. Chem. Soc. 2023, 145, 24126−24135.

(51) Gao, J.; Feng, L.; Ma, R.; Su, B.-J.; Alenad, A. M.; Liu, Y.; Beller, M.; Jagadeesh, R. V. Cobalt single-atom catalysts for domino reductive amination and amidation of levulinic acid and related molecules to N-heterocycles. Chem. Catal. 2022, 2, 178−194.

(52) Chan, K. W.; Mance, D.; Safonova, O. V.; Copéret, C. Well-Defined Silica-Supported Tungsten(IV)−Oxo Complex: Olefin Metathesis Activity, Initiation, and Role of Brønsted Acid Sites. J. Am. Chem. Soc. 2019, 141, 18286−18292.

(53) Korzynski, ́ M. D.; Copéret, C. Single sites in heterogeneous catalysts: separating myth from reality. Trends Chem. 2021, 3, 850− 862.

(54) Chen, Y.; Zhang, R.; Chen, Z.; Liao, J.; Song, X.; Liang, X.; Wang, Y.; Dong, J.; Singh, C. V.; Wang, D.; et al. Heterogeneous Rhodium Single-Atom-Site Catalyst Enables Chemoselective Carbene N−H Bond Insertion. J. Am. Chem. Soc. 2024, 146, 10847−10856.

(55) Li, W.-H.; Yang, J.; Jing, H.; Zhang, J.; Wang, Y.; Li, J.; Zhao, J.; Wang, D.; Li, Y. Creating High Regioselectivity by Electronic Metal-Support Interaction of a Single-Atomic-Site Catalyst. J. Am. Chem. Soc. 2021, 143, 15453−15461.

(56) Mozgawa, B.; Zasada, F.; Fedyna, M.; Góra-Marek, K.; Tabor, E.; Mlekodaj, K.; Dedec ̌ ek, ̌ J.; Zhao, Z.; Pietrzyk, P.; Sojka, Z. Analysis of NH -TPD Profiles for CuSSZ-13 SCR Catalyst of Controlled Al Distribution − Complexity Resolved by First Principles Thermodynamics of NH Desorption, IR and EPR Insight into Cu Speciation. Chem.-Eur. J. 2021, 27, 17159−17180.

(57) Huang, D.; He, N.; Zhu, Q.; Chu, C.; Weon, S.; Rigby, K.; Zhou, X.; Xu, L.; Niu, J.; Stavitski, E.; Kim, J. H. Conflicting Roles of Coordination Number on Catalytic Performance of Single-Atom Pt Catalysts. ACS Catal. 2021, 11, 5586−5592.

![](images/ccebac181f038f0dcf10493497c4bef9919dade56a96b96d2c256a3936af370b.jpg)

CAS BIOFINDER DISCOVERY PLATFORMTM

BRIDGE   
BIOLOGY AND   
CHEMISTRY FOR   
FASTER   
ANSWERS

Analyze target relationships, compound effects, and disease pathways

Explore the platform