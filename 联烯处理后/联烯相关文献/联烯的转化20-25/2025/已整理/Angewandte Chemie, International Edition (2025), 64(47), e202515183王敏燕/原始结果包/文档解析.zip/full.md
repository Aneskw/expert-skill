Sulfinylamines

How to cite: Angew. Chem. Int. Ed. 2025, 64, e202515183   
doi.org/10.1002/anie.202515183

# Regio-, Stereo-, and Enantioselective Copper-Catalyzed Allylation of Sulfinylamines with Allenes

Jie Zhu, Yue Zhao, Shengming Ma,\* and Minyan Wang\*

Abstract: Sulfinamides, pivotal scaffolds in modern organic synthesis, have undergone a continuous evolution of synthetic methodologies over the past century, yet the precise construction of sulfur stereocenters remains a significant synthetic challenge. Herein, we report a versatile catalytic asymmetric strategy for the synthesis of S-chirogenic allyl sulfinamides through the direct allylation of sulfinylamines with allenes. Our methodology employs a catalytic system comprising copper salts, hydrosilanes, and readily accessible chiral ligands, which facilitates the in situ generation of organocopper surrogates via hydrocupration of allenes. This approach demonstrates remarkable substrate scope and excellent regio-, stereo-, and enantioselectivity across a diverse array of sulfinamide products. Comprehensive mechanistic investigations, including detailed experimental studies and computational analyses, have been conducted to elucidate the reaction pathway and identify the key factors governing enantioselectivity.

Chiral sulfinamides featuring stereogenic S(IV) centers have garnered particular attention as pivotal synthetic targets.<sup>[1–15]</sup> These compounds not only function as crucial intermediates for the stereoselective assembly of sulfur-containing functional groups<sup>[16–19]</sup> but also exhibit remarkable versatility as bifunctional reagents under mild photoredox catalysis conditions.<sup>[20,21]</sup> Among these, the synthesis of chiral Sallyl sulfinamides has garnered significant attention due to their intricate structural complexity and diverse applications. A landmark achievement in 1990 facilitated the enantiopure synthesis of S-allyl sulfinamides via ene reactions of trans-alkenes with N-sulfinylcarbamates derived from chiral alcohols (Figure 1a).<sup>[22]</sup> To eliminate the reliance on chiral auxiliaries, Beyah and colleagues in 2017 pioneered an asymmetric catalytic variant, employing a chiral antimony catalyst in the ene-type sulfinamidation of cis- alkenes (Figure 1b).<sup>[23]</sup> However, the propensity of the N-sulfonyl sulfur-centered chirality, highlighting the necessity for more robust sulfinamide moiety to act as a leaving group, has limited its utility in adaptable synthetic methodologies.

Sulfinylamines (R–NSO), distinguished by their orthogonal cumulative π-systems, have emerged as pivotal building blocks in organic synthesis, facilitating a diverse range of chemical transformations.<sup>[24,25]</sup> The nucleophilic addition of magnesium reagents to sulfinylamines, developed in 1974, offers a direct method for synthesizing S-allyl sulfinamides, as well as a broad range of other sulfinamides (Figure 1c).<sup>[26–28]</sup> Subsequent catalytic advancements have aimed at enhancing compatibility with sensitive functional groups by employing readily accessible alkyl<sup>[29,30]</sup> and aryl<sup>[31]</sup> feedstocks in addition reactions. The advent of asymmetric catalysis utilizing aryl boron compounds<sup>[32,33]</sup> or halides<sup>[34–37]</sup> with sulfinylamines has introduced novel pathways for the synthesis of chiral sulfinamides. Inspired by these developments, we propose an enantioselective nucleophilic addition of allylmetal species to sulfinylamines to establish an S-stereogenic center. Here, we present an asymmetric catalytic allylation of sulfinylamines for the synthesis of enantioenriched S-allyl sulfinamides with excellent regio-, stereo-, and enantioselectivity (Figure 1d). Our strategy leverages copper salts, hydrosilanes, and commercially available ligands to in situ generate allylcopper nucleophiles from allenes with high regio- and stereoselectivity through hydrocupration.<sup>[38–68]</sup> Mechanistic investigations reveal that the formation of the enantioenriched S-allyl sulfinamides is achieved through the migratory insertion of the allylcopper nucleophile into the sulfinimine, rather than via a chair-like Zimmerman-Traxler transition state.<sup>[69,70]</sup> This approach not only enhances the synthetic efficiency but also broadens the scope of accessible chiral sulfinamides, paving the way for further exploration in sulfur-centered stereochemistry. Our investigation commenced with the utilization of allene 1a with N-sulfinyltritylamine (I) as the model substrates (Table 1). We initially established a reaction system employing 10 mol% of Cu(OAc) and 12 mol% a) Sn-mediated stereoselective allylic sulfinamidation by chiral auxiliaries:

![](images/a25f158d929cac528c1ba51eec102350fa01450a0beeffaaef413f913df87b03.jpg)

![](images/b91b1ac4c3fee898858701d5170ee771fb187bcf4753fd1f3ec2cfeeafe12738.jpg)

![](images/8feb7ea67e0e3e5727b21651a86fa3520a639f76f4c6870fd173e6bddd006b99.jpg)

![](images/3cda862686fb876030c9947913a4940a226c6adb391c42656c744a0d8620976a.jpg)  
Figure 1. Development of asymmetric catalytic strategies for the construction of S-chirogenic allyl sulfinamides.

of QuinoxP (L1), along with 3.0 equivalents of DEMS, conducted in THF at $0 \mathrm { ~ } ^ { \circ } \mathrm { C }$ for 12 h under a nitrogen atmosphere. This preliminary setup afforded the target trans product 1b in a modest 27% yield with an enantiomeric ratio (er) of 55/45 (entry 1). No rearrangement-type branched byproducts were observed. Subsequent ligand optimization revealed significant improvements. Switching to BINAP (L2) enhanced the yield to 37% with an improved er of 60/40 (entry 2). The introduction of JosiPhos (L3) further refined the er to 63/37 (entry 3). A more pronounced enhancement in enantioselectivity was observed upon substituting the phenyl groups on the phosphorus of JosiPhos with 3,5-CF -Ph groups (L4), which escalated the er to 85/15 while maintaining high yield (entry 4). However, replacing $\mathrm { P C y } _ { 2 }$ with P<sup>t</sup>Bu (L5) resulted in a slight decline in both yield and enantioselectivity (entry 5). The use of ligand L6, featuring bulky electrondonating aryl groups on the phosphorus atom, led to a notable decrease in both yield and enantioselectivity (entry 6). The choice of solvent emerged as a critical factor for achieving high enantioselectivity. Employing dioxolane as the solvent yielded comparable enantioselectivity but reduced the yield to 30% (entry 7). Conversely, MTBE as the solvent not only improved the enantioselectivity to 87/13 er but also increased the yield to 87% (entry 8). Exploration of alternative copper sources, such as MesCu and TcCu, proved beneficial, with TcCu notably enhancing the yield to 89% with an er of

88/12 (entries 9 and 10). Various silane variants were also tested. DPS displayed relevant reactivity, while TES produced product 1b with an er of 90/10 and a yield of 74% (entries 11 and 12). Further optimization revealed that lowering the reaction temperature enhanced the reaction outcome (entries 13 and 14). Remarkably, reducing the temperature to 60 °C resulted in an outstanding er of 95/5 and a yield of 80% (entry 15). Under these conditions, substituting TES with DEMS also yielded comparable results (entry 16). Reducing the catalyst loading to 5 mol% decreased conversion but preserved enantioselectivity (entry 17). Control experiments highlighted the indispensable role of the copper catalyst, as its omission completely halted the reaction (entry 18).

In our pursuit to comprehensively explore the reactivity and structural diversity of allenes, we conducted a systematic series of experiments utilizing sulfinylamine I as the key reactant partner (Table 2). Our investigation commenced with the evaluation of allene 2a and its methyl-substituted analogues (2a–7a), followed by ethyl (8a), isopropyl (9a), tert-butyl (10a), and phenyl (11a) derivatives, all of which successfully yielded the corresponding products (2b–11b) with remarkable efficiency. Significantly, allenes bearing diverse ether functionalities on the benzene core (12a–17a) demonstrated exceptional reactivity, delivering the target products 12b– 17b with notably high enantioselectivities. The compatibility of halide-substituted substrates was particularly noteworthy, with fluorine (18a–21a), chlorine (22a), and bromine (23a) derivatives exhibiting minimal interference in the reaction outcomes while maintaining superior enantioselectivity. Our experimental results further confirmed the remarkable compatibility of fluoroalkyl substituents, including CF (26a) and OCF H (27a), under the optimized reaction conditions. The treatment of naphthalene and dibenzo[b,d]thiophenecontaining allenes (26a–28a) proceeded with commendable efficiency, yielding products (26b–28b) with excellent enantioselectivity. A particularly significant advancement was achieved in the successful transformation of 1,1-disubstituted allenes 29a–37a featuring methyl and aryl moieties, which afforded products 29b–37b with an exceptional enantioselectivity and Z/E selectivity. To unambiguously determine the stereochemical outcome, we performed X-ray crystallographic analysis on product 34b,<sup>[71]</sup> which conclusively established its E,R-configuration. Expanding the substrate scope further, we demonstrated the exceptional chemoselectivity of the reaction towards naphthyl (38a), long-chain alkyl (39a), and cyclic (40a) allenes, which exclusively yielded the desired products 38b–40b under the optimized conditions.

Table 1: Optimization of reaction conditions.<sup>a)</sup>
<table><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td><img src="images/4ad81c99685ca94e92a45a3dbfe7e8d66a1a7029312d24b8ce8300f2c98f7a25.jpg"/></td><td></td><td></td><td></td></tr><tr><td>Entry 1</td><td>Cat [M] (mol%)</td><td>L* (mol%)</td><td>Additive (equiv.)</td><td>T (°C)</td><td>Solvent THF</td><td>er of 1b Yield of 1b (%)b) (%)c)</td></tr><tr><td></td><td>Cu(OAc)₂ (10)</td><td>L1 (12)</td><td>DEMS (3.0)</td><td>0 0</td><td>THF</td><td>55/45 27 60/40 37</td></tr><tr><td>2</td><td>Cu(OAc)₂ (10)</td><td>L2 (12)</td><td>DEMS (3.0)</td><td>0</td><td>THF</td><td>63/37 71</td></tr><tr><td>3</td><td>Cu(OAc)₂ (10)</td><td>L3 (12)</td><td>DEMS (3.0)</td><td>0</td><td>THF 85/15</td><td></td></tr><tr><td>4</td><td>Cu(OAc)₂ (10)</td><td>L4 (12)</td><td>DEMS (3.0)</td><td>0</td><td>THF 83/17</td><td>86</td></tr><tr><td>5</td><td>Cu(OAc)₂ (10)</td><td>L5 (12)</td><td>DEMS (3.0)</td><td>0</td><td>THF 61/39</td><td>73</td></tr><tr><td>6</td><td>Cu(OAc)₂ (10)</td><td>L6 (12)</td><td>DEMS (3.0)</td><td>0</td><td>dioxolane 85/15</td><td>41</td></tr><tr><td>7</td><td>Cu(OAc)2 (10)</td><td>L4 (12)</td><td>DEMS (3.0)</td><td>0</td><td>MTBE 87/13</td><td>30 87</td></tr><tr><td>8</td><td>Cu(OAc){₂ (10)</td><td>L4 (12)</td><td>DEMS (3.0)</td><td>0</td><td>MTBE 86/14</td><td></td></tr><tr><td>9</td><td>MesCu (10)</td><td>L4 (12)</td><td>DEMS (3.0)</td><td>0</td><td>MTBE 88/12</td><td>84</td></tr><tr><td>10</td><td>TcCu (10)</td><td>L4 (12)</td><td>DEMS (3.0)</td><td></td><td>MTBE 85/15</td><td>89</td></tr><tr><td>11</td><td>TcCu (10)</td><td>L4 (12)</td><td>DPS (3.0)</td><td>0</td><td>90/10</td><td>80</td></tr><tr><td>12</td><td>TcCu (10)</td><td>L4 (12)</td><td>TES (3.0)</td><td>0</td><td>MTBE 90/10</td><td>74</td></tr><tr><td>13</td><td>TcCu (10)</td><td>L4 (12)</td><td>TES (3.0)</td><td>-20 -40</td><td>MTBE MTBE 93/7</td><td>82</td></tr><tr><td>14</td><td>TcCu (10)</td><td>L4 (12)</td><td>TES (3.0) TES (3.0)</td><td>-60</td><td>MTBE 95/5</td><td>82</td></tr><tr><td>15</td><td>TcCu (10)</td><td>L4 (12)</td><td>DEMS (3.0)</td><td>-60</td><td>MTBE 95/5</td><td>80 (78)d)</td></tr><tr><td>16</td><td>TcCu (10)</td><td>L4 (12)</td><td>TES (3.0)</td><td>-60</td><td>MTBE 93/7</td><td>77 55</td></tr><tr><td>17</td><td>TcCu (5)</td><td>L4 (6) L4 (12)</td><td>TES (3.0)</td><td>-60</td><td>MTBE</td><td>0</td></tr><tr><td>18</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<sup>a)</sup>Reaction conditions: cat [Cu] (5–10 mol%), L (6–12 mol%), sulfinylamine I (0.1 mmol), 1a (0.30 mmol), and hydrosilane (0.3 mmol) in 2 mL of solvent for 12 h under nitrogen atmosphere. <sup>b)</sup>Determined by chiral HPLC. <sup>c)</sup>Determined by crude <sup>19</sup>F NMR. <sup>d)</sup>Isolated yield. DEMS (EtO) MeSiH. <sup>DPS</sup> = <sup>Ph</sup>2<sup>SiH</sup>2<sup>.</sup> <sup>TES</sup> = <sup>(EtO)</sup>3<sup>SiH.</sup> <sup>MTBE</sup> = <sup>methyl</sup> <sup>tert-butyl</sup> <sup>ether.</sup> <sup>MesCu</sup> = <sup>(2,4,6-trimethylphenyl)copper.</sup> <sup>TcCu</sup> = <sup>copper(I)</sup> thiophene-2-carboxylate  
thiophene-2-carboxylate.

To demonstrate the synthetic versatility of our method, we conducted comprehensive experiments (Scheme 1). Initially, this approach’s utility was highlighted through a 1.0 mmol-scale synthesis and subsequent transformations. The reaction using allene 1a and sulfinylamine I as substrates was smoothly executed, yielding product 1b in 68% yield without any loss of enantioselectivity. Subsequently, the deprotection experiment was performed. Treatment of sulfinamide 1b with methanesulfonic acid led to the deprotection product 41 in 71% yield, maintaining the enantioselectivity. Hydrogenation of 1b with a Pd/C catalyst produced alkyl-sulfinamide 42 in 80% yield with 94/6 er.

To gain deeper insights into the reaction pathway, we conducted extensive mechanistic studies as depicted in Scheme 2. Initially, when stoichiometric amounts of ligand L4 and TcCu were combined, the copper complex 43 was formed, as confirmed by X-ray analysis<sup>[71]</sup> (Scheme 2a). Utilizing this complex as a catalyst in the reaction between substrates 1a and I produced results of comparable efficacy, strongly suggesting that this complex serves as the active catalytic species. A clear linear relationship was observed when compounds 1a and I were reacted using L4 as the chiral ligand, indicating that the ratio of Cu to L4 is 1/1, without any self-aggregation of the catalyst (see Supporting Information for details).

Table 2: Substrate scope of allenes.<sup>a)</sup>  
![](images/54e8ffadd3e7503bc54d81b28624447a17f81349d8be125e0cb6e65b0cc55e83.jpg)  
<sup>a)</sup> Reaction conditions: TcCu (10 mol%), L4 (12 mol%), sulfinylamine I (0.10 mmol), 2–40a (0.30 mmol), TES (0.30 mmol), in MTBE, at 60 °C, 12 h, under $\mathsf { N } _ { 2 }$ atomsphere, in a sealed Schlenk tube. er values determined by chiral HPLC. Isolated yields determined by silica gel chromatography.

![](images/162e691a7d4758b2e49d657f7769771cd8cf6a37d9f53c1a1dc0d366d4d671b2.jpg)  
Scheme 1. Downstream transformations of 1b.

To further investigate the mechanism, we conducted deuterium labeling experiments (Scheme 2b). When Ph SiD reagent was used instead of (EtO) SiH with allene 1a or 34a, the D atoms were completely transferred to the central carbon of the allene, suggesting that the Cu-D species inserts at this position. Finally, the influence of different Nsubstituents on the sulfinylamines was examined (Scheme 2c).

a) Synthesis of copper complex 43 and testing its reactivity:

Sulfinylamines with Ts (II) and Ph (III) substituents did not yield the desired products 1c and 1d. Although the use of sulfinylamines bearing sterically hindered Ad (IV), TIPS (V), and SiPh (VI) groups produced small amounts of products 1e–g, the enantioselectivity was low. These findings suggest that the choice of sulfinylamine I is advantageous for achieving both high reactivity and stereoselectivity. Notably, allene 1a undergoes allylation with ketone 44 under the current reaction conditions, exclusively yielding the branched product 45 (Scheme 2d).<sup>[72–79]</sup> The notable regioselectivity difference underscores the distinct reactivity between ketones and sulfinylamines. Ketone 44 has an electrophilicity index of 0.929 eV, much lower than sulfinylamine’s 1.219 eV. This higher index in sulfinylamine I reflects its stronger electrophilic nature, boosting its ability to attract electrons in reactions. Furthermore, the frontier molecular orbital theory is used to explain the different selectivities of the reaction (see Supporting Information for details).

Based on the aforementioned mechanistic experiments, density functional theory (DFT) was then performed to elucidate the detailed mechanism and the origin of stereo- and enantio-selectivity in the Cu(I)-catalyzed reaction between allene and sulfinylamine I.<sup>[80,81]</sup> The calculated reaction mechanism for the generation of allylcopper intermediates is illustrated in Supporting Information. Initially, the copper(I) catalyst coordinates with the chiral ligand L4, generating the active catalyst 43. When silane is introduced into the system, the active catalyst 43 undergoes a σ-CAM mechanism with the silane via the transition state TS1A, with an activation

b) Deturation experiments

![](images/b6f0368478b536230b23ce4f5935322192a95a720722025b66dfcae03647a817.jpg)  
Scheme 2. Mechanistic experiments.

![](images/e2ee5fd4d23440b74187cef3ae120e2d2780641761688578ab9addd8017a1126.jpg)  
Figure 2. Seteroselectivity analysis for 1,3-copper migration.

energy of 18.5 kcal mol−<sup>1</sup>.<sup>[82]</sup> The resulting copper-hydride species, INT1A, selectively engages in migratory insertion with the allene, leading to the formation of diverse types of organocopper species with regioselectivity (see Supporting Information for details).<sup>[83]</sup> Subsequently, the favorable intermediate INT2A undergoes a 1,3-copper migration, a key step in determining the stereoselectivity of the product (Figure 2).<sup>[84]</sup> For allene 1a, the energy barrier for the formation of the E-configured intermediate INT3A-E via the transition state TS3A-E is 6.5 kcal $\mathrm { m o l ^ { - 1 } }$ , which is 1.2 kcal mol−<sup>1</sup> lower than that for the formation of INT3A-Z via transition state TS3A-Z (6.5 versus 7.7 kcal mol−<sup>1</sup>). For the disubstituted allene 29a, the stereoselectivity of the reaction can also be well controlled (4.9 kcal $\mathrm { m o l } ^ { - 1 }$ for TS3A-E-29a versus 6.9 kcal $\mathrm { m o l ^ { - 1 } }$ for TS3A-Z-29a). These disparities are primarily attributed to the substantial steric hindrance between the phenyl group and the alkenyl hydrogen in both TS3A-Z and TS3A-Z-29a.

Furthermore, we investigated the allylation reactions of INT2A and INT3A-E with sulfinylamine I, respectively (Figure 3). The coordination of N and O atoms of sulfinylamine into intermediate INT2A can form INT3A-N and INT3A-O, respectively. Due to the relatively higher calculated energy for INT3B-N, we excluded the reaction pathway involving this intermediate. The allylation reaction that proceeds through the six-membered chair-like Zimmerman-Traxler transition state TS3B-linear-R has an energy barrier of 11.8 kcal $\mathrm { \ m o l ^ { - 1 } } .$ . Although this pathway is more kinetically favorable than the direct allylation route leading to branched products, its energy requirement remains significantly higher than that of the 1,3-copper migration process of INT2A via transition states TS3A-E. These computational results imply that INT2A exhibits a distinct preference for undergoing transformation to yield INT3A-E, rather than participating in an allylation reaction with sulfinylamine. The migratory insertion between intermediate INT3A-E and sulfinylamine I is the crucial step dictating both the regio- and enantioselectivity within the catalytic cycle. The migratory insertion reaction of the S═N bond through the transition state TS4A-linear-R manifests a pronounced kinetic favorability. Specifically, the energy barrier associated with this pathway is 2.8 kcal $\mathrm { m o l ^ { - 1 } }$ lower than that of the analogous reaction pathway via the transition state TS4A-linear-S (4.0 kcal mol−<sup>1</sup> versus 6.8 kcal mol−<sup>1</sup>). This distinct energy disparity leads to a greater tendency for the product to form in the Rconfiguration. The selective migratory insertion of the S═O double bond into intermediate INT3A-E occurs via the transition states TS4B-R and TS4B-S, with activation energies of 8.2 and 5.4 kcal/mol, respectively. These values are substantially higher than the activation energies associated with the migratory insertion involving the S═N double bond. To gain deeper insights into the enantioselectivity observed in the migratory insertion process, the independent gradient model based on Hirshfeld partitioning (IGMH) was utilized to analyze the non-covalent interactions between the substrate and the chiral ligand fragment in transition states TS4Alinear-R and TS4A-linear-S.<sup>[85]</sup> Structural analysis reveals that in the favorable transition state TS4A-linear-R, stronger hydrogen-bond interactions exist between the C-H bonds of the chiral ligand and the oxygen or nitrogen atoms of reagent I. These interactions contribute to the stabilization of the transition state TS4A-linear-R, resulting in an activation energy barrier 2.8 kcal mol−<sup>1</sup> lower than that of the transition state TS4A-linear-S.

![](images/cc95935b98237e6644dfc9062ce72808feda2e83a2e26be273c8f5e10f6d8b2f.jpg)  
Figure 3. Transition-state models of regiodivergence in copper-catalyzed allylation reactions.

In conclusion, this study establishes a robust and versatile copper-catalyzed platform for the stereoselective synthesis of chiral S-allyl sulfinamides, addressing a long-standing challenge in asymmetric sulfur chemistry. The developed methodology demonstrates remarkable functional group tolerance and substrate scope, enabling the efficient coupling of diverse allenes with sulfinylamines under mild reductive conditions. Through a synergistic combination of experimental investigations and computational analyses, we have elucidated the intricate reaction mechanism and identified key factors governing the selective aryl addition processes. Given the growing recognition of chiral S-stereogenic compounds as privileged structural motifs in pharmaceutical development and agrochemical innovation, we anticipate that this catalytic system will find broad applications in the synthesis of biologically active molecules.

## Acknowledgements

The authors would like to thank financial support from the National Key R&D Program of China (2022YFA1503200), the Natural Science Foundation of Jiangsu Province (Grant BK20240059), and the Fundamental Research Funds for the Central Universities (Grant 020514380326) for their financial support. The authors are also grateful to the High-Performance Computing Center of Nanjing University for performing the numerical calculations in this paper on its blade cluster system.

## Conflict of Interests

The authors declare no conflict of interest.

## Data Availability Statement

The data that support the findings of this study are available in the supplementary material of this article.

Keywords: Allenes • Allylation • Asymmetric catalysis • Copper • Sulfinamides

[1] C. R. Johnson, Acc. Chem. Res. 1973, 6, 341–347. https://doi.org 10.1021/ar50070a003.

[2] M. Reggelin, C. Zur, Synthesis 2000, 2000, 1–64. https://doi.org/ 10.1055/s-2000-6217.

[3] H. Okamura, C. Bolm, Chem. Lett. 2004, 33, 482–487.

[4] J. Drabowicz, Phosphorus, Sulfur Silicon Relat. Elem. 2017, 192, 145–148. https://doi.org/10.1080/10426507.2016.1252366.

[5] U. Lücking, Org. Chem. Front. 2019, 6, 1319–1324.

[6] L. Ma, S. Chen, G. Li, J. Zhu, Q. Wang, Z. Tang, ACS Catal. 2019, 9, 1525–1530. https://doi.org/10.1021/acscatal.8b04850.

[7] W.ojaczyns. E, , J. Wojaczyn´ ski,´ Chem. Rev. 2020, 120, 4578– 4611.

[8] M. J. Tilby, M. C. Willis, Expert Opin. Drug Discov. 2021, 16, 1227–1231. https://doi.org/10.1080/17460441.2021.1948008.

[9] T. S.-B. Lou, M. C. Willis, Nat. Rev. Chem. 2022, 6, 146–162. https://doi.org/10.1038/s41570-021-00352-8.

[10] X. Zhang, F. Wang, C.-H. Tan, JACS Au 2023, 3, 700–714.

[11] X. Zhang, E. C. X. Ang, Z. Yang, C. W. Kee, C.-H. Tan, Nature 2022, 604, 298–303. https://doi.org/10.1038/s41586-022-04524-4.

[12] S. Huang, Z. Zeng, N. Zhang, W. Qin, Y. Lan, H. Yan, Nat. Chem. 2023, 15, 185–193. https://doi.org/10.1038/s41557-022- 01120-x.

[13] T. Wei, H.-L. Wang, Y. Tian, M.-S. Xie, H.-M. Guo, Nat. Chem. 2024, 16, 1301–1311. https://doi.org/10.1038/s41557-024-01522-z.

[14] M. Liao, Y. Liu, H. Long, Q. Xiong, X. Lv, Z. Luo, X. Wu, Y. R. Chi, Chem 2024, 10, 1541–1552.

[15] H.-J. Jiang, W. Fang, X. Chen, X.-R. Yu, Y.-D. Meng, L.-P. Fang, M.-L. Shen, C.-Z. Yao, Q. Li, X. Hong, J. Yu, J. Am. Chem. Soc. 2025, 147, 2137–2147. https://doi.org/10.1021/jacs.4c16233.

[16] J. A. Ellman, T. D. Owens, T. P. Tang, Acc. Chem. Res. 2002, 35, 984–995. https://doi.org/10.1021/ar020066u.

[17] P. Dinér, A. Sadhukhan, B. Blomkvist, Chem-CatChem 2014, 6, 3063–3066.

[18] M. T. Robak, M. A. Herbage, J. A. Ellman, Chem. Rev. 2010, 110, 3600–3740. https://doi.org/10.1021/cr900382t.

[19] S. Otocka, M. Kwiatkowska, L. Madalinska, P. Kiełbasin´ ski,´ Chem. Rev. 2017, 117, 4147–4181. https://doi.org/10.1021/acs. chemrev.6b00517.

[20] E. A. Noten, C. H. Ng, R. M. Wolesensky, C. R. J. Stephenson, Nat. Chem. 2024, 16, 599–606. https://doi.org/10.1038/s41557- 023-01404-w.

[21] C. Hervieu, M. S. Kirillova, Y. Hu, S. Cuesta-Galisteo, E. Merino, C. Nevado, Nat. Chem. 2024, 16, 607–614. https://doi. org/10.1038/s41557-023-01414-8.

[22] J. K. Whitesell, J. F. Carpenter, H. K. Yaser, T. Machajewski, J. Am. Chem. Soc. 1990, 112, 7653–7659 https://doi.org/10.1021/ ja00177a029.

[23] L. Bayeh, P. Q. Le, U. K. Tambar, Nature 2017, 547, 196–200. https://doi.org/10.1038/nature22805.

[24] Z.-X. Zhang, M. C. Willis, Chem 2022, 8, 1137–1146. https://doi. org/10.1016/j.chempr.2022.02.013.

[25] B.-C. Wang, F. Hu, J. Bai, F.-Y. Xiong, P. Chen, J. Li, Y. Tan, Y.- L. Guo, W.-J. Xiao, L.-Q. Lu, Angew. Chem. Int. Ed. 2024, 63, e202319728 Angew. Chem. 2024, 136, e20231972.

[26] S. B. Bowlus, J. A. Katzenellenbogen, Synth. Commun. 1974, 4, 137–141. https://doi.org/10.1080/00397917408062061.

[27] T. Q. Davies, A. Hall, M. C. Willis, Angew. Chem. Int. Ed. 2017, 129, 14937–14941 Angew. Chem. 2017, 129, 15133–15137. https:// doi.org/10.1002/ange.201708590.

[28] M. Ding, Z.-X. Zhang, T. Q. Davies, M. C. Willis, Org. Lett. 2022, 24, 1711–1715. https://doi.org/10.1021/acs.orglett.2c00347.

[29] L. Li, S.-Q. Zhang, Y. Chen, X. Cui, G. Zhao, Z. Tang, G.-X. Li, ACS Catal. 2022, 12, 15334–15340. https://doi.org/10.1021/ acscatal.2c05169.

[30] J. A. Andrews, J. Kalepu, C. F. Palmer, D. L. Poole, K. E. Christensen, M. C. Willis, J. Am. Chem. Soc. 2023, 145, 21623–21629. https://doi.org/10.1021/jacs.3c07974.

[31] P. K. T. Lo, W. C. Willis, J. Am. Chem. Soc. 2021, 143, 15576– 15581. https://doi.org/10.1021/jacs.1c08052.

[32] Y. Shi, Y. Yuan, J. Li, J. Yang, J. Zhang, J. Am. Chem. Soc. 2024, 146, 17580–17586. https://doi.org/10.1021/jacs.4c03473.

[33] L. Xi, X. Fang, M. Wang, Z. Shi, J. Am. Chem. Soc. 2024, 146, 17587–17594. https://doi.org/10.1021/jacs.4c04050.

[34] X. Lv, Z. Shi, Chem 2025, https://doi.org/10.1016/j.chempr.2025. 102715.

[35] X. Fang, L. Xi, M. Wang, J. Xiao, Y. Zhao, M. C. Willis, Z. Shi, Nat. Commun. 2025, 16, 2547. https://doi.org/10.1038/s41467- 025-57471-9.

[36] J. Yang, Y. Yuan, X. Tian, H. Zheng, Y. Li, J. Zhang, Angew. Chem. Int. Ed. 2025, 64, e202506243 Angew. Chem. 2025, 137, e202506243.

[37] L. Ding, J. Chen, H. Lu, Z. Shi, J. Am. Chem. Soc. 2025, 147, 28389–28398. https://doi.org/10.1021/jacs.5c09416.

[38] N. Krause, A. S. K. Hashmi, in Modern Allene Chemistry, Wiley-VCH, Winheim, Germany 2004. https://doi.org/10.1002/ 9783527619573.

[39] X. Zhang, S. Ma, in Fluorination, Springer, Singapore, 2019, Vol. 1, pp. 1–16.

[40] R. Zimmer, C. U. Dinesh, E. Nandanan, F. A. Khan, Chem. Rev. 2000, 100, 3067–3126. https://doi.org/10.1021/cr9902796.

[41] S. Ma, Acc. Chem. Res. 2003, 36, 701–712. https://doi.org/10.1021/ ar020133k.

[42] L. K. Sydnes, Chem. Rev. 2003, 103, 1133–1150. https://doi.org/ 10.1021/cr010025w.

[43] S. Ma, Chem. Rev. 2005, 105, 2829–2872. https://doi.org/10.1021/ cr020024j.

[44] G. B. Hammond, in Fluorine-Containing Synthons, American Chemical Society, Washington, DC, USA 2005, pp. 204–215, https://doi.org/10.1021/bk-2005-0911.ch010.

[45] M. Brasholz, H. U. Reissig, R. Zimmer, Acc. Chem. Res. 2009, 42, 45–56. https://doi.org/10.1021/ar800011h.

[46] S. Ma, Acc. Chem. Res. 2009, 42, 1679–1688. https://doi.org/10. 1021/ar900153r.

[47] S. Yu, S. Ma, Angew. Chem. Int. Ed. 2012, 124, 3074–3112 Angew. Chem. 2012, 128, 3128–3167. https://doi.org/10.1002/ ange.201101460.

[48] T. Lu, Z. Lu, Z. X. Ma, Y. Zhang, R. P. Hsung, Chem. Rev. 2013, 113, 4862–4904. https://doi.org/10.1021/cr400015d.

[49] J. Ye, S. Ma, Acc. Chem. Res. 2014, 47, 989–1000. https://doi.org/ 10.1021/ar4002069.

[50] F. López, J. L. Mascareñas, Chem. Soc. Rev. 2014, 43, 2904–2915.

[51] B. Alcaide, P. Almendros, C. Aragoncillo, Chem. Soc. Rev. 2014, 43, 3106–3135. https://doi.org/10.1039/C3CS60462D.

[52] M. P. Muñoz, Chem. Soc. Rev. 2014, 43, 3164–3183.

[53] A. P. Pulis, K. Yeung, D. J. Procter, Chem. Sci. 2017, 8, 5240– 5247. https://doi.org/10.1039/C7SC01968H.

[54] M. Holmes, L. A. Schwartz, M. J. Krische, Chem. Rev. 2018, 118, 6026–6052. https://doi.org/10.1021/acs.chemrev.8b00213.

[55] Y. Liu, M. Bandini, Chin. J. Chem. 2019, 37, 431–441. https://doi. org/10.1002/cjoc.201800568.

[56] L. Liu, R. M. Ward, J. M. Schomaker, Chem. Rev. 2019, 119, 12422–12490. https://doi.org/10.1021/acs.chemrev.9b00312.

[57] J. M. Alonso, P. Almendros, Chem. Rev. 2021, 121, 4193–4252. https://doi.org/10.1021/acs.chemrev.0c00986.

[58] C. Deutsch, N. Krause, B. H. Lipshutz, Chem. Rev. 2008, 108, 2916–2927. https://doi.org/10.1021/cr0684321.

[59] A. J. Jordan, G. Lalic, J. P. Sadighi, Chem. Rev. 2016, 116, 8318– 8372. https://doi.org/10.1021/acs.chemrev.6b00366.

[60] J. Chen, J. Guo, Z. Lu, Chin. J. Chem. 2018, 36, 1075–1109. https://doi.org/10.1002/cjoc.201800314.

[61] R. Y. Liu, S. L. Buchwald, Acc. Chem. Res. 2020, 53, 1229–1243. https://doi.org/10.1021/acs.accounts.0c00164.

[62] Y. Tani, K. Kuga, T. Fujihara, J. Terao, Y. Tsuji, Chem. Commun. 2015, 51, 13020–13023. https://doi.org/10.1039/C5CC03932K.

[63] T. Fujihara, K. Yokota, J. Terao, Y. Tsuji, Chem. Commun. 2017, 53, 7898–7900. https://doi.org/10.1039/C7CC02816D.

[64] M. Lee, M. Nguyen, C. Brandt, W. Kaminsky, G. Lalic, Angew. Chem. Int. Ed. 2017, 129, 15703–15707 Angew. Chem. 2017, 129, 15909–15913. https://doi.org/10.1002/ange.201709144.

[65] Y. Sun, Y. Zhou, Y. Shi, J. del Pozo, S. Torker, A. H. Hoveyda, J. Am. Chem. Soc. 2019, 141, 12087–12099. https://doi.org/10.1021 jacs.9b05465.

[66] G. Xu, B. Fu, H. Zhao, Y. Li, G. Zhang, Y. Wang, T. Xiong, Q. Zhang, Chem. Sci. 2019, 10, 1802–1806. https://doi.org/10.1039/ C8SC04505D.

[67] Y.-X. Tan, X.-Q. Tang, P. Liu, D.-S. Kong, Y.-L. Chen, P. Tian, G.-Q. Lin, Org. Lett. 2018, 20, 248–251. https://doi.org/10.1021/ acs.orglett.7b03608.

[68] Y. Yuan, X. Zhang, H. Qian, S. Ma, Chem. Sci. 2020, 11, 9115– 9121. https://doi.org/10.1039/D0SC03227A.

[69] T. Mejuch, N. Gilboa, E. Gayon, H. Wang, K. N. Houk, I. Marek, Acc. Chem. Res. 2013, 46, 1659–1669. https://doi.org/10.1021 ar4000532.

[70] M. N. Grayson, M. J. Krische, K. N. Houk, J. Am. Chem. Soc. 2015, 137, 8838–8850. https://doi.org/10.1021/jacs. 5b04844.

[71] Deposition Number(s) 2468970 (for 34b) and 2468971 (for 43) contain the supplementary crystallographic data for this paper. These data are provided free of charge by the joint CambridgeCrystallographic Data Centre and FachinformationszentrumKarlsruhe Access Structures service.

[72] R. Y. Liu, Y. Yang, S. L. Buchwald, Angew. Chem. Int. Ed. 2016, 128, 14077–14080 Angew. Chem. 2016, 128, 14283–14286. https:// doi.org/10.1002/ange.201608446.

[73] E. Y. Tsai, R. Y. Liu, Y. Yang, S. L. Buchwald, J. Am. Chem. Soc. 2018, 140, 2007–2011.

[74] R. K. Klake, S. L. Gargaro, S. L. Gentry, S. O. Elele, J. D. Sieber, Org. Lett. 2019, 21, 7992–7998. https://doi.org/10.1021/ acs.orglett.9b02973.

[75] R. Y. Liu, Y. Zhou, Y. Yang, S. L. Buchwald, J. Am. Chem. Soc. 2019, 141, 2251–2256. https://doi.org/10.1021/jacs. 8b13907.

[76] S. L. Gargaro, R. K. Klake, K. L. Burns, S. O. Elele, S. L. Gentry, J. D. Sieber, Org. Lett. 2019, 21, 9753–9758. https://doi.org/10. 1021/acs.orglett.9b03937.

[77] J. Qiu, S. Gao, C. Li, L. Zhang, Z. Wang, X. Wang, K. Ding, Chem.–Eur. J. 2019, 25, 13874–13878. https://doi.org/10.1002 chem.201903906.

[78] Y. Ye, I. Kevlishvili, S. Feng, P. Liu, S. L. Buchwald, J. Am. Chem. Soc. 2020, 142, 10550–10556. https://doi.org/10.1021/jacs. 0c04286.

[79] N. Jiang, P.-Z. Liu, Z.-Z. Pan, S.-Q. Wang, Q. Peng, L. Yin, Angew. Chem. Int. Ed. 2024, 63, e202402195 Angew. Chem. 2024, 136, e202402195. https://doi.org/10.1002/anie.202402195.

[80] J. Peng, R. Bai, Y. Lan, Acc. Chem. Res. 2025, 58, 1484–1495. https://doi.org/10.1021/acs.accounts.5c00115.

[81] All calculations were performed at the B3LYP-D3BJ/6- 311 G(d,p)-SDD/SMD(methyl tert-butyl ether)//B3LYP-D3BJ/6-31G(d)-SDD level of theory using Gaussian 09 software package (see Supporting Information for details).

[82] R. N. Perutz, S. Sabo-Etienne, Angew. Chem. Int. Ed. 2007, 119, 2578–2592 Angew. Chem. 2007, 119, 2630–2645. https://doi.org/ 10.1002/ange.200603224.

[83] E. Soriano, I. Fernández, Chem. Soc. Rev. 2014, 43, 3041. https:// doi.org/10.1039/c3cs60457h.

[84] X. Dong, H. Wang, H. Liu, F. Wang, Org. Chem. Front. 2020, 7, 3530–3556. https://doi.org/10.1039/D0QO00558D.

[85] T. Lu, Q. Chen, J. Comput. Chem. 2022, 43, 539–555. https://doi. org/10.1002/jcc.26812.