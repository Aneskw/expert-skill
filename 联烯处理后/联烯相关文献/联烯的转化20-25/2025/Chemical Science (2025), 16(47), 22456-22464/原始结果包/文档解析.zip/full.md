EDGE ARTICLE

View Article Online

View Journal | View Issue

![](images/20f9b8852eb3a1b9a3bf613ca4577aa78021c4af9d0f952fc022871084c38c36.jpg)

Check for updates

Cite this: Chem. Sci., 2025, 16, 22456

All publication charges for this article have been paid for by the Royal Society of Chemistry

# Palladium-catalysed asymmetric annulations of Morita–Baylis–Hillman carbonates with allenes or alkenes via migratory insertion

Jin-Yu Huang,†<sup>a</sup> Xin-Ting Qin,†<sup>a</sup> Han-Wen Rao,<sup>a</sup> Zhi-Chao Chen,\*<sup>a</sup> Lei Zhu, <sup>b</sup> Qin Ouyang, \*<sup>b</sup> Wei Du <sup>a</sup> and Ying-Chun Chen \*<sup>a</sup>

Received 8th September 2025   
Accepted 14th October 2025

As one of the most versatile intermediates in organic synthesis, p-allylpalladium complexes have been extensively exploited in allylic alkylation reactions with a wide range of nucleophiles. In contrast, their engagement in the migratory insertion process remains significantly underdeveloped. Here we demonstrate that the p-allylpalladium intermediates derived from ${ \mathsf { P d } } ^ { 0 }$ and Morita–Baylis–Hillman (MBH) carbonates of activated ketones can isomerize to the corresponding h<sup>1</sup>-form when stabilised by a pendent carbonyl group, and undertake migratory insertion into various allenes and even styrene-type alkenes eficiently. Subsequent vinylogous deprotonation of the newly formed multifunctional pallylpalladium species followed by isomerization and intramolecular allylic alkylation leads to skeletally diverse (3 + 2) adducts with high levels of regio- and stereoselectivity. This catalytic strategy not only achieves migratory insertion of non-zwitterionic p-allylpalladium intermediates, but also overcomes the inherent limitations that the MBH carbonates can only undergo annulations with electrophilic dipolarophiles via Lewis base catalysis. Mechanistic insights are further elucidated through comprehensive density functional theory calculation studies.

DOI: 10.1039/d5sc06910f

rsc.li/chemical-science

## Introduction

Owing to their ready availability and versatile reactivity, pallylpalladium complexes have emerged as a type of cornerstone synthons in modern organic chemistry.<sup>1</sup> Such robust intermediates can be readily generated through various pathways, including the oxidative addition of Pd<sup>0</sup> to allylic derivatives,<sup>2</sup> as well as Pd-mediated C–H activation of alkenes<sup>3</sup> or hydropalladation [or Pd<sup>0</sup>-promoted protonation] of polyunsaturated hydrocarbons.<sup>4</sup> Traditionally, p-allylpalladium species are utilised as electrophiles in the Tsuji–Trost allylic alkylation reaction (Scheme 1a, path $\mathbf { A } ) . ^ { 5 }$ Alternatively, p-allylpalladium species occasionally serve as nucleophiles to couple with electrophiles in the presence of suitable reductants (Scheme 1a, path B).<sup>6</sup>

Unlike $\operatorname { a r y l - P d } ^ { \mathrm { { I I } } }$ or alkenyl-Pd<sup>II</sup> intermediates,<sup>7</sup> allyl-Pd<sup>II</sup> species were rarely applied in migratory insertion reactions. In fact, in the 1970s, Powell conceptually demonstrated that pallylpalladium complexes could undertake migratory insertion into 1,3-dienes through transient formation of corresponding h<sup>1</sup>-intermediates (Scheme 1a, path C).<sup>8</sup> However, synthetic transformations of p-allylpalladium complexes into valueadded products via migratory insertion have been scarcely explored ever since, probably due to the reluctant isomerization of thermodynamically more stable h<sup>3</sup>-allylpalladium complexes to their h<sup>1</sup>-ones. A major breakthrough was achieved by Trost in 2018, who uncovered that speci<sup></sup>c oxatrimethylene–methane– palladium species INTA underwent a cascade migratory insertion/allylation reaction with 1,3-dienes to furnish cis-fused methylene tetrahydrofurans (Scheme 1b).<sup>9</sup> Experimental and density functional theory (DFT) studies veri<sup></sup>ed that the preinstalled ester group was instrumental for the desired migratory insertion, which not only stabilized INTA in a h<sup>1</sup>-form, but also efectively lowered the LUMO (lowest unoccupied molecular orbital) energy, rendering them more closely with the HOMO (highest occupied molecular orbital) energy of 1,3-diene partners.<sup>10</sup> Later, Garg and Ma have accomplished migratory insertion of p-allylpalladium-contained 1,4-C,N-dipoles INTB into strained cyclic allenes and terminal allenes, respectively.<sup>11</sup> Recently, we realised migratory insertion of azapalladacycles INTC, in situ generated from electron-de<sup></sup>cient 1-azadienes and $\mathrm { P d } ^ { 0 }$ via oxidative addition, into racemic internal allenes, and enantioselective and regiodivergent allylation could be obtained to deliver tetrahydropyridine products.<sup>12</sup> Despite such impressive progress, only limited and specially tailored zwitterionic pallylpalladium complexes were successfully utilised in migratory insertion reactions. Alternative application of novel functionalised p-allylpalladium species, especially the nonzwitterionic ones, to undergo migratory insertion reactions with diverse unsaturated systems would be highly desirable.

a) Typical reaction pathways of π-allylpalladium complexes  
![](images/ca6085c95495ea4e4718b3ddaf3a93bee91b4b2e322afd9db60458587a0d3d9f.jpg)  
b) Migratory insertion and annulation of zwitterionic π-allylpalladium species

![](images/315c6ea88e8104f28df885f5faf64ae103a7bbb1d76092de37e2ef00b314ccbd.jpg)

c) This work: migratory insertion of π-allylpalladium species from MBH carbonates and cascade transformations  
![](images/2d90edc22f6ee0a3aaac60f5a446501ad7fcd9cb8dc9a5a126febcb25a4e0d7c.jpg)  
Scheme 1 Development of migratory insertion reactions of p-allylpalladium-based species.

The Morita–Baylis–Hillman (MBH) adducts, condensed from carbonyls and activated alkenes, have been widely used in annulations aer conversion to zwitterionic allylic ylide species with organic Lewis bases, but their counterparts were inherently limited to electrophilic alkenes and dipoles.<sup>13</sup> We envisioned that functionalised MBH carbonates, such as ninhydrin-derived ones 1, could be activated by $\mathrm { P d } ^ { 0 }$ to form h<sup>3</sup>-allylpalladium complexes I.<sup>14</sup> The pendent carbonyl might serve as an additional coordinating site to facilitate the isomerisation of I to the h<sup>1</sup>-form II or II0, which would help lower the LUMO energy and facilitate the migratory insertion into allenes 2 possibly. Notably, the vinylogous b0-protons of the resultant pallylpalladium complexes III are highly acidic and could be readily deprotonated by the previously generated t-butoxide anion.<sup>15</sup> Subsequent isomerisation and intramolecular Tsuji– Trost reaction would <sup></sup>nally furnish (3 + 2) cycloadducts 3, even enantioselectively. This rational design would not only broaden the p-allylpalladium species suitable for migratory insertion reactions, but also introduce a novel catalytic strategy for the transformations of multifunctional MBH carbonates, allowing for their assemblies with electron-neutral unsaturated systems, which are not feasible via conventional Lewis base catalysis.

## Results and discussion

## Reaction optimisation

We initiated the investigation by examining the reaction between MBH carbonate 1a and racemic internal allene 2a in

Table 1 Condition optimisations of the asymmetric $( 3 + 2 )$ annulations of MBH carbonates 1 and racemic allene $2 \mathsf { a } ^ { a }$  
![](images/0fee49685a050c6d1ae8a4d66b8213927439075be93046e2141924acda80c5c5.jpg)

<table><tr><td>Entry</td><td>[Pd]</td><td>L</td><td>Solvent</td><td> $\mathrm { Y i e l d } ^ { b } \left( \% \right)$ </td><td> $\mathsf { e e } ^ { c } \left( \% \right)$ </td></tr><tr><td> $1 ^ { d }$ </td><td> $\mathrm { P d } ( \mathrm { P P h } _ { 3 } ) _ { 4 }$ </td><td>一</td><td>DCM</td><td> ${ } ^ { 3 \mathbf { a } , 1 8 }$ </td><td>一</td></tr><tr><td>2</td><td> $\mathbf { P d } ( \mathbf { O A c } ) _ { 2 }$ </td><td>L1</td><td>DCM</td><td>3a, 30</td><td>66</td></tr><tr><td>3</td><td> $\mathbf { P d } ( \mathbf { O A c } ) _ { 2 }$ </td><td>L2</td><td>DCM</td><td>3a, 70</td><td>61</td></tr><tr><td>4</td><td> $\mathbf { P d } ( \mathbf { O A c } ) _ { 2 }$ </td><td>L3</td><td>DCM</td><td> ${ } ^ { 3 \mathbf { a } , 8 0 }$ </td><td>70</td></tr><tr><td>5</td><td> $\mathbf { P d } ( \mathbf { O A c } ) _ { 2 }$ </td><td>L4</td><td>DCM</td><td>3a, 84</td><td>73</td></tr><tr><td>6</td><td> $\mathbf { P d } ( \mathbf { O A c } ) _ { 2 }$ </td><td>L5</td><td>DCM</td><td>3a, 89</td><td>81</td></tr><tr><td>7</td><td> $\mathbf { P d } ( \mathbf { O A c } ) _ { 2 }$ </td><td>L6</td><td>DCM</td><td>3a, 86</td><td>82</td></tr><tr><td>8</td><td> $\mathbf { P d } ( \mathbf { O A c } ) _ { 2 }$ </td><td>L7</td><td>DCM</td><td>3a, 76</td><td>87</td></tr><tr><td>9</td><td> $\mathbf { P d } ( \mathbf { O A c } ) _ { 2 }$ </td><td>L8</td><td>DCM</td><td>3a, 81</td><td>33</td></tr><tr><td>10</td><td> $\mathbf { P d } ( \mathbf { O A c } ) _ { 2 }$ </td><td>L9</td><td>DCM</td><td>3a, 35</td><td>5</td></tr><tr><td>11</td><td> $\mathbf { P d } ( \mathbf { O A c } ) _ { 2 }$ </td><td>L7</td><td>DCE</td><td>3a, 63</td><td>85</td></tr><tr><td>12</td><td> $\mathbf { P d } ( \mathbf { O A c } ) _ { 2 }$ </td><td>L7</td><td>MeOH</td><td>3a, 34</td><td>89</td></tr><tr><td>13</td><td> $\mathbf { P d } ( \mathbf { O A c } ) _ { 2 }$ </td><td>L7</td><td>Toluene</td><td>3a, 17</td><td>89</td></tr><tr><td>14</td><td> $\mathbf { P d } ( \mathbf { O A c } ) _ { 2 }$ </td><td>L7</td><td>THF</td><td>3a, 74</td><td>88</td></tr><tr><td> $1 5 ^ { e }$ </td><td> $\mathbf { P d } ( \mathbf { O A c } ) _ { 2 }$ </td><td>L7</td><td>DCM</td><td>3b, 81</td><td>90</td></tr><tr><td> $1 6 ^ { e }$ </td><td> $\operatorname { P d } ( \operatorname { T F A } ) _ { 2 }$ </td><td>L7</td><td>DCM</td><td>3b, 93</td><td>92</td></tr><tr><td> $1 7 ^ { e }$ </td><td> $\mathrm { P d } _ { 2 } ( \mathrm { d b } \mathbf { a } ) _ { 3 }$ </td><td>L7</td><td>DCM</td><td>3b, 70</td><td>81</td></tr><tr><td> $1 8 ^ { e }$ </td><td> $\mathrm { P d } ( \mathrm { a l l y l } ) \mathrm { c p }$ </td><td>L7</td><td>DCM</td><td>3b, 15</td><td>61</td></tr><tr><td> $1 9 ^ { e , f }$ </td><td> $\operatorname { P d } ( \operatorname { T F A } ) _ { 2 }$ </td><td>L7</td><td>DCM</td><td>3b, 68</td><td>93</td></tr><tr><td> $2 0 ^ { d , e }$ </td><td> $\operatorname { P d } ( \operatorname { T F A } ) _ { 2 }$ </td><td>L7</td><td>DCM</td><td>NR</td><td>一</td></tr><tr><td> $2 1 ^ { e , g }$ </td><td> $\operatorname { P d } ( \operatorname { T F A } ) _ { 2 }$ </td><td>L7</td><td>DCM</td><td> ${ \mathbf { 3 6 } } , { \mathbf { 8 4 } }$ </td><td>91</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

<sup>a</sup> Unless noted otherwise, the reaction was performed with MBH carbonate 1a (0.1 mmol), racemic allene 2a (0.2 mmol), [Pd] (10 mol%), L (12 mol%) and Et N (0.05 mmol) in DCM (1.0 mL) at 40 °C for 24 h under Ar. <sup>b</sup> Yield of the isolated product. <sup>c</sup> Determined by HPLC analysis on a chiral stationary phase. <sup>d</sup> Without $\mathrm { E t } _ { 3 } \mathrm { N } . \mathrm { ~ } ^ { e }$ 1b (0.1 mmol) was used. <sup>f</sup> At rt. <sup>g</sup> With 2a (0.1 mmol).

DCM at $4 0 ~ ^ { \circ } \mathrm { C }$ under the catalysis of $\mathrm { P d } ( \mathrm { P P h } _ { 3 } ) _ { \mathfrak { c } }$ <sub>4</sub>. To our delight, apparent conversions were observed to give the desired (3 + 2) annulation product 3a, albeit in a low yield, as side reactions promoted by Lewis basic PPh were also noted (Table 1, entry 1). Consequently, a series of chiral ligands in combination with Pd(OAc) were examined for asymmetric induction. Aer screenings,<sup>16</sup> it was found that using pyridinyl-oxazoline L1 exhibited fair catalytic eficiency and moderate enantioselectivity (entry 2). Introducing either electron-donating or withdrawing substituents into the pyridine skeleton (L2–L4) improved the yield signi<sup></sup>cantly, but the enantioselectivity was unsatisfactory (entries 3–5). Chiral bisoxazolines L5–L8 were applicable (entries 6–9), and a high ee value was obtained with L7 having bulky tert-butyl groups (entry 8). Unfortunately, poor catalytic eficacy was observed with ligand L9 (entry 10). Other solvents were tested but delivered diminished yields (entries 11–14). While slightly higher enantioselectivity was achieved by employing MBH carbonate 1b from ethyl acrylate (entry 15), a quick survey of palladium sources revealed that Pd(TFA) was a better choice (entries 16–18). Lowering the temperature resulted in a signi<sup></sup>cantly reduced yield because of incomplete conversions (entry 19). A control experiment veri<sup></sup>ed the necessity of $\mathrm { E t } _ { 3 } \mathrm { N }$ (entry 20), which might act as a reductant to ensure the generation of reactive $\mathrm { P d } ^ { \bar { 0 } }$ from the $\mathrm { P d } ^ { \mathrm { I I } }$ precatalyst.<sup>17</sup> It should be noted that a high yield was retained by employing 1.0 equivalent of allene 2a (entry 21).

## Substrate scope investigation

Consequently, we <sup></sup>rst investigated the scope of MBH carbonates 1 in the reactions with racemic allene 2a under the catalysis of $\mathrm { P d } ( \mathrm { T F A } ) _ { 2 } / \mathrm { L } 7$ . As summarised in Scheme 2a, comparable good yields and enantioselectivity were obtained for products 3a–c with diverse ester groups, whereas slightly diminished enantiocontrol was observed for products 3d and 3e from vinyl ketone-derived carbonates 1. In addition, high yields and ee values were attained for the MBH carbonates 1 bearing either electron-rich or -de<sup></sup>cient groups on the phenyl ring (products 3f–h), even for the benzo[f]ninhydrin-derived one (product 3i). Next, a variety of racemic symmetric allenes 2 were explored. As illustrated in Scheme 2b, a wide range of 1,3-dialkyl substituted allenes 2, even those with various functionalities, all underwent the (3 + 2) annulations with MBH carbonate 1b smoothly, producing 3j–r in moderate to good yields with uniformly high enantioselectivity. Some allenes with drug motifs were also compatible (product 3s and 3t). In addition, cyclic allene worked well to yield product 3u with moderate enantioselectivity. Notably, 1,3-diaryl-substituted allenes 2 were also applicable under the catalysis of $\mathbf { P d } ( \mathbf { T F A } ) _ { 2 } / \mathbf { L 9 } ,$ giving corresponding product 3v–z in moderate to high yields and enantioselectivity.

Encouraged by these results, we next turned our attention to explore the $\left( 3 + 2 \right)$ annulations of the MBH carbonate 1b with more challenging unsymmetrical allenes, as simultaneous control over enantio- and regioselectivity in the allylation step would be encountered. Delightfully, 1-aryl-, 1-alkoxyl- and 1- amino-substituted terminal allenes exhibited high reactivity in the assemblies with MBH carbonate 1b under the catalysis of Pd(TFA) /L10, and products 4a–g were generally furnished in outstanding yields and regioselectivity, whereas moderate to good ee values were obtained. Even a 1,1-disubstituted allene was compatible, afording product 4h featuring a quaternary stereocenter with good data (Scheme 2c). Moderate regioselectivity could be achieved with 1-aryl-3-alkyl-allene, but both products 5a and 5a0 were obtained with poor enantioselectivity under the catalysis of $\mathbf { P d } ( \mathbf { T F A } ) _ { 2 } / \mathbf { L 1 1 }$ . Notably, even trisubstituted allenes proved to be reliable partners, preferentially afording products 5b and 5c having a quaternary stereocenter with high regioselectivity, though the enantioselectivity was currently unsatisfactory (Scheme 2d).

Migratory insertion of p-allylpalladium complexes into simple alkenes represents a more challenging task. Although strained norbornenes can engage in such a process,<sup>18</sup> attempts to perform migratory insertion of zwitterionic p-allylpalladium species with alkenes all proved unsuccessful due to the high energy barriers involved.<sup>10</sup> Notably, the assembly of MBH carbonate 1b and 2-vinylnaphthalene 6a was successful under the catalysis of Pd(OAc) /L8, with tetrabutylammonium chloride (TBAC) as an additive,<sup>19</sup> furnishing (3 + 2) product 7a with good enantioselectivity, albeit in a fair yield, probably by forming dearomative intermediate V.<sup>20</sup> Importantly, other benzo-fused heteroarenes were compatible (products 7b–e), as summarised in Scheme 2e. Collectively, these reactions well demonstrated the broad applicability of the current approach with respect to diversely substituted allenes as well as terminal alkenes.

![](images/032c5979f67b90aa06a1fba49c8ad2d5d35eeea4ff95b8bafcdb5275148285c7.jpg)  
Scheme 2 Asymmetric (3 + 2) annulations of MBH carbonates and diverse allenes<sup>a</sup>. <sup>a</sup>On a 0.1 mmol scale. <sup>b</sup>For 48 h. <sup>c</sup>With L10 (12 mol%) at rt. <sup>d</sup>With alkene 6 (0.5 mmol), Pd(OAc) (10 mol%), L8 (12 mol%), TBAC (50 mol%) and Et N (1.0 equiv) in EtOH (1.0 mL).<sup>e</sup>The absolute configuration of enantiopure 3q, 4e and 7a were determined by X-ray analysis. Other products were assigned by analogy.

a) Regiodivergent annulations of pyrazolone-derived MBH carbonates  
![](images/f15d3b9c7875b07d70e8d9098f8a789f5b3c597d81211dab5d6b6bf0b42cc0f5.jpg)  
S Exploration of more types of MBH carbonates<sup>a</sup>. <sup>a</sup>On a 0.1 mmol scale. <sup>b</sup>The absolute configurations of enantiopure 9b was determined by X-ray analysis after conversion to 18. The relative configuration of 12b was determined by X-ray analysis after derivatisation, and its absolute configuration was assigned by ECD analysis (see the SI). Other products were assigned by analogy.

To further exhibit the generality of this protocol and construct skeletally diverse products, the MBH carbonates derived from other activated ketones were investigated. As depicted in Scheme 3a, pyrazolone-based MBH carbonates 8 underwent similar (3 + 2) annulations with both terminal and internal allenes eficiently in the presence of Pd(TFA) /L10 or L13, respectively, afording products 9a–h bearing two adjacent stereocenters with moderate to good enantioselectivity. Notably, a diferent regioselective O-allylation of intermediate VI occurred to deliver (5 + 2) product 10 by using Pd(TFA) /L14, albeit in moderate yield and stereoselectivity. In addition, isatin-based MBH carbonates 11 were also suitable for (3 + 2) annulations with allenes, and products 12a and 12b were aforded with moderate data under the catalysis of Pd(TFA) with L7 or L10, respectively (Scheme 3b). Regrettably, some aldehyde-derived MBH carbonates and tetrasubstituted allenes were not suitable for current transformation.<sup>16</sup>

## Synthetic transformations

The obtained multifunctional (3 + 2) annulation adducts demonstrate versatile synthetic utility, serving as a valuable platform for accessing structurally diverse architectures. As illustrated in Scheme 4, treating product 9b with $\mathrm { K } _ { 2 } \mathrm { O s O } _ { 4 } \cdot 2 \mathrm { H } _ { 2 } \mathrm { O } /$ NMO provided diol 13 with high diastereoselectivity. Interestingly, chemoselective oxidative cleavage of terminal ole<sup></sup>n of 9b with $\mathrm { K _ { 2 } O s O _ { 4 } } \cdot 2 \mathrm { H _ { 2 } O } / \mathrm { N a I O _ { 4 } }$ furnished ketone 14, which could be further converted to chiral lactone 15 via Baeyer–Villiger rearrangement. Besides, the exo-cyclic double bond of 9b also underwent selective hydrogenation to yield 16, or sulfur-

![](images/6e2dd31053fb8522f68801aa3aa15e11f333a3a62fa865afbf14441ed6126278.jpg)  
Conditions: i) $K _ { 2 } O { \tt s O } _ { 4 } { \cdot } 2 H _ { 2 } O$ (10 mol%), NMO (5.0 equiv), THF/H₂O, rt, 12 h. $\mathrm { \ddot { \iota } ( i ) } \ K _ { 2 } \mathsf { O s O } _ { 4 } { \bullet } 2 \mathsf { H } _ { 2 } \mathsf { O }$ (10 mol%), NalO₄ (5.0 equiv), THF/H₂O, rt, 2 h. iii) m-CPBA (2.0 equiv), NaHCO₃ (2.0 equiv), DCM, rt, 48 h. iv) Pd/C (10 wt%), H2balloon, EtOAc, rt. 12 h. y) PhSSPh (0.6 eguiy). Rongalite (2.0 eguiy) $K _ { 2 } C O _ { 3 } ( 1$ .0 equiv), DMF, rt, 12 h. vi) LiOH (5.0 equiv), THF/MeOH/H₂O, 60 °C, 1 h. vii) 2-aminonaphthalene (2.0 equiv), i-BuOCOCI (2.0 equiv), N-methylmorpholine (2.0 equiv), DCM, rt, 12 h.

![](images/56ed482f763e8355627b15afe6b00a03cc6f3224c366ac85b3f3229357220c3e.jpg)  
Scheme 4 Synthetic transformations of products.

Michael addition to give $^ { 1 7 , ^ { 2 1 } }$ both with exclusive diastereoselectivity. Additionally, the ethyl ester group of 9b was amenable to hydrolysis followed by condensation with 2-aminonaphthalene to generate amide 18 with retained enantioselectivity. Moreover, a ring-closing metathesis reaction of compound 9e delivered polycyclic product 19.

## Mechanism studies

As proposed in Scheme 5a, path A, the key p-allylpalladium complex INT3 may be generated from the oxidative addition of $\mathrm { P d } ^ { 0 }$ to MBH carbonate 1b, followed by migratory insertion into simpli<sup></sup>ed allene $\mathbf { 2 a ^ { \prime } . ^ { 1 1 } }$ Alternatively, allene $\mathbf { 2 } \mathbf { a } ^ { \prime }$ might also be activated by $\mathrm { P d } ^ { 0 }$ via $\boldsymbol { \eta } ^ { 2 }$ -coordination and backdonation based on a Dewar–Chatt–Duncanson model,<sup>12,22</sup> which is indeed supported by DFT calculations. It is found that the HOMO energy of $\mathrm { P d } ^ { 0 } { \cdot } \boldsymbol { \eta } ^ { 2 }$ -complex INT6 ( 4.79 eV) is signi<sup></sup>cantly enhanced compared to that of allene $2 \mathbf { a } ^ { \prime } \ \left( - 6 . 8 7 \ \mathrm { e V } \right)$ . The nucleophilicity enhanced INT6 may attack MBH carbonate 1b to form p-allylpalladium complex INT3 in a $\mathbf { S } _ { \mathbf { N } } 2 ^ { \prime }$ fashion (path B).

To <sup></sup>gure out which reaction pathway is more favourable, comprehensive DFT calculations were conducted. As shown in

Scheme 5b (black line), the energy barrier of oxidative addition of $\mathrm { P d } ^ { 0 }$ to MBH carbonate 1b via TS1 is 15.5 kcal mol−<sup>1</sup>. Notably, the pendent carbonyl group of 1,3-indandione serves as an additional binding group to facilitate the isomerisation of $\eta ^ { 3 } -$ allylpalladium complex INT1 to slightly more stable $\boldsymbol \eta ^ { 1 } .$ -one INT2. Subsequent migratory insertion of INT2 into allene $\mathbf { 2 } \mathbf { a } ^ { \prime }$ via TS2, with a free energy barrier of 22.0 kcal $\mathrm { m o l } ^ { - 1 }$ , constitutes the rate-determining step and is feasible under current reaction conditions. Although the ester moiety can also serve as a binding group to form INT20, the energy barrier for subsequent migratory insertion into allene 2a0 via TS20 is apparently higher than that of TS2 (25.8 vs. 22.0 kcal $\mathrm { m o l } ^ { - 1 }$ , red line), because of apparent steric hindrance between the ester group and the 1,3-indandione skeleton in $\bf { T } { \bf { S } } \boldsymbol { 2 } ^ { \prime } ,$ , as noted in Scheme 5c. In contrast, the attack of HOMO-raised $\operatorname { P d } ^ { 0 } { \cdot } \boldsymbol { \eta } ^ { 2 } .$ -complex INT6 on MBH carbonate 1b via TS4 features a signi<sup></sup>cantly higher energy barrier of 31.0 kcal $\mathrm { m o l } ^ { - 1 }$ (blue line), indicating it is dynamically infeasible at current reaction temperature. Consequently, the proposed oxidative addition/migratory insertion process is more favourable for the initial assembly of two partners. Moreover, as conjugated polyunsaturated systems are typically required for p-Lewis base catalysis,<sup>22b–d</sup> the successful engagement of styrene-type alkenes 6 in current $\left( 3 + 2 \right)$ annulations (Scheme 2e) provides additional and solid evidence in supporting an oxidative addition/migratory insertion mechanism.

The strong electron-withdrawing efect of both 1,3-indandione and the p-allylpalladium complex renders the b0-H of INT3 highly acidic, which can be easily deprotonated by the in situ generated t-butoxide anion to deliver the more stable intermediate INT4 with a signi<sup></sup>cant exotherm of 35.0 kcal $\mathrm { m o l } ^ { - 1 }$ . In addition, an outer-sphere allylic alkylation via TS3, with an energy barrier of only 5.2 kcal $\mathrm { m o l } ^ { - 1 }$ , can smoothly occur to provide product 3b0 aer ligand exchange.<sup>16</sup>

As outlined in Scheme 6a, racemic 2h was recovered when 2.0 equivalents of 2h were used, indicating that kinetic resolution of racemic allene 2h is not involved in this transformation. Instead, the dynamic kinetic transformation (DKT) of the pallylpalladium species IV appears to be operative.<sup>12</sup> Consequently, further calculations were conducted to elucidate the origin of enantioselectivity. Both INT4 and ent-INT4 would be generated via migratory insertion of INT2 into racemic 2a0 followed by deprotonation. As depicted in Scheme 6b, a comparative geometry analysis reveals that the distance between $\mathrm { H } ^ { 1 }$ and $\mathrm { H } ^ { 2 }$ in TS3 (2.15 Å) is longer than that between $\boldsymbol { \mathrm { \Pi } } ^ { \boldsymbol { \mathrm { H } } ^ { 3 } }$ and $\mathrm { H } ^ { 4 }$ in ent-TS3 (2.07 Å), indicating a greater 1,3-strain between the adjacent H atom and $\mathrm { C H } _ { 3 }$ moiety in ent-TS3. This steric repulsion leads to the free energy of ent-TS3 being 2.2 kcal $\mathrm { m o l } ^ { - 1 }$ higher than that of TS3, suggesting that ent-INT4 would undergo dynamic kinetic transformation (DKT) into INT4 via ${ \pi } \mathrm { - } \sigma \mathrm { - } \pi$ isomerisation, thus producing (R)-3b0 predominantly.<sup>23</sup> This theoretical prediction is in agreement with the experimental observations. The above DFT calculations identify migratory insertion as the rate-determining step, and intramolecular allylation as the enantioselectivity-determining step.

a) Two possible reaction pathways  
![](images/a019994a2a1aa7f7d08f6f3c825acd3f14b82d6b1c78d7a04e11099de9f42806.jpg)  
b) Free-energy profiles for the two competitive catalytic pathways

![](images/53477a45adf7fa9fdf1ea0d3a596498e1f9684985557653e932a9316cd9fc1f6.jpg)

c) Comparison of the free engery of migratory insertion via different coordination modes  
![](images/7c2cfcf4f6f481ccdcb7387e9b341443d72d60051e0ac96b86b726831630a2fe.jpg)  
Scheme 5 Mechanism studies on diferent activation pathways.

a) Dynamic kinetic transformation experiment

![](images/999b2d583fe6b902300dd031b0f946220498a979ca33125d1b25e5343ace4cde.jpg)  
b) Elucidation of the origin of enantioselectivity

![](images/e17ad7b3e3dbd6ff949ec2afa5cdc09f62b0f3098c77d8aa86254a9048fef9c5.jpg)  
Scheme 6 Elucidation of the enantioselectivity.

## Conclusions

In summary, with the assistance of experimental results and density functional theory calculations, we demonstrated that the functionalised p-allylpalladium complexes, generated by oxidative addition of $\mathrm { P d } ^ { 0 }$ to the Morita–Baylis–Hillman carbonates from activated ketones, could readily isomerise to their h<sup>1</sup>-form via ligation with the pendent carbonyl group, which enabled migratory insertion into diverse allenes and styrene-type alkenes. Subsequent vinylogous deprotonation and intramolecular allylic alkylation furnished (3 + 2) annulation products. This protocol featured substantial substrate scope and good functional group compatibility, delivering a diversity of spirocyclic frameworks with moderate to excellent regio-, chemo-, and stereoselectivity. As a result, a novel transformative paradigm for multifunctional MBH carbonates has been established via migratory insertion of the in situ formed non-zwitterionic p-allylpalladium species, rendering their unprecedented annulations with electron-neutral unsaturated systems—previously inaccessible under Lewis base catalysis. Further expansion studies of these Morita–Baylis–Hillman carbonates with other types of unsaturated systems are under investigation, and the results will be reported in due course.

## Author contributions

The manuscript was written through contributions ofall authors. All authors have given approval to the <sup></sup>nal version of the manuscript.

## Conflicts of interest

There are no con<sup></sup>icts to declare.

## Data availability

CCDC 2473163–2473167 (3q, 4e, 7a, 18 and the derivative of racemic 12b) contain the supplementary crystallographic data for this paper.<sup>24a–e</sup>

The data that support the <sup></sup>ndings of this study are available in the supplementary information (SI) or on request from the corresponding author. Supplementary information: experimental procedures, spectroscopic data for new compounds, NMR, HRMS spectra and HPLC chromatograms, and CIF <sup></sup>les of enantiopure products 3q, 4e, 7a, 18 and the derivative of racemic 12b. See DOI: https://doi.org/10.1039/d5sc06910f.

## Acknowledgements

This project was supported by the Sichuan Science and Technology Program (2025ZNSFSC0124). We thank Dr Meng Yang from College of Chemistry, Sichuan University, for X-ray difraction analysis, and Dr Wan-Shu Wang from West China School of Pharmacy, Sichuan University, for NMR analysis.

## Notes and references

1 For selected reviews, see: (a) B. M. Trost, Chem. Pharm. Bull., 2002, 50, 1–14; (b) S. Parisotto and A. Deagostino, Synthesis, 2019, 51, 1892–1912; (c) O. P\`amies, J. Margalef, S. Cañellas, J. James, E. Judge, P. J. Guiry, C. Moberg, J.-E. B¨ackvall, A. Pfaltz, M. A. Peric\`as and M. Di´eguez, Chem. Rev., 2021, 121, 4373–4505; (d) L. Mohammadkhani and M. M. Heravi, Chem. Rec., 2021, 21, 29–68; (e) B. Niu, Y. Wei and M. Shi, Org. Chem. Front., 2021, 8, 3475–3501; (f) B. Xu, Q. Wang, C. Fang, Z.-M. Zhang and J. Zhang, Chem. Soc. Rev., 2024, 53, 883–971.

2 For selected reviews, see: (a) N. A. Butt and W. Zhang, Chem. Soc. Rev., 2015, 44, 7929–7967; (b) J. Qian and G. Jiang, Curr. Catal., 2017, 6, 25–30; (c) Q.-Z. Li, Y. Liu, M.-Z. Li, X. Zhang, T. Qi and J.-L. Li, Org. Biomol. Chem., 2020, 18, 3638–3648; (d) Y. You, Q. Li, Y.-P. Zhang, J.-Q. Zhao, Z.-H. Wang and W.-C. Yuan, ChemCatChem, 2022, 14, e202101887.

3 For selected reviews, see: (a) S. E. Mann, L. Benhamou and T. D. Sheppard, Synthesis, 2015, 47, 3079–3117; (b) P. Wang and L. Gong, Acc. Chem. Res., 2020, 53, 2841–2854.

4 For selected reviews, see: (a) G. Li, X. Huo, X. Jiang and W. Zhang, Chem. Soc. Rev., 2020, 49, 2060–2118; (b) G. Cera and G. Maestri, ChemCatChem, 2022, 14, e202200295; (c) L. Li, S. Wang, A. Jakhar and Z. Shao, Green Synth. Catal., 2023, 4, 124–134.

5 For a selected review, see: (a) R. A. Fernandes and J. L. Nallasivam, Org. Biomol. Chem., 2019, 17, 8647–8672; for recent selected examples, see: ; (b) Z. Yang and J. J. Wang, Angew. Chem., Int. Ed., 2021, 60, 27288–27292; (c) Y. Jin, Y. Jing, C. Li, M. Li, W. Wu, Z. Ke and H. Jiang, Nat. Chem., 2022, 14, 1118–1125; (d) J. Liu, W.-B. Cao and S.-L. You, Chem, 2024, 10, 1295–1305; (e) S. H. M. Kaster, L. Zhu, W. L. Lyon, R. Ma, S. E. Ammann and M. C. White, Science, 2024, 385, 1067–1076.

6 For selected reviews and examples, see: (a) K. Spielmann, G. Niel, R. M. de Figueiredo and J. Campagne, Chem. Soc. Rev., 2018, 47, 1159–1173; (b) S.-F. Zhu, X.-C. Qiao, Y.-Z. Zhang, L.-X. Wang and Q.-L. Zhou, Chem. Sci., 2011, 2, 1135–1140; (c) T. Mita, Y. Higuchi and Y. Sato, Chem.– Eur. J., 2015, 21, 16391–16394; (d) Y. Li, P. Chen,

Z.-C. Chen, W. Du, Q. Ouyang and Y.-C. Chen, Org. Chem. Front., 2021, 8, 5418–5423.

7 For selected reviews, see: (a) Y. Ping, Y. Li, J. Zhu and W. Kong, Angew. Chem., Int. Ed., 2019, 58, 1562–1573; (b) R.-X. Liang and Y.-X. Jia, Acc. Chem. Res., 2022, 55, 734– 745; (c) G. Zhao, W. Li and J. Zhang, Chem.–Eur. J., 2024, 30, e202400076.

8 R. Hughes and J. Powell, J. Am. Chem. Soc., 1972, 94, 7723– 7732.

9 (a) B. M. Trost, Z. Huang and G. M. Murhade, Science, 2018, 362, 564–568; (b) B. M. Trost and Z. Huang, Angew. Chem., Int. Ed., 2019, 58, 6396–6399; (c) W. Chai, Q. Zhou, W. Ai, Y. Zheng, T. Qin, X. Xu and W. Zi, J. Am. Chem. Soc., 2021, 143, 3595–3603; (d) W. Zhang, P.-C. Zhang, Y.-L. Li, H.-H. Wu and J. Zhang, J. Am. Chem. Soc., 2022, 144, 19627–19634.

10 Y. Zou, S. Chen and K. N. Houk,J. Am. Chem. Soc., 2019, 141, 12382–12387.

11 (a) D. C. Witkowski, M. S. McVeigh, G. M. Scherer, S. M. Anthony and N. K. Garg, J. Am. Chem. Soc., 2023, 145, 10491–10496; (b) H. Xu and S. Ma, Angew. Chem., Int. Ed., 2023, 62, e202213676.

12 R.-J. Yan, Y. Hu, L. Zhu, J. Zhang, Q. Wang, J.-Y. Huang, Z.-C. Chen, Q. Ouyang, W. Du and Y.-C. Chen, ACS Catal., 2024, 14, 12824–12832.

13 For selected reviews, see: (a) P. Xie and Y. Huang, Org. Biomol. Chem., 2015, 13, 8578–8595; (b) Z.-C. Chen, Z. Chen, W. Du and Y.-C. Chen, Chem. Rec., 2020, 20, 541– 555; (c) A. Calcatelli, A. CherubiniCelli, E. Carletti and X. Companyo, Synthesis, 2020, 52, 2922–2939; (d) X.-H. Duan, H.-R. Du and Y.-X. Song, Org. Chem. Front., 2025, 12, 2076–2130.

14 Z.-L. He, P. Chen, Z.-C. Chen, W. Du and Y.-C. Chen, Org. Lett., 2022, 24, 100–104.

15 For selected reviews, see: (a) R. C. Fuson, Chem. Rev., 1935, 16, 1–27; (b) C. Curti, L. Battistini, A. Sartori and F. Zanardi, Chem. Rev., 2020, 120, 2448–2612.

16 For more details, see the SI.

17 (a) A. M. Trzeciak, Z. Ciunik and J. J. Zi´ołkowski, Organometallics, 2002, 21, 132–137; (b) J. Bajohr, A. G. Diallo, A. Whyte, S. Gaillard, J. Renaud and M. Lautens, Org. Lett., 2021, 23, 2797–2801.

18 (a) B. M. Trost and S. Schneider,J. Am. Chem. Soc., 1989, 111, 4430–4433; (b) B. M. Trost and H. Urabe, Tetrahedron Lett., 1990, 31, 615–618; (c) K. Ohe, H. Matsuda, T. Ishihara, S. Ogoshi, N. Chatani and S. Murai, J. Org. Chem., 1993, 58,

1173–1177; (d) I. Ikeda, A. Ohsuka, K. Tani, T. Hirao and H. Kurosawa, J. Org. Chem., 1996, 61, 4971–4974.

19 (a) K. Fagnou and M. Lautens, Angew. Chem., Int. Ed., 2002, 41, 26–47; (b) T. Cantat, N. Agenet, A. Jutand, R. Pleixats and M. Moreno-Manas, Eur. J. Org Chem., 2005, 4277–4286; (c) J. G. Knight, P. A. Stoker, K. Tchabanenko, S. J. Harwood and K. W. M. Lawrie, Tetrahedron, 2008, 64, 3744–3750; (d) M. A. Lowe, M. Ostovar, S. Ferrini, C. C. Chen, P. G. Lawrence, F. Fontana, A. A. Calabrese and V. K. Aggarwal, Angew. Chem., Int. Ed., 2011, 50, 6370– 6374; (e) C. B. E. Chao, Q. H. Pham, C. Richardson, S. G. Pyne and C. J. T. Hyland, J. Org. Chem., 2024, 89, 13744–13755.

20 For selected examples, see: (a) S. Tabuchi, K. Hirano and M. Miura, Angew. Chem., Int. Ed., 2016, 55, 6973–6977; (b) K. J. Schwarz, C. Yang, J. W. B. Fyfe and T. N. Snaddon, Angew. Chem., Int. Ed., 2018, 57, 12102–12105; (c) S. Sun, Q. Zhang and W. Zi, ACS Catal., 2023, 13, 12952–12959.

21 W. Guo, G. Lv, J. Chen, W. Gao, J. Ding and H. Wu, Tetrahedron, 2010, 66, 2297–2300.

22 (a) G. J. Kubas, J. Organomet. Chem., 2001, 635, 37–68; (b) B.-X. Xiao, B. Jiang, R.-J. Yan, J.-X. Zhu, K. Xie, X.-Y. Gao, Q. Ouyang, W. Du and Y.-C. Chen, J. Am. Chem. Soc., 2021, 143, 4809–4816; (c) Q. He, L. Zhu, Z.-H. Yang, B. Zhu, Q. Ouyang, W. Du and Y.-C. Chen, J. Am. Chem. Soc., 2021, 143, 17989–17994; for a perspective, see: ; (d) Z.-C. Chen, Q. Ouyang, W. Du and Y.-C. Chen, J. Am. Chem. Soc., 2024, 146, 6422–6437.

23 For selected reviews and examples, see: (a) J. Steinreiber, K. Faber and H. Griengl, Chem.–Eur. J., 2008, 14, 8060– 8072; (b) V. Bhat, E. R. Welin, X. Guo and B. M. Stoltz, Chem. Rev., 2017, 117, 4528–4561; (c) B. M. Trost, D. B. Horne and M. J. Woltering, Angew. Chem., Int. Ed., 2003, 42, 5987–5990; (d) B. M. Trost, M. R. Machacek and H. C. Tsui, J. Am. Chem. Soc., 2005, 127, 7014–7024; (e) J. Zhang, X. Huo, J. Xiao, L. Zhao, S. Ma and W. Zhang, J. Am. Chem. Soc., 2021, 143, 12622–12632.

24 (a) CCDC 2473163: Experimental Crystal Structure Determination, 2025, DOI: 10.5517/ccdc.csd.cc2p0jgq; (b) CCDC 2476164: Experimental Crystal Structure Determination, 2025, DOI: 10.5517/ccdc.csd.cc2p3n8r; (c) CCDC 2476165: Experimental Crystal Structure Determination, 2025, DOI: 10.5517/ccdc.csd.cc2p3n9s; (d) CCDC 2476166: Experimental Crystal Structure Determination, 2025, DOI: 10.5517/ccdc.csd.cc2p3nbt; (e) CCDC 2476167: Experimental Crystal Structure Determination, 2025, DOI: 10.5517/ccdc.csd.cc2p3ncv.