pubs.acs.org/OrgLett

Letter

# Enantioselective and Regiodivergent Skeletal Transformations of 1,2,3-Thiadiazoles to Alkylidene Dihydrothiophenes

Cunzhi Chen, Youwei Chen, Hongguang Du, Jiaxi Xu, and Zhanhui Yang\*

![](images/d215f33ab8a162a3ed04b6f53094a0e1494b2e25b67883097dcc4d23d0af3fd9.jpg)  
ABSTRACT: By leveraging the Rh-catalyzed asymmetric skeletal editing of 1,2,3-thiadiazoles, we successfully achieve the ligandcontrolled enantioselective and regiodivergent synthesis of structurally diverse 2- and 3-alkylidene 2,3-dihydrothiophenes. Late-stage structural editing of complex natural and drug molecules is also enabled.

many medicinally relevant molecules.<sup>1</sup> They are found in 128 US FDA-approved drugs, 18 best-sold drugs by retail sales,<sup>2</sup> and many other bioactive molecules. However, very little attention has been paid to alkylidene dihydrothiophenes (type I, type II, and type III), which possess 3-dimensional-structures and one stereocenter (Scheme 1A). These structural properties cater to the well-recognized concept�escape from flatland, making them promising scafolds in drug development campaigns. The enantioselective synthesis of these molecules nonetheless is highly challenging. The limited synthetic routes mainly relied on the dearomative functionaliztion of parent thiophene rings (Scheme 1B).<sup>4−6</sup> In 2021, Sun and Houk reported the chiral phosphoric acid (CPA)-catalyzed enantioselective dearomative functionalization of thiophenes by means of 1,10-conjugate addition, giving type I structures.<sup>5</sup> In 2022, Buchwald and Liu disclosed the enantioselective synthesis of type II products via CuH-catalyzed dearomative addition of 3- vinylthiophenes to ketones.<sup>6</sup> Despite these state-of-the-art advances, new synthetic methods based on diferent synthetic logics are still in demand.

We envisage a skeletal editing strategy<sup>7</sup> for enantioselective   
and regiodivergent construction of alkylidene-2,3-dihydrothio  
phenes, by diatomic swap from N−N atoms of1,2,3-thiadiazoles   
to two C−C atoms of allenes (Scheme 1C).<sup>8</sup> Although Lee’s,<sup>10</sup> and our<sup>11</sup> groups established the   
prototypes of this skeletal editing with alkynes,<sup>9</sup> alkenes,<sup>10a,d</sup>   
nitriles,<sup>10b,c</sup> aryl thiocyana-tes<sup>11</sup>�the reactions therein were   
termed as denitrogenative (3 + 2) transannulations�the   
asymmetric catalytic versions are very scarce, and the only two

reports come from our group.<sup>12</sup> Challenges exist in our synthetic proposal: (1) The highly unsaturated products are susceptible to further aromatization to give nonchiral thiophenes, as demonstrated by our previous work.<sup>13</sup> (2) It is dificult to simultaneously maintain the regiocontrol of the type II and type III products, enantiocontrol of new stereocenters, and the Z- or E-geometric control of exocyclic C�C bonds of both products in excellent levels. Herein, by adoption of a ligand-controlled tactic (Scheme 1D), the above challenges are well addressed. Our work provides a novel synthetic access to enantiopure 3- dimensional alkylidene-2,3-dihydrothiophenes, which might be used as a potential pharmacore in future drug development campaigns.

We first optimized the chiral ligands and other reaction parameters, revealing two sets of optimal conditions (see Tables S1 and S2 in Supporting Information): with (4R, 5R)-DIOP enantiopure 2-alkylidene-2,3-dihydrothiophenes are exclusively furnished (Conditions A), while with (R)-Cy-BINAP the regioreversed 3-alkylidene-2,3-dihydrothiophenes were enantioselectively synthesized (Conditions B). We suggest that the steric hindrance ofthe ligands controls the regioselectivity. A plausible mechanism is proposed (see Scheme S1 in Supporting

![](images/9edf97e3dfd2a050b32aab797bd868b187a78fdb6484d1c4c6f2ede579027746.jpg)

Scheme 1. Background and Our Strategy for Synthesis of Alkylidene Dihydrothiophenes  
![](images/4f32164704c174744ff3beb8533fab8a2fa8897e8ae5360cd6021ee9931f4acf.jpg)

Information),<sup>14−16</sup> and theoretical investigations on the origins of regio- and enantiocontrol are underway.

We first evaluated the synthesis of enantiopure type III products 3 (Figure 1A). The reactions showed a broad substrate scope and functional group tolerance. The skeletal editing of 5- aryl-substituted 1,2,3-thiadiazole-4-carboxylates (1a−1o) proceeded smoothly, regardless of the functionalities on the aryl rings, furnishing 3aA−3oA in 57−95% yields and 96−99% ee. The other regioisomers were formed in such a small amount that they could not be isolated. Well tolerated functional groups include halogens (3fA−3iA, 3jA), cyano (3lA), nitro (3kA), and fur-2-yl (3mA), and thiophen-2-yl (3nA). Aromatization occurred for 3eA, accounting for the low yield (32%). However, shortening the reaction time to 80 min significantly improved the yield to 92% (96% ee). In addition, 5-methyl, 5-chloro, and 5-bromo thiadiazoles were also demonstrated as viable substrates, converting to desired products in 90−94% ee (3pA−3rA). The absolute configuration of 3rA was unambiguously assigned by single-crystal X-ray difraction (CCDC: 2404905). The ester group on the 4-position can also be diversified. For example, the reaction of 3-bromopropyl 1,2,3- thiadiazole-4-carboxylate delivered 3sA in 93% yield and 86% ee, with the labile C(sp<sup>3</sup>)−Br bond remaining untouched. Replacement of the ester group with secondary amide slightly lowered the yields, whereas improved the enantioselectivity to 99% ee, as demonstrated by the enantioselective formation of 3tA−3zA.

A number of allenes were also assessed under Conditions A. Diversifying the ester group ((±)-2H−2O) or replacing the methyl of (±)-2A with substituted phenyls ((±)-2B−2F) and propyl ((±)-2G) did not afect the regio- or enantioselectivities. Desired products were obtained in 44−99% yields and 90−97% ee. In addition, a sulfonyl allene was also amenable, giving 3bO in 90% yield with 90% ee.

By changing (4R,5R)-DIOP to (R)-Cy-BINAP (Conditions B), we accomplished the regio-reversed synthesis of type II products (Figure 1B). Desired products 4aA−4dA, 4gA, 4hA, and 4jA−4lA were produced in 50−76% yields and 92−99% ee, with regioselective ratios varying from 3:1 to 17:1. Apparently, the regioselectivity is quite sensitive to the electronic properties of the aromatic substituents. The reactions of four additional allenes (4bH, 4aB, 4aD, 4aE) gave excellent enantiocontrol (>99% ee) and almost unchanged regioselectivity (4.5:1 or 4:1 rr). The other regioisomers can be separated by column chromatography. For instance, 3aA was isolated in 8% yield (96% ee). Notably, the substrate scope under Conditions B is a bit limited (see Scheme S2 in the Supporting Information). For example, 5-methyl or 5-bromo-1,2,3-thiadiazoles failed to undergo the skeletal editing and remained intact.

The scalability was demonstrated by the 1 mmol scale reaction, in which 3aA was obtained in 89% yield and 96% ee (Scheme 2A). Oxidation of 3aA with excess m-CPBA or reduction with NaBH −CoCl led to sulfone 5 or transdihydrothiphene 6 in good yields without erosion of the enantiopurity (Scheme 2B). It deserves mention that the exocyclic C�C bond is more susceptible to reduction than the endocyclic one. Deuterium-labeled allene 2E-d aforded deuterium-incorporated product 3aE-d in 90% yield and 95% ee (Scheme 2C). The deuterium of the starting material was almost all retained in the product.

Our protocol can be applied to the late-stage diversification of natural and pharmaceutically relevant molecules (Scheme 2D). Five 1,2,3-thiadiazoles derived from D-galactopyranose (7a), cholesterol (7b), stigmasterol (7c), diosgenin (7d), and pregnenolone (7e) were transformed eficiently, giving 8aA− 8eA in 56−85% yields and 95.5:4.5−98:2 dr. These highly diastereo- and enantiopure structures may arguably serve as potential lead compounds in drug discovery. Dehydroabietylamine and oleylamine were also late-stage modified, giving 8fA in 57% yield, 99:1 dr and 8gA in 60% yield, 99% ee, respectively. On the other hand, the regio-reversed skeletal transformation can also be applied in the structural modification of natural products, as exemplified by the synthesis of9aA and 9bA from Dgalactopyranose and cholesterol. These reactions in the presence of complex structures further expand the functionality tolerance.

![](images/d64d4c1f70ba44fd5288f7a92a0c19613d6dc3156c2478f995e05d57fed96ac7.jpg)  
Figure 1. Substrate Scope. <sup>a</sup>The reaction time was shortened to 80 min. <sup>b</sup>All of the rr values are determined by <sup>1</sup>H NMR of the crude reaction mixtures.

The bromine and iodine atoms of 3rA and 3iA allow for Suzuki coupling reactions, producing thiophenes 10 and 11 in

Scheme 2. Synthetic Applications and Control Experiments<sup>a</sup>  
![](images/05ad607d9b8fd857bae34cbf44ef1bf29eab04e0a1f8c07bd1cfdbae6689d8be.jpg)  
<sup>a</sup>The dr values are determined by HPLC.

68% and 77% yields, respectively (Scheme 2E). Aromatization took place, probably due to basic conditions.

In conclusion, we have developed a strategically novel rhodium-catalyzed and ligand-controlled regiodivergent and enantioselective synthetic route to alkylidene-2,3-dihydrothiophenes through diatomic skeletal editing of 1,2,3-thiadiazoles with allenoates. Both types of products are synthesized in up to 99% yield and up to 99% ee. Late-stage structural modifications of complex natural and drug molecules are performed, rendering chiral and 3-dimensional chemical spaces with higher levels of molecular complexity. It is anticipated that our synthetic routes to these underexplored enantiopure 3-dimensional alkylidene-2,3-dihydrothiophenes will ofer compelling opportunities and provide novel lead compounds for future drug discoveries and developments.

## ■ ASSOCIATED CONTENT

## Data Availability Statement

The data underlying this study are available in the published article, in its Supporting Information, and openly available in Dryad at 10.5061/dryad.sxksn03dz.

## \*sı Supporting Information

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acs.orglett.5c01067.

Results on reaction condition optimizations, plausible mechanism, experimental procedures, X-raycrystallographic data for 3rA and 9aA, additional Figures S1− S4, Schemes S1−S12, Tables S1, S2, <sup>1</sup>H and <sup>13</sup>C NMR and HPLC spectroscopic data and spectra, additional references (PDF)

## Accession Codes

Deposition Numbers 2404905 and 2411572 contain the supplementary crystallographic data for this paper. These data can be obtained free of charge via the joint Cambridge Crystallographic Data Centre (CCDC) and Fachinformationszentrum Karlsruhe Access Structures service.

## ■ AUTHOR INFORMATION

## Corresponding Author

Zhanhui Yang − College of Chemistry, Beijing University of Chemical Technology, Beijing 100029, P. R. China; orcid.org/0000-0001-7050-8780; Email: zhyang@ mail.buct.edu.cn

## Authors

Cunzhi Chen − College of Chemistry, Beijing University of Chemical Technology, Beijing 100029, P. R. China

Youwei Chen − College of Chemistry, Beijing University of Chemical Technology, Beijing 100029, P. R. China

Hongguang Du − College of Chemistry, Beijing University of Chemical Technology, Beijing 100029, P. R. China; orcid.org/0000-0003-3237-4261

Jiaxi Xu − College of Chemistry, Beijing University of Chemical Technology, Beijing 100029, P. R. China; orcid.org/0000- 0002-9039-4933

Complete contact information is available at: https://pubs.acs.org/10.1021/acs.orglett.5c01067

## Notes

The authors declare no competing financial interest.

## ■ ACKNOWLEDGMENTS

We thank the National Natural Science Foundation of China (No. 22371011) for financial support.

## ■ REFERENCES

(1) Scott, K. A.; Njardarson, J. T. Analysis of US FDA-Approved Drugs Containing Sulfur Atoms. Top. Curr. Chem. 2018, 376, 5.

(2) (a) McGrath, N. A.; Brichacek, M.; Njardarson, J. T. A Graphical Journey of Innovative Organic Architectures That Have Improved Our Lives. J. Chem. Educ. 2010, 87, 1348−1349. (b) https://sites.arizona. edu/njardarson-lab/top200-posters/

(3) (a) Lovering, F. Escape from Flatland 2: complexity and promiscuity. Med. Chem. Comm. 2013, 4, 515−519. (b) Lovering, F.; Bikker, J.; Humblet, C. Escape from Flatland: Increasing Saturation as an Approach to Improving Clinical Success. J. Med. Chem. 2009, 52, 6752−6756. (c) Ishikawa, M.; Hashimoto, Y. Improvement in Aqueous Solubility in Small Molecule Drug Discovery Programs by Disruption of Molecular Planarity and Symmetry. J. Med. Chem. 2011, 54, 1539− 1554.

(4) Ding, C.-H.; Dong, J.-L.; Yu, L.-S.-H.; Xie, J.-W. Organocatalytic Domino Michael/cyclization for the synthesis ofhighly substituted 4, 5- dihydrothiophenes. Chin. Chem. Lett. 2018, 29, 517−520.

(5) Li, X.; Duan, M.; Yu, P.; Houk, K. N.; Sun, J. Organocatalytic enantioselective dearomatization of thiophenes by 1,10-conjugate addition of indole imine methides. Nat. Commun. 2021, 12, 4881.

(6) Dong, Y.; Schuppe, A. W.; Mai, B. K.; Liu, P.; Buchwald, S. L. Confronting the Challenging Asymmetric Carbonyl 1,2-Addition Using Vinyl Heteroarene Pronucleophiles: Ligand-Controlled Regiodivergent Processes through a Dearomatized Allyl−Cu Species. J. Am. Chem. Soc. 2022, 144, 5985−5995.

(7) For skeletal editing through diatomic swaps: (a) Shi, W.-x.; Lv, J.- y.; Xiao, W.-j.; Xie, H.-d.; Li, J.-j.; Jiang, Y.-l.; Su, X.-c.; Xue, J.-y.; Li, C.- x.; Zou, Y.; Yan, M.; Zhang, X.-j. Pyrimidines to Pyridines: Two Atom

Swap Skeletal Editing. CCS Chem. 2025, 0, 1−7. (b) Cheng, Q.; Bhattacharya, D.; Haring, M.; Cao, H.; Mück-Lichtenfeld, C.; Studer, A. Skeletal editing of pyridines through atom-pair swap from CN to CC. Nat. Chem. 2024, 16, 741−748. (c) Pradhan, S.; Mohammadi, F.; Bouffard, J. Skeletal transformation of unactivated arenes enabled by a low-temperature dearomative (3 + 2) cycloaddition. J. Am. Chem. Soc. 2023, 145, 12214−12223. (d) Morofuji, T.; Nagai, S.; Watanabe, A.; Inagawa, K.; Kano, N. Streptocyanine as an activation mode of amine catalysis for the conversion of pyridine rings to benzene rings. Chem. Sci. 2023, 14, 485−490. (e) Cabrera-Pardo, J. R.; Chai, D. I.; Kozmin, S. A. Silver-Promoted Benzannulations of Siloxyalkynes with Pyridinium and Isoquinolinium Salts. Adv. Synth. Catal. 2013, 355, 2495−2498. (f) Cabrera-Pardo, J. R.; Chai, D. I.; Liu, S.; Mrksich, M.; Kozmin, S. A. Label-assisted mass spectrometry for the acceleration of reaction discovery and optimization. Nat. Chem. 2013, 5, 423−427.

(8) For recent reviews, see: (a) Tokareva, M. A.; Glukhareva, T. V.; Keaveney, S. T. Recent Advances in the Denitrogenative Annulation Reactions of 1,2,3-Thiadiazoles. ChemCatChem. 2024, 16, No. e202301488. (b) Shafran, Y.; Glukhareva, T.; Dehaen, W.; Bakulev, V. Chapter Three - Recent Developments in the Chemistry of 1,2,3-Thiadiazoles. Adv. Heterocycl. Chem. 2018, 126, 109−172. (c) Lee, P. H. Denitrogenative Transannulation of Thiadiazoles. In Denitrogenative Transformation of Nitrogen Heterocycles; Anbarasan, P., Ed.; 2025. DOI: 10.1002/9783527844852.ch14. (d) Bakulev, V. A.; Beryozkina, T. V.; Dehaen, W. 1,2,3-Thiadiazoles. Compr. Heterocycl. Chem. IV 2022, 5, 318−347.

(9) Kurandina, D.; Gevorgyan, V. Rhodium Thiavinyl Carbenes from 1,2,3-Thiadiazoles Enable Modular Synthesis of Multisubstituted Thiophenes. Org. Lett. 2016, 18, 1804−1807.

(10) (a) Son, J.-Y.; Kim, J.; Han, S. H.; Kim, S. H.; Lee, P. H. Regioselective Synthesis ofDihydrothiophenes and Thiophenes via the Rhodium-Catalyzed Transannulation of 1,2,3-Thiadiazoles with Alkenes. Org. Lett. 2016, 18, 5408−5411. (b) Seo, B.; Kim, Y. G.; Lee, P. H. Synthesis of Isothiazole via the Rhodium-Catalyzed Transannulation of 1,2,3-Thiadiazoles with Nitriles. Org. Lett. 2016, 18, 5050−5053. (c) Seo, B.; Kim, H.; Kim, Y. G.; Baek, Y.; Um, K.; Lee, P. H. Synthesis of Bicyclic Isothiazoles through an Intramolecular Rhodium-Catalyzed Transannulation of Cyanothiadiazoles. J. Org. Chem. 2017, 82, 10574−10582. (d) Kim, J. E.; Lee, J.; Yun, H.; Baek, Y.; Lee, P. H. Rhodium-Catalyzed Intramolecular Transannulation Reaction of Alkynyl Thiadiazole Enabled 5, n-Fused Thiophenes. J. Org. Chem. 2017, 82, 1437−1447.

(11) Dong, Z.; Ma, M.-Y.; Xu, J.; Yang, Z. Catalytic (3 + 2) umpolung annulations of α-thioacyl carbenes with aryl isothiocyanates. Chem. Commun. 2022, 58, 7980−7983.

(12) (a) Chen, C.; Fang, S.; Dong, Z.; Xu, J.; Yang, Z. Catalytic Diastereospecific and Enantioselective (3 + 2) Transannulations of 1,2,3-Thiadiazoles with Strained Norbornene Derivatives. Org. Lett. 2022, 24, 2110−2114. (b) Chen, C.; Lv, K.; Chen, Y.; Du, H.; Xu, J.; Liu, T.; Yang, Z. Catalytic Enantioselective (3 + 2) Annulations of Nucleophilic Thioacyl Rh(I)-Carbenes with Achmatowicz Rearrangement Products. ACS Catal. 2024, 14, 8949−8957.

(13) Chen, C.; Fang, S.; Yu, M.; Xu, J.; Yang, Z. Catalytic site-specific and regioselective (3 + 2) transannulations between 1,2,3-thiadiazoles and allenoates. Org. Chem. Front. 2023, 10, 661−667.

(14) (a) Tokareva, M. A.; Pernik, I.; Lewis, W.; Messerle, B. A.; Glukhareva, T. V.; Keaveney, S. T. Rh(I)-Catalyzed Denitrogenative Transformations of 1,2,3-Thiadiazoles: Ligand-Controlled Product Selectivity and the Structure of the Key Organorhodium Intermediate Revealed. ACS Catal. 2022, 12, 5574−5584. (b) Tokareva, M. A.; Pernik, I.; Messerle, B. A.; Glukhareva, T. V.; Keaveney, S. T. The effect of the C5-substituent on regioselectivity in the Rh(i)-catalyzed intermolecular transannulation of 1,2,3-thiadiazoles with phenylacetylene. Catal. Sci. Technol. 2023, 13, 2772−2782. (c) Reza, T.; Tokareva, M. A.; Dobson, N. K.; Shanahan, A. L.; Sheather, K.; Richardson, C.; Keaveney, S. T. Regioselectivity for the Rh(I)-catalyzed Annulation of 1,2,3-Thiadiazoles with Alkynes: Experimental and Computational Analysis Reveal the Surprising Role of the Alkyne Substituent. ChemCatChem. 2023, 15, No. e202301117.

(15) Lv, K.; Bao, X. Mechanistic insights into the Rh(i)-catalyzed transannulation of 1,2,3-thiadiazoles with alkenes, alkynes, and nitriles: Does the intermediacy of α-thiavinyl Rh-carbenoids play an important role? Org. Chem. Front. 2021, 8, 310−318.

(16) (a) Zhou, B.; Wu, Q.; Dong, Z.; Xu, J.; Yang, Z. Rhodium-Catalyzed 1,1-Hydroacylation of Thioacyl Carbenes with Alkynyl Aldehydes and Subsequent Cyclization. Org. Lett. 2019, 21, 3594− 3599. (b) Wu, Q.; Dong, Z.; Xu, J.; Yang, Z. Sulfur-controlled and rhodium-catalyzed formal (3 + 3) transannulation of thioacyl carbenes with alk-2-enals and mechanistic insights. Org. Biomol. Chem. 2021, 19, 3173−3180. (c) Dong, Z.; Chen, C.; Wang, J.; Xu, J.; Yang, Z. Dual roles of bisphosphines and epoxides: Rh-catalyzed highly chemoselective and diastereoselective (3 + 2) transannulations of 1,2,3- thiadiazoles with cyanoepoxides. Org. Chem. Front. 2021, 8, 6687− 6698. (d) Wei, H.; Chen, C.; Gao, A.; Yang, Z. Rh(I)-catalyzed enantioselective (3 + 2) transannulations of 1,2,3-thiadiazoles with Pchiral monodentate phosphines. Phosphorus, Sulfur, Silicon Relat. Elem. 2024, 199, 157−161.