pubs.acs.org/OrgLett

Letter

# Z‑Selective Iron-Catalyzed C−H Alkylations with Allenes: Access to Stereodefined Olefins

Silvia Cattani, Filippo Cordovani, Davide Balestri, Joaõ C. A. Oliveira, Sven Erik Peters, Lutz Ackermann,\* and Gianpiero Cera\*

![](images/80a6427ef3ee5b79a258bff91ecd27ce0c26763aa5b2a56893b020efc03d90a4.jpg)

Cite This: Org. Lett. 2025, 27, 7950−7955

![](images/463711c3146162092d15c8e63d274c6033cce1a7a7d4497c25a44b4e5832ca16.jpg)

Read Online

ACCESS

Metrics & More

Article Recommendations

\*sı Supporting Information

![](images/fb45968bde99e65df82a39de02bb51cb35b18e06c20aec6d7512c6e227e196e1.jpg)  
ABSTRACT: We report an unprecedented iron-catalyzed C−H alkylation of widespread benzamides using readily available allenes. The method, based on cheap, nontoxic, and earth abundant iron catalysts, exploits the assistance of removable triazole directing groups to yield a wide array of Z internal olefins, even at room temperature, with excellent stereocontrol, good yields, and broad functional group tolerance.  
Scheme 1. Z-Selective C−H Alkylations with Unsaturated Hydrocarbons

O <sup>lefins</sup> <sup>represent</sup> <sup>one</sup> <sup>of</sup> <sup>the</sup> <sup>most</sup> <sup>important</sup> <sup>scafolds</sup> <sup>in</sup> organic chemistry due to their use in the flavor and fragrance industries, material sciences, and naturally occurring molecules with important biological applications.<sup>1</sup> One of the primary challenges associated with their synthesis is the control of the stereochemical configuration (E or Z), which often influences their inherent chemical and physical properties.<sup>2</sup> While synthesis routes for E-olefins are well established, accessing Z-olefins remains a challenging goal.<sup>3</sup> In the last years, transition-metal-catalyzed C−H activations have emerged as a powerful platform for step- and atom-economical molecular transformations.<sup>4</sup> In this context, value-added olefins can be synthesized by means of C−H activations using unsaturated hydrocarbons as reaction patterns.<sup>5</sup> Despite these advances, C−H activation methods to access Z-olefins continue to be scarce and are limited to the functionalization of heterocyclic indole substrates. Cobalt catalysts have been exploited for C−H/C−C activations of vinylcyclopropanes for the synthesis of Z-olefins (Scheme 1a, I).<sup>6</sup> Further, rhodiumor manganese-catalyzed C−H allylations with tailoreddesigned allenes were recently reported as an efective approach for producing alkenes with high Z-selectivities (Scheme 1a, II).<sup>7</sup> In this scenario, approaches to Z-olefins by chelation-assisted C−H activation of ubiquitous benzamides remain unexplored. Among transition metal catalysts, iron represents the most attractive in terms of its earth abundance, cost eficiency, and low toxicity,<sup>8</sup> and it has recently witnessed significant momentum toward eficient C−H activations.<sup>9</sup>

a) Z-selective, metal-catalyzed C—H alkylations with unsaturated hydrocarbons

![](images/39ddcf16a3c5bd82ee1e3cfe069383a2d68ee1582ea0201a951bd8a889ab1f3f.jpg)  
b) This work: Z-selective, iron-catalyzed C—H alkylations with allenes

![](images/2ccc8b09bfa34d537df0d10931c2be8022d88ee49fb22befdb0249a9fd014537.jpg)

![](images/ae169201e1795beed5ece5ec1f701ceff9279e59845fad9ba948bc082d5117ab.jpg)

Intrigued by our recent findings on iron-catalyzed C−H activations by triazole assistance,<sup>10</sup> we wondered whether readily available allenes<sup>11</sup> could be employed to access Zstereoisomers through the geometrical restrictions ofered by the triazole chelation<sup>12</sup> (Scheme 1, b). We commenced our studies by probing triazolyl (TAH)-derived<sup>10j</sup> benzamide 1a in various reaction conditions using monosubstituted allene 2a. Noteworthily, iron catalysis enabled the envisioned C−H alkylation, leading to the synthesis of 3aa with exclusive Zselectivity (Table 1).

Table 1. Variation of Reaction Conditions<sup>a</sup>
<table><tr><td colspan="2"></td><td><img src="images/58313766ec848d018861626fcb940bf36f9a8ce452013c51c9c647341cfae9b9.jpg"/></td><td></td></tr><tr><td colspan="2"></td><td></td><td>3aa [%]b</td></tr><tr><td>Entryª 1</td><td colspan="3">Variation of reaction conditions 80 (77)</td></tr><tr><td>2</td><td colspan="3">none FeCl2 instead of Fe(acac)₃ 72</td></tr><tr><td>3</td><td colspan="3">CoCl2 or Ni(acac)₂ or Pd(OAc)₂ instead of Fe(acac)₃ --</td></tr><tr><td>4</td><td colspan="3">2,2&#x27;-bipy instead of dppe 一</td></tr><tr><td>5</td><td colspan="3">dppen instead of dppe 63 (58)</td></tr><tr><td>6</td><td colspan="3">dppbz instead of dppe 11</td></tr><tr><td>7</td><td colspan="3">TMSCH2MgBr instead of PhMgBr --</td></tr><tr><td>8</td><td colspan="3">i-PrMgBr instead of PhMgBr 20</td></tr><tr><td>9</td><td colspan="3">ZnCl2TMEDA --</td></tr><tr><td>10</td><td colspan="3">No ZnCl2</td></tr><tr><td>11</td><td colspan="3">25 ℃ (70)</td></tr></table>

<sup>a</sup>Reaction conditions: 1a (0.2 mmol), 2a (0.4 mmol), [Fe] (0.03 mmol), ligand (0.03 mmol), RMgBr (0.6 mmol), ZnX (0.4 mmol), THF (0.2 mL). <sup>b</sup>Yields determined using 1,3,5-trimethoxybenzene as the internal standard. In parentheses, isolated yields. dppe = 1,2- bis(diphenylphosphino)ethane; dppbz = 1,2-bis(diphenylphosphino)- benzene; dppen = cis-1,2-bis(diphenylphosphino)ethene.

The optimal reaction conditions devised for the Z-selective C−H alkylation required a bidentate diphosphine ligand such as dppe, ZnCl (2.0 equiv), and PhMgBr (3.0 equiv) as the base. Other iron precatalysts such as FeCl were found to be suitable for the reaction (entry 2), while broadly employed transition metals such as cobalt, nickel, or palladium did not provide any transformation under otherwise identical reaction conditions (entry 3). This outcome reflected the unique nature of the iron catalytic regime. Among the ligands tested, 2,2′- bipyridine (entry 4) failed to promote the C−H alkylation, while the backbone of the diphosphine ligands significantly influenced the outcome. In fact, the use of more rigid scafolds such as dppen and dppbz led to product 3aa in lower yields (entries 5, 6). The use of alkyl magnesium reagents was detrimental to the catalysis, in contrast to previously reported iron-catalyzed C−H annulations (entries 7, 8).<sup>10,10d,e,h</sup> Zinc salts were crucial, as well. Hence, when ZnCl was employed as a TMEDA adduct, a transformation was not observed (entry 9). Likewise, its absence was detrimental to the iron-catalyzed C−H alkylation with allenes, likely due to less efective transmetalation (entry 10).<sup>13</sup> The catalytic transformation was also efective under exceedingly mild conditions at 25 °C. In this latter case, the desired product 3aa was isolated in good yields of 70% (entry 11). It is important to note that the use of the most popular 8-AQ directing group was not possible for this type of transformation.<sup>14</sup> Despite numerous eforts (see Supporting Information for more details), we were not able to isolate any C−H alkylation products here. Under the optimized catalytic conditions, we next probed the versatility of the Z-selective, iron-catalyzed C−H alkylation protocol in the presence of benzamide derivatives (Scheme 2). Diferently

![](images/56e3ad913d4cda2f4d1e49622250448db12add7b5d1cda6e241773cf63e0fa60.jpg)

substituted methylene-tethered triazoles 1b−d were all applicable, although they delivered the corresponding products 3ba−da in only moderate yields. Various arenes, functionalized with both electron-rich and electron-withdrawing groups at the para and meta positions, were all generally well-applicable. Also, challenging nitrile and boronate<sup>15</sup> derivatives were well tolerated under the catalytic conditions (3oa−pa). Finally, heterocyclic derivatives were selectively converted into desired products 3ua−wa.

Subsequently, a set of diversely decorated allenes 2 was utilized for iron-catalyzed C−H alkylations (Scheme 3). Alkyland aryl-substituted allenes 2 were thus eficiently converted into the corresponding products 3ab−ad. Allenes attached to (thio)ethers and carbazole moieties were also well-tolerated (3ae−ag). A silyl-allenyl ether directly yielded the corresponding unprotected alcohol 3ah upon acidic workup of the catalytic reaction. The iron catalysis displayed a remarkable functional group tolerance since compounds 3ai−ak, functionalized with alkyl chlorides and esters, were all produced in good yields. Prompted by these findings, we probed the ironcatalyzed method in the presence of monosubstituted allenes decorated with complex synthetic scafolds. For instance, Lmenthol- and cholesterol-functionalized benzamides 3al,am were delivered in synthetically useful yields as well as Dmannose diacetonide derivative 3an. Furthermore, the applicability of the C−H alkylation method was demonstrated in the presence of pyrene and calix[4]arenes (3ao,ap).<sup>16</sup> The reactivity of 1,1-disubstituted allenes was further tested. A dialkyl derivatives such as 2q was reacted under standard conditions, leading to product 3aq in high yields. The outstanding Z-selectivity was retained for asymmetrical disubstituted allenes. Particularly, when allenes 2r−t were submitted to iron catalysis, the corresponding products 3ar−at were formed with complete to high stereoselectivity, in very good yields.

![](images/1c6e08f1029ab02ac15d68bf50c73d364c1d0e5edcbe3ffe9bce32d90d1c4c8a.jpg)

To gain insights into the origin of the experimentally observed Z-selectivity, DFT calculations were carried out for the migratory insertion elementary step at the PW6B95-D4/ def2-TZVP+SMD(THF)//TPSS-D3(BJ)/def2-SVP level of theory (Figure 1) (see SI for more details). Given the electronic nature of the iron(II) complexes, high-spin (quintet), low-spin (singlet), and an intermediate triplet state were taken into consideration for both Z- and E-selective pathways. For the latter two scenarios, a spin-crossover is at play, from a triplet (I-1) to a singlet surface upon allene coordination (I-2). In the latter, the Z-pathway (I-2Z) was shown to be energetically favorable over the E-pathway (I-2E) by 5.9 kcal mol<sup>−1</sup>. Such an accentuated stabilization is associated with less steric hindrance upon allene coordination.

![](images/1c2f381bc9bce714801deb41b5ad8b0fc9d857479127e7b0d20cdb579d72c7df.jpg)  
Figure 1. Computed relative Gibbs free energies (ΔG) in kcal mol<sup>−1</sup> for the allene coordination-induced migratory insertion to access both Z- and E-selectivity pathways (top and bottom, respectively) at the PW6B95-D4/def2-TZVP+SMD(THF)//TPSS-D3(BJ)/def2-SVP level of theory.

Afterward, coordination-induced migratory insertion proceeds through transition state TS(2−3), where the Z-pathway (TS(2−3)Z) was calculated to be favored over the E-pathway (TS(2−3)E) by an overall barrier of 1.1 kcal mol<sup>−1</sup>. Such results provide strong support for the experimentally obtained Z-selectivity.

Based on several experimental evidence (see SI for more a catalytic cycle initiated by a facile C−H activation that proceeds via a ligand-to-ligand hydrogen transfer (LLHT)<sup>18</sup> leading to B, as depicted in Scheme 4. Subsequently, a stereodetermining, coordination-induced migratory insertion of the allene occurs, forming the key cyclometalated species C. The origin of the high stereoselectivity toward the formation of the Z-alkenes could be attributed to repulsive steric interactions in the migratory allene insertion. Finally, protodemetalation delivers product 3aa, regenerating the active iron species A (Scheme 4). The observed high levels of chemoselectivity toward proto-demetalation over annulation are likely due to the nature of the allene substitution pattern, contrasting with our previous findings on annulations. In the latter the leaving groups on the allene were shown to aid the C−N forming reductive elimination from intermediate C<sup>10a,e</sup>

Scheme 4. Plausible Reaction Mechanism  
![](images/d7f6e8bc8e081b2ed140f5a52603be98bf3ab5b72a597a0c14556f63f29a20e9.jpg)

The synthetic utility of the iron-catalyzed C−H alkylation protocol was finally demonstrated through several orthogonal diversifications of the triazole directing group. As in the example, compound 3ra was transformed into the corresponding carboxylic acid 4ra by a first protection of the secondary amide as a tert-butyloxycarbamate and subsequent basic hydrolysis (Scheme 5, a). Noteworthily, 4ra retained the Z-

## Scheme 5. Removal of TAH and Late-Stage Modifications

![](images/b7d9bebb500a5f48592f855aebd0e45701f256bce45b8c8dd092f27ef93009fb.jpg)

geometry of the olefinic fragment. The functionalization of 3aa as a carbamate was further exploited to directly convert the amide into the corresponding ketone 5aa by simple reaction with PhMgBr (Scheme 5, b).<sup>19</sup> Finally, the use of m-CPBA enabled an unprecedented oxidative deprotection strategy for 3ab, leading to the synthetically versatile 3,4-dihydrocoumarin derivative 6ab (Scheme 5, c).<sup>20</sup>

In conclusion, we reported on a strategy for the stereoselective synthesis of internal Z-olefins by means of ironcatalyzed C−H alkylations with allenes. The iron catalysis exploited the features of bioisosteric triazoles to deliver a family of benzamides with ample scope and functional group tolerance, even in the presence of challenging boronate esters or nitriles. The triazole could be removed in a traceless fashion, leading to biorelevant compounds.

## ■ ASSOCIATED CONTENT

## Data Availability Statement

The data underlying this study are available in the published article and its Supporting Information.

## \*sı Supporting Information

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acs.orglett.5c02274.

General remarks and materials, mechanistic studies, Xray crystallography, and copies of NMR spectra (PDF)

## Accession Codes

Deposition Numbers 2427040−2427042 contain the supplementary crystallographic data for this paper. These data can be obtained free of charge via the joint Cambridge Crystallographic Data Centre (CCDC) and Fachinformationszentrum Karlsruhe Access Structures service.

## ■ AUTHOR INFORMATION

## Corresponding Authors

Lutz Ackermann − Wöhler Research Institute for Sustainable Chemistry, Georg-August-Universität Göttingen, 37077 Göttingen, Germany; DZHK (German Centre for Cardiovascular Research), 10875 Berlin, Germany; orcid.org/0000-0001-7034-8772;

Gianpiero Cera − Dipartimento di Scienze Chimiche, della Vita e della Sostenibilità Ambientale, Università di Parma, I-43124 Parma, Italy; orcid.org/0000-0002-2702-282X; Email: gianpiero.cera@unipr.it

## Authors

Silvia Cattani − Dipartimento di Scienze Chimiche, della Vita e della Sostenibilità Ambientale, Università di Parma, I-43124 Parma, Italy

Filippo Cordovani − Dipartimento di Scienze Chimiche, della Vita e della Sostenibilità Ambientale, Università di Parma, I-43124 Parma, Italy

Davide Balestri − Dipartimento di Scienze Chimiche, della Vita e della Sostenibilità Ambientale, Università di Parma, I-43124 Parma, Italy

João C. A. Oliveira − Wöhler Research Institute for Sustainable Chemistry, Georg-August-Universität Göttingen, 37077 Göttingen, Germany; DZHK (German Centre for Cardiovascular Research), 10875 Berlin, Germany

Sven Erik Peters − Wöhler Research Institute for Sustainable Chemistry, Georg-August-Universität Göttingen, 37077 Göttingen, Germany

Complete contact information is available at: https://pubs.acs.org/10.1021/acs.orglett.5c02274

## Notes

The authors declare no competing financial interest.

## ■ ACKNOWLEDGMENTS

The authors thank Centro Interdipartimentale di Misure of the University of Parma for the NMR measurement. This research was supported by National Programs (PON “Ricerca e Innovazione” 2014−2020 Azione IV.4 and Azione IV.5), by the Italian MIUR (PRIN 20227Z3BL8), and by the University of Parma (FIL−Bando di Ateneo per la Ricerca 2022, Azione B). The support by the DZHK (German Centre for Cardiovascular Research) (L.A.), the ERC Advanced Grant (101021358, L.A.), the DFG (SPP2363 L.A.) and the FCI (Kekulé-Fellowship no. 114311 S.E.P.) is gratefully acknowledged.

## ■ REFERENCES

(1) Williams, J. M. J. Preparation of Alkenes: A Practical Approach; Oxford University Press: Oxford, U.K., 1996.

(2) (a) Oger, C.; Balas, L.; Durand, T. Are alkyne reductions chemo-, regio-, and stereoselective enough to provide pure (Z)-olefins in polyfunctionalized bioactive molecules? Chem. Rev. 2013, 113, 1313−1350. (b) Dugave, C.; Demange, L. Cis-Trans Isomerization of Organic Molecules and Biomolecules: Implications and Applications. Chem. Rev. 2003, 103, 2475−2532.

(3) For selected, recent examples, see: (a) Chen, J.-J.; Guan, M.-H.; He, P.; Huang, M.-Y.; Zhang, X.-Y.; Zhu, S.-F. Iron-catalysed alkenylzincation of allenes via electrophilicity reversal. Nat. Catal. 2025, 8, 178−186. (b) Liu, Q.; Qin, C.; Wan, J.; Mai, B. K.; Sui, X. Z.; Kobayashi, H.; Zahedian, H.; Liu, P.; Hoveyda, A. H. Synthesis of Zgem-Cl,CF -Substituted Alkenes by Stereoselective Cross-Metathesis and the Role of Disubstituted Mo Alkylidenes. J. Am. Chem. Soc. 2024, 146, 22485. (c) Guo, F.-K.; Lu, Y.-L.; Huang, M.-Y.; Yang, J.-M.; Guo, J.-L.; Wan, Z.-Y.; Zhu, S.-F. Wittig/B−H insertion reaction: A unique access to trisubstituted Z-alkenes. Sci. Adv. 2023, 9, No. eadj2486. (d) Ge, L.; Sinnema, E. G.; Pérez, J. M.; Postolache, R.; Reis, M. C.; Harutyunyan, S. R. Enantio- and Z-selective synthesis of functionalized alkenes bearing tertiary allylic stereogenic center. Sci. Adv. 2023, 9, No. eadf8742. (e) Lee, M. T.; Goodstein, M. B.; Lalic, G. Synthesis of Isomerically Pure (Z)-Alkenes from Terminal Alkynes and Terminal Alkenes: Silver-Catalyzed Hydroalkylation of Alkynes. J. Am. Chem. Soc. 2019, 141, 17086−17091. (f) Cheung, C. W.; Zhurkin, F. E.; Hu, X. Z-Selective Olefin Synthesis via Iron-Catalyzed Reductive Coupling of Alkyl Halides with Terminal Arylalkynes. J. Am. Chem. Soc. 2015, 137, 4932−4935. (g) Meek, S.; O’Brien, R.; Llaveria, J.; Schrock, R. R.; Hoveyda, A. H. Catalytic Z-selective olefin cross-metathesis for natural product synthesis. Nature 2011, 471, 461−466. For a recent review on photocatalytic methods, see: (h) Nevesely,́ T.; Wienhold, M.; Molloy, J. J.; Gilmour, R. Advances in the E → Z Isomerization of Alkenes Using Small Molecule Photocatalysts. Chem. Rev. 2022, 122, 2650−2694.

(4) For selected reviews, see: (a) de Jesus, R.; Hiersinger, K.; van Gemmeren, M. Preparative Scale Applications of C−H Activation in Medicinal Chemistry. Angew. Chem., Int. Ed. 2023, 62, No. e202306659. (b) Rogge, T.; Kaplaneris, N.; Chatani, N.; Kim, J.; Chang, S.; Punji, B.; Schafer, L. L.; Musaev, D. G.; Wencel-Delord, J.; Roberts, C. A.; Sarpong, R.; Wilson, Z. E.; Brimble, M. A.; Johansson, M. J.; Ackermann, L. C−H Activation. Nature Rev. Methods Primer 2021, 1, 43. (c) Dalton, T.; Faber, T.; Glorius, F. C− H Activation: Toward Sustainability and Applications. ACS Cent. Sci. 2021, 7, 245−261. (d) Gandeepan, P.; Müller, T.; Zell, D.; Cera, G.; Warratz, S.; Ackermann, L. 3d Transition Metals for C−H Activation. Chem. Rev. 2019, 119, 2192−2452.

(5) (a) Deng, S.-M.; Zhao, Y.-X.; Wang, C. When transition-metalcatalyzed C−H activation meets allene chemistry. Tetrahedron Chem. 2023, 8, No. 100049. (b) Banjare, S. K.; Mahulkar, P. S.; Nanda, T.; Pati, B. V.; Najiar, L. O.; Ravikumar, P. C. Diverse reactivity of alkynes in C−H activation reactions. Chem. Commun. 2022, 58, 10262−10289. (c) Dutta, S.; Bhattacharya, T.; Werz, D. B.; Maiti, D. Transition-metal-catalyzed C−H allylation reactions. Chem. 2021, 7, 555−605. (d) Ali, W.; Prakash, G.; Maiti, D. Recent development in transition metal-catalysed C−H olefination. Chem. Sci. 2021, 12, 2735−2759.

(6) (a) Meyer, T. H.; Liu, W.; Feldt, M.; Wuttke, A.; Mata, R. A.; Ackermann, L. Manganese(I)-Catalyzed Dispersion-Enabled C−H/ C−C Activation. Chem.�Eur. J. 2017, 23, 5443−5447. (b) Zell, D.;

Bu, Q.; Feldt, M.; Ackermann, L. Mild C-H/C-C Activation by Z-Selective Cobalt Catalysis. Angew. Chem., Int. Ed. 2016, 55, 7408− 7412.

(7) (a) Ma, C.; Li, C.; Bai, J.; Xiao, J.; Zhai, Y.; Guo, Y.; Ma, S. Rhodium-Catalyzed Intermolecular Stereoselective Allylation of Indoles with Allenes. ACS Catal. 2022, 12, 10141−10146. (b) Kumar, D. V.; Sundararaju, B. Manganese-Catalyzed Z-Selective Allylation of Indoles with Allenyl Derivatives. J. Org. Chem. 2024, 89, 10087−10092.

(8) For comprehensive reviews on iron catalysis, see: (a) Li, L.-J.; He, Y.; Yang, Y.; Guo, J.; Lu, Z.; Wang, C.; Zhu, S.; Zhu, S.-F. Recent Advances in Mn, Fe, Co, and Ni-Catalyzed Organic Reactions. CCS Chem. 2024, 6, 537−584. (b) Rana, S.; Biswas, J. P.; Paul, S.; Paika, A.; Maiti, D. Organic synthesis with the most abundant transition metal−iron: from rust to multitasking catalysts. Chem. Soc. Rev. 2021, 50, 243−472. (c) Bolm, C.; Legros, J.; Le Paih, J.; Zani, L. Ironcatalyzed reactions in organic synthesis. Chem. Rev. 2004, 104, 6217− 6254.

(9) For representative reviews, see: (a) Mo, J.; Messinis, A. M.; Li, J.; Warratz, S.; Ackermann, L. Chelation-Assisted Iron-Catalyzed C−H Activations: Scope and Mechanism. Acc. Chem. Res. 2024, 57, 10−22. (b) Cattani, S.; Cera, G. Modern Organometallic C−H Functionalizations with Earth-Abundant Iron Catalysts: An Update. Chem.� Asian J. 2024, 19, No. e202300897. (c) Lanzi, M.; Cera, G. Iron-Catalyzed C−H Functionalizations under Triazole-Assistance. Molecules 2020, 25, 1806. (d) Shang, R.; Ilies, L.; Nakamura, E. Iron-Catalyzed C−H Bond Activation. Chem. Rev. 2017, 117, 9086−9139. (e) Ackermann, L.; Vicente, R. Ruthenium-Catalyzed Direct Arylations through C−H Bond Cleavages. Top. Curr. Chem. 2009, 292, 211−229.

(10) For select examples, see: (a) Cattani, S.; Pandit, N. K.; Buccio, M.; Balestri, D.; Ackermann, L.; Cera, G. Iron-Catalyzed C−H Alkylation/Ring Opening with Vinylbenzofurans Enabled by Triazoles. Angew. Chem., Int. Ed. 2024, 63, No. e202404319. (b) Cattani, S.; Secchi, A.; Ackermann, L.; Cera, G. Triazole-enabled, iron-catalysed linear/branched selective C−H alkylations with alkenes. Org. Biomol. Chem. 2023, 21, 1264−1269. (c) Mo, J.; Messinis, A. M.; Oliveira, J. C. A.; Demeshko, S.; Meyer, F.; Ackermann, L. Iron-Catalyzed Triazole-Enabled C−H Activation with Bicyclopropylidenes. ACS Catal. 2021, 11, 1053−1064. (d) Mo, J.; Müller, T.; Oliveira, J. C. A.; Demeshko, S.; Meyer, F.; Ackermann, L. Iron-Catalyzed C−H Activation with Propargyl Acetates: Mechanistic Insights on Iron(II) by Experiment, Kinetics, Mössbauer Spectroscopy and Computation. Angew. Chem., Int. Ed. 2019, 58, 12874−12878. (e) Mo, J.; Müller, T.; Oliveira, J. C. A.; Ackermann, L. 1,4-Iron Migration for Expedient Allene Annulations through Iron-Catalyzed C−H/N−H/C−O/C−H Functionalizations. Angew. Chem., Int. Ed. 2018, 57, 7719−7723. (f) Shen, Z.; Cera, G.; Haven, T.; Ackermann, L. Tri-Substituted Triazole-Enabled C−H Activation of Benzyl and Aryl Amines by Iron-Catalysis. Org. Lett. 2017, 19, 3795−3798. (g) Cera, G.; Haven, T.; Ackermann, L. Iron-Catalyzed C−H Alkynylation through Triazole Assistance: Expedient Access to Bioactive Heterocycles. Chem.�Eur. J. 2017, 23, 3577−3582. (h) Cera, G.; Haven, T.; Ackermann, L. Iron-catalyzed C−H/N−H activation by triazole guidance: versatile alkyne annulation. Chem. Commun. 2017, 53, 6460−6463. (i) Cera, G.; Haven, T.; Ackermann, L. Expedient Iron-Catalyzed C−H Allylation/Alkylation by Triazole Assistance with Ample Scope. Angew. Chem., Int. Ed. 2016, 55, 1484− 1488. (j) Gu, Q.; Mamari, H. H. Al; Graczyk, K.; Diers, E.; Ackermann, L. Iron-Catalyzed C(sp2)−H and C(sp3)−H Arylation by Triazole Assistance. Angew. Chem., Int. Ed. 2014, 53, 3868−3871.

(11) For selected examples of C−H activation with allenes, see: [Fe] (a) Messinis, A. M.; Oliveira, J. C. A.; Stückl, C.; Ackermann, L. Cyclometallated Iron(II) Alkoxides in Iron-Catalyzed C−H Activations by Weak O-Carbonyl Chelation. ACS Catal. 2022, 12 (9), 4947−4960. (b) Messinis, A. M.; Finger, L. H.; Hu, L.; Ackermann, L. Allenes for Versatile Iron-Catalyzed C−H Activation by Weak O-Coordination: Mechanistic Insights by Kinetics, Intermediate Isolation, and Computation. J. Am. Chem. Soc. 2020, 142, 13102−

(o) Wang, H.; Beiring, B.; Yu, D.-G.; Collins, K. D.; Glorius, F. [3]Dendralene Synthesis: Rhodium(III)-Catalyzed Alkenyl C−H Activation and Coupling Reaction with Allenyl Carbinol Carbonate. Angew. Chem., Int. Ed. 2013, 52, 12430−12434. (p) Wang, H.; Glorius, F. Mild Rhodium(III)-Catalyzed C−H Activation and Intermolecular Annulation with Allenes. Angew. Chem., Int. Ed. 2012, 51, 7318−7322. (q) Tran, D. N.; Cramer, N. syn-Selective Rhodium(I)-Catalyzed Allylations of Ketimines Proceeding through a Directed C−H Activation/Allene Addition Sequence. Angew. Chem., Int. Ed. 2010, 49, 8181−8184. For recent reviews, see: (r) Deng, S.- M.; Zhao, Y.-X.; Wang, C. When transition-metal-catalyzed C−H activation meets allene chemistry. Tetrahedron Chem. 2023, 8, No. 100049. (s) Dutta, S.; Bhattacharya, T.; Werz, D. B.; Maiti, D. Transition-metal-catalyzed C−H allylation reactions. Chem. 2021, 7, 555−605.

(12) (a) Ye, X.; He, Z.; Ahmed, T.; Weise, K.; Akhmedov, N. G.; Petersen, J. L.; Shi, X. 1,2,3-Triazoles as versatile directing group for selective sp<sup>2</sup> and sp<sup>3</sup> C−H activation: cyclization vs substitution. Chem. Sci. 2013, 4, 3712−3716. (b) Jeyachandran, R.; Potukuchi, H. K.; Ackermann, L. Copper-Catalyzed CuAAC/Intramolecular C-H Arylation Sequence: Synthesis of Annulated 1,2,3-Triazoles. Beilstein J. Org. Chem. 2012, 8, 1771−1777.

(13) (a) Sun, Y.; Tang, H.; Chen, K.; Hu, L.; Yao, J.; Shaik, S.; Chen, H. Two-State Reactivity in Low-Valent Iron-Mediated C−H Activation and the Implications for Other First-Row Transition Metals. J. Am. Chem. Soc. 2016, 138, 3715−3730. (b) Norinder, J.; Matsumoto, A.; Yoshikai, N.; Nakamura, E. Iron-Catalyzed Direct Arylation through Directed C−H Bond Activation. J. Am. Chem. Soc. 2008, 130, 5858−5859.

(14) For recent examples of iron-catalyzed C-H activations with 8- AQ as directing group, see: (a) Doba, T.; Matsubara, T.; Ilies, L.; Shang, R.; Nakamura, E. Homocoupling-free iron-catalysed twofold C−H activation/cross-couplings of aromatics via transient connection of reactants. Nat. Catal. 2019, 2, 400−406. (b) Ilies, L.; Zhou, Y.; Yang, H.; Matsubara, T.; Shang, R.; Nakamura, E. Iron-Catalyzed Directed Alkylation of Carboxamides with Olefins via a Carbometalation Pathway. ACS Catal. 2018, 8, 11478−11482.

(15) (a) Beletskaya, I. P.; Alonso, F.; Tyurin, V. The Suzuki-Miyaura reaction after the Nobel prize. Coord. Chem. Rev. 2019, 385, 137−173.

(b) Hall, D. Boronic Acids: Preparation and Applications; Wiley-VCH: Weinheim, Germany, 2011.

(16) Gutsche, C. D. Calixarenes: An Introduction; Royal Society of Chemistry, Cambridge, U.K., 2nd ed., 2008.

(17) Boddie, T. E.; Carpenter, S. H.; Baker, T. M.; DeMuth, J. C.; Cera, G.; Brennessel, W. W.; Ackermann, L.; Neidig, M. L. Identification and Reactivity of Cyclometalated Iron(II) Intermediates in Triazole-Directed Iron-Catalyzed C−H Activation. J. Am. Chem. Soc. 2019, 141, 12338−12345.

(18) (a) Loup, J.; Zell, D.; Oliveira, J. C. A.; Keil, H.; Stalke, D.; Ackermann, L. Asymmetric Iron-Catalyzed C−H Alkylation Enabled by Remote Ligand meta-Substitution. Angew. Chem., Int. Ed. 2017, 56, 14197−14201. (b) Zell, D.; Bursch, M.; Müller, V.; Grimme, S.; Ackermann, L. Switch of C-H Activation Mechanism for Full Selectivity Control in Cobalt(III)-Catalyzed C−H Alkylations. Angew. Chem., Int. Ed. 2017, 56, 10378−10382. (c) Guihaumé, J.; Halbert, S.; Eisenstein, O.; Perutz, R. N. Hydrofluoroarylation of alkynes with Ni catalysts. C−H activation via ligand-to-ligand hydrogen transfer, an alternative to oxidative addition. Organometallics 2012, 31, 1300−1314.

(19) Sureshbabu, P.; Azeez, S.; Muniyappan, N.; Sabiah, S.; Kandasamy, J. Chemoselective Synthesis of Aryl Ketones from Amides and Grignard Reagents via C(O)−N Bond Cleavage under Catalyst-Free Conditions. J. Org. Chem. 2019, 84, 11823−11838.

(20) Superchi, S.; Minutolo, F.; Pini, D.; Salvadori, P. Asymmetric Synthesis of the Dihydroisocoumarin Moiety of AI-77-B via Copper-Mediated Cross-Coupling and Sharpless Asymmetric Dihydroxyla tion. J. Org. Chem. 1996, 61, 3183−318.